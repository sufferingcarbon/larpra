#!/usr/bin/env python3
"""
Independent ground truth for the Matrix / Linear Equations module.

Nothing here shares code with the TypeScript solver. For every case it uses from-scratch Fraction
arithmetic (written here, not imported from anywhere) plus NumPy as a float cross-check to compute:

  1. Ax = b: the solution kind (unique / none / many) and, for a unique solution, the exact values,
     via a from-scratch Fraction Gauss-Jordan;
  2. determinant, via a from-scratch exact Fraction cofactor expansion, cross-checked against
     numpy.linalg.det;
  3. rank, via the from-scratch Fraction row reduction;
  4. inverse, via the from-scratch Fraction Gauss-Jordan on [A | I], verified by A * A^-1 = I exactly;
  5. eigenvalues, via numpy.linalg.eigvals (float/complex), used as a numeric cross-check for the
     exact rational eigenvalues the TS solver reports.

It writes src/algorithms/matrix/__tests__/fixtures/groundTruth.ts, which the vitest suite compares the
solver against: the built-in examples (asserted to equal the app's examples.ts, so the two can't drift)
plus seeded random matrices in several families.

Usage (from the repo root):   python3 tools/matrix_ground_truth.py
Requires: numpy.
"""
import json
import random
import warnings
from fractions import Fraction
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "src/algorithms/matrix/__tests__/fixtures/groundTruth.ts"
SEED = 20260925

warnings.filterwarnings("ignore")


# ---------------------------------------------------------------- exact Fraction linear algebra (from scratch)


def frac_matrix(M):
    return [[Fraction(x) for x in row] for row in M]


def frac_rref(M, pivot_limit=None):
    """Returns (rref, pivot_cols) for a Fraction matrix M (rows are lists), via textbook Gauss-Jordan.
    pivot_limit restricts pivoting to columns [0, pivot_limit) — needed when M is augmented (e.g. [A | I]
    or [A | b]) so the identity/RHS block on the right is never mistaken for a new pivot column."""
    M = [row[:] for row in M]
    m = len(M)
    n = len(M[0]) if m else 0
    limit = n if pivot_limit is None else pivot_limit
    pivot_cols = []
    r = 0
    for c in range(limit):
        p = next((i for i in range(r, m) if M[i][c] != 0), None)
        if p is None:
            continue
        M[r], M[p] = M[p], M[r]
        pv = M[r][c]
        M[r] = [x / pv for x in M[r]]
        for i in range(m):
            if i != r and M[i][c] != 0:
                f = M[i][c]
                M[i] = [a - f * b for a, b in zip(M[i], M[r])]
        pivot_cols.append(c)
        r += 1
        if r == m:
            break
    return M, pivot_cols


def frac_det(M):
    n = len(M)
    if n == 1:
        return M[0][0]
    if n == 2:
        return M[0][0] * M[1][1] - M[0][1] * M[1][0]
    total = Fraction(0)
    for j in range(n):
        if M[0][j] == 0:
            continue
        minor = [row[:j] + row[j + 1 :] for row in M[1:]]
        cof = frac_det(minor)
        total += (M[0][j] * cof) if j % 2 == 0 else -(M[0][j] * cof)
    return total


def frac_inverse(M):
    n = len(M)
    aug = [M[i] + [Fraction(1) if i == j else Fraction(0) for j in range(n)] for i in range(n)]
    rref, pivots = frac_rref(aug, pivot_limit=n)
    if len(pivots) < n:
        return None
    return [row[n:] for row in rref]


def solve_system(A, b):
    """Returns ('unique', x) | ('none', None) | ('many', (particular, basis))."""
    m = len(A)
    n = len(A[0])
    aug = [A[i] + [b[i]] for i in range(m)]
    rref, pivots = frac_rref(aug, pivot_limit=n)
    # inconsistency: a row with all zeros in the coefficient part but non-zero after the bar
    for row in rref:
        if all(x == 0 for x in row[:n]) and row[n] != 0:
            return ("none", None)
    free = [c for c in range(n) if c not in pivots]
    particular = [Fraction(0)] * n
    for k, c in enumerate(pivots):
        # row k has its pivot in column c
        particular[c] = rref[k][n]
    if not free:
        return ("unique", particular)
    basis = []
    for f in free:
        v = [Fraction(0)] * n
        v[f] = Fraction(1)
        for k, c in enumerate(pivots):
            v[c] = -rref[k][f]
        basis.append(v)
    return ("many", (particular, basis))


def rank_of(A):
    _, pivots = frac_rref([row[:] for row in A])
    return len(pivots)


# ---------------------------------------------------------------- cases


def to_jsonable_frac(x: Fraction):
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


CASES = []


def add_case(label, family, matrix, rhs=None):
    CASES.append({"label": label, "family": family, "matrix": matrix, "rhs": rhs})


# the built-in examples (kept in sync with examples.ts; the TS test asserts equality)
BUILTIN = [
    ("2×2 system, unique solution", [[2, 1], [1, -1]], [5, 1]),
    ("2×2 system, no solution", [[1, 2], [2, 4]], [3, 5]),
    ("2×2 system, infinitely many solutions", [[1, -2], [-2, 4]], [3, -6]),
    ("3×3 system, unique solution", [[0, 2, 1], [1, 1, 1], [2, 1, -1]], [4, 6, 1]),
    ("3×3 system, no solution", [[1, 1, 1], [2, -1, 3], [3, 0, 4]], [6, 2, 7]),
    ("3×3 system, infinitely many solutions", [[1, 1, 1], [2, -1, 3], [3, 0, 4]], [6, 2, 8]),
]
for label, M, b in BUILTIN:
    add_case(label, "builtin-system", M, b)

BUILTIN_MATRIX_ONLY = [
    ("Determinant of a 2×2 matrix", [[4, 3], [6, 3]]),
    ("Determinant of a 3×3 matrix", [[2, -1, 3], [0, 4, 5], [1, 2, -2]]),
    ("Determinant of a singular matrix", [[1, 2, 3], [0, 1, 4], [1, 3, 7]]),
    ("Determinant of a 4×4 matrix", [[1, 2, 0, 3], [4, 0, 1, 2], [0, 1, 2, 1], [2, 3, 1, 0]]),
    ("Inverse of a 2×2 matrix", [[4, 7], [2, 6]]),
    ("Inverse of a 3×3 matrix", [[2, 0, 1], [1, 3, 2], [0, 1, 1]]),
    ("Attempted inverse of a singular matrix", [[1, 2, 3], [0, 1, 1], [2, 3, 5]]),
    ("Rank and nullspace of a rank-deficient matrix", [[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]]),
    ("Rank of a full-rank rectangular matrix", [[1, 0], [0, 1], [2, 3]]),
    ("Eigenvalues of a symmetric 2×2 matrix", [[2, 1], [1, 2]]),
    ("Eigenvalues of a 2×2 rotation matrix (complex)", [[0, -1], [1, 0]]),
    ("Eigenvalues of a defective 2×2 matrix", [[1, 1], [0, 1]]),
    ("Eigenvalues of a 3×3 matrix", [[2, 0, 0], [0, 0, -1], [0, 1, 0]]),
    ("Eigenvalues of a symmetric 3×3 matrix", [[2, 1, 1], [1, 2, 1], [1, 1, 2]]),
]
for label, M in BUILTIN_MATRIX_ONLY:
    add_case(label, "builtin-matrix", M)

# seeded random square + rectangular matrices, small integer entries
rng = random.Random(SEED)
for k in range(30):
    n = rng.choice([2, 2, 3, 3, 4])
    M = [[rng.randint(-6, 6) for _ in range(n)] for _ in range(n)]
    add_case(f"random square {k}", "random-square", M)
for k in range(20):
    m = rng.randint(2, 5)
    n = rng.randint(2, 5)
    M = [[rng.randint(-6, 6) for _ in range(n)] for _ in range(m)]
    b = [rng.randint(-6, 6) for _ in range(m)]
    add_case(f"random system {k}", "random-system", M, b)
for k in range(20):
    n = rng.choice([2, 2, 3])
    M = [[rng.randint(-4, 4) for _ in range(n)] for _ in range(n)]
    add_case(f"random eigen {k}", "random-eigen", M)

# ---------------------------------------------------------------- compute ground truth for every case

results = []
for case in CASES:
    M = case["matrix"]
    Mf = frac_matrix(M)
    m, n = len(M), len(M[0])
    square = m == n

    entry = {
        "label": case["label"],
        "family": case["family"],
        "matrix": M,
        "rhs": case["rhs"],
        "rank": rank_of(Mf),
    }

    if case["rhs"] is not None:
        bf = [Fraction(x) for x in case["rhs"]]
        kind, data = solve_system(Mf, bf)
        entry["solutionKind"] = kind
        entry["solutionX"] = [to_jsonable_frac(x) for x in data] if kind == "unique" else None

    if square:
        det_exact = frac_det(Mf)
        entry["determinant"] = to_jsonable_frac(det_exact)
        if n <= 6:
            np_det = float(np.linalg.det(np.array(M, dtype=float)))
            assert abs(np_det - float(det_exact)) < 1e-6 + 1e-6 * abs(np_det), (case["label"], np_det, float(det_exact))

        inv = frac_inverse(Mf)
        entry["singular"] = inv is None
        entry["inverse"] = [[to_jsonable_frac(x) for x in row] for row in inv] if inv is not None else None
        if inv is not None:
            prod = [[sum(Mf[i][k] * inv[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
            for i in range(n):
                for j in range(n):
                    assert prod[i][j] == (1 if i == j else 0)

        if n <= 4:
            eig = np.linalg.eigvals(np.array(M, dtype=float))
            eig_sorted = sorted(((round(float(e.real), 6), round(float(e.imag), 6)) for e in eig), key=lambda t: (-t[0], -t[1]))
            entry["eigenvaluesNumeric"] = eig_sorted

    results.append(entry)

OUT.parent.mkdir(parents=True, exist_ok=True)
header = (
    "// GENERATED by tools/matrix_ground_truth.py — do not edit by hand.\n"
    "// Independent ground truth: from-scratch exact-Fraction Gauss-Jordan/cofactor expansion in Python, cross-checked\n"
    "// against numpy.linalg.det/eigvals for the float-sensitive parts.\n"
    "export interface GTCase {\n"
    "  label: string;\n"
    "  family: string;\n"
    "  matrix: number[][];\n"
    "  rhs: number[] | null;\n"
    "  rank: number;\n"
    "  solutionKind?: 'unique' | 'none' | 'many';\n"
    "  solutionX?: string[] | null;\n"
    "  determinant?: string;\n"
    "  singular?: boolean;\n"
    "  inverse?: string[][] | null;\n"
    "  eigenvaluesNumeric?: [number, number][];\n"
    "}\n\n"
    "export const GT_CASES: GTCase[] = "
)
text = header + json.dumps(results, indent=1) + ";\n"
OUT.write_text(text)
print(f"Wrote {len(results)} cases to {OUT}")
