#!/usr/bin/env python3
"""
Independent ground truth for the Integer Programming (Branch & Bound) module.

Nothing here shares code with the TypeScript solver. For every problem it:

  1. solves it with scipy.optimize.milp (HiGHS' branch-and-cut),
  2. classifies the LP relaxation with scipy.optimize.linprog. When the relaxation is unbounded, milp alone
     cannot always tell "unbounded" from "infeasible", so the truth is decided by the rational-data theorem:
     unbounded relaxation + an integer-feasible point (milp with objective 0) => unbounded; no point => infeasible,
  3. cross-checks the answer by exhaustive enumeration where the integer box is finite and small:
       * pure integer/binary problems: every integer point is tested in exact Fraction arithmetic (no floats),
       * mixed problems: every integer point is enumerated and the continuous part solved with linprog,
  4. asserts that all of the above agree (the script aborts on any disagreement).

It then writes src/algorithms/integer/__tests__/fixtures/groundTruth.ts, which the vitest suite compares the solver
against: the built-in examples (read from the same examples.data.json the app uses) plus ~250 seeded random problems in
nine families (knapsacks, set covers, mixed-integer, equalities, mixed-sign rows, unbounded, contradictory, decimals).

Usage (from the repo root):   python3 tools/ip_ground_truth.py
Requires: numpy, scipy >= 1.9.
"""
import itertools
import json
import math
import random
from fractions import Fraction
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import Bounds, LinearConstraint, linprog, milp

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = ROOT / "src/algorithms/integer/examples.data.json"
OUT = ROOT / "src/algorithms/integer/__tests__/fixtures/groundTruth.ts"
SEED = 20260921
TOL = 1e-6
BRUTE_EXACT_LIMIT = 60_000
BRUTE_MIXED_LIMIT = 1_500


def F(x):
    """Exact value of a UI-style decimal (the TypeScript side reads decimals exactly, too)."""
    return Fraction(str(x))


def types_of(p):
    return p.get("varTypes") or ["integer"] * len(p["variables"])


# ----------------------------------------------------------------------------
# scipy
# ----------------------------------------------------------------------------
def rows_of(p):
    n = len(p["variables"])
    A = np.array([c["coeffs"] for c in p["constraints"]], dtype=float).reshape(len(p["constraints"]), n)
    lo = np.array([c["rhs"] if c["relation"] in (">=", "=") else -np.inf for c in p["constraints"]], dtype=float)
    hi = np.array([c["rhs"] if c["relation"] in ("<=", "=") else np.inf for c in p["constraints"]], dtype=float)
    return A, lo, hi


def upper_bounds(p):
    return np.array([1.0 if t == "binary" else np.inf for t in types_of(p)])


def run_milp(p, zero_objective=False):
    sign = -1.0 if p["sense"] == "max" else 1.0
    c = np.array(p["objective"], dtype=float) * (0.0 if zero_objective else sign)
    A, lo, hi = rows_of(p)
    cons = [LinearConstraint(A, lo, hi)] if len(A) else []
    integrality = np.array([0 if t == "continuous" else 1 for t in types_of(p)])
    bounds = Bounds(np.zeros(len(c)), upper_bounds(p))
    res = milp(c, constraints=cons, integrality=integrality, bounds=bounds)
    if res.status not in (0, 2, 3):
        # HiGHS presolve occasionally mis-reduces a small equality-only MIP to "optimal" with an
        # infeasible point (status 4, "Solve error"); presolve=False sidesteps that bug.
        res = milp(c, constraints=cons, integrality=integrality, bounds=bounds, options={"presolve": False})
    return res.status, (sign * res.fun if res.status == 0 else None)


def relaxation_status(p):
    sign = -1.0 if p["sense"] == "max" else 1.0
    c = np.array(p["objective"], dtype=float) * sign
    A_ub, b_ub, A_eq, b_eq = [], [], [], []
    for row in p["constraints"]:
        a, r, b = row["coeffs"], row["relation"], row["rhs"]
        if r == "<=":
            A_ub.append(a), b_ub.append(b)
        elif r == ">=":
            A_ub.append([-x for x in a]), b_ub.append(-b)
        else:
            A_eq.append(a), b_eq.append(b)
    ub = upper_bounds(p)
    bounds = [(0, None if math.isinf(u) else u) for u in ub]
    res = linprog(c, A_ub=A_ub or None, b_ub=b_ub or None, A_eq=A_eq or None, b_eq=b_eq or None, bounds=bounds, method="highs")
    return res.status


STATUS = {0: "optimal", 2: "infeasible", 3: "unbounded"}


def truth(p):
    """(status, objective|None, scipy_direct_status)"""
    direct, value = run_milp(p)
    relax = relaxation_status(p)
    if relax == 2:
        status, value = "infeasible", None
    elif relax == 3:
        feas, _ = run_milp(p, zero_objective=True)
        status, value = ("unbounded" if feas == 0 else "infeasible" if feas == 2 else "other"), None
    else:
        status = STATUS.get(direct, "other")
        if status != "optimal":
            value = None
    if direct in STATUS and STATUS[direct] != status:
        # milp gave a definite verdict; it must match the theorem-based one
        raise AssertionError(f"milp says {STATUS[direct]} but truth says {status}: {json.dumps(p)}")
    return status, value, STATUS.get(direct, "other")


# ----------------------------------------------------------------------------
# exhaustive enumeration
# ----------------------------------------------------------------------------
def integer_box(p):
    """Finite upper bound per integer variable, derived only from rows where it is provably valid; None if unknown."""
    types = types_of(p)
    n = len(types)
    U = [1 if t == "binary" else None for t in types]
    for row in p["constraints"]:
        a = [F(x) for x in row["coeffs"]]
        if row["relation"] in ("<=", "=") and all(x >= 0 for x in a):
            b = F(row["rhs"])
            for j in range(n):
                if a[j] > 0:
                    u = math.floor(b / a[j])
                    U[j] = u if U[j] is None else min(U[j], u)
    return [None if types[j] == "continuous" else U[j] for j in range(n)]


def feasible_exact(p, x):
    for row in p["constraints"]:
        lhs = sum(F(a) * v for a, v in zip(row["coeffs"], x))
        rhs = F(row["rhs"])
        r = row["relation"]
        if (r == "<=" and lhs > rhs) or (r == ">=" and lhs < rhs) or (r == "=" and lhs != rhs):
            return False
    return True


def brute_force(p):
    """('exact'|'lp-per-point'|'none', status|None, value|None)"""
    types = types_of(p)
    n = len(types)
    U = integer_box(p)
    int_idx = [j for j in range(n) if types[j] != "continuous"]
    if any(U[j] is None for j in int_idx) or any(U[j] < 0 for j in int_idx):
        # a negative derived bound means the box is empty
        if all(U[j] is not None for j in int_idx):
            return "exact" if len(int_idx) == n else "lp-per-point", "infeasible", None
        return "none", None, None
    size = 1
    for j in int_idx:
        size *= U[j] + 1
    sign = 1 if p["sense"] == "max" else -1
    c = [F(x) for x in p["objective"]]

    if len(int_idx) == n:
        if size > BRUTE_EXACT_LIMIT:
            return "none", None, None
        best = None
        for point in itertools.product(*[range(U[j] + 1) for j in range(n)]):
            if feasible_exact(p, point):
                v = sum(ci * xi for ci, xi in zip(c, point))
                if best is None or sign * v > sign * best:
                    best = v
        return "exact", ("optimal" if best is not None else "infeasible"), best

    if size > BRUTE_MIXED_LIMIT:
        return "none", None, None
    cont = [j for j in range(n) if types[j] == "continuous"]
    best = None
    for point in itertools.product(*[range(U[j] + 1) for j in int_idx]):
        fixed = dict(zip(int_idx, point))
        A_ub, b_ub, A_eq, b_eq = [], [], [], []
        for row in p["constraints"]:
            rest = float(row["rhs"]) - sum(row["coeffs"][j] * fixed[j] for j in int_idx)
            a = [row["coeffs"][j] for j in cont]
            r = row["relation"]
            if r == "<=":
                A_ub.append(a), b_ub.append(rest)
            elif r == ">=":
                A_ub.append([-x for x in a]), b_ub.append(-rest)
            else:
                A_eq.append(a), b_eq.append(rest)
        base = sum(float(c[j]) * fixed[j] for j in int_idx)
        cc = np.array([-float(c[j]) * sign * -1 * 1 for j in cont], dtype=float)  # minimise sign*(-obj)... see below
        cc = np.array([-sign * float(c[j]) for j in cont], dtype=float)
        res = linprog(cc, A_ub=A_ub or None, b_ub=b_ub or None, A_eq=A_eq or None, b_eq=b_eq or None,
                      bounds=[(0, None)] * len(cont), method="highs")
        if res.status == 3:
            return "none", None, None
        if res.status == 0:
            v = base + sum(float(c[j]) * x for j, x in zip(cont, res.x))
            if best is None or sign * v > sign * best:
                best = v
    return "lp-per-point", ("optimal" if best is not None else "infeasible"), best


# ----------------------------------------------------------------------------
# problem generators (seeded; every one is small enough for the exact solver to finish instantly)
# ----------------------------------------------------------------------------
def prob(sense, obj, types, rows):
    n = len(obj)
    return {
        "sense": sense,
        "variables": [f"x{i + 1}" for i in range(n)],
        "objective": obj,
        "varTypes": types,
        "constraints": [{"coeffs": a, "relation": r, "rhs": b} for a, r, b in rows],
    }


def gen_knapsack(rng, binary):
    n, m = (rng.randint(3, 7), rng.randint(1, 3)) if binary else (rng.randint(3, 5), rng.randint(1, 3))
    rows = []
    for _ in range(m):
        w = [rng.randint(1, 15) for _ in range(n)]
        rows.append((w, "<=", max(6, int(sum(w) * rng.uniform(0.3, 0.6)))))
    return prob("max", [rng.randint(1, 20) for _ in range(n)], ["binary" if binary else "integer"] * n, rows)


def gen_cover(rng):
    n, m = rng.randint(4, 7), rng.randint(3, 6)
    rows = []
    for _ in range(m):
        a = [1 if rng.random() < 0.45 else 0 for _ in range(n)]
        if not any(a):
            a[rng.randrange(n)] = 1
        rows.append((a, ">=", rng.choice([1, 1, 1, 2])))
    types = [rng.choice(["binary", "binary", "integer"]) for _ in range(n)]
    return prob("min", [rng.randint(1, 9) for _ in range(n)], types, rows)


def gen_mixed(rng):
    n, m = rng.randint(3, 5), rng.randint(2, 3)
    types = [rng.choice(["integer", "integer", "continuous", "binary"]) for _ in range(n)]
    types[0], types[-1] = "integer", "continuous"
    half = lambda lo, hi: rng.randint(2 * lo, 2 * hi) / 2
    rows = [([rng.randint(1, 9) for _ in range(n)], "<=", rng.randint(10, 30) + rng.choice([0, 0.5])) for _ in range(m)]
    return prob("max", [half(1, 9) for _ in range(n)], types, rows)


def gen_equality(rng):
    n = rng.randint(3, 4)
    rows = [([rng.randint(2, 9) for _ in range(n)], "=", rng.randint(10, 40))]
    if rng.random() < 0.5:
        rows.append(([rng.randint(1, 5) for _ in range(n)], "<=", rng.randint(8, 25)))
    return prob(rng.choice(["max", "min"]), [rng.randint(1, 9) for _ in range(n)], ["integer"] * n, rows)


def gen_signed(rng):
    n, m = rng.randint(2, 4), rng.randint(2, 4)
    rows = []
    for _ in range(m):
        a = [rng.randint(-5, 9) for _ in range(n)]
        if not any(a):
            a[0] = 1
        rows.append((a, rng.choices(["<=", ">=", "="], [60, 25, 15])[0], rng.randint(-5, 30)))
    for j in range(n):  # a box keeps every case bounded, so exhaustive enumeration applies
        e = [0] * n
        e[j] = 1
        rows.append((e, "<=", rng.randint(3, 8)))
    types = [rng.choice(["integer", "integer", "binary", "continuous"]) for _ in range(n)]
    return prob(rng.choice(["max", "min"]), [rng.randint(-6, 9) for _ in range(n)], types, rows)


def gen_unbounded(rng):
    n = rng.randint(2, 3)
    star = rng.randrange(n)
    obj = [rng.randint(-3, 5) for _ in range(n)]
    obj[star] = rng.randint(1, 6)
    rows = []
    for _ in range(rng.randint(1, 3)):
        a = [rng.randint(-3, 4) for _ in range(n)]
        a[star] = -rng.randint(0, 3)  # the ray along x_star never violates a "<=" row
        if not any(a):
            a[(star + 1) % n] = 1
        rows.append((a, "<=", rng.randint(0, 12)))
    return prob("max", obj, ["integer"] * n, rows)


def gen_contradictory(rng):
    n = rng.randint(2, 4)
    a = [rng.randint(1, 6) for _ in range(n)]
    lo = rng.randint(8, 20)
    rows = [(a, ">=", lo), (a, "<=", lo - rng.randint(1, 6))]
    if rng.random() < 0.5:
        rows.append(([rng.randint(0, 4) for _ in range(n)] or [1], "<=", 30))
    rows = [(r[0] if any(r[0]) else [1] + r[0][1:], r[1], r[2]) for r in rows]
    return prob(rng.choice(["max", "min"]), [rng.randint(1, 9) for _ in range(n)], ["integer"] * n, rows)


def gen_decimals(rng):
    n, m = rng.randint(3, 5), rng.randint(1, 3)
    d = lambda lo, hi: round(rng.randint(int(lo * 10), int(hi * 10)) / 10, 1)
    rows = [([d(0.5, 6) for _ in range(n)], "<=", d(8, 30)) for _ in range(m)]
    return prob("max", [d(0.5, 9) for _ in range(n)], [rng.choice(["integer", "binary"]) for _ in range(n)], rows)


FAMILIES = [
    ("knapsack-integer", 30, lambda r: gen_knapsack(r, False)),
    ("knapsack-binary", 30, lambda r: gen_knapsack(r, True)),
    ("set-cover", 30, gen_cover),
    ("mixed-integer", 30, gen_mixed),
    ("equality", 30, gen_equality),
    ("mixed-signs", 40, gen_signed),
    ("unbounded", 20, gen_unbounded),
    ("contradictory", 10, gen_contradictory),
    ("decimals", 25, gen_decimals),
]


# ----------------------------------------------------------------------------
def record(label, family, p):
    status, value, direct = truth(p)
    kind, b_status, b_value = brute_force(p)
    if kind != "none" and status in ("optimal", "infeasible"):
        assert b_status == status, f"{label}: scipy={status}, enumeration={b_status}\n{json.dumps(p)}"
        if status == "optimal":
            assert abs(float(b_value) - value) < TOL * max(1, abs(value)), f"{label}: scipy={value}, enumeration={float(b_value)}"
    exact = None
    if kind == "exact" and b_status == "optimal":
        exact = str(b_value) if b_value.denominator == 1 else f"{b_value.numerator}/{b_value.denominator}"
    return {
        "label": label,
        "family": family,
        "problem": p,
        "expected": {"status": status, "objective": value, "exactObjective": exact},
        "checks": {"scipyDirect": direct, "enumeration": kind},
    }


def main():
    cases = []
    for ex in json.loads(EXAMPLES.read_text()):
        cases.append(record(ex["name"], "example", ex["problem"]))
    rng = random.Random(SEED)
    for family, count, gen in FAMILIES:
        for i in range(count):
            cases.append(record(f"{family} #{i + 1}", family, gen(rng)))

    tally = {}
    for c in cases:
        key = (c["family"] if c["family"] == "example" else "random", c["expected"]["status"])
        tally[key] = tally.get(key, 0) + 1
    enum = {}
    for c in cases:
        enum[c["checks"]["enumeration"]] = enum.get(c["checks"]["enumeration"], 0) + 1
    print("cases:", len(cases), "| by status:", dict(sorted(tally.items())), "| enumeration cross-check:", enum)
    assert not any(c["expected"]["status"] == "other" for c in cases), "a case has no definite ground truth"

    header = (
        "// AUTO-GENERATED by tools/ip_ground_truth.py — do not edit by hand.\n"
        "// Independent ground truth: scipy.optimize.milp + linprog, cross-checked by exhaustive enumeration.\n\n"
        "import { IPProblem } from \"../../../../types/integer\";\n\n"
        "export interface GTCase {\n  label: string;\n  family: string;\n  problem: IPProblem;\n"
        "  expected: { status: \"optimal\" | \"infeasible\" | \"unbounded\"; objective: number | null; exactObjective: string | null };\n"
        "  checks: { scipyDirect: string; enumeration: \"exact\" | \"lp-per-point\" | \"none\" };\n}\n\n"
        f"export const GT_META = {{ scipy: \"{scipy.__version__}\", seed: {SEED}, generatedBy: \"tools/ip_ground_truth.py\" }};\n\n"
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(header + "export const GT_CASES: GTCase[] = " + json.dumps(cases, ensure_ascii=False, indent=1) + ";\n")
    print("wrote", OUT.relative_to(ROOT))


if __name__ == "__main__":
    main()
