#!/usr/bin/env python3
"""
Independent ground truth for the Game Theory module.

Nothing here shares code with the TypeScript solver. For every game it computes:

  1. the pure-strategy equilibria by brute-force best-response checking (exact integer comparisons),
  2. whether the game is degenerate, with a *different* method than the app uses. The app tests that the
     best-response polytopes are simple (exact vertex enumeration); here, straight from the definition -- "some
     mixed strategy has more pure best responses than its support size" -- one small LP per (support S,
     best-response set T with |T| = |S| + 1) asks whether such a mixed strategy exists,
  3. for nondegenerate games, the complete list of equilibria from nashpy's vertex_enumeration (a different
     algorithm from the app's), cross-checked against a separate exact-Fraction support enumeration written here in
     Python; the script aborts if they disagree, or if the count is even (Wilson's theorem: nondegenerate games have
     an odd number of equilibria). nashpy's own support_enumeration is deliberately NOT used as truth: on some
     nondegenerate games (e.g. A=[[-1,8,-3],[-6,-7,7]], B=[[9,-8,7],[0,-9,2]]) it silently misses an equilibrium
     that the vertex enumeration and the exact enumeration both find and that is easy to verify by hand,
  4. for zero-sum games, the value of the game from scipy.optimize.linprog, cross-checked against nashpy's
     equilibrium payoff.

It then writes src/algorithms/game/__tests__/fixtures/groundTruth.ts, which the vitest suite compares the solver
against: the 11 built-in examples (the test asserts these matrices equal the app's examples.ts, so the two can't
drift) plus ~170 seeded random games in six families.

Usage (from the repo root):   python3 tools/game_ground_truth.py
Requires: numpy, scipy, nashpy.
"""
import itertools
import json
import random
import warnings
from fractions import Fraction
from pathlib import Path

import nashpy as nash
import numpy as np
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "src/algorithms/game/__tests__/fixtures/groundTruth.ts"
SEED = 20260924
TOL = 1e-7

warnings.filterwarnings("ignore")  # nashpy warns on degenerate games; we detect those ourselves


def zero_sum(A):
    return [[0 - x for x in row] for row in A]


CLASSICS = [
    ("Prisoner's Dilemma", [[-1, -3], [0, -2]], [[-1, 0], [-3, -2]]),
    ("Matching Pennies", [[1, -1], [-1, 1]], zero_sum([[1, -1], [-1, 1]])),
    ("Battle of the Sexes", [[2, 0], [0, 1]], [[1, 0], [0, 2]]),
    ("Saddle-point zero-sum game", [[6, 2, 1], [7, 0, 1], [4, 4, 3]], zero_sum([[6, 2, 1], [7, 0, 1], [4, 4, 3]])),
    ("Stag Hunt", [[4, 0], [3, 3]], [[4, 3], [0, 3]]),
    ("Chicken", [[0, -1], [1, -10]], [[0, 1], [-1, -10]]),
    ("Rock-Paper-Scissors", [[0, -1, 1], [1, 0, -1], [-1, 1, 0]], zero_sum([[0, -1, 1], [1, 0, -1], [-1, 1, 0]])),
    ("Solvable by iterated dominance", [[1, 2, 9], [2, 4, 0], [5, 3, 1]], [[4, 3, 2], [2, 4, 1], [1, 5, 0]]),
    ("Zero-sum game needing the LP", [[4, 0, 0, -2], [-1, 6, -2, 6], [-1, 0, 1, 4]], zero_sum([[4, 0, 0, -2], [-1, 6, -2, 6], [-1, 0, 1, 4]])),
    ("Three-way coordination game", [[3, 0, 0], [0, 2, 0], [0, 0, 1]], [[3, 0, 0], [0, 2, 0], [0, 0, 1]]),
    ("Indifferent row player (degenerate)", [[2, 2], [2, 2]], [[1, 0], [0, 1]]),
]


def pure_equilibria(A, B):
    m, n = len(A), len(A[0])
    out = []
    for i in range(m):
        for j in range(n):
            if all(A[i][j] >= A[k][j] for k in range(m)) and all(B[i][j] >= B[i][l] for l in range(n)):
                out.append([i, j])
    return out


def _degenerate_side(Pay, m, n):
    """Is there a mixed strategy p on rows (supp S) with |T| = |S|+1 columns all best responses (payoff matrix Pay, m x n)?"""
    Pay = np.array(Pay, dtype=float)
    for s in range(1, min(m, n - 1) + 1):
        for S in itertools.combinations(range(m), s):
            for T in itertools.combinations(range(n), s + 1):
                # variables: p_S (s), t, u   maximize t
                nv = s + 2
                c = np.zeros(nv)
                c[s] = -1.0
                A_ub, b_ub = [], []
                for k in range(s):  # t <= p_k
                    row = np.zeros(nv)
                    row[k] = -1.0
                    row[s] = 1.0
                    A_ub.append(row)
                    b_ub.append(0.0)
                for j in range(n):
                    if j in T:
                        continue
                    row = np.zeros(nv)
                    for k, i in enumerate(S):
                        row[k] = Pay[i][j]
                    row[s + 1] = -1.0  # sum p*Pay - u <= 0
                    A_ub.append(row)
                    b_ub.append(0.0)
                A_eq, b_eq = [], []
                row = np.zeros(nv)
                row[:s] = 1.0
                A_eq.append(row)
                b_eq.append(1.0)
                for j in T:
                    row = np.zeros(nv)
                    for k, i in enumerate(S):
                        row[k] = Pay[i][j]
                    row[s + 1] = -1.0
                    A_eq.append(row)
                    b_eq.append(0.0)
                bounds = [(0, None)] * s + [(None, 1.0), (None, None)]
                res = linprog(c, A_ub=np.array(A_ub), b_ub=b_ub, A_eq=np.array(A_eq), b_eq=b_eq, bounds=bounds, method="highs")
                if res.status == 0 and -res.fun > TOL:
                    return True
    return False


def is_degenerate(A, B):
    m, n = len(A), len(A[0])
    # Player 1's mixed strategies p: Player 2's best responses maximize sum_i p_i B[i][j]
    if _degenerate_side(B, m, n):
        return True
    # Player 2's mixed strategies q: Player 1's best responses maximize sum_j A[i][j] q_j  (transpose)
    AT = [[A[i][j] for i in range(m)] for j in range(n)]
    return _degenerate_side(AT, n, m)


def key(eq):
    p, q = eq
    return tuple(round(float(x), 6) + 0.0 for x in list(p) + list(q))


def _solve(M, rhs):
    """Exact Gauss-Jordan over Fractions: the unique solution, or None if singular/inconsistent."""
    n, cols = len(M), len(M[0])
    R = [row[:] + [rhs[i]] for i, row in enumerate(M)]
    r = 0
    piv = []
    for c in range(cols):
        p = next((i for i in range(r, n) if R[i][c] != 0), None)
        if p is None:
            continue
        R[r], R[p] = R[p], R[r]
        pv = R[r][c]
        R[r] = [x / pv for x in R[r]]
        for i in range(n):
            if i != r and R[i][c] != 0:
                f = R[i][c]
                R[i] = [x - f * y for x, y in zip(R[i], R[r])]
        piv.append(c)
        r += 1
    if len(piv) < cols or any(R[i][cols] != 0 for i in range(r, n)):
        return None
    return [R[i][cols] for i in range(cols)]


def exact_support_enumeration(A, B):
    """Independent exact re-implementation (Fractions) of equal-size support enumeration."""
    m, n = len(A), len(A[0])
    A = [[Fraction(x) for x in row] for row in A]
    B = [[Fraction(x) for x in row] for row in B]
    out = []
    for k in range(1, min(m, n) + 1):
        for I in itertools.combinations(range(m), k):
            for J in itertools.combinations(range(n), k):
                Mq = [[A[i][j] for j in J] + [Fraction(-1)] for i in I] + [[Fraction(1)] * k + [Fraction(0)]]
                sq = _solve(Mq, [Fraction(0)] * k + [Fraction(1)])
                if sq is None:
                    continue
                Mp = [[B[i][j] for i in I] + [Fraction(-1)] for j in J] + [[Fraction(1)] * k + [Fraction(0)]]
                sp = _solve(Mp, [Fraction(0)] * k + [Fraction(1)])
                if sp is None:
                    continue
                q, u, p, v = sq[:k], sq[k], sp[:k], sp[k]
                if any(x <= 0 for x in q) or any(x <= 0 for x in p):
                    continue
                P = [Fraction(0)] * m
                Q = [Fraction(0)] * n
                for a, i in enumerate(I):
                    P[i] = p[a]
                for a, j in enumerate(J):
                    Q[j] = q[a]
                if all(sum(A[i][j] * Q[j] for j in range(n)) <= u for i in range(m)) and all(
                    sum(B[i][j] * P[i] for i in range(m)) <= v for j in range(n)
                ):
                    out.append((P, Q))
    return out


nashpy_support_misses = 0


def full_equilibria(A, B):
    global nashpy_support_misses
    g = nash.Game(np.array(A, dtype=float), np.array(B, dtype=float))
    ve = sorted(key(e) for e in g.vertex_enumeration())
    ex = sorted(key(e) for e in exact_support_enumeration(A, B))
    if ve != ex:
        raise SystemExit(f"nashpy vertex enumeration and exact support enumeration disagree on a nondegenerate game: {A} {B}\n{ve}\n{ex}")
    if len(ve) % 2 != 1:
        raise SystemExit(f"nondegenerate game with an even number of equilibria: {A} {B} {ve}")
    if sorted(key(e) for e in g.support_enumeration()) != ve:
        nashpy_support_misses += 1
    m = len(A)
    return [[list(k[:m]), list(k[m:])] for k in ve]


def zero_sum_value(A):
    m, n = len(A), len(A[0])
    A = np.array(A, dtype=float)
    # variables p (m), v ; maximize v s.t. sum_i p_i A[i][j] >= v
    c = np.zeros(m + 1)
    c[m] = -1.0
    A_ub = np.hstack([-A.T, np.ones((n, 1))])
    b_ub = np.zeros(n)
    A_eq = np.array([[1.0] * m + [0.0]])
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=[1.0], bounds=[(0, None)] * m + [(None, None)], method="highs")
    assert res.status == 0
    v = -res.fun
    g = nash.Game(A)
    for p, q in g.support_enumeration():
        assert abs(float(np.array(p) @ A @ np.array(q)) - v) < 1e-6, "nashpy equilibrium payoff != LP value"
        break
    return v


def build_case(label, family, A, B, is_zero_sum):
    m, n = len(A), len(A[0])
    deg = is_degenerate(A, B)
    case = {
        "label": label,
        "family": family,
        "A": A,
        "B": B,
        "zeroSum": is_zero_sum,
        "pure": pure_equilibria(A, B),
        "degenerate": deg,
        "equilibria": None if deg else full_equilibria(A, B),
        "value": zero_sum_value(A) if is_zero_sum else None,
    }
    if not deg and is_zero_sum:
        assert len(case["equilibria"]) == 1, "nondegenerate zero-sum games have a unique equilibrium"
    return case


def main():
    rng = random.Random(SEED)
    cases = []

    for name, A, B in CLASSICS:
        cases.append(build_case(name, "classic", A, B, all(A[i][j] + B[i][j] == 0 for i in range(len(A)) for j in range(len(A[0])))))

    def rand_matrix(m, n, lo, hi):
        return [[rng.randint(lo, hi) for _ in range(n)] for _ in range(m)]

    families = [
        ("general-wide-small", [(2, 2), (2, 3), (3, 2)], 14, (-9, 9), False),
        ("general-wide-mid", [(3, 3), (3, 4), (4, 3)], 12, (-9, 9), False),
        ("general-wide-large", [(4, 4), (2, 5), (5, 2)], 5, (-9, 9), False),
        ("general-ties", [(2, 2), (2, 3), (3, 3)], 14, (0, 2), False),
        ("zero-sum", [(2, 2), (2, 3), (3, 3), (3, 4), (4, 4), (4, 5)], 6, (-6, 6), True),
        ("symmetric", [(2, 2), (3, 3), (4, 4)], 8, (-5, 9), False),
    ]
    for fam, sizes, per_size, (lo, hi), zs in families:
        for (m, n) in sizes:
            for k in range(per_size):
                A = rand_matrix(m, n, lo, hi)
                if zs:
                    B = zero_sum(A)
                elif fam == "symmetric":
                    B = [[A[j][i] for j in range(m)] for i in range(m)]  # B = A^T (symmetric game)
                else:
                    B = rand_matrix(m, n, lo, hi)
                cases.append(build_case(f"{fam} {m}x{n} #{k + 1}", fam, A, B, zs))

    n_deg = sum(c["degenerate"] for c in cases)
    body = json.dumps(cases, indent=1)
    OUT.write_text(
        "// GENERATED by tools/game_ground_truth.py — do not edit by hand.\n"
        "// Independent ground truth (nashpy support + vertex enumeration, scipy linprog, LP-based degeneracy oracle).\n"
        "export interface GTCase {\n  label: string;\n  family: string;\n  A: number[][];\n  B: number[][];\n  zeroSum: boolean;\n"
        "  pure: [number, number][];\n  degenerate: boolean;\n  equilibria: [number[], number[]][] | null;\n  value: number | null;\n}\n\n"
        f"export const GT_CASES: GTCase[] = {body};\n"
    )
    print(f"wrote {len(cases)} cases ({n_deg} degenerate, {len(cases) - n_deg} nondegenerate) -> {OUT.relative_to(ROOT)}")
    print(f"(nashpy's own support_enumeration disagreed with the truth on {nashpy_support_misses} nondegenerate games)")


if __name__ == "__main__":
    main()
