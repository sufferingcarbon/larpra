#!/usr/bin/env python3
"""
Independent ground truth for the CPM/PERT module.

Nothing here shares code with the TypeScript solver. For every project it:

  1. builds a networkx DiGraph and uses networkx.topological_sort,
  2. runs forward/backward passes in exact rational arithmetic (fractions.Fraction),
  3. finds critical paths a *different* way from the solver: enumerate every
     source->sink path with networkx.all_simple_paths and keep the longest ones,
  4. cross-checks the project duration against a linear program (scipy.linprog):
         minimize T  s.t.  s_v >= s_p + d_p,  T >= s_v + d_v,  s_v >= 0
  5. asserts the slack-based critical set == the union of nodes on longest paths.

It then writes src/algorithms/cpm/__tests__/fixtures/groundTruth.ts, which the
vitest suite compares the solver against (built-in examples + 150 random DAGs
whose activities are listed in *non-topological* order on purpose).

Usage (from the repo root):   python3 tools/cpm_ground_truth.py
Requires: networkx, scipy.
"""
import json
import random
from fractions import Fraction
from pathlib import Path

import networkx as nx
from scipy.optimize import linprog

OUT = Path(__file__).resolve().parent.parent / "src/algorithms/cpm/__tests__/fixtures/groundTruth.ts"


# ----------------------------------------------------------------------------
# Core independent solver
# ----------------------------------------------------------------------------
def durations_of(acts, mode):
    """Return ({name: Fraction duration}, {name: Fraction variance} | None)."""
    d, v = {}, ({} if mode == "pert" else None)
    for a in acts:
        if mode == "pert":
            o, m, p = (Fraction(a[k]) for k in ("optimistic", "mostLikely", "pessimistic"))
            d[a["name"]] = (o + 4 * m + p) / 6
            v[a["name"]] = ((p - o) / 6) ** 2
        else:
            d[a["name"]] = Fraction(a["duration"])
    return d, v


def solve(label, mode, acts):
    G = nx.DiGraph()
    for a in acts:
        G.add_node(a["name"])
    for a in acts:
        for p in a["predecessors"]:
            G.add_edge(p, a["name"])
    assert nx.is_directed_acyclic_graph(G), label
    d, var = durations_of(acts, mode)
    order = list(nx.topological_sort(G))

    es, ef = {}, {}
    for v in order:
        es[v] = max((ef[p] for p in G.predecessors(v)), default=Fraction(0))
        ef[v] = es[v] + d[v]
    D = max(ef.values())

    ls, lf = {}, {}
    for v in reversed(order):
        lf[v] = min((ls[s] for s in G.successors(v)), default=D)
        ls[v] = lf[v] - d[v]
    slack = {v: ls[v] - es[v] for v in G}
    assert all(slack[v] == lf[v] - ef[v] >= 0 for v in G), label

    # --- critical paths via full path enumeration (independent of the solver's method)
    sources = [v for v in G if G.in_degree(v) == 0]
    sinks = [v for v in G if G.out_degree(v) == 0]
    all_paths = []
    for s in sources:
        for t in sinks:
            if s == t:
                all_paths.append([s])
            else:
                all_paths.extend(nx.all_simple_paths(G, s, t))
    length = lambda path: sum(d[x] for x in path)
    longest = max(length(p) for p in all_paths)
    assert longest == D, (label, longest, D)
    crit_paths = sorted(p for p in all_paths if length(p) == longest)
    crit_from_slack = {v for v in G if slack[v] == 0}
    crit_from_paths = {v for p in crit_paths for v in p}
    assert crit_from_slack == crit_from_paths, (label, crit_from_slack, crit_from_paths)

    # --- LP cross-check of the project duration
    names = list(G.nodes)
    idx = {n: i for i, n in enumerate(names)}
    n = len(names)
    # variables: s_0..s_{n-1}, T ; minimise T
    c = [0.0] * n + [1.0]
    A, b = [], []
    for u, v in G.edges:
        row = [0.0] * (n + 1)
        row[idx[u]] = 1.0
        row[idx[v]] = -1.0
        A.append(row)
        b.append(-float(d[u]))
    for v in names:
        row = [0.0] * (n + 1)
        row[idx[v]] = 1.0
        row[n] = -1.0
        A.append(row)
        b.append(-float(d[v]))
    lp = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)] * (n + 1), method="highs")
    assert lp.status == 0 and abs(lp.fun - float(D)) < 1e-7, (label, lp.fun, D)

    f = float
    out = {
        "label": label,
        "mode": mode,
        "activities": acts,
        "projectDuration": f(D),
        "schedule": {
            v: {
                "duration": f(d[v]),
                "variance": (f(var[v]) if var else None),
                "es": f(es[v]), "ef": f(ef[v]), "ls": f(ls[v]), "lf": f(lf[v]), "slack": f(slack[v]),
            }
            for v in G
        },
        "criticalPaths": crit_paths,
    }
    if mode == "pert":
        pv = max(sum(var[x] for x in p) for p in crit_paths)  # conservative: largest variance among critical paths
        out["projectVariance"] = f(pv)
        out["projectStdDev"] = f(pv) ** 0.5
        out["criticalPathVariances"] = [f(sum(var[x] for x in p)) for p in crit_paths]
    else:
        out["projectVariance"] = None
        out["projectStdDev"] = None
    return out


# ----------------------------------------------------------------------------
# Built-in examples (must match src/algorithms/cpm/examples.ts by name & data)
# ----------------------------------------------------------------------------
def act(name, dur, preds):
    return {"name": name, "duration": dur, "predecessors": preds}


def pert(name, o, m, p, preds):
    return {"name": name, "optimistic": o, "mostLikely": m, "pessimistic": p, "predecessors": preds}


EXAMPLES = [
    ("Simple chain (A → B → C)", "cpm", [
        act("A", 3, []), act("B", 5, ["A"]), act("C", 2, ["B"]),
    ]),
    ("Diamond dependency (A → {B, C} → D)", "cpm", [
        act("A", 2, []), act("B", 4, ["A"]), act("C", 6, ["A"]), act("D", 3, ["B", "C"]),
    ]),
    ("Two equally long critical paths", "cpm", [
        act("A", 3, []), act("B", 4, ["A"]), act("C", 5, ["A"]), act("D", 6, ["B"]),
        act("E", 5, ["C"]), act("F", 2, ["A"]), act("G", 4, ["D", "E"]), act("H", 3, ["F", "G"]),
    ]),
    ("14-activity construction project", "cpm", [
        act("A", 2, []), act("B", 4, ["A"]), act("C", 10, ["B"]), act("D", 6, ["C"]),
        act("E", 4, ["C"]), act("F", 5, ["E"]), act("G", 7, ["D"]), act("H", 9, ["E", "G"]),
        act("I", 7, ["C"]), act("J", 8, ["F", "I"]), act("K", 4, ["J"]), act("L", 5, ["J"]),
        act("M", 2, ["H"]), act("N", 6, ["K", "L"]),
    ]),
    ("PERT: simple diamond", "pert", [
        pert("A", 2, 3, 10, []), pert("B", 3, 6, 9, ["A"]), pert("C", 1, 4, 7, ["A"]),
        pert("D", 2, 3, 4, ["B", "C"]),
    ]),
    ("PERT: software release with two critical paths", "pert", [
        pert("A", 2, 4, 6, []), pert("B", 3, 5, 13, ["A"]), pert("C", 4, 6, 8, ["B"]),
        pert("D", 2, 5, 14, ["B"]), pert("E", 1, 2, 3, ["C", "D"]), pert("F", 3, 4, 11, ["E"]),
        pert("G", 1, 2, 5, ["B"]), pert("H", 1, 1, 1, ["F", "G"]),
    ]),
]


# ----------------------------------------------------------------------------
# Random DAG fixtures
# ----------------------------------------------------------------------------
def random_case(rng, i):
    n = rng.randint(1, 12)
    mode = "pert" if rng.random() < 0.4 else "cpm"
    names = [chr(ord("A") + k) for k in range(n)]
    p_edge = rng.uniform(0.1, 0.6)
    preds = {v: [] for v in names}
    for j in range(n):           # edges only go low index -> high index, so the graph is a DAG
        for k in range(j):
            if rng.random() < p_edge:
                preds[names[j]].append(names[k])
    # Some cases use a tiny pool of durations on purpose, so ties (multiple critical
    # paths, zero-duration activities) show up far more often than with wide random values.
    tie_prone = rng.random() < 0.45
    pool = rng.choice([[1], [1, 2], [0, 1, 2], [2, 3]]) if tie_prone else None
    acts = []
    for v in names:
        if mode == "pert":
            if tie_prone:
                o = rng.choice(pool)
                m = o + rng.choice([0, 1])
                p = m + rng.choice([0, 1, 2])
            else:
                o = rng.randint(0, 8)
                m = o + rng.randint(0, 6)
                p = m + rng.randint(0, 8)
            acts.append(pert(v, o, m, p, preds[v]))
        else:
            dur = rng.choice(pool) if tie_prone else rng.choice([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 0.5, 1.5, 2.5])
            acts.append(act(v, dur, preds[v]))
    rng.shuffle(acts)            # listing order is deliberately NOT topological
    return (f"random #{i} ({mode}, {n} activities)", mode, acts)


def main():
    rng = random.Random(20260920)
    cases = [solve(*e) for e in EXAMPLES]
    example_labels = [c["label"] for c in cases]
    randoms = [solve(*random_case(rng, i)) for i in range(150)]
    header = (
        "// AUTO-GENERATED by tools/cpm_ground_truth.py — do not edit by hand.\n"
        "// Independent ground truth (networkx + exact Fractions + scipy LP cross-check).\n"
    )
    types = """
export interface GTActivity {
  name: string;
  duration?: number;
  optimistic?: number;
  mostLikely?: number;
  pessimistic?: number;
  predecessors: string[];
}
export interface GTScheduleEntry {
  duration: number;
  variance: number | null;
  es: number;
  ef: number;
  ls: number;
  lf: number;
  slack: number;
}
export interface GTCase {
  label: string;
  mode: "cpm" | "pert";
  activities: GTActivity[];
  projectDuration: number;
  schedule: Record<string, GTScheduleEntry>;
  criticalPaths: string[][];
  projectVariance: number | null;
  projectStdDev: number | null;
  criticalPathVariances?: number[];
}
"""
    body = (
        f"\nexport const exampleGroundTruth: GTCase[] = {json.dumps(cases, indent=1, ensure_ascii=False)};\n"
        f"\nexport const randomGroundTruth: GTCase[] = {json.dumps(randoms, indent=1, ensure_ascii=False)};\n"
    )
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(header + types + body, encoding="utf-8")
    multi = sum(1 for r in randoms if len(r["criticalPaths"]) > 1)
    print(f"wrote {OUT}")
    print(f"  {len(cases)} example cases, {len(randoms)} random cases ({multi} with >1 critical path)")
    for c in cases:
        print(f"  - {c['label']}: D={c['projectDuration']:g}, critical={['→'.join(p) for p in c['criticalPaths']]}"
              + (f", Var={c['projectVariance']:.4f}, sd={c['projectStdDev']:.4f}, pathVars={[round(x,4) for x in c['criticalPathVariances']]}" if c['mode'] == 'pert' else ""))


if __name__ == "__main__":
    main()
