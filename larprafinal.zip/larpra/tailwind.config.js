/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#F5F4EF",
        ledger: "#EDEBE2",
        ink: "#161B22",
        graphite: "#4B5257",
        rule: "#D8D4C6",
        forest: "#2F6B4F",
        forestDark: "#1F4A36",
        sienna: "#B5482A",
        gold: "#B08A2E",
      },
      fontFamily: {
        display: ["Space Grotesk", "sans-serif"],
        sans: ["IBM Plex Sans", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
      backgroundImage: {
        grid:
          "linear-gradient(to right, #DFDCCF 1px, transparent 1px), linear-gradient(to bottom, #DFDCCF 1px, transparent 1px)",
      },
      backgroundSize: {
        grid: "24px 24px",
      },
    },
  },
  plugins: [],
};
