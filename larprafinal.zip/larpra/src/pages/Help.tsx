const entries = [
  {
    title: "Graphical method",
    body: "Applies only to two-variable problems. Every constraint becomes a boundary line; the feasible region is the intersection of all the half-planes and the non-negative quadrant. By the fundamental theorem of linear programming, if an optimal solution exists it occurs at a corner point of that region, so the method evaluates the objective at every corner and keeps the best one.",
  },
  {
    title: "Simplex method",
    body: "Starts from a basic feasible solution (all slack variables basic) and repeatedly pivots to an adjacent basic feasible solution with a better objective value, using the Cj − Zj row to choose the entering variable and the minimum-ratio test to choose the leaving variable. Stops when no entering variable can improve the objective.",
  },
  {
    title: "Two-phase method",
    body: "Used whenever a constraint is ≥ or = and therefore needs an artificial variable to obtain a starting basic feasible solution. Phase I minimizes the sum of the artificial variables; if that minimum is zero, a feasible starting point for the real problem has been found and Phase II proceeds with the original objective. If it can't reach zero, the problem is infeasible.",
  },
  {
    title: "Degenerate solution",
    body: "Occurs when a basic variable takes the value zero. It's detected here by a tie in the minimum-ratio test. Degenerate problems can in principle cycle; larpra breaks ties by choosing the lowest-indexed row, which is a standard anti-cycling rule.",
  },
  {
    title: "Alternate optimal solutions",
    body: "At the optimal tableau, if a non-basic variable's Cj − Zj equals zero, bringing it into the basis would not change the objective value — so every point on the edge between the two corresponding corner points is also optimal.",
  },
  {
    title: "Unbounded",
    body: "During simplex, this is detected when an entering column has no positive coefficient anywhere, so the ratio test has nothing to limit it. In the graphical method, it's detected by finding a feasible direction of unlimited travel that keeps improving the objective.",
  },
  {
    title: "Infeasible",
    body: "No point satisfies every constraint simultaneously. In the simplex engine this shows up as Phase I being unable to drive the artificial variables to zero.",
  },
  {
    title: "Dijkstra's algorithm (shortest path)",
    body: "Finds the shortest distance from a single source to every other node in a graph with non-negative edge weights. Repeatedly finalizes whichever unvisited node currently has the smallest tentative distance, then relaxes its outgoing edges. Requires non-negative weights — a negative edge can make an already-finalized node's distance wrong, since Dijkstra never revisits a finalized node. Use Bellman-Ford instead if negative weights are possible.",
  },
  {
    title: "Kruskal's algorithm (minimum spanning tree)",
    body: "Sorts every edge by weight and adds each one in order unless it would close a cycle (checked with a union-find structure), stopping once n−1 edges have been accepted. Correct by the cut property: the cheapest edge crossing any split of the nodes into two groups always belongs to some minimum spanning tree. Only defined for undirected, connected graphs.",
  },
  {
    title: "Prim's algorithm (minimum spanning tree)",
    body: "Grows a single tree outward from a starting node, at each step adding the cheapest edge with exactly one endpoint already in the tree. Reaches the same minimum total weight as Kruskal's regardless of starting node, though the specific edges chosen among ties can differ.",
  },
  {
    title: "Ford-Fulkerson / Edmonds-Karp (maximum flow)",
    body: "Repeatedly finds a path from source to sink with spare capacity in the residual graph (Edmonds-Karp specifically uses breadth-first search, which finds the shortest such path and guarantees polynomial termination) and pushes flow equal to the bottleneck — the smallest spare capacity along that path. Stops when no augmenting path remains, at which point the max-flow/min-cut theorem guarantees the flow found is maximum.",
  },
  {
    title: "Nearest Neighbor (TSP heuristic)",
    body: "Builds a tour by always hopping to whichever unvisited city is closest to the current one, then closes the loop back to the start. Fast, but a heuristic: it never reconsiders an earlier choice, so it can strand a distant city for an expensive late addition. Not guaranteed to find the optimal tour.",
  },
  {
    title: "Branch and Bound (exact TSP)",
    body: "Searches the space of possible city orderings, but prunes any partial route once its lower bound (the cost so far, plus each remaining city's cheapest still-available outgoing edge) is no better than the best complete tour already found. Because that bound never overestimates the true remaining cost, the tour found once every branch has been explored or pruned is provably optimal — not just the best one tried.",
  },
  {
    title: "CPM: forward and backward pass",
    body: "Given activities with durations and predecessors, the forward pass visits them in topological order and sets each one's earliest start (ES) to the latest earliest-finish among its predecessors (0 if it has none), with EF = ES + duration. The largest EF is the project duration. The backward pass then works from the last activity back: each activity's latest finish (LF) is the smallest latest-start among its successors (the project duration if it has none), with LS = LF − duration. A cycle in the precedence relations makes both passes impossible, so larpra rejects it and names the loop.",
  },
  {
    title: "Slack and the critical path",
    body: "Slack (total float) = LS − ES = LF − EF: how far an activity can slip without delaying the project. Activities with zero slack are critical. A critical path is a chain from a start activity to an end activity in which every activity is critical and every hand-off is tight — one activity's EF equals the next one's ES — and its durations add up to exactly the project duration. A network can have several critical paths; larpra lists all of them. Slack is shared along a path, so using it up on one activity leaves less for the others.",
  },
  {
    title: "PERT (three-point estimates)",
    body: "Each activity gets an optimistic (a), most-likely (m) and pessimistic (b) time. Its expected duration is (a + 4m + b) / 6 and its variance is ((b − a) / 6)². The ordinary CPM passes then run on the expected durations. Assuming independent activities, the project duration is approximately normal with mean equal to the critical path's length and variance equal to the sum of the variances of the activities on it; when several critical paths tie, larpra uses the largest path variance, the cautious choice. This ignores near-critical paths, so it can understate uncertainty when several paths are close in length.",
  },
  {
    title: "M/M/1 queue",
    body: "A single server, Poisson arrivals at rate λ, exponential service at rate μ, FCFS, unlimited queue. Stable only if ρ = λ/μ < 1. Then P0 = 1 − ρ, Pn = (1 − ρ)ρⁿ (a geometric distribution), L = ρ/(1 − ρ), Lq = ρ·L, and W = L/λ, Wq = Lq/λ by Little's Law. Every quantity is a direct consequence of solving the birth-death steady-state balance equations with constant birth rate λ and constant death rate μ.",
  },
  {
    title: "M/M/c queue and Erlang C",
    body: "c identical parallel servers share one FCFS queue. The offered load is a = λ/μ (in erlangs); utilization is ρ = a/c, and stability requires ρ < 1. P0 normalizes the c 'light traffic' states (aⁿ/n! for n < c) against the geometric tail of 'all servers busy' states. Erlang C, C(c, a) = (a^c/c!)·(1/(1−ρ))·P0, is the probability an arrival finds every server busy and must wait; from it, Lq = C(c,a)·ρ/(1−ρ), and Wq, W, L follow from Little's Law exactly as in M/M/1.",
  },
  {
    title: "Erlang B (loss system)",
    body: "The blocking probability of a companion system with the same c servers but no waiting room at all: an arrival that finds every server busy is turned away rather than queued. B(c, a) = (a^c/c!) / Σₙ₌₀^c aⁿ/n!. larpra reports it alongside Erlang C as a cross-check — B(c,a) ≤ C(c,a) always, since a system that lets customers wait can never turn away a larger fraction of arrivals than one that doesn't.",
  },
  {
    title: "Best responses and pure Nash equilibria",
    body: "A strategy is a best response to the opponent's choice if no other strategy of yours pays more against it (ties all count). Player 1 compares payoffs down each column; Player 2 compares across each row. A cell where both players are best-responding is a pure-strategy Nash equilibrium: neither player gains by switching alone. Some games have none (Matching Pennies), some one (Prisoner's Dilemma), some several (Battle of the Sexes).",
  },
  {
    title: "Dominance and iterated elimination",
    body: "Strategy s strictly dominates t if s pays more than t against every opponent choice, so t can never be part of an equilibrium. larpra removes strictly dominated strategies in rounds — every strictly dominated strategy of both players at once, each judged only against the strategies still remaining — and repeats until nothing more can go. The result doesn't depend on the order of removal. Weak dominance (never worse, sometimes equal) is used only to report a weakly dominant strategy, never to remove anything, because removing weakly dominated strategies can discard genuine equilibria and the survivors can depend on the order.",
  },
  {
    title: "Mixed strategies and the indifference principle",
    body: "A mixed strategy is a probability distribution over pure strategies. In an equilibrium, every pure strategy a player uses with positive probability must earn the same expected payoff against the opponent's mix (otherwise they'd shift weight to the better one), and no unused strategy may earn more. So Player 2's mix q is pinned down by making Player 1 indifferent among Player 1's supported rows: Σⱼ A[i][j]·qⱼ = u for each of them, together with Σqⱼ = 1 — and likewise p from Player 2's payoffs.",
  },
  {
    title: "Support enumeration",
    body: "For each size k and every choice of k rows and k columns (the supports), larpra writes the indifference equations, solves the linear system exactly with fractions, and accepts the pair only if all probabilities come out strictly positive and no row or column outside the supports would pay strictly more. Only equal-size supports are tried: for a nondegenerate game an equilibrium's supports always have equal size. The number of pairs grows quickly, C(m,k)·C(n,k) per size, which is why strategies are capped at 6 per player.",
  },
  {
    title: "Degenerate games",
    body: "A game is degenerate when some mixed strategy has more pure best responses than the number of strategies it uses — for instance a player who is indifferent between two rows whatever the opponent does. Nondegenerate games have finitely many equilibria and an odd number of them (Wilson's theorem). Degenerate games may have continua of equilibria, which no finite list can display; larpra tests for degeneracy exactly, names the offending tie, and says when the list may be incomplete.",
  },
  {
    title: "Zero-sum games, minimax and the LP",
    body: "When Player 2's payoff is always minus Player 1's, Player 1 can guarantee at least the maximin (the best of the row minimums) and Player 2 can hold Player 1 to at most the minimax (the least of the column maximums); maximin ≤ minimax always. If they are equal there is a pure saddle point. Otherwise von Neumann's minimax theorem gives a value v in mixed strategies, found by linear programming: add a constant c so every payoff is positive, let yᵢ = pᵢ/v′, and minimize Σy subject to Σᵢ A′[i][j]·yᵢ ≥ 1 for every column j. Player 2's problem is its dual, so the two optima are equal, v′ = 1/Σy, v = v′ − c and p = y/Σy.",
  },
  {
    title: "Row echelon form and Gaussian elimination",
    body: "Working left to right, each column's pivot is the topmost non-zero entry at or below the current row (swapped up if needed), and every entry below it is eliminated by subtracting a multiple of the pivot row. A matrix in row echelon form has each pivot strictly to the right of the one above it, with zeros below every pivot. Row swaps, scaling a row by a non-zero number, and adding a multiple of one row to another never change the solution set of the system the rows represent — that's what makes elimination valid. Back-substitution (or continuing to reduced row echelon form, where every pivot is scaled to 1 with zeros above it too) then reads the solution straight off.",
  },
  {
    title: "Classifying Ax = b: unique, none, or infinitely many",
    body: "After elimination, a row that reads 0 = c for some non-zero c is a contradiction — no values of the unknowns satisfy it, so the system has no solution. Otherwise, if every column has a pivot the solution is unique (read off by back-substitution). If some columns have no pivot, those unknowns are free variables: the system has infinitely many solutions, described by one particular solution (setting every free variable to 0) plus any combination of the nullspace's basis vectors.",
  },
  {
    title: "Determinant by cofactor expansion",
    body: "Expanding along row 1, det(A) = Σⱼ a₁ⱼ·Cⱼ, where the cofactor Cⱼ = (−1)^(1+j)·det(minor₁ⱼ) and minor₁ⱼ is A with row 1 and column j removed. For 2×2 this is the closed form ad − bc; for 3×3, a(ei − fh) − b(di − fg) + c(dh − eg) (Sarrus' rule in cofactor form). Expanding along any fixed row or column gives the same value; row 1 is used here so the same matrix always produces the same expansion tree. A is invertible exactly when det(A) ≠ 0.",
  },
  {
    title: "Matrix inverse by Gauss-Jordan elimination",
    body: "Augment A with the identity matrix, [A | I], and row-reduce the left block to I; the same sequence of row operations turns the right block into A⁻¹. This works because each row operation is left-multiplication by an elementary matrix E, and if Eₖ···E₁A = I then Eₖ···E₁ = A⁻¹ by definition — applying that same product to I produces exactly that. If a column has no pivot during elimination, A has rank below n and no inverse exists.",
  },
  {
    title: "Rank and the rank–nullity theorem",
    body: "The rank of A is the number of pivots in any row echelon form of A — equivalently, the dimension of its column space (and, by the same count, its row space). For an m × n matrix, rank(A) + nullity(A) = n, where the nullity is the number of free variables, i.e. the dimension of the nullspace (the solution set of Ax = 0). Row operations change neither the rank nor the nullspace, so reducing A to echelon form is enough to read both off.",
  },
  {
    title: "Nullspace basis",
    body: "From A in reduced row echelon form, each free variable contributes one basis vector: set that free variable to 1, every other free variable to 0, and read the pivot variables off the reduced rows (each pivot row directly gives one variable in terms of the free ones). The resulting vectors are linearly independent — each has a 1 in its own free coordinate and 0 in every other free coordinate — and together they span every solution of Ax = 0, so they form a basis of the nullspace.",
  },
  {
    title: "Characteristic polynomial and eigenvalues",
    body: "The eigenvalues of A are the roots of det(A − λI) = 0, a degree-n polynomial in λ. larpra computes its coefficients exactly with the Faddeev–LeVerrier recursion (repeated multiplication by A and taking traces) rather than expanding the symbolic determinant, then finds roots via the rational root theorem with deflation, the quadratic formula (exact when the discriminant is a perfect square), and a numerical fallback for cubics and quartics with no further rational roots. A degree-n polynomial always has exactly n roots counted with multiplicity, possibly complex, possibly repeated.",
  },
  {
    title: "Eigenvectors and defective matrices",
    body: "For each eigenvalue λ, the eigenvectors are the non-zero solutions of (A − λI)v = 0 — found the same way as any nullspace, by row-reducing A − λI. The dimension of that eigenspace (the geometric multiplicity) can be less than the eigenvalue's multiplicity as a root of the characteristic polynomial (its algebraic multiplicity); when it is, A is called defective for that eigenvalue and cannot be diagonalized. A symmetric matrix is never defective — its eigenvalues are always real and it always has a full set of eigenvectors, which can be chosen mutually orthogonal.",
  },
];

export function Help() {
  return (
    <div className="mx-auto max-w-2xl px-6 py-10">
      <h1 className="font-display text-2xl font-semibold text-ink">Algorithm reference</h1>
      <p className="mt-2 text-sm text-graphite">
        Short, precise explanations of the rules larpra's algorithms actually use — not marketing
        copy, the literal decision rules.
      </p>
      <div className="mt-6 space-y-6">
        {entries.map((e) => (
          <div key={e.title}>
            <h2 className="font-display text-base font-semibold text-ink">{e.title}</h2>
            <p className="mt-1 text-sm leading-relaxed text-graphite">{e.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
