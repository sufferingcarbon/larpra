import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { TSP } from "../../pages/TSP";
import { ProblemInput } from "../../components/tsp/ProblemInput";
import { NNView } from "../../components/tsp/NNView";
import { BnBView } from "../../components/tsp/BnBView";
import { tspExamples } from "../../algorithms/tsp/examples";
import { solveNearestNeighbor } from "../../algorithms/tsp/nearestNeighbor";
import { solveTSPBranchAndBound } from "../../algorithms/tsp/branchAndBound";

describe("TSP page renders without throwing", () => {
  it("renders the initial (unsolved) page", () => {
    const html = renderToStaticMarkup(<TSP />);
    expect(html).toContain("Traveling Salesman");
  });
});

describe("ProblemInput renders every example without throwing", () => {
  tspExamples.forEach((ex, i) => {
    it(`example ${i}: ${ex.name}`, () => {
      const html = renderToStaticMarkup(<ProblemInput problem={ex.problem} onChange={() => {}} errors={[]} />);
      expect(html.length).toBeGreaterThan(0);
    });
  });
});

describe("NNView renders every step of every example without throwing", () => {
  tspExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveNearestNeighbor(ex.problem);
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<NNView problem={ex.problem} state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});

describe("BnBView renders every step of every example without throwing", () => {
  tspExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveTSPBranchAndBound(ex.problem);
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<BnBView problem={ex.problem} state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});
