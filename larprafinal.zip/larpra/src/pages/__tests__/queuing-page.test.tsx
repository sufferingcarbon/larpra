import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Queuing } from "../../pages/Queuing";
import { QueuingView } from "../../components/queuing/QueuingView";
import { QueuingInputForm } from "../../components/queuing/QueuingInputForm";
import { mm1Examples, mmcExamples } from "../../algorithms/queuing/examples";
import { solveMM1, solveMMc } from "../../algorithms/queuing/solve";

describe("Queuing page renders without throwing", () => {
  it("renders the initial (unsolved) page", () => {
    const html = renderToStaticMarkup(<Queuing />);
    expect(html).toContain("Queuing Models");
    expect(html).toContain("M/M/1");
  });
});

describe("QueuingInputForm renders in both modes", () => {
  it("M/M/1 mode", () => {
    const html = renderToStaticMarkup(
      <QueuingInputForm
        model="mm1"
        onModelChange={() => {}}
        mm1={{ lambda: 5, mu: 10, maxN: 15 }}
        onMM1Change={() => {}}
        mmc={{ lambda: 20, mu: 6, servers: 4, maxN: 20 }}
        onMMcChange={() => {}}
        errors={[]}
      />
    );
    expect(html.length).toBeGreaterThan(0);
  });

  it("M/M/c mode, with validation errors shown", () => {
    const html = renderToStaticMarkup(
      <QueuingInputForm
        model="mmc"
        onModelChange={() => {}}
        mm1={{ lambda: 5, mu: 10, maxN: 15 }}
        onMM1Change={() => {}}
        mmc={{ lambda: 20, mu: 6, servers: 4, maxN: 20 }}
        onMMcChange={() => {}}
        errors={["Arrival rate λ must be a positive number."]}
      />
    );
    expect(html).toContain("positive number");
  });
});

describe("QueuingView renders every step of every M/M/1 example without throwing", () => {
  mm1Examples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveMM1(ex.problem);
      expect(result.status).toBe("optimal");
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<QueuingView state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});

describe("QueuingView renders every step of every M/M/c example without throwing", () => {
  mmcExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveMMc(ex.problem);
      expect(result.status).toBe("optimal");
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<QueuingView state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});

describe("QueuingView renders the unstable snapshot without throwing", () => {
  it("M/M/1, ρ ≥ 1", () => {
    const result = solveMM1({ lambda: 10, mu: 5, maxN: 10 });
    expect(result.status).toBe("unstable");
    const html = renderToStaticMarkup(<QueuingView state={result.steps[result.steps.length - 1].state} />);
    expect(html.length).toBeGreaterThan(0);
  });

  it("M/M/c, a >= c", () => {
    const result = solveMMc({ lambda: 100, mu: 5, servers: 4, maxN: 10 });
    expect(result.status).toBe("unstable");
    const html = renderToStaticMarkup(<QueuingView state={result.steps[result.steps.length - 1].state} />);
    expect(html.length).toBeGreaterThan(0);
  });
});
