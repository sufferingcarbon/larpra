import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { CPM } from "../../pages/CPM";
import { Help } from "../../pages/Help";
import { Dashboard } from "../../components/Dashboard";
import { modules } from "../../components/Sidebar";
import { ProblemInput } from "../../components/cpm/ProblemInput";
import { CPMView } from "../../components/cpm/CPMView";
import { CPMGantt, niceStep } from "../../components/cpm/CPMGantt";
import { cpmExamples } from "../../algorithms/cpm/examples";
import { solveCPM } from "../../algorithms/cpm/solve";

describe("CPM page renders without throwing", () => {
  it("renders the initial (unsolved) page with both mode buttons, the example loader and Solve", () => {
    const html = renderToStaticMarkup(<CPM />);
    expect(html).toContain("CPM / PERT");
    expect(html).toContain("CPM — one duration per activity");
    expect(html).toContain("PERT — three-point estimates");
    expect(html).toContain("Load example");
    expect(html).toContain("Solve");
    // defaults to the diamond example in CPM mode: a Duration column, no a/m/b columns
    expect(html).toContain(">Duration<");
    expect(html).not.toContain("Optimistic (best case)");
  });

  it("lists every built-in example in the loader", () => {
    const html = renderToStaticMarkup(<CPM />);
    for (const ex of cpmExamples) expect(html).toContain(ex.name.replace("→", "→"));
  });
});

describe("ProblemInput renders every example in its own mode", () => {
  cpmExamples.forEach((ex, i) => {
    it(`example ${i}: ${ex.name}`, () => {
      const html = renderToStaticMarkup(<ProblemInput problem={ex.problem} mode={ex.mode} onChange={() => {}} errors={[]} />);
      for (const a of ex.problem.activities) expect(html).toContain(`value="${a.name}"`);
      if (ex.mode === "pert") {
        expect(html).toContain("Optimistic (best case)");
        expect(html).toContain("Variance ((b − a) / 6)²");
      } else {
        expect(html).not.toContain("Optimistic (best case)");
      }
    });
  });

  it("shows validation errors above the table", () => {
    const html = renderToStaticMarkup(
      <ProblemInput problem={{ activities: [] }} mode="cpm" onChange={() => {}} errors={["Add at least one activity."]} />
    );
    expect(html).toContain("Add at least one activity.");
  });

  it("PERT mode shows the computed expected duration and variance next to the estimates", () => {
    const html = renderToStaticMarkup(<ProblemInput problem={cpmExamples[4].problem} mode="pert" onChange={() => {}} errors={[]} />);
    expect(html).toContain(">4<"); // te of A = 4
    expect(html).toContain(">1.7778<"); // var of A = 16/9
  });
});

describe("CPMView renders every step of every example without throwing", () => {
  cpmExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveCPM(ex.problem, ex.mode);
      expect(result.steps.length).toBeGreaterThan(0);
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<CPMView state={step.state} timeMax={result.projectDuration} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
        expect(html, `step ${i} has no Gantt`).toContain("<svg");
        for (const a of ex.problem.activities) expect(html, `step ${i} misses ${a.name}`).toContain(`>${a.name}<`);
      });
    });
  });

  it("shows PERT columns only for PERT, and variance/σ only once the summary step is reached", () => {
    const pert = solveCPM(cpmExamples[4].problem, "pert");
    const first = renderToStaticMarkup(<CPMView state={pert.steps[0].state} />);
    const last = renderToStaticMarkup(<CPMView state={pert.steps[pert.steps.length - 1].state} />);
    expect(first).toContain("a / m / b");
    expect(first).not.toContain("σ =");
    expect(last).toContain("σ = 1.6997");

    const cpm = solveCPM(cpmExamples[1].problem, "cpm");
    expect(renderToStaticMarkup(<CPMView state={cpm.steps[3].state} />)).not.toContain("a / m / b");
  });

  it("forward-pass steps show the phase badge, highlight the current row, and leave uncomputed cells blank", () => {
    const r = solveCPM(cpmExamples[1].problem, "cpm");
    const step = r.steps.find((s) => s.title.startsWith("Forward pass — B"))!;
    const html = renderToStaticMarkup(<CPMView state={step.state} />);
    expect(html).toContain("Forward pass");
    expect(html).toContain("bg-gold/10"); // the current row
    expect(html).toContain("text-graphite/30"); // the "·" placeholders for LS/LF/slack of every row
  });

  it("critical-path steps list the discovered path(s) and highlight the newest", () => {
    const r = solveCPM(cpmExamples[2].problem, "cpm");
    const found = r.steps.filter((s) => s.state.stepKind === "critical-path-found");
    const html = renderToStaticMarkup(<CPMView state={found[1].state} />);
    expect(html).toContain("A → B → D → G → H");
    expect(html).toContain("A → C → E → G → H");
    expect(html).toContain("Critical paths found so far");
    expect(html).toContain("border-sienna");
  });
});

describe("CPMGantt", () => {
  it("draws no bars before the forward pass has computed anything", () => {
    const r = solveCPM(cpmExamples[1].problem, "cpm");
    const html = renderToStaticMarkup(<CPMGantt state={r.steps[0].state} />);
    expect(html).not.toContain("<title>");
  });

  it("draws one bar per computed activity, and colours the critical ones after the slack step", () => {
    const r = solveCPM(cpmExamples[1].problem, "cpm");
    const afterForward = renderToStaticMarkup(<CPMGantt state={r.steps.find((s) => s.state.stepKind === "forward-complete")!.state} />);
    expect((afterForward.match(/<title>/g) ?? []).length).toBe(4);
    const afterSlack = renderToStaticMarkup(<CPMGantt state={r.steps.find((s) => s.state.stepKind === "slack")!.state} timeMax={11} />);
    expect((afterSlack.match(/fill="#B5482A"/g) ?? []).length).toBeGreaterThanOrEqual(3); // A, C, D critical
    expect(afterSlack).toContain("slack 2"); // B's float label
  });

  it("dims activities that are not on the critical path currently being shown", () => {
    const r = solveCPM(cpmExamples[1].problem, "cpm");
    const step = r.steps.find((s) => s.state.stepKind === "critical-path-found")!;
    expect(renderToStaticMarkup(<CPMGantt state={step.state} />)).toContain('opacity="0.3"');
  });

  it("niceStep picks 1/2/5 × 10ⁿ spacings that keep the axis to about ten gridlines or fewer", () => {
    expect(niceStep(10)).toBe(1);
    expect(niceStep(11)).toBe(2);
    expect(niceStep(20)).toBe(2);
    expect(niceStep(44)).toBe(5);
    expect(niceStep(1000)).toBe(100);
    expect(niceStep(0.8)).toBeCloseTo(0.1, 12);
    expect(niceStep(0)).toBeGreaterThan(0);
    for (const max of [1, 3, 7, 13, 24, 44, 99, 250, 1234]) expect(max / niceStep(max)).toBeLessThanOrEqual(10.0001);
  });
});

describe("CPM wiring", () => {
  it("the sidebar marks CPM / PERT as ready", () => {
    const cpm = modules.find((m) => m.id === "cpm")!;
    expect(cpm.ready).toBe(true);
    expect(cpm.label).toBe("CPM / PERT");
  });

  it("the dashboard mentions CPM / PERT among the implemented modules", () => {
    const html = renderToStaticMarkup(<Dashboard onSelect={() => {}} />);
    expect(html).toContain("CPM / PERT (forward and backward passes");
  });

  it("the algorithm reference documents the forward/backward pass, slack and PERT", () => {
    const html = renderToStaticMarkup(<Help />);
    expect(html).toContain("CPM: forward and backward pass");
    expect(html).toContain("Slack and the critical path");
    expect(html).toContain("PERT (three-point estimates)");
  });
});
