import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Game } from "../Game";
import { Help } from "../Help";
import { Sidebar, modules } from "../../components/Sidebar";
import { GameView, formatLP, EquilibriaList } from "../../components/game/GameView";
import { GameInputForm } from "../../components/game/GameInputForm";
import { PayoffTable } from "../../components/game/PayoffTable";
import { gameExamples } from "../../algorithms/game/examples";
import { solveGame } from "../../algorithms/game/solve";
import { MAX_STRATEGIES } from "../../algorithms/game/common";
import { GameInput } from "../../types/game";

const noop = () => {};
const example = (name: string) => gameExamples.find((e) => e.name === name)!.problem;
const html = (el: JSX.Element) => renderToStaticMarkup(el);
const stepHtml = (name: string, kind: string) => {
  const r = solveGame(example(name));
  const step = r.steps.find((s) => s.state.stepKind === kind);
  expect(step, `${name}: ${kind}`).toBeDefined();
  return html(<GameView state={step!.state} />);
};

describe("Game page", () => {
  it("renders the initial (unsolved) page with the input tables, example picker and Save & share", () => {
    const out = html(<Game />);
    expect(out).toContain("Game Theory");
    expect(out).toContain("Load example");
    expect(out).toContain("Player 1 (row player) payoffs");
    expect(out).toContain("Player 2 (column player) payoffs");
    expect(out).toContain('aria-label="Save and share"');
    expect(out).toContain("Problem (.json)");
    // the controls that make no sense on paper are hidden when printing
    expect(out).toMatch(/gap-3 rounded border border-rule bg-white p-4 print:hidden/);
    expect(out).toMatch(/print:hidden">\s*Load example/);
    // nothing has been solved yet
    expect(out).not.toMatch(/\d+ Nash equilibri(um|a) found/);
  });

  it("every built-in example is offered in the picker", () => {
    const out = html(<Game />);
    for (const ex of gameExamples) expect(out, ex.name).toContain(ex.name.replace(/'/g, "&#x27;"));
  });

  it("is registered in the sidebar as ready, and the sidebar renders it", () => {
    const g = modules.find((m) => m.id === "game")!;
    expect(g.ready).toBe(true);
    expect(html(<Sidebar active="game" onSelect={noop} />)).toContain("Game Theory");
  });

  it("the algorithm reference explains the game theory ideas", () => {
    const out = html(<Help />);
    for (const t of ["Best responses and pure Nash equilibria", "Dominance and iterated elimination", "Support enumeration", "Degenerate games", "Zero-sum games, minimax and the LP"]) {
      expect(out).toContain(t.replace(/&/g, "&amp;"));
    }
  });
});

describe("GameInputForm", () => {
  const bos = example("Battle of the Sexes");
  it("general-sum: shows both payoff tables", () => {
    const out = html(<GameInputForm problem={bos} onChange={noop} errors={[]} />);
    expect(out).toContain("Player 1 (row player) payoffs");
    expect(out).toContain("Player 2 (column player) payoffs");
    expect((out.match(/type="number"/g) ?? []).length).toBe(8);
    expect(out).not.toContain("readOnly");
  });

  it("zero-sum: shows only Player 1's table (Player 2's is derived)", () => {
    const mp = example("Matching Pennies");
    const out = html(<GameInputForm problem={mp} onChange={noop} errors={[]} />);
    expect(out).toContain("Player 1 (row player) payoffs");
    expect(out).not.toContain("Player 2 (column player) payoffs");
    expect((out.match(/type="number"/g) ?? []).length).toBe(4);
    expect(out).toContain('checked=""');
  });

  it("shows validation errors", () => {
    const out = html(<GameInputForm problem={bos} onChange={noop} errors={["Each player needs at least one strategy."]} />);
    expect(out).toContain("at least one strategy");
  });

  it("disables the add buttons at the strategy cap", () => {
    const big: GameInput = {
      rowNames: Array.from({ length: MAX_STRATEGIES }, (_, i) => `R${i}`),
      colNames: Array.from({ length: MAX_STRATEGIES }, (_, i) => `C${i}`),
      payoffA: Array.from({ length: MAX_STRATEGIES }, () => Array(MAX_STRATEGIES).fill(0)),
      payoffB: Array.from({ length: MAX_STRATEGIES }, () => Array(MAX_STRATEGIES).fill(0)),
      zeroSum: false,
    };
    const out = html(<GameInputForm problem={big} onChange={noop} errors={[]} />);
    const buttons = out.split("<button").filter((c) => c.includes("Add Player"));
    expect(buttons).toHaveLength(2);
    for (const b of buttons) expect(b).toContain('disabled=""');
    const small = html(<GameInputForm problem={bos} onChange={noop} errors={[]} />);
    for (const b of small.split("<button").filter((c) => c.includes("Add Player"))) expect(b).not.toContain('disabled=""');
  });

  it("hides the remove buttons when only one strategy is left", () => {
    const one: GameInput = { rowNames: ["Only"], colNames: ["Col"], payoffA: [[1]], payoffB: [[2]], zeroSum: false };
    const out = html(<GameInputForm problem={one} onChange={noop} errors={[]} />);
    expect(out).not.toContain("Remove row strategy");
    expect(out).not.toContain("Remove column strategy");
  });
});

describe("GameView renders every step of every built-in example", () => {
  gameExamples.forEach((ex) => {
    it(ex.name, () => {
      const r = solveGame(ex.problem);
      expect(r.status).toBe("solved");
      r.steps.forEach((s, i) => {
        const out = html(<GameView state={s.state} />);
        expect(out.length, `step ${i} (${s.title})`).toBeGreaterThan(0);
        expect(out, `step ${i} (${s.title}) has no payoff table`).toContain('data-testid="payoff-table"');
        expect(out).not.toMatch(/undefined|NaN|\[object Object\]/);
      });
    });
  });
});

describe("GameView content", () => {
  it("best-response steps underline best responses; a shaded cell marks a pure equilibrium", () => {
    const r = solveGame(example("Prisoner's Dilemma"));
    const br = html(<GameView state={r.steps.find((s) => s.state.stepKind === "row-br")!.state} />);
    expect(br).toContain("border-forest");
    expect(br).toContain("best response to");
    const pure = html(<GameView state={r.steps.find((s) => s.state.stepKind === "pure-equilibria")!.state} />);
    expect(pure).toContain("bg-forest/15");
  });

  it("dominance rounds name the eliminated strategy and its dominator, and strike eliminated ones through", () => {
    const r = solveGame(example("Solvable by iterated dominance"));
    const rounds = r.steps.filter((s) => s.state.stepKind === "dominance-round");
    expect(rounds).toHaveLength(4);
    const first = html(<GameView state={rounds[0].state} />);
    expect(first).toContain("Round 1");
    expect(first).toContain("strictly dominated by");
    const last = html(<GameView state={rounds[3].state} />);
    expect(last).toContain("line-through");
  });

  it("the dominant-strategy summary says so for a game that has one", () => {
    expect(stepHtml("Prisoner's Dilemma", "dominant")).toContain("strictly dominant");
    expect(stepHtml("Matching Pennies", "dominant")).toContain("no dominant strategy");
  });

  it("zero-sum: security levels, both LPs, then the solution with the exact value", () => {
    const sec = stepHtml("Zero-sum game needing the LP", "security");
    expect(sec).toContain("Maximin");
    expect(sec).toContain("Minimax");
    const lp1 = stepHtml("Zero-sum game needing the LP", "lp-row");
    expect(lp1).toContain("minimize");
    expect(lp1).toContain("≥ 1");
    expect(lp1).toContain("vs C1");
    expect(lp1).toContain("shifted by +3");
    const lp2 = stepHtml("Zero-sum game needing the LP", "lp-col");
    expect(lp2).toContain("maximize");
    const sol = stepHtml("Zero-sum game needing the LP", "zero-sum-solution");
    expect(sol).toContain("8/17");
    expect(sol).toContain("Value of the game");
  });

  it("zero-sum saddle-point game: the security step shades the saddle cell, and the LP still confirms the value", () => {
    const r = solveGame(example("Saddle-point zero-sum game"));
    const sec = html(<GameView state={r.steps.find((s) => s.state.stepKind === "security")!.state} />);
    expect(sec).toContain("Maximin");
    expect(sec).toContain("bg-forest/15");
    expect(r.value).toBe("3");
    expect(stepHtml("Saddle-point zero-sum game", "zero-sum-solution")).toContain("Value of the game");
  });

  it("the LP steps replay the exact simplex tableaux, opened when the full solution is shown", () => {
    const r = solveGame(example("Zero-sum game needing the LP"));
    const st = r.steps.find((s) => s.state.stepKind === "lp-row")!.state;
    const closed = html(<GameView state={st} />);
    expect(closed).toContain("Simplex tableaux (");
    expect(closed).toContain("Phase");
    expect(closed).not.toContain("<details open");
    expect(html(<GameView state={st} expanded />)).toContain("<details open");
    const dual = html(<GameView state={r.steps.find((s) => s.state.stepKind === "lp-col")!.state} />);
    expect(dual).toContain("Simplex tableaux (");
  });

  it("support enumeration lists each pair with its outcome and equations, and the tally", () => {
    const r = solveGame(example("Rock-Paper-Scissors"));
    const size3 = r.steps.filter((s) => s.state.stepKind === "supports-size").pop()!;
    const out = html(<GameView state={size3.state} />);
    expect(out).toContain('data-outcome="equilibrium"');
    expect(out).toContain("Indifference equations");
    expect(out).toContain("1/3");
    expect(out).toContain("Equilibrium: 1");
    expect(out).toContain("pairs tried");
    expect(r.steps.find((s) => s.state.stepKind === "supports-overview")!.title).toContain("support pairs to try");
  });

  it("the degeneracy verdict is shown, with the witness when the game is degenerate", () => {
    expect(stepHtml("Indifferent row player (degenerate)", "supports-overview")).toContain("Degenerate game.");
    const nd = stepHtml("Battle of the Sexes", "supports-overview");
    expect(nd).toContain("Nondegenerate game");
    expect(nd).not.toContain("Degenerate game.");
  });

  it("the summary lists every equilibrium with exact probabilities and bars", () => {
    const r = solveGame(example("Battle of the Sexes"));
    const out = html(<GameView state={r.steps[r.steps.length - 1].state} />);
    expect((out.match(/data-testid="equilibrium"/g) ?? []).length).toBe(3);
    expect(out).toContain("2/3");
    expect(out).toContain("1/3");
    expect(out).toContain("Mixed");
    expect(out).toContain("width:");
  });

  it("EquilibriaList uses the singular for one equilibrium", () => {
    const r = solveGame(example("Prisoner's Dilemma"));
    const st = r.steps[r.steps.length - 1].state;
    expect(html(<EquilibriaList equilibria={st.equilibria} state={st} />)).toContain("equilibrium found so far: 1");
  });
});

describe("PayoffTable", () => {
  it("zero-sum tables show a single number per cell; general-sum tables show both payoffs", () => {
    const zs = solveGame(example("Matching Pennies")).steps[0].state;
    const gs = solveGame(example("Battle of the Sexes")).steps[0].state;
    expect(html(<PayoffTable state={zs} />)).not.toContain(" , ");
    expect(html(<PayoffTable state={gs} />)).toContain(" , ");
  });

  it("the setup step has no best-response legend yet", () => {
    const st = solveGame(example("Battle of the Sexes")).steps[0].state;
    expect(html(<PayoffTable state={st} />)).not.toContain("underline");
  });
});

describe("formatLP", () => {
  it("writes a minimization LP in plain algebra", () => {
    const lines = formatLP({
      sense: "min",
      variables: ["y1", "y2", "y3"],
      objective: [1, 1, 1],
      constraints: [
        { coeffs: [7, 2, 0], relation: ">=", rhs: 1, label: "vs C1" },
        { coeffs: [0, -1, 3], relation: ">=", rhs: 1 },
      ],
    });
    expect(lines).toEqual(["minimize  y1 + y2 + y3", "7y1 + 2y2 ≥ 1    (vs C1)", "−y2 + 3y3 ≥ 1", "y1, y2, y3 ≥ 0"]);
  });
});
