import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Network } from "../../pages/Network";
import { GraphEditor } from "../../components/network/GraphEditor";
import { ShortestPathView } from "../../components/network/ShortestPathView";
import { MSTView } from "../../components/network/MSTView";
import { MaxFlowView } from "../../components/network/MaxFlowView";
import { shortestPathExamples, mstExamples, maxFlowExamples } from "../../algorithms/network/examples";
import { solveDijkstra } from "../../algorithms/network/dijkstra";
import { solveMST } from "../../algorithms/network/mst";
import { solveMaxFlow } from "../../algorithms/network/maxflow";

describe("Network page renders without throwing", () => {
  it("renders the initial (unsolved) page", () => {
    const html = renderToStaticMarkup(<Network />);
    expect(html).toContain("Network");
    expect(html).toContain("Routing");
  });
});

describe("GraphEditor renders every example graph without throwing", () => {
  [...shortestPathExamples.map((e) => e.problem.graph), ...mstExamples.map((e) => e.graph), ...maxFlowExamples.map((e) => e.problem.graph)].forEach(
    (graph, i) => {
      it(`graph ${i}`, () => {
        const html = renderToStaticMarkup(<GraphEditor graph={graph} onChange={() => {}} errors={[]} />);
        expect(html.length).toBeGreaterThan(0);
      });
    }
  );
});

describe("ShortestPathView renders every step of every non-error example without throwing", () => {
  shortestPathExamples
    .filter((ex) => ex.problem.graph.edges.every((e) => e.weight >= 0))
    .forEach((ex) => {
      it(ex.name, () => {
        const result = solveDijkstra(ex.problem);
        result.steps.forEach((step, i) => {
          const html = renderToStaticMarkup(
            <ShortestPathView graph={ex.problem.graph} state={step.state} source={ex.problem.source} />
          );
          expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
        });
      });
    });
});

describe("MSTView renders every step of every example, both methods, without throwing", () => {
  mstExamples.forEach((ex) => {
    it(`${ex.name} — kruskal`, () => {
      const result = solveMST({ graph: ex.graph, method: "kruskal" });
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<MSTView state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
    it(`${ex.name} — prim`, () => {
      const result = solveMST({ graph: ex.graph, method: "prim", startNode: ex.defaultStartNode });
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<MSTView state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});

describe("MaxFlowView renders every step of every example without throwing", () => {
  maxFlowExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveMaxFlow(ex.problem);
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(
          <MaxFlowView state={step.state} source={ex.problem.source} sink={ex.problem.sink} />
        );
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});
