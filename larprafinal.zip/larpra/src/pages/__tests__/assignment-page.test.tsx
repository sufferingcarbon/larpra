import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Assignment } from "../../pages/Assignment";
import { ProblemInput } from "../../components/assignment/ProblemInput";
import { AssignmentGrid } from "../../components/assignment/AssignmentGrid";
import { assignmentExamples } from "../../algorithms/assignment/examples";
import { solveAssignment } from "../../algorithms/assignment/solve";

describe("Assignment page renders without throwing", () => {
  it("renders the initial (unsolved) page", () => {
    const html = renderToStaticMarkup(<Assignment />);
    expect(html).toContain("Assignment Problem");
  });
});

describe("ProblemInput renders every example without throwing", () => {
  assignmentExamples.forEach((ex) => {
    it(ex.name, () => {
      const html = renderToStaticMarkup(<ProblemInput problem={ex.problem} onChange={() => {}} errors={[]} />);
      expect(html.length).toBeGreaterThan(0);
    });
  });
});

describe("AssignmentGrid renders every step of every example without throwing", () => {
  assignmentExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveAssignment(ex.problem);
      result.steps.forEach((step, i) => {
        const html = renderToStaticMarkup(<AssignmentGrid state={step.state} />);
        expect(html.length, `step ${i} (${step.title}) rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});
