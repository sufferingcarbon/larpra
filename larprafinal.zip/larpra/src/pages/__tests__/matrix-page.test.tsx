import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Matrix } from "../Matrix";
import { Help } from "../Help";
import { Sidebar, modules } from "../../components/Sidebar";
import { MatrixView } from "../../components/matrix/MatrixView";
import { ProblemInput } from "../../components/matrix/ProblemInput";
import { matrixExamples } from "../../algorithms/matrix/examples";
import { solveMatrix } from "../../algorithms/matrix/solve";
import { MatrixInput } from "../../types/matrix";

const noop = () => {};
const example = (name: string) => matrixExamples.find((e) => e.name === name)!.problem;
const html = (el: JSX.Element) => renderToStaticMarkup(el);

describe("Matrix page", () => {
  it("renders the initial (unsolved) page with the input grid, example picker and Save & share", () => {
    const out = html(<Matrix />);
    expect(out).toContain("Matrix / Linear Equations");
    expect(out).toContain("Load example");
    expect(out).toContain('aria-label="Save and share"');
    expect(out).toContain("Problem (.json)");
    expect(out).toMatch(/gap-3 rounded border border-rule bg-white p-4 print:hidden/);
    expect(out).toMatch(/print:hidden">\s*Load example/);
    expect(out).not.toContain("Unique solution");
  });

  it("every built-in example is offered in the picker", () => {
    const out = html(<Matrix />);
    for (const ex of matrixExamples) expect(out, ex.name).toContain(ex.name);
  });

  it("is registered in the sidebar as ready, and the sidebar renders it", () => {
    const m = modules.find((mod) => mod.id === "matrix")!;
    expect(m.ready).toBe(true);
    expect(html(<Sidebar active="matrix" onSelect={noop} />)).toContain("Matrix");
  });

  it("the algorithm reference explains the matrix module's ideas", () => {
    const out = html(<Help />);
    for (const t of [
      "Row echelon form and Gaussian elimination",
      "Classifying Ax = b: unique, none, or infinitely many",
      "Determinant by cofactor expansion",
      "Matrix inverse by Gauss-Jordan elimination",
      "Rank and the rank",
      "Nullspace basis",
      "Characteristic polynomial and eigenvalues",
      "Eigenvectors and defective matrices",
    ]) {
      expect(out, t).toContain(t.replace(/&/g, "&amp;"));
    }
  });
});

describe("ProblemInput", () => {
  const sys = example("2×2 system, unique solution");

  it("gaussian operation: shows the matrix grid plus an rhs (b) column", () => {
    const out = html(<ProblemInput problem={sys} onChange={noop} errors={[]} />);
    expect(out).toContain(">b<");
    expect((out.match(/type="number"/g) ?? []).length).toBe(6); // 2x2 matrix + 2 rhs entries
  });

  it("non-gaussian operation: no rhs column", () => {
    const det = example("Determinant of a 3×3 matrix");
    const out = html(<ProblemInput problem={det} onChange={noop} errors={[]} />);
    expect(out).not.toContain(">b<");
    expect((out.match(/type="number"/g) ?? []).length).toBe(9);
  });

  it("shows validation errors", () => {
    const out = html(<ProblemInput problem={sys} onChange={noop} errors={["The matrix needs at least one row and one column."]} />);
    expect(out).toContain("at least one row");
  });

  it("hides remove-row/column controls when only one row or column remains", () => {
    const one: MatrixInput = { operation: "rank", matrix: [[5]] };
    const out = html(<ProblemInput problem={one} onChange={noop} errors={[]} />);
    expect(out).not.toContain("Remove row 1");
    expect(out).not.toContain("Remove column 1");
  });

  it("disables the add-row/column buttons at MAX_DIM", () => {
    const big: MatrixInput = { operation: "rank", matrix: Array.from({ length: 6 }, () => Array(6).fill(0)) };
    const out = html(<ProblemInput problem={big} onChange={noop} errors={[]} />);
    const buttons = out.split("<button").filter((c) => c.includes("Add row") || c.includes("Add column"));
    expect(buttons.length).toBeGreaterThan(0);
    for (const b of buttons) expect(b).toContain('disabled=""');
  });

  it("disables the add-column button (but not add-row) for square-only operations", () => {
    const inv = example("Inverse of a 2×2 matrix");
    const out = html(<ProblemInput problem={inv} onChange={noop} errors={[]} />);
    const addCol = out.split("<button").find((c) => c.includes("Add column"))!;
    expect(addCol).toContain('disabled=""');
  });
});

describe("MatrixView renders every step of every built-in example", () => {
  matrixExamples.forEach((ex) => {
    it(ex.name, () => {
      const r = solveMatrix(ex.problem);
      expect(r.status).toBe("solved");
      r.steps.forEach((s, i) => {
        const out = html(<MatrixView state={s.state} />);
        expect(out.length, `step ${i} (${s.title})`).toBeGreaterThan(0);
        expect(out, `step ${i} (${s.title}) has no matrix view`).toContain('data-testid="matrix-view"');
        expect(out, `step ${i} (${s.title})`).not.toMatch(/undefined|NaN|\[object Object\]/);
      });
    });
  });
});

describe("MatrixView content", () => {
  it("Ax=b: unique solution is shown with every variable's value", () => {
    const r = solveMatrix(example("2×2 system, unique solution"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("Unique solution");
    expect(out).toContain("x1 = 2");
    expect(out).toContain("x2 = 1");
  });

  it("Ax=b: no solution shows the contradiction", () => {
    const r = solveMatrix(example("2×2 system, no solution"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("No solution");
    expect(out).toMatch(/0 = /);
  });

  it("Ax=b: infinitely many solutions shows the parametric lines", () => {
    const r = solveMatrix(example("2×2 system, infinitely many solutions"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("Infinitely many solutions");
    expect(out).toContain("free");
  });

  it("determinant: the cofactor tree is rendered with the final value and invertibility", () => {
    const r = solveMatrix(example("Determinant of a 3×3 matrix"));
    const summary = r.steps.find((s) => s.state.stepKind === "summary")!;
    const out = html(<MatrixView state={summary.state} />);
    expect(out).toContain("det(A) =");
    expect(out).toContain("invertible");
  });

  it("determinant: a singular matrix is flagged", () => {
    const r = solveMatrix(example("Determinant of a singular matrix"));
    const summary = r.steps.find((s) => s.state.stepKind === "summary")!;
    const out = html(<MatrixView state={summary.state} />);
    expect(out).toContain("singular");
  });

  it("inverse: shows A, A⁻¹ side by side, and the verified product", () => {
    const r = solveMatrix(example("Inverse of a 2×2 matrix"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("A⁻¹");
    expect(out).toContain("verified");
  });

  it("inverse: a singular matrix reports no inverse exists", () => {
    const r = solveMatrix(example("Attempted inverse of a singular matrix"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("No inverse exists");
  });

  it("rank/nullspace: shows the basis vectors and parametric form for a deficient matrix", () => {
    const r = solveMatrix(example("Rank and nullspace of a rank-deficient matrix"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("Nullspace basis");
    expect(out).toContain("v1 =");
  });

  it("rank/nullspace: trivial nullspace is shown for a full-rank matrix", () => {
    const r = solveMatrix(example("Rank of a full-rank rectangular matrix"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("{0}");
  });

  it("eigen: the characteristic polynomial and eigenvalue table are rendered", () => {
    const r = solveMatrix(example("Eigenvalues of a symmetric 2×2 matrix"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("det(A − λI)");
    expect(out).toContain("λ");
  });

  it("eigen: complex eigenvalues are marked as not computed exactly for the eigenvector", () => {
    const r = solveMatrix(example("Eigenvalues of a 2×2 rotation matrix (complex)"));
    const last = r.steps[r.steps.length - 1];
    const out = html(<MatrixView state={last.state} />);
    expect(out).toContain("not computed exactly");
  });

  it("eigen: a defective matrix's step explanation names the eigenspace as defective", () => {
    const r = solveMatrix(example("Eigenvalues of a defective 2×2 matrix"));
    const eigStep = r.steps.find((s) => s.state.stepKind === "eigenvector-result");
    expect(eigStep).toBeDefined();
    expect(eigStep!.explanation).toContain("defective");
    // and the view itself shows the geometric multiplicity is below the algebraic one
    const out = html(<MatrixView state={eigStep!.state} />);
    expect(out).toMatch(/<td class="text-center">2<\/td>/); // algebraic multiplicity 2
    expect(out).toMatch(/<td class="text-center">1<\/td>/); // geometric multiplicity 1
  });

  it("the tableau highlights the pivot cell and shows the row operation in textbook notation", () => {
    const r = solveMatrix(example("3×3 system, unique solution"));
    const swapStep = r.steps.find((s) => s.state.stepKind === "swap")!;
    expect(swapStep.title).toContain("Swap R1");
    const out = html(<MatrixView state={swapStep.state} />);
    expect(out).toContain('data-testid="tableau"');
    expect(out).toContain("R1 ↔ R2");
  });
});
