import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { IntegerProgramming } from "../../pages/IntegerProgramming";
import { IPProblemInput } from "../../components/integer/ProblemInput";
import { BnBTreeView } from "../../components/integer/BnBTreeView";
import { NodeDetail } from "../../components/integer/NodeDetail";
import { ipExamples } from "../../algorithms/integer/examples";
import { solveIP } from "../../algorithms/integer/branchAndBound";

describe("Integer Programming page renders without throwing", () => {
  it("renders the initial (unsolved) page", () => {
    const html = renderToStaticMarkup(<IntegerProgramming />);
    expect(html).toContain("Integer Programming");
  });
});

describe("IPProblemInput renders every example without throwing", () => {
  ipExamples.forEach((ex, i) => {
    it(`example ${i}: ${ex.name}`, () => {
      const html = renderToStaticMarkup(<IPProblemInput problem={ex.problem} onChange={() => {}} errors={[]} />);
      expect(html.length).toBeGreaterThan(0);
    });
  });
});

describe("BnBTreeView renders every example at every step, and NodeDetail renders every node", () => {
  ipExamples.forEach((ex) => {
    it(ex.name, () => {
      const result = solveIP(ex.problem);
      result.steps.forEach((_, i) => {
        const html = renderToStaticMarkup(<BnBTreeView problem={ex.problem} tree={result.tree} stepIndex={i} onOpenNode={() => {}} />);
        expect(html.length, `step ${i} rendered nothing`).toBeGreaterThan(0);
      });
      result.tree.forEach((node) => {
        const html = renderToStaticMarkup(<NodeDetail problem={ex.problem} node={node} onClose={() => {}} />);
        expect(html.length, `node P${node.id} rendered nothing`).toBeGreaterThan(0);
      });
    });
  });
});
