import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { Transportation } from "../../pages/Transportation";
import { ProblemInput } from "../../components/transportation/ProblemInput";
import { transportationExamples } from "../../algorithms/transportation/examples";

describe("Transportation page renders without throwing", () => {
  it("renders the initial (unsolved) page", () => {
    const html = renderToStaticMarkup(<Transportation />);
    expect(html).toContain("Transportation Problem");
  });
});

describe("ProblemInput renders every example without throwing", () => {
  transportationExamples.forEach((ex) => {
    it(ex.name, () => {
      const html = renderToStaticMarkup(<ProblemInput problem={ex.problem} onChange={() => {}} errors={[]} />);
      expect(html.length).toBeGreaterThan(0);
    });
  });
});
