import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { ExportBar } from "../../components/ExportBar";
import { Sidebar } from "../../components/Sidebar";
import { StepControls } from "../../components/StepControls";
import { LinearProgramming } from "../LinearProgramming";
import { Transportation } from "../Transportation";
import { Assignment } from "../Assignment";
import { Network } from "../Network";
import { TSP } from "../TSP";
import { CPM } from "../CPM";
import { Game } from "../Game";
import { Matrix } from "../Matrix";
import { cpmExamples } from "../../algorithms/cpm/examples";
import { solveCPM } from "../../algorithms/cpm/solve";

const payload = { problem: cpmExamples[1].problem, options: { mode: "cpm" as const } };
const noop = () => {};

describe("ExportBar", () => {
  it("before solving: problem export and import are available, solution export and PDF are disabled", () => {
    const html = renderToStaticMarkup(<ExportBar module="cpm" payload={payload} solved={null} onImport={noop} />);
    expect(html).toContain("Save &amp; share");
    expect(html).toContain("Problem (.json)");
    expect(html).toContain("Import…");
    const button = (label: string) => html.split("<button").find((chunk) => chunk.includes(label)) ?? "";
    for (const label of ["Solution (.json)", "Save as PDF"]) {
      expect(button(label), label).toContain('disabled=""');
      expect(button(label), label).toContain('title="Solve first"');
    }
    for (const label of ["Problem (.json)", "Import…"]) expect(button(label), label).not.toContain('disabled=""');
    expect(html).not.toContain("print:block"); // no print-only caption without a solution
  });

  it("after solving: everything is enabled and a print-only caption names the method", () => {
    const solved = { payload, result: solveCPM(payload.problem, "cpm") };
    const html = renderToStaticMarkup(
      <ExportBar module="cpm" payload={payload} solved={solved} onImport={noop} subtitle="CPM / PERT — CPM (single durations)" />
    );
    expect(html).not.toContain('disabled=""'); // (class names contain "disabled:" variants, so match the attribute)
    expect(html).toContain("hidden text-sm print:block");
    expect(html).toContain("CPM / PERT — CPM (single durations)");
    expect(html).toContain("full step-by-step solution");
  });

  it("the whole controls card is hidden when printing, and the file input only accepts JSON", () => {
    const html = renderToStaticMarkup(<ExportBar module="lp" payload={{ problem: { sense: "max", objective: [1], variables: ["x"], constraints: [] }, options: {} }} solved={null} onImport={noop} />);
    expect(html).toContain("print:hidden");
    expect(html).toContain('accept=".json,application/json"');
    expect(html).toContain("Import a larpra Linear Programming file");
  });
});

describe("Every module page offers Save & share", () => {
  const pages: [string, JSX.Element][] = [
    ["Linear Programming", <LinearProgramming />],
    ["Transportation", <Transportation />],
    ["Assignment", <Assignment />],
    ["Network & Routing", <Network />],
    ["Traveling Salesman", <TSP />],
    ["CPM / PERT", <CPM />],
    ["Game Theory", <Game />],
    ["Matrix / Linear Equations", <Matrix />],
  ];
  pages.forEach(([name, page]) => {
    it(name, () => {
      const html = renderToStaticMarkup(page);
      expect(html).toContain('aria-label="Save and share"');
      expect(html).toContain("Problem (.json)");
      // the Solve/Reset bar and the example pickers are hidden in print
      expect(html).toMatch(/gap-3 rounded border border-rule bg-white p-4 print:hidden/);
      expect(html).toMatch(/print:hidden">\s*Load example/);
    });
  });
});

// The stylesheet itself (page breaks, un-clipped layout, hidden controls) is verified by rendering real PDFs in a browser.
describe("Print chrome", () => {
  it("the sidebar and the step controls are hidden when printing", () => {
    expect(renderToStaticMarkup(<Sidebar active="cpm" onSelect={noop} />)).toContain("md:block print:hidden");
    expect(renderToStaticMarkup(<StepControls index={0} total={3} onChange={noop} onShowFullSolution={noop} onReset={noop} />)).toContain("print:hidden");
  });
});
