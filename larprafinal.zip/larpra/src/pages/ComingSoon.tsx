import { Hammer } from "lucide-react";

export function ComingSoon({ moduleName }: { moduleName: string }) {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-start px-6 py-16">
      <Hammer size={28} className="text-graphite" />
      <h1 className="mt-4 font-display text-xl font-semibold text-ink">{moduleName}</h1>
      <p className="mt-2 text-sm text-graphite">
        This module is staged for a later development milestone and isn't implemented yet. Rather
        than fake a solver for it, larpra simply doesn't claim to support it until the real
        algorithm is built and tested — see the Linear Programming module for what a finished
        module looks like.
      </p>
    </div>
  );
}
