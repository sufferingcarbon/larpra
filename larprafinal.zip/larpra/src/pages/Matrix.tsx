import { useMemo, useState } from "react";
import { MatrixInput, MatrixResult } from "../types/matrix";
import { solveMatrix } from "../algorithms/matrix/solve";
import { validateMatrix } from "../algorithms/matrix/common";
import { matrixExamples } from "../algorithms/matrix/examples";
import { ProblemInput } from "../components/matrix/ProblemInput";
import { MatrixView } from "../components/matrix/MatrixView";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";

const defaultProblem: MatrixInput = structuredClone((matrixExamples.find((e) => e.name === "2×2 system, unique solution") ?? matrixExamples[0]).problem);

export function Matrix() {
  const [problem, setProblem] = useState<MatrixInput>(defaultProblem);
  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [result, setResult] = useState<MatrixResult | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["matrix"] | null>(null);

  const errors = useMemo(() => validateMatrix(problem), [problem]);

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      const r = solveMatrix(problem);
      setSolvedPayload({ problem: structuredClone(problem), options: {} });
      setResult(r);
      setStepIndex(0);
      setShowFull(false);
      setShowWhy(false);
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
      setResult(null);
    }
  };

  const reset = () => {
    setResult(null);
    setStepIndex(0);
    setShowFull(false);
    setShowWhy(false);
    setRunError(null);
  };

  const loadExample = (name: string) => {
    const ex = matrixExamples.find((e) => e.name === name);
    if (ex) {
      setProblem(structuredClone(ex.problem));
      reset();
    }
  };

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };

  const importPayload = (p: PayloadMap["matrix"]) => {
    setProblem(p.problem);
    reset();
  };

  const steps = result?.steps ?? [];
  const currentStep = steps[stepIndex];

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Matrix / Linear Equations</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Solve Ax = b by Gaussian elimination and back-substitution, compute determinants by cofactor expansion, invert
        matrices by Gauss-Jordan, find rank and nullspace, and compute eigenvalues and eigenvectors for small matrices —
        every row operation shown as a step, every value an exact fraction.
      </p>

      <section className="mt-6 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="text-sm text-graphite print:hidden">
            Load example:{" "}
            <select className="focus-ring rounded border border-rule px-2 py-1" defaultValue="" onChange={(e) => e.target.value && loadExample(e.target.value)}>
              <option value="" disabled>
                Choose…
              </option>
              {matrixExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <ProblemInput
          problem={problem}
          onChange={(p) => {
            setProblem(p);
            if (result) reset();
          }}
          errors={errors}
        />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <button className="focus-ring rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40" onClick={solve} disabled={errors.length > 0}>
          Solve
        </button>
        <button className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna" onClick={reset}>
          Reset
        </button>
      </section>

      <ExportBar
        module="matrix"
        payload={{ problem, options: {} }}
        solved={result && result.status === "solved" && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={`Matrix / Linear Equations — ${problem.operation}`}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {result && result.status === "solved" && (
        <section className="mt-4 rounded border border-rule bg-white">
          <StatusBanner result={result} />

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark" onClick={() => setShowWhy((w) => !w)}>
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>}
              <MatrixView state={currentStep.state} />
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    <MatrixView state={s.state} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={(i) => {
              setStepIndex(i);
              setShowWhy(false);
            }}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />
        </section>
      )}

      {result && result.status === "invalid" && (
        <div className="mt-4 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {result.notes.map((n, i) => (
              <li key={i}>{n}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function StatusBanner({ result }: { result: MatrixResult }) {
  const a = result.answer;
  let summary: string;
  let ok = true;
  if (a.solution) {
    summary = a.solution.kind === "unique" ? "Unique solution found" : a.solution.kind === "none" ? "No solution" : "Infinitely many solutions";
    ok = a.solution.kind !== "none";
  } else if (a.determinant !== undefined) {
    summary = `det(A) = ${a.determinant}`;
  } else if (a.inverse) {
    summary = a.inverse.singular ? "A is singular — no inverse" : "Inverse computed";
    ok = !a.inverse.singular;
  } else if (a.rank) {
    summary = `rank = ${a.rank.rank}, nullity = ${a.rank.nullity}`;
  } else if (a.eigen) {
    summary = `${a.eigen.eigenvalues.length} eigenvalue${a.eigen.eigenvalues.length === 1 ? "" : "s"} found`;
  } else {
    summary = "Solved";
  }
  return (
    <div className={`flex flex-wrap items-center gap-2 border-b border-rule px-4 py-3 text-sm font-medium ${ok ? "bg-forest/10 text-forestDark" : "bg-sienna/10 text-sienna"}`}>
      {ok ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
      {summary}
    </div>
  );
}
