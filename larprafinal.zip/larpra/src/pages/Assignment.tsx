import { useMemo, useState } from "react";
import { AssignmentProblemInput, AssignmentResult } from "../types/assignment";
import { solveAssignment } from "../algorithms/assignment/solve";
import { validateProblem } from "../algorithms/assignment/standardize";
import { assignmentExamples } from "../algorithms/assignment/examples";
import { ProblemInput } from "../components/assignment/ProblemInput";
import { AssignmentGrid } from "../components/assignment/AssignmentGrid";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2 } from "lucide-react";

const blankProblem: AssignmentProblemInput = {
  workerNames: ["W1", "W2", "W3"],
  taskNames: ["T1", "T2", "T3"],
  costs: [
    [9, 11, 14],
    [6, 15, 13],
    [12, 13, 6],
  ],
};

export function Assignment() {
  const [problem, setProblem] = useState<AssignmentProblemInput>(blankProblem);
  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [result, setResult] = useState<AssignmentResult | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["assignment"] | null>(null);

  const errors = useMemo(() => validateProblem(problem), [problem]);

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      const r = solveAssignment(problem);
      setSolvedPayload({ problem, options: {} });
      setResult(r);
      setStepIndex(0);
      setShowFull(false);
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
      setResult(null);
    }
  };

  const reset = () => {
    setResult(null);
    setStepIndex(0);
    setShowFull(false);
    setRunError(null);
  };

  const loadExample = (name: string) => {
    const ex = assignmentExamples.find((e) => e.name === name);
    if (ex) {
      setProblem(ex.problem);
      setResult(null);
      setStepIndex(0);
      setShowFull(false);
    }
  };

  const steps = result?.steps ?? [];
  const currentStep = steps[stepIndex];

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };
  const importPayload = (p: PayloadMap["assignment"]) => {
    setProblem(p.problem);
    reset();
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Assignment Problem</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Solve the one-to-one worker/task assignment with the Hungarian algorithm — row and
        column reduction, minimum-line zero covering, and augmenting-path matching, every
        cycle shown as its own step.
      </p>

      <section className="mt-6 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="text-sm text-graphite print:hidden">
            Load example:{" "}
            <select
              className="focus-ring rounded border border-rule px-2 py-1"
              defaultValue=""
              onChange={(e) => e.target.value && loadExample(e.target.value)}
            >
              <option value="" disabled>
                Choose…
              </option>
              {assignmentExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <ProblemInput problem={problem} onChange={setProblem} errors={errors} />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <button
          className="focus-ring rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button
          className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
          onClick={reset}
        >
          Reset
        </button>
      </section>

      <ExportBar
        module="assignment"
        payload={{ problem, options: {} }}
        solved={result && result.status !== "invalid" && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle="Assignment Problem — Hungarian algorithm"
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {result && result.status !== "invalid" && (
        <section className="mt-4 rounded border border-rule bg-white">
          <StatusBanner result={result} />

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && (
                <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>
              )}
              <AssignmentGrid state={currentStep.state} />
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    <AssignmentGrid state={s.state} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={setStepIndex}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />

          {result.assignment && <AssignmentSummary result={result} />}
        </section>
      )}

      {result && result.status === "invalid" && (
        <div className="mt-4 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {result.notes.map((n, i) => (
              <li key={i}>{n}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function StatusBanner({ result }: { result: AssignmentResult }) {
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-rule bg-forest/10 px-4 py-3 text-sm font-medium text-forestDark">
      <CheckCircle2 size={16} />
      Optimal assignment found
      {result.totalCost !== undefined && <span className="font-mono">Minimum cost = {result.totalCost}</span>}
      {result.notes.map((n, i) => (
        <span key={i} className="w-full text-xs font-normal opacity-80">
          {n}
        </span>
      ))}
    </div>
  );
}

function AssignmentSummary({ result }: { result: AssignmentResult }) {
  const rows = Object.entries(result.assignment ?? {});
  return (
    <div className="border-t border-rule p-4">
      <h3 className="font-display text-sm font-semibold">Final assignment</h3>
      <table className="ledger-table mt-2 w-full">
        <thead>
          <tr>
            <th>Worker</th>
            <th>Task</th>
          </tr>
        </thead>
        <tbody>
          {rows.map(([worker, task], i) => (
            <tr key={i}>
              <th className="text-left font-sans font-normal text-graphite">{worker}</th>
              <td>{task}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
