import { useMemo, useState } from "react";
import { IPProblem, IPOptions, DEFAULT_IP_OPTIONS, NodeSelection, BranchingRule, NODE_SELECTIONS, BRANCHING_RULES, IPResult } from "../types/integer";
import { solveIP } from "../algorithms/integer/branchAndBound";
import { validateIP } from "../algorithms/integer/standardize";
import { ipExamples } from "../algorithms/integer/examples";
import { IPProblemInput } from "../components/integer/ProblemInput";
import { BnBTreeView } from "../components/integer/BnBTreeView";
import { NodeDetail } from "../components/integer/NodeDetail";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2 } from "lucide-react";

const blankProblem: IPProblem = {
  sense: "max",
  variables: ["x1", "x2"],
  objective: [5, 4],
  varTypes: ["integer", "integer"],
  constraints: [
    { coeffs: [1, 1], relation: "<=", rhs: 5, label: "Constraint 1" },
    { coeffs: [10, 6], relation: "<=", rhs: 45, label: "Constraint 2" },
  ],
};

const nodeSelectionLabel: Record<NodeSelection, string> = { "depth-first": "Depth-first", "best-bound": "Best bound" };
const branchingLabel: Record<BranchingRule, string> = { "lowest-index": "Lowest index", "most-fractional": "Most fractional" };

export function IntegerProgramming() {
  const [problem, setProblem] = useState<IPProblem>(blankProblem);
  const [options, setOptions] = useState<IPOptions>(DEFAULT_IP_OPTIONS);
  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [result, setResult] = useState<IPResult | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["integer"] | null>(null);
  const [openNodeId, setOpenNodeId] = useState<number | null>(null);

  const errors = useMemo(() => validateIP(problem), [problem]);

  const resetStepping = () => {
    setStepIndex(0);
    setShowFull(false);
    setShowWhy(false);
    setOpenNodeId(null);
  };

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      const r = solveIP(problem, options);
      setSolvedPayload({ problem, options });
      setResult(r);
      resetStepping();
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
      setResult(null);
    }
  };

  const reset = () => {
    setResult(null);
    setRunError(null);
    resetStepping();
  };

  const loadExample = (name: string) => {
    const ex = ipExamples.find((e) => e.name === name);
    if (ex) {
      setProblem(ex.problem);
      reset();
    }
  };

  const importPayload = (p: PayloadMap["integer"]) => {
    setProblem(p.problem);
    setOptions({ ...DEFAULT_IP_OPTIONS, ...p.options });
    reset();
  };

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };

  const steps = result?.steps ?? [];
  const currentStep = steps[stepIndex];
  const visitedUpTo = currentStep ? currentStep.state.nodeId ?? undefined : undefined;
  void visitedUpTo;
  const openNode = result && openNodeId !== null ? result.tree[openNodeId] : null;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Integer Programming</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Exact Branch &amp; Bound for integer, binary, and mixed-integer problems — every subproblem is
        solved with the real two-phase simplex engine, and the search tree grows one subproblem at a
        time as you step through.
      </p>

      <section className="mt-6 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3 print:hidden">
          <label className="text-sm text-graphite">
            Load example:{" "}
            <select className="focus-ring rounded border border-rule px-2 py-1" defaultValue="" onChange={(e) => e.target.value && loadExample(e.target.value)}>
              <option value="" disabled>
                Choose…
              </option>
              {ipExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <IPProblemInput problem={problem} onChange={setProblem} errors={errors} />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-4 rounded border border-rule bg-white p-4 print:hidden">
        <label className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Node selection</span>
          <select className="focus-ring rounded border border-rule px-2 py-1" value={options.nodeSelection} onChange={(e) => setOptions({ ...options, nodeSelection: e.target.value as NodeSelection })}>
            {NODE_SELECTIONS.map((n) => (
              <option key={n} value={n}>
                {nodeSelectionLabel[n]}
              </option>
            ))}
          </select>
        </label>
        <label className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Branching</span>
          <select className="focus-ring rounded border border-rule px-2 py-1" value={options.branching} onChange={(e) => setOptions({ ...options, branching: e.target.value as BranchingRule })}>
            {BRANCHING_RULES.map((b) => (
              <option key={b} value={b}>
                {branchingLabel[b]}
              </option>
            ))}
          </select>
        </label>
        <label className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Node limit</span>
          <input
            type="number"
            className="focus-ring w-24 rounded border border-rule px-2 py-1"
            value={options.nodeLimit}
            min={1}
            onChange={(e) => setOptions({ ...options, nodeLimit: Math.max(1, Number(e.target.value) || 1) })}
          />
        </label>
        <button className="focus-ring ml-auto rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40" onClick={solve} disabled={errors.length > 0}>
          Solve
        </button>
        <button className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna" onClick={reset}>
          Reset
        </button>
      </section>

      <ExportBar
        module="integer"
        payload={{ problem, options }}
        solved={result && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={`Integer Programming — Branch & Bound (${nodeSelectionLabel[options.nodeSelection]}, ${branchingLabel[options.branching]} branching)`}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {result && (
        <section className="mt-4 rounded border border-rule bg-white">
          <StatusBanner result={result} />

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark" onClick={() => setShowWhy((w) => !w)}>
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>}

              <CounterBar state={currentStep.state} />
              <div className="mt-3">
                <BnBTreeView problem={problem} tree={result.tree} stepIndex={stepIndex} onOpenNode={setOpenNodeId} />
              </div>
              {openNode && (
                <div className="mt-3">
                  <NodeDetail problem={problem} node={openNode} onClose={() => setOpenNodeId(null)} />
                </div>
              )}
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              <BnBTreeView problem={problem} tree={result.tree} stepIndex={steps.length - 1} onOpenNode={setOpenNodeId} />
              {openNode && <NodeDetail problem={problem} node={openNode} onClose={() => setOpenNodeId(null)} />}
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-3 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={(i) => {
              setStepIndex(i);
              setOpenNodeId(null);
            }}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />

          {result.notes.length > 0 && (
            <div className="border-t border-rule px-4 py-3 text-xs text-graphite">
              {result.notes.map((n, i) => (
                <p key={i}>{n}</p>
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}

function CounterBar({ state }: { state: import("../types/integer").BnBStepState }) {
  const c = state.counters;
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs">
      <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">LPs solved: {c.lpSolved}</span>
      <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">Branched: {c.branched}</span>
      <span className="rounded-full bg-forest/10 px-2.5 py-1 font-medium text-forestDark">Integer found: {c.integerSolutions}</span>
      <span className="rounded-full bg-sienna/10 px-2.5 py-1 font-medium text-sienna">Infeasible: {c.prunedInfeasible}</span>
      <span className="rounded-full bg-sienna/10 px-2.5 py-1 font-medium text-sienna">Pruned: {c.prunedBound + c.prunedInherited}</span>
      <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">Open: {c.open}</span>
      {state.incumbent && <span className="rounded-full bg-forest/15 px-2.5 py-1 font-medium text-forestDark">Incumbent Z = {state.incumbent.value}</span>}
      {state.bestBound && <span className="rounded-full bg-gold/15 px-2.5 py-1 font-medium text-gold">Best bound Z ≤/≥ {state.bestBound}</span>}
    </div>
  );
}

function StatusBanner({ result }: { result: IPResult }) {
  const map: Record<string, { label: string; tone: string }> = {
    optimal: { label: "Optimal integer solution found", tone: "bg-forest/10 text-forestDark" },
    infeasible: { label: "Infeasible — no integer point satisfies every constraint", tone: "bg-sienna/10 text-sienna" },
    unbounded: { label: "Unbounded — objective can improve without limit", tone: "bg-sienna/10 text-sienna" },
    node_limit: { label: "Stopped at the node limit — result is not proven optimal", tone: "bg-gold/15 text-gold" },
  };
  const info = map[result.status];
  return (
    <div className={`flex flex-wrap items-center gap-2 border-b border-rule px-4 py-3 text-sm font-medium ${info.tone}`}>
      <CheckCircle2 size={16} />
      {info.label}
      {result.optimalValueExact && <span className="font-mono">Z* = {result.optimalValueExact}</span>}
      {result.optimalSolutionExact && (
        <span className="font-mono">({Object.entries(result.optimalSolutionExact).map(([k, v]) => `${k}=${v}`).join(", ")})</span>
      )}
      {result.feasiblePoint && (
        <span className="font-mono">
          witness: ({Object.entries(result.feasiblePoint).map(([k, v]) => `${k}=${v}`).join(", ")})
        </span>
      )}
      {result.bestBound && <span className="font-mono">best bound: {result.bestBound}</span>}
    </div>
  );
}
