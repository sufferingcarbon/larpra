import { useMemo, useState } from "react";
import { MM1Input, MMcInput, QueuingModelType, QueuingResult } from "../types/queuing";
import { solveMM1, solveMMc } from "../algorithms/queuing/solve";
import { validateMM1, validateMMc } from "../algorithms/queuing/common";
import { mm1Examples, mmcExamples } from "../algorithms/queuing/examples";
import { QueuingInputForm } from "../components/queuing/QueuingInputForm";
import { QueuingView } from "../components/queuing/QueuingView";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2, XOctagon } from "lucide-react";

const defaultMM1: MM1Input = { lambda: 5, mu: 10, maxN: 15 };
const defaultMMc: MMcInput = { lambda: 20, mu: 6, servers: 4, maxN: 20 };

export function Queuing() {
  const [model, setModel] = useState<QueuingModelType>("mm1");
  const [mm1Params, setMM1Params] = useState<MM1Input>(defaultMM1);
  const [mmcParams, setMMcParams] = useState<MMcInput>(defaultMMc);
  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [result, setResult] = useState<QueuingResult | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["queuing"] | null>(null);

  const errors = useMemo(() => (model === "mm1" ? validateMM1(mm1Params) : validateMMc(mmcParams)), [model, mm1Params, mmcParams]);

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      const r = model === "mm1" ? solveMM1(mm1Params) : solveMMc(mmcParams);
      const payload: PayloadMap["queuing"] =
        model === "mm1" ? { problem: { model: "mm1", params: mm1Params }, options: {} } : { problem: { model: "mmc", params: mmcParams }, options: {} };
      setSolvedPayload(payload);
      setResult(r);
      setStepIndex(0);
      setShowFull(false);
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
      setResult(null);
    }
  };

  const reset = () => {
    setResult(null);
    setStepIndex(0);
    setShowFull(false);
    setRunError(null);
  };

  const loadExample = (name: string) => {
    if (model === "mm1") {
      const ex = mm1Examples.find((e) => e.name === name);
      if (ex) setMM1Params(ex.problem);
    } else {
      const ex = mmcExamples.find((e) => e.name === name);
      if (ex) setMMcParams(ex.problem);
    }
    reset();
  };

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };

  const importPayload = (p: PayloadMap["queuing"]) => {
    setModel(p.problem.model);
    if (p.problem.model === "mm1") setMM1Params(p.problem.params);
    else setMMcParams(p.problem.params);
    reset();
  };

  const currentPayload: PayloadMap["queuing"] =
    model === "mm1" ? { problem: { model: "mm1", params: mm1Params }, options: {} } : { problem: { model: "mmc", params: mmcParams }, options: {} };

  const steps = result?.steps ?? [];
  const currentStep = steps[stepIndex];
  const examples = model === "mm1" ? mm1Examples : mmcExamples;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Queuing Models</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        M/M/1 and M/M/c queues with Poisson arrivals and exponential service times — every metric
        (utilization, P0, Erlang C/B, L, Lq, W, Wq, the steady-state distribution) computed exactly
        from λ, μ and the number of servers, with the closed-form derivation shown step by step.
      </p>

      <section className="mt-6 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3 print:hidden">
          <label className="text-sm text-graphite">
            Load example:{" "}
            <select
              className="focus-ring rounded border border-rule px-2 py-1"
              defaultValue=""
              onChange={(e) => e.target.value && loadExample(e.target.value)}
            >
              <option value="" disabled>
                Choose…
              </option>
              {examples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <QueuingInputForm
          model={model}
          onModelChange={(m) => {
            setModel(m);
            reset();
          }}
          mm1={mm1Params}
          onMM1Change={setMM1Params}
          mmc={mmcParams}
          onMMcChange={setMMcParams}
          errors={errors}
        />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <button
          className="focus-ring rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna" onClick={reset}>
          Reset
        </button>
      </section>

      <ExportBar
        module="queuing"
        payload={currentPayload}
        solved={result && result.status !== "invalid" && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={model === "mm1" ? "Queuing Models — M/M/1" : `Queuing Models — M/M/${mmcParams.servers}`}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {result && result.status === "unstable" && (
        <div className="mt-4 rounded border border-sienna/40 bg-sienna/10 p-4">
          <div className="flex items-center gap-2 text-sm font-medium text-sienna">
            <XOctagon size={16} /> Unstable — no steady state
          </div>
          <ul className="mt-2 list-inside list-disc space-y-0.5 text-sm text-sienna">
            {result.notes.map((n, i) => (
              <li key={i}>{n}</li>
            ))}
          </ul>
          {result.steps.length > 0 && (
            <div className="mt-3 border-t border-sienna/30 pt-3">
              <QueuingView state={result.steps[result.steps.length - 1].state} />
            </div>
          )}
        </div>
      )}

      {result && result.status === "invalid" && (
        <div className="mt-4 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {result.notes.map((n, i) => (
              <li key={i}>{n}</li>
            ))}
          </ul>
        </div>
      )}

      {result && result.status === "optimal" && (
        <section className="mt-4 rounded border border-rule bg-white">
          <div className="flex flex-wrap items-center gap-2 border-b border-rule bg-forest/10 px-4 py-3 text-sm font-medium text-forestDark">
            <CheckCircle2 size={16} />
            Steady state reached
            {result.notes.map((n, i) => (
              <span key={i} className="w-full text-xs font-normal opacity-80">
                {n}
              </span>
            ))}
          </div>

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>}
              <QueuingView state={currentStep.state} />
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    <QueuingView state={s.state} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={setStepIndex}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />
        </section>
      )}
    </div>
  );
}
