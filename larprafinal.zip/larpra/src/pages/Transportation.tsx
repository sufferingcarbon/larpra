import { useMemo, useState } from "react";
import { InitialMethod, TransportationProblemInput, TransportationResult } from "../types/transportation";
import { solveTransportation } from "../algorithms/transportation/solve";
import { validateProblem } from "../algorithms/transportation/standardize";
import { transportationExamples } from "../algorithms/transportation/examples";
import { ProblemInput } from "../components/transportation/ProblemInput";
import { TransportationGrid } from "../components/transportation/TransportationGrid";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2 } from "lucide-react";

const blankProblem: TransportationProblemInput = {
  sourceNames: ["S1", "S2"],
  destNames: ["D1", "D2", "D3"],
  costs: [
    [4, 6, 8],
    [6, 8, 6],
  ],
  supply: [10, 15],
  demand: [8, 9, 8],
};

const methodLabels: Record<InitialMethod, string> = {
  "northwest-corner": "NW Corner",
  "least-cost": "Least Cost",
  vogel: "VAM",
};

export function Transportation() {
  const [problem, setProblem] = useState<TransportationProblemInput>(blankProblem);
  const [method, setMethod] = useState<InitialMethod>("vogel");
  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [result, setResult] = useState<TransportationResult | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["transportation"] | null>(null);

  const errors = useMemo(() => validateProblem(problem), [problem]);

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      const r = solveTransportation(problem, method);
      setSolvedPayload({ problem, options: { method } });
      setResult(r);
      setStepIndex(0);
      setShowFull(false);
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
      setResult(null);
    }
  };

  const reset = () => {
    setResult(null);
    setStepIndex(0);
    setShowFull(false);
    setRunError(null);
  };

  const loadExample = (name: string) => {
    const ex = transportationExamples.find((e) => e.name === name);
    if (ex) {
      setProblem(ex.problem);
      setResult(null);
      setStepIndex(0);
      setShowFull(false);
    }
  };

  const steps = result?.steps ?? [];
  const currentStep = steps[stepIndex];

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };
  const importPayload = (p: PayloadMap["transportation"]) => {
    setProblem(p.problem);
    if (p.options.method) setMethod(p.options.method);
    reset();
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Transportation Problem</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Build an initial feasible solution with North-West Corner, Least Cost, or Vogel's
        Approximation Method, then optimize it to the true minimum cost with MODI (u-v method) —
        every penalty, loop and pivot shown as its own step.
      </p>

      <section className="mt-6 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="text-sm text-graphite print:hidden">
            Load example:{" "}
            <select
              className="focus-ring rounded border border-rule px-2 py-1"
              defaultValue=""
              onChange={(e) => e.target.value && loadExample(e.target.value)}
            >
              <option value="" disabled>
                Choose…
              </option>
              {transportationExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <ProblemInput problem={problem} onChange={setProblem} errors={errors} />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <div className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Initial method</span>
          <div className="flex overflow-hidden rounded border border-rule">
            {(Object.keys(methodLabels) as InitialMethod[]).map((m) => (
              <button
                key={m}
                className={`px-3 py-1.5 ${method === m ? "bg-forest text-white" : "bg-white text-ink"}`}
                onClick={() => setMethod(m)}
              >
                {methodLabels[m]}
              </button>
            ))}
          </div>
        </div>
        <button
          className="focus-ring ml-auto rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button
          className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
          onClick={reset}
        >
          Reset
        </button>
      </section>

      <ExportBar
        module="transportation"
        payload={{ problem, options: { method } }}
        solved={result && result.status !== "invalid" && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={`Transportation Problem — ${methodLabels[solvedPayload?.options.method ?? method]} initial solution, MODI optimisation`}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {result && result.status !== "invalid" && (
        <section className="mt-4 rounded border border-rule bg-white">
          <StatusBanner result={result} />

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && (
                <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>
              )}
              <TransportationGrid state={currentStep.state} />
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    <TransportationGrid state={s.state} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={setStepIndex}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />

          {result.allocation && <AllocationSummary result={result} />}
        </section>
      )}

      {result && result.status === "invalid" && (
        <div className="mt-4 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {result.notes.map((n, i) => (
              <li key={i}>{n}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function StatusBanner({ result }: { result: TransportationResult }) {
  const map: Record<string, { label: string; tone: string }> = {
    optimal: { label: "Optimal solution found", tone: "bg-forest/10 text-forestDark" },
    degenerate_optimal: { label: "Optimal — degenerate solution", tone: "bg-gold/15 text-gold" },
  };
  const info = map[result.status] ?? { label: result.status, tone: "bg-ledger text-graphite" };
  return (
    <div className={`flex flex-wrap items-center gap-2 border-b border-rule px-4 py-3 text-sm font-medium ${info.tone}`}>
      <CheckCircle2 size={16} />
      {info.label}
      {result.totalCost !== undefined && <span className="font-mono">Minimum cost = {result.totalCost}</span>}
      {result.notes.map((n, i) => (
        <span key={i} className="w-full text-xs font-normal opacity-80">
          {n}
        </span>
      ))}
    </div>
  );
}

function AllocationSummary({ result }: { result: TransportationResult }) {
  const rows = Object.entries(result.allocation ?? {}).flatMap(([src, dests]) =>
    Object.entries(dests).map(([dest, amt]) => ({ src, dest, amt }))
  );
  return (
    <div className="border-t border-rule p-4">
      <h3 className="font-display text-sm font-semibold">Final shipping plan</h3>
      <table className="ledger-table mt-2 w-full">
        <thead>
          <tr>
            <th>Source</th>
            <th>Destination</th>
            <th>Units</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <th className="text-left font-sans font-normal text-graphite">{r.src}</th>
              <th className="text-left font-sans font-normal text-graphite">{r.dest}</th>
              <td>{r.amt}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
