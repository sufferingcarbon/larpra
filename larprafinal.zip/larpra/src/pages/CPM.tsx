import { useMemo, useState } from "react";
import { CPMMode, CPMProblemInput } from "../types/cpm";
import { solveCPM } from "../algorithms/cpm/solve";
import { validateCPM } from "../algorithms/cpm/standardize";
import { convertMode } from "../algorithms/cpm/edit";
import { cpmExamples } from "../algorithms/cpm/examples";
import { ProblemInput } from "../components/cpm/ProblemInput";
import { CPMView } from "../components/cpm/CPMView";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2, Info } from "lucide-react";

const defaultProblem: CPMProblemInput = cpmExamples[1].problem;

export function CPM() {
  const [mode, setMode] = useState<CPMMode>("cpm");
  const [problem, setProblem] = useState<CPMProblemInput>(defaultProblem);
  const [result, setResult] = useState<ReturnType<typeof solveCPM> | null>(null);

  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["cpm"] | null>(null);

  const errors = useMemo(() => validateCPM(problem, mode), [problem, mode]);

  const resetStepping = () => {
    setStepIndex(0);
    setShowFull(false);
    setShowWhy(false);
  };

  const reset = () => {
    setResult(null);
    resetStepping();
  };

  const solve = () => {
    if (errors.length > 0) return;
    setResult(solveCPM(problem, mode));
    setSolvedPayload({ problem, options: { mode } });
    resetStepping();
  };

  const switchMode = (next: CPMMode) => {
    if (next === mode) return;
    setProblem(convertMode(problem, next));
    setMode(next);
    reset();
  };

  const loadExample = (name: string) => {
    const ex = cpmExamples.find((e) => e.name === name);
    if (ex) {
      setMode(ex.mode);
      setProblem(ex.problem);
      reset();
    }
  };

  const steps = result?.steps ?? [];
  const currentStep = steps[stepIndex];
  const solved = result?.status === "optimal" && steps.length > 0;
  const solvedIsPert = result?.isPert ?? false;

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };
  const importPayload = (p: PayloadMap["cpm"]) => {
    setMode(p.options.mode ?? "cpm");
    setProblem(p.problem);
    reset();
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">CPM / PERT</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Critical Path Method: a forward pass finds the earliest each activity can start and finish, a backward pass finds the
        latest it can without delaying the project, and the difference is its slack. PERT feeds three-point time estimates through
        the same passes and adds a project variance.
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {(["cpm", "pert"] as CPMMode[]).map((m) => (
          <button
            key={m}
            className={`focus-ring rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
              mode === m ? "bg-forest text-white" : "border border-rule bg-white text-graphite hover:border-forest"
            }`}
            onClick={() => switchMode(m)}
            aria-pressed={mode === m}
          >
            {m === "cpm" ? "CPM — one duration per activity" : "PERT — three-point estimates"}
          </button>
        ))}
      </div>

      <section className="mt-4 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="flex min-w-0 max-w-full flex-wrap items-center gap-2 text-sm text-graphite print:hidden">
            Load example:
            <select
              className="focus-ring min-w-0 max-w-full rounded border border-rule px-2 py-1"
              defaultValue=""
              onChange={(e) => e.target.value && loadExample(e.target.value)}
            >
              <option value="" disabled>
                Choose…
              </option>
              {cpmExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <ProblemInput problem={problem} mode={mode} onChange={setProblem} errors={errors} />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <button
          className="focus-ring rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button
          className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
          onClick={reset}
        >
          Reset
        </button>
      </section>

      <ExportBar
        module="cpm"
        payload={{ problem, options: { mode } }}
        solved={solved && result && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={`CPM / PERT — ${solvedPayload?.options.mode === "pert" ? "PERT (three-point estimates)" : "CPM (single durations)"}`}
      />

      {result && result.status === "invalid" && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{result.notes[0] ?? "Could not solve this problem."}</span>
        </div>
      )}

      {solved && result && (
        <section className="mt-4 rounded border border-rule bg-white">
          <div className="space-y-1.5 border-b border-rule bg-forest/10 px-4 py-3 text-sm text-forestDark">
            <div className="flex flex-wrap items-center gap-2 font-medium">
              <CheckCircle2 size={16} />
              Project duration = <span className="font-mono">{Math.round(result.projectDuration! * 1e4) / 1e4}</span>
              {solvedIsPert && result.projectStdDev !== undefined && (
                <span className="font-mono">
                  · σ = {Math.round(result.projectStdDev * 1e4) / 1e4}
                </span>
              )}
            </div>
            <div className="font-mono text-xs">
              {result.criticalPaths!.length === 1 ? "Critical path: " : `${result.criticalPaths!.length} critical paths: `}
              {result.criticalPaths!.slice(0, 3).map((p) => p.join(" → ")).join("  |  ")}
              {result.criticalPaths!.length > 3 && "  | …"}
            </div>
          </div>

          {result.notes.length > 0 && (
            <ul className="space-y-1 border-b border-rule bg-ledger/40 px-4 py-2 text-xs text-graphite">
              {result.notes.map((n, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <Info size={13} className="mt-0.5 shrink-0" />
                  <span>{n}</span>
                </li>
              ))}
            </ul>
          )}

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                  {currentStep.operation && <p className="mt-1 font-mono text-xs text-forestDark">{currentStep.operation}</p>}
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && (
                <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>
              )}
              <CPMView state={currentStep.state} timeMax={result.projectDuration} />
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  {s.operation && <p className="mt-1 font-mono text-xs text-forestDark">{s.operation}</p>}
                  <div className="mt-2">
                    <CPMView state={s.state} timeMax={result.projectDuration} />
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={(i) => {
              setStepIndex(i);
              setShowWhy(false);
            }}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />
        </section>
      )}
    </div>
  );
}
