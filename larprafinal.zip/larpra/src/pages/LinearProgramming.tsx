import { useMemo, useState } from "react";
import { LPProblem, LPResult, AlgorithmStep } from "../types/lp";
import { solveSimplex, SimplexTableauState } from "../algorithms/lp/simplex";
import { solveGraphical, GraphicalState } from "../algorithms/lp/graphical";
import { lpExamples } from "../algorithms/lp/examples";
import { ProblemInput } from "../components/lp/ProblemInput";
import { GraphicalView } from "../components/lp/GraphicalView";
import { SimplexView } from "../components/lp/SimplexView";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2 } from "lucide-react";

type Method = "graphical" | "simplex";

const blankProblem: LPProblem = {
  sense: "max",
  objective: [3, 5],
  variables: ["x1", "x2"],
  constraints: [
    { coeffs: [1, 0], relation: "<=", rhs: 4, label: "Constraint 1" },
    { coeffs: [0, 2], relation: "<=", rhs: 12, label: "Constraint 2" },
    { coeffs: [3, 2], relation: "<=", rhs: 18, label: "Constraint 3" },
  ],
};

function validate(problem: LPProblem): string[] {
  const errors: string[] = [];
  if (problem.objective.some((c) => Number.isNaN(c))) errors.push("Objective coefficients must be numbers.");
  if (problem.constraints.length === 0) errors.push("Add at least one constraint.");
  problem.constraints.forEach((c, i) => {
    if (c.coeffs.some((v) => Number.isNaN(v))) errors.push(`Constraint ${i + 1} has a missing coefficient.`);
    if (Number.isNaN(c.rhs)) errors.push(`Constraint ${i + 1} is missing a right-hand-side value.`);
    if (c.coeffs.every((v) => v === 0)) errors.push(`Constraint ${i + 1} has all-zero coefficients.`);
  });
  return errors;
}

export function LinearProgramming() {
  const [problem, setProblem] = useState<LPProblem>(blankProblem);
  const [method, setMethod] = useState<Method>("graphical");
  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [result, setResult] = useState<LPResult<any> | null>(null);
  const [runError, setRunError] = useState<string | null>(null);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["lp"] | null>(null);

  const errors = useMemo(() => validate(problem), [problem]);
  const canGraph = problem.variables.length === 2;

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      const effective: Method = method === "graphical" && canGraph ? "graphical" : "simplex";
      const r = effective === "graphical" ? solveGraphical(problem) : solveSimplex(problem);
      setSolvedPayload({ problem, options: { method: effective } });
      setResult(r);
      setStepIndex(0);
      setShowFull(false);
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
      setResult(null);
    }
  };

  const reset = () => {
    setResult(null);
    setStepIndex(0);
    setShowFull(false);
    setRunError(null);
  };

  const loadExample = (name: string) => {
    const ex = lpExamples.find((e) => e.name === name);
    if (ex) {
      setProblem(ex.problem);
      setResult(null);
      setStepIndex(0);
      setShowFull(false);
      if (ex.problem.variables.length !== 2) setMethod("simplex");
    }
  };

  const steps: AlgorithmStep<any>[] = result?.steps ?? [];
  const currentStep = steps[stepIndex];

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };
  const importPayload = (p: PayloadMap["lp"]) => {
    setProblem(p.problem);
    if (p.options.method) setMethod(p.options.method === "graphical" && p.problem.variables.length !== 2 ? "simplex" : p.options.method);
    reset();
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Linear Programming</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Solve two-variable problems graphically or run the full simplex method — with Big-M-free
        two-phase handling for ≥ and = constraints — one genuine tableau at a time.
      </p>

      <section className="mt-6 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="text-sm text-graphite print:hidden">
            Load example:{" "}
            <select
              className="focus-ring rounded border border-rule px-2 py-1"
              defaultValue=""
              onChange={(e) => e.target.value && loadExample(e.target.value)}
            >
              <option value="" disabled>
                Choose…
              </option>
              {lpExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <ProblemInput problem={problem} onChange={setProblem} errors={errors} />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <div className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Method</span>
          <div className="flex overflow-hidden rounded border border-rule">
            <button
              className={`px-3 py-1.5 ${method === "graphical" ? "bg-forest text-white" : "bg-white text-ink"} disabled:opacity-40`}
              onClick={() => setMethod("graphical")}
              disabled={!canGraph}
              title={!canGraph ? "Graphical method only supports 2 variables" : undefined}
            >
              Graphical
            </button>
            <button
              className={`px-3 py-1.5 ${method === "simplex" ? "bg-forest text-white" : "bg-white text-ink"}`}
              onClick={() => setMethod("simplex")}
            >
              Simplex
            </button>
          </div>
        </div>
        <button
          className="focus-ring ml-auto rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button
          className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
          onClick={reset}
        >
          Reset
        </button>
      </section>

      <ExportBar
        module="lp"
        payload={{ problem, options: { method } }}
        solved={result && solvedPayload ? { payload: solvedPayload, result } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={`Linear Programming — ${solvedPayload?.options.method === "graphical" ? "Graphical method" : "Simplex (two-phase)"}`}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {result && (
        <section className="mt-4 rounded border border-rule bg-white">
          <StatusBanner result={result} />

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && (
                <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>
              )}

              {"lines" in (currentStep.state as object) ? (
                <GraphicalView state={currentStep.state as GraphicalState} varNames={[problem.variables[0], problem.variables[1]]} />
              ) : (
                <SimplexView state={currentStep.state as SimplexTableauState} />
              )}
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {steps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    {"lines" in (s.state as object) ? (
                      <GraphicalView state={s.state as GraphicalState} varNames={[problem.variables[0], problem.variables[1]]} />
                    ) : (
                      <SimplexView state={s.state as SimplexTableauState} />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={steps.length}
            onChange={setStepIndex}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />

          {result.sensitivity && (result.status === "optimal" || result.status === "alternate_optima") && (
            <SensitivityPanel sensitivity={result.sensitivity} problem={problem} />
          )}
        </section>
      )}
    </div>
  );
}

function StatusBanner({ result }: { result: LPResult<any> }) {
  const map: Record<string, { label: string; tone: string }> = {
    optimal: { label: "Optimal solution found", tone: "bg-forest/10 text-forestDark" },
    alternate_optima: { label: "Optimal — alternate optima exist", tone: "bg-gold/15 text-gold" },
    infeasible: { label: "Infeasible — no solution satisfies every constraint", tone: "bg-sienna/10 text-sienna" },
    unbounded: { label: "Unbounded — objective has no finite optimum", tone: "bg-sienna/10 text-sienna" },
    degenerate: { label: "Degenerate solution", tone: "bg-gold/15 text-gold" },
  };
  const info = map[result.status];
  return (
    <div className={`flex flex-wrap items-center gap-2 border-b border-rule px-4 py-3 text-sm font-medium ${info.tone}`}>
      <CheckCircle2 size={16} />
      {info.label}
      {result.optimalValue !== undefined && (
        <span className="font-mono">Z* = {Number(result.optimalValue.toFixed(6))}</span>
      )}
      {result.optimalSolution && (
        <span className="font-mono">
          (
          {Object.entries(result.optimalSolution)
            .map(([k, v]) => `${k}=${Number((v as number).toFixed(4))}`)
            .join(", ")}
          )
        </span>
      )}
      {result.notes.map((n, i) => (
        <span key={i} className="w-full text-xs font-normal opacity-80">
          {n}
        </span>
      ))}
    </div>
  );
}

function SensitivityPanel({
  sensitivity,
  problem,
}: {
  sensitivity: NonNullable<LPResult<any>["sensitivity"]>;
  problem: LPProblem;
}) {
  return (
    <div className="border-t border-rule p-4">
      <h3 className="font-display text-sm font-semibold">Sensitivity analysis</h3>
      <p className="mt-1 text-xs text-graphite">
        Shadow prices are currently computed for ≤ constraints only; ≥ and = constraints will be
        added in a later milestone. Reduced costs follow the Cj − Zj convention from the final
        tableau — check your textbook's sign convention when comparing.
      </p>
      <div className="mt-3 grid gap-4 sm:grid-cols-2">
        <div>
          <p className="mb-1 text-xs font-medium uppercase tracking-wide text-graphite">Shadow prices</p>
          <table className="ledger-table w-full">
            <tbody>
              {problem.constraints.map((c, i) => {
                const label = c.label ?? `Constraint ${i + 1}`;
                const val = sensitivity.shadowPrices[label];
                return (
                  <tr key={label}>
                    <th className="text-left font-sans font-normal text-graphite">{label}</th>
                    <td>{val ?? "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div>
          <p className="mb-1 text-xs font-medium uppercase tracking-wide text-graphite">Reduced costs</p>
          <table className="ledger-table w-full">
            <tbody>
              {problem.variables.map((v) => (
                <tr key={v}>
                  <th className="text-left font-sans font-normal text-graphite">{v}</th>
                  <td>{sensitivity.reducedCosts[v]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
