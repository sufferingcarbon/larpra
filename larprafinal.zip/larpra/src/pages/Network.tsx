import { useMemo, useState } from "react";
import { GraphInput, MSTMethod, MSTResult, MaxFlowResult, ShortestPathResult } from "../types/network";
import { solveDijkstra, solveMST, solveMaxFlow } from "../algorithms/network/solve";
import { validateGraph } from "../algorithms/network/graph";
import { shortestPathExamples, mstExamples, maxFlowExamples } from "../algorithms/network/examples";
import { GraphEditor } from "../components/network/GraphEditor";
import { ShortestPathView } from "../components/network/ShortestPathView";
import { MSTView } from "../components/network/MSTView";
import { MaxFlowView } from "../components/network/MaxFlowView";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2 } from "lucide-react";

type Mode = "shortest-path" | "mst" | "max-flow";

const defaultSPGraph: GraphInput = {
  directed: true,
  nodes: ["A", "B", "C"],
  edges: [
    { from: "A", to: "B", weight: 4 },
    { from: "B", to: "C", weight: 2 },
    { from: "A", to: "C", weight: 9 },
  ],
};
const defaultMSTGraph: GraphInput = {
  directed: false,
  nodes: ["A", "B", "C"],
  edges: [
    { from: "A", to: "B", weight: 1 },
    { from: "B", to: "C", weight: 2 },
    { from: "A", to: "C", weight: 3 },
  ],
};
const defaultFlowGraph: GraphInput = {
  directed: true,
  nodes: ["S", "A", "T"],
  edges: [
    { from: "S", to: "A", weight: 5 },
    { from: "A", to: "T", weight: 5 },
    { from: "S", to: "T", weight: 2 },
  ],
};

export function Network() {
  const [mode, setMode] = useState<Mode>("shortest-path");

  const [spGraph, setSpGraph] = useState<GraphInput>(defaultSPGraph);
  const [spSource, setSpSource] = useState("A");

  const [mstGraph, setMstGraph] = useState<GraphInput>(defaultMSTGraph);
  const [mstMethod, setMstMethod] = useState<MSTMethod>("kruskal");
  const [mstStart, setMstStart] = useState("A");

  const [flowGraph, setFlowGraph] = useState<GraphInput>(defaultFlowGraph);
  const [flowSource, setFlowSource] = useState("S");
  const [flowSink, setFlowSink] = useState("T");

  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);

  const [spResult, setSpResult] = useState<ShortestPathResult | null>(null);
  const [mstResult, setMstResult] = useState<MSTResult | null>(null);
  const [flowResult, setFlowResult] = useState<MaxFlowResult | null>(null);
  // Snapshot of the inputs a result was solved from, so later edits don't retroactively change a rendered step.
  const [solvedSpGraph, setSolvedSpGraph] = useState<GraphInput>(defaultSPGraph);
  const [solvedSpSource, setSolvedSpSource] = useState("A");
  const [solvedFlowSource, setSolvedFlowSource] = useState("S");
  const [solvedFlowSink, setSolvedFlowSink] = useState("T");
  const [solvedNetwork, setSolvedNetwork] = useState<PayloadMap["network"] | null>(null);

  const errors = useMemo(() => {
    if (mode === "shortest-path") return validateGraph(spGraph);
    if (mode === "mst") return validateGraph(mstGraph);
    return validateGraph(flowGraph, { requirePositiveWeights: true });
  }, [mode, spGraph, mstGraph, flowGraph]);

  const resetStepping = () => {
    setStepIndex(0);
    setShowFull(false);
    setRunError(null);
  };

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    try {
      if (mode === "shortest-path") {
        const r = solveDijkstra({ graph: spGraph, source: spSource });
        setSpResult(r);
        setSolvedNetwork({ problem: { type: "shortest-path", graph: spGraph, source: spSource }, options: {} });
        setSolvedSpGraph(spGraph);
        setSolvedSpSource(spSource);
        if (r.status !== "optimal") setRunError(r.notes[0] ?? "This problem could not be solved.");
      } else if (mode === "mst") {
        const r = solveMST({ graph: mstGraph, method: mstMethod, startNode: mstStart });
        setMstResult(r);
        setSolvedNetwork({ problem: { type: "mst", graph: mstGraph, method: mstMethod, startNode: mstStart }, options: {} });
        if (r.status !== "optimal") setRunError(r.notes[0] ?? "This problem could not be solved.");
      } else {
        const r = solveMaxFlow({ graph: flowGraph, source: flowSource, sink: flowSink });
        setFlowResult(r);
        setSolvedNetwork({ problem: { type: "max-flow", graph: flowGraph, source: flowSource, sink: flowSink }, options: {} });
        setSolvedFlowSource(flowSource);
        setSolvedFlowSink(flowSink);
        if (r.status !== "optimal") setRunError(r.notes[0] ?? "This problem could not be solved.");
      }
      resetStepping();
    } catch (e) {
      setRunError(e instanceof Error ? e.message : "Could not solve this problem.");
    }
  };

  const reset = () => {
    setSpResult(null);
    setMstResult(null);
    setFlowResult(null);
    resetStepping();
  };

  const switchMode = (m: Mode) => {
    setMode(m);
    reset();
  };

  const loadSPExample = (name: string) => {
    const ex = shortestPathExamples.find((e) => e.name === name);
    if (ex) {
      setSpGraph(ex.problem.graph);
      setSpSource(ex.problem.source);
      reset();
    }
  };
  const loadMSTExample = (name: string) => {
    const ex = mstExamples.find((e) => e.name === name);
    if (ex) {
      setMstGraph(ex.graph);
      setMstStart(ex.defaultStartNode);
      reset();
    }
  };
  const loadFlowExample = (name: string) => {
    const ex = maxFlowExamples.find((e) => e.name === name);
    if (ex) {
      setFlowGraph(ex.problem.graph);
      setFlowSource(ex.problem.source);
      setFlowSink(ex.problem.sink);
      reset();
    }
  };

  const activeSteps =
    mode === "shortest-path" ? spResult?.steps ?? [] : mode === "mst" ? mstResult?.steps ?? [] : flowResult?.steps ?? [];
  const currentStep = activeSteps[stepIndex];
  const hasResult = mode === "shortest-path" ? !!spResult : mode === "mst" ? !!mstResult : !!flowResult;
  const isOptimal =
    (mode === "shortest-path" && spResult?.status === "optimal") ||
    (mode === "mst" && mstResult?.status === "optimal") ||
    (mode === "max-flow" && flowResult?.status === "optimal");

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };
  const currentNetwork: PayloadMap["network"] = {
    problem:
      mode === "shortest-path"
        ? { type: "shortest-path", graph: spGraph, source: spSource }
        : mode === "mst"
        ? { type: "mst", graph: mstGraph, method: mstMethod, startNode: mstStart }
        : { type: "max-flow", graph: flowGraph, source: flowSource, sink: flowSink },
    options: {},
  };
  const activeResult = mode === "shortest-path" ? spResult : mode === "mst" ? mstResult : flowResult;
  const sp = solvedNetwork?.problem;
  const networkSubtitle =
    sp?.type === "mst"
      ? `Network & Routing — Minimum Spanning Tree (${sp.method === "prim" ? "Prim" : "Kruskal"})`
      : sp?.type === "max-flow"
      ? `Network & Routing — Maximum Flow (Edmonds-Karp) from ${sp.source} to ${sp.sink}`
      : sp?.type === "shortest-path"
      ? `Network & Routing — Shortest Path (Dijkstra) from ${sp.source}`
      : "Network & Routing";
  const importPayload = (p: PayloadMap["network"]) => {
    const pr = p.problem;
    if (pr.type === "shortest-path") {
      setSpGraph(pr.graph);
      setSpSource(pr.source);
    } else if (pr.type === "mst") {
      setMstGraph(pr.graph);
      setMstMethod(pr.method);
      setMstStart(pr.startNode);
    } else {
      setFlowGraph(pr.graph);
      setFlowSource(pr.source);
      setFlowSink(pr.sink);
    }
    setMode(pr.type);
    reset();
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Network & Routing</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Shortest Path (Dijkstra), Minimum Spanning Tree (Kruskal / Prim), and Maximum Flow
        (Edmonds-Karp) — every relaxation, edge decision, and augmenting path shown as its own
        step.
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {(["shortest-path", "mst", "max-flow"] as Mode[]).map((m) => (
          <button
            key={m}
            className={`focus-ring rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
              mode === m ? "bg-forest text-white" : "border border-rule bg-white text-graphite hover:border-forest"
            }`}
            onClick={() => switchMode(m)}
          >
            {m === "shortest-path" ? "Shortest Path" : m === "mst" ? "Minimum Spanning Tree" : "Maximum Flow"}
          </button>
        ))}
      </div>

      {mode === "shortest-path" && (
        <section className="mt-4 rounded border border-rule bg-white p-4">
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <label className="text-sm text-graphite print:hidden">
              Load example:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1"
                defaultValue=""
                onChange={(e) => e.target.value && loadSPExample(e.target.value)}
              >
                <option value="" disabled>
                  Choose…
                </option>
                {shortestPathExamples.map((ex) => (
                  <option key={ex.name} value={ex.name}>
                    [{ex.difficulty}] {ex.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm text-graphite">
              Source:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1 font-mono"
                value={spSource}
                onChange={(e) => setSpSource(e.target.value)}
              >
                {spGraph.nodes.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <GraphEditor graph={spGraph} onChange={setSpGraph} errors={errors} lockDirected />
        </section>
      )}

      {mode === "mst" && (
        <section className="mt-4 rounded border border-rule bg-white p-4">
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <label className="text-sm text-graphite print:hidden">
              Load example:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1"
                defaultValue=""
                onChange={(e) => e.target.value && loadMSTExample(e.target.value)}
              >
                <option value="" disabled>
                  Choose…
                </option>
                {mstExamples.map((ex) => (
                  <option key={ex.name} value={ex.name}>
                    [{ex.difficulty}] {ex.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm text-graphite">
              Method:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1"
                value={mstMethod}
                onChange={(e) => setMstMethod(e.target.value as MSTMethod)}
              >
                <option value="kruskal">Kruskal</option>
                <option value="prim">Prim</option>
              </select>
            </label>
            {mstMethod === "prim" && (
              <label className="text-sm text-graphite">
                Start node:{" "}
                <select
                  className="focus-ring rounded border border-rule px-2 py-1 font-mono"
                  value={mstStart}
                  onChange={(e) => setMstStart(e.target.value)}
                >
                  {mstGraph.nodes.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </label>
            )}
          </div>
          <GraphEditor graph={mstGraph} onChange={setMstGraph} errors={errors} lockDirected />
        </section>
      )}

      {mode === "max-flow" && (
        <section className="mt-4 rounded border border-rule bg-white p-4">
          <div className="mb-4 flex flex-wrap items-center gap-3">
            <label className="text-sm text-graphite print:hidden">
              Load example:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1"
                defaultValue=""
                onChange={(e) => e.target.value && loadFlowExample(e.target.value)}
              >
                <option value="" disabled>
                  Choose…
                </option>
                {maxFlowExamples.map((ex) => (
                  <option key={ex.name} value={ex.name}>
                    [{ex.difficulty}] {ex.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm text-graphite">
              Source:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1 font-mono"
                value={flowSource}
                onChange={(e) => setFlowSource(e.target.value)}
              >
                {flowGraph.nodes.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm text-graphite">
              Sink:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1 font-mono"
                value={flowSink}
                onChange={(e) => setFlowSink(e.target.value)}
              >
                {flowGraph.nodes.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <GraphEditor graph={flowGraph} onChange={setFlowGraph} errors={errors} lockDirected />
        </section>
      )}

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <button
          className="focus-ring rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button
          className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
          onClick={reset}
        >
          Reset
        </button>
      </section>

      <ExportBar
        module="network"
        payload={currentNetwork}
        solved={
          hasResult && isOptimal && activeSteps.length > 0 && solvedNetwork && solvedNetwork.problem.type === mode && activeResult
            ? { payload: solvedNetwork, result: activeResult }
            : null
        }
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={networkSubtitle}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {hasResult && isOptimal && activeSteps.length > 0 && (
        <section className="mt-4 rounded border border-rule bg-white">
          <div className="flex flex-wrap items-center gap-2 border-b border-rule bg-forest/10 px-4 py-3 text-sm font-medium text-forestDark">
            <CheckCircle2 size={16} />
            {mode === "shortest-path" && "Shortest paths computed"}
            {mode === "mst" && "Minimum spanning tree found"}
            {mode === "max-flow" && "Maximum flow computed"}
            {mode === "mst" && mstResult?.totalWeight !== undefined && (
              <span className="font-mono">Total weight = {mstResult.totalWeight}</span>
            )}
            {mode === "max-flow" && flowResult?.maxFlow !== undefined && (
              <span className="font-mono">Max flow = {flowResult.maxFlow}</span>
            )}
          </div>

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && (
                <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>
              )}
              {mode === "shortest-path" && (
                <ShortestPathView graph={solvedSpGraph} state={currentStep.state as any} source={solvedSpSource} />
              )}
              {mode === "mst" && <MSTView state={currentStep.state as any} />}
              {mode === "max-flow" && (
                <MaxFlowView state={currentStep.state as any} source={solvedFlowSource} sink={solvedFlowSink} />
              )}
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {activeSteps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    {mode === "shortest-path" && (
                      <ShortestPathView graph={solvedSpGraph} state={s.state as any} source={solvedSpSource} />
                    )}
                    {mode === "mst" && <MSTView state={s.state as any} />}
                    {mode === "max-flow" && (
                      <MaxFlowView state={s.state as any} source={solvedFlowSource} sink={solvedFlowSink} />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={activeSteps.length}
            onChange={setStepIndex}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />
        </section>
      )}
    </div>
  );
}
