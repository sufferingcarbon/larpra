import { useMemo, useState } from "react";
import { TSPProblemInput } from "../types/tsp";
import { solveNearestNeighbor, solveTSPBranchAndBound } from "../algorithms/tsp/solve";
import { validateTSP } from "../algorithms/tsp/standardize";
import { tspExamples } from "../algorithms/tsp/examples";
import { ProblemInput } from "../components/tsp/ProblemInput";
import { NNView } from "../components/tsp/NNView";
import { BnBView } from "../components/tsp/BnBView";
import { StepControls } from "../components/StepControls";
import { ExportBar } from "../components/ExportBar";
import { PayloadMap } from "../export/schema";
import { HelpCircle, AlertTriangle, CheckCircle2 } from "lucide-react";

type Method = "nearest-neighbor" | "branch-and-bound";

const defaultProblem: TSPProblemInput = {
  cities: ["A", "B", "C", "D"],
  symmetric: true,
  distances: [
    [0, 3, 8, 5],
    [3, 0, 4, 6],
    [8, 4, 0, 2],
    [5, 6, 2, 0],
  ],
};

export function TSP() {
  const [method, setMethod] = useState<Method>("nearest-neighbor");
  const [problem, setProblem] = useState<TSPProblemInput>(defaultProblem);
  const [startCity, setStartCity] = useState("A");

  const [stepIndex, setStepIndex] = useState(0);
  const [showFull, setShowFull] = useState(false);
  const [showWhy, setShowWhy] = useState(false);
  const [runError, setRunError] = useState<string | null>(null);

  const [nnResult, setNnResult] = useState<ReturnType<typeof solveNearestNeighbor> | null>(null);
  const [bnbResult, setBnbResult] = useState<ReturnType<typeof solveTSPBranchAndBound> | null>(null);
  const [solvedProblem, setSolvedProblem] = useState<TSPProblemInput>(defaultProblem);
  const [solvedPayload, setSolvedPayload] = useState<PayloadMap["tsp"] | null>(null);

  const errors = useMemo(() => validateTSP(problem), [problem]);

  const resetStepping = () => {
    setStepIndex(0);
    setShowFull(false);
    setRunError(null);
  };

  const solve = () => {
    setRunError(null);
    if (errors.length > 0) return;
    if (method === "nearest-neighbor") {
      const r = solveNearestNeighbor(problem, startCity);
      setNnResult(r);
      if (r.status !== "optimal") setRunError(r.notes[0] ?? "Could not complete a tour.");
    } else {
      const r = solveTSPBranchAndBound(problem);
      setBnbResult(r);
      if (r.status !== "optimal") setRunError(r.notes[0] ?? "Could not solve this problem.");
    }
    setSolvedProblem(problem);
    setSolvedPayload({ problem, options: { method, startCity } });
    resetStepping();
  };

  const reset = () => {
    setNnResult(null);
    setBnbResult(null);
    resetStepping();
  };

  const switchMethod = (m: Method) => {
    setMethod(m);
    reset();
  };

  const loadExample = (name: string) => {
    const ex = tspExamples.find((e) => e.name === name);
    if (ex) {
      setProblem(ex.problem);
      setStartCity(ex.problem.cities[0]);
      reset();
    }
  };

  const activeSteps = method === "nearest-neighbor" ? nnResult?.steps ?? [] : bnbResult?.steps ?? [];
  const currentStep = activeSteps[stepIndex];
  const hasResult = method === "nearest-neighbor" ? !!nnResult : !!bnbResult;
  const isOptimal =
    (method === "nearest-neighbor" && nnResult?.status === "optimal") ||
    (method === "branch-and-bound" && bnbResult?.status === "optimal");

  const beginPrint = () => {
    const previous = showFull;
    setShowFull(true);
    return () => setShowFull(previous);
  };
  const importPayload = (p: PayloadMap["tsp"]) => {
    setProblem(p.problem);
    if (p.options.method) setMethod(p.options.method);
    setStartCity(p.options.startCity && p.problem.cities.includes(p.options.startCity) ? p.options.startCity : p.problem.cities[0] ?? "A");
    reset();
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink">Traveling Salesman Problem</h1>
      <p className="mt-1 max-w-2xl text-sm text-graphite">
        Nearest Neighbor (a fast heuristic — not guaranteed optimal) and exact Branch and Bound
        (guaranteed optimal, with every branch, bound, and prune shown).
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {(["nearest-neighbor", "branch-and-bound"] as Method[]).map((m) => (
          <button
            key={m}
            className={`focus-ring rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
              method === m ? "bg-forest text-white" : "border border-rule bg-white text-graphite hover:border-forest"
            }`}
            onClick={() => switchMethod(m)}
          >
            {m === "nearest-neighbor" ? "Nearest Neighbor" : "Exact Branch & Bound"}
          </button>
        ))}
      </div>

      <section className="mt-4 rounded border border-rule bg-white p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <label className="text-sm text-graphite print:hidden">
            Load example:{" "}
            <select
              className="focus-ring rounded border border-rule px-2 py-1"
              defaultValue=""
              onChange={(e) => e.target.value && loadExample(e.target.value)}
            >
              <option value="" disabled>
                Choose…
              </option>
              {tspExamples.map((ex) => (
                <option key={ex.name} value={ex.name}>
                  [{ex.difficulty}] {ex.name}
                </option>
              ))}
            </select>
          </label>
          {method === "nearest-neighbor" && (
            <label className="text-sm text-graphite">
              Start city:{" "}
              <select
                className="focus-ring rounded border border-rule px-2 py-1 font-mono"
                value={startCity}
                onChange={(e) => setStartCity(e.target.value)}
              >
                {problem.cities.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>
        <ProblemInput problem={problem} onChange={setProblem} errors={errors} />
      </section>

      <section className="mt-4 flex flex-wrap items-center gap-3 rounded border border-rule bg-white p-4 print:hidden">
        <button
          className="focus-ring rounded bg-forest px-4 py-1.5 text-sm font-medium text-white hover:bg-forestDark disabled:opacity-40"
          onClick={solve}
          disabled={errors.length > 0}
        >
          Solve
        </button>
        <button
          className="focus-ring rounded border border-rule px-4 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
          onClick={reset}
        >
          Reset
        </button>
        {method === "branch-and-bound" && problem.cities.length > 8 && (
          <span className="flex items-center gap-1 text-xs text-gold">
            <AlertTriangle size={14} /> {problem.cities.length} cities: exact search may take a moment.
          </span>
        )}
      </section>

      <ExportBar
        module="tsp"
        payload={{ problem, options: { method, startCity } }}
        solved={hasResult && isOptimal && activeSteps.length > 0 && solvedPayload ? { payload: solvedPayload, result: method === "nearest-neighbor" ? nnResult : bnbResult } : null}
        onImport={importPayload}
        beginPrint={beginPrint}
        subtitle={`Traveling Salesman — ${solvedPayload?.options.method === "branch-and-bound" ? "exact Branch & Bound" : "Nearest Neighbor (heuristic)"}`}
      />

      {runError && (
        <div className="mt-4 flex items-start gap-2 rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          <span>{runError}</span>
        </div>
      )}

      {hasResult && isOptimal && activeSteps.length > 0 && (
        <section className="mt-4 rounded border border-rule bg-white">
          <div className="flex flex-wrap items-center gap-2 border-b border-rule bg-forest/10 px-4 py-3 text-sm font-medium text-forestDark">
            <CheckCircle2 size={16} />
            {method === "nearest-neighbor" ? "Tour complete" : "Optimal tour found"}
            {method === "nearest-neighbor" && nnResult?.totalCost !== undefined && (
              <span className="font-mono">Cost = {nnResult.totalCost}</span>
            )}
            {method === "branch-and-bound" && bnbResult?.totalCost !== undefined && (
              <span className="font-mono">Cost = {bnbResult.totalCost}</span>
            )}
          </div>

          {!showFull && currentStep && (
            <div className="p-4">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-semibold">{currentStep.title}</h3>
                  <p className="mt-1 text-sm text-graphite">{currentStep.explanation}</p>
                </div>
                {currentStep.why && (
                  <button
                    className="focus-ring flex shrink-0 items-center gap-1 rounded border border-rule px-2 py-1 text-xs text-graphite hover:border-forest hover:text-forestDark"
                    onClick={() => setShowWhy((w) => !w)}
                  >
                    <HelpCircle size={14} /> Why?
                  </button>
                )}
              </div>
              {showWhy && currentStep.why && (
                <p className="mb-3 rounded bg-ledger/60 px-3 py-2 text-sm text-graphite">{currentStep.why}</p>
              )}
              {method === "nearest-neighbor" && <NNView problem={solvedProblem} state={currentStep.state as any} />}
              {method === "branch-and-bound" && <BnBView problem={solvedProblem} state={currentStep.state as any} />}
            </div>
          )}

          {showFull && (
            <div className="space-y-6 p-4">
              {activeSteps.map((s, i) => (
                <div key={i} className="border-b border-rule pb-4 last:border-0">
                  <h3 className="font-display text-sm font-semibold">
                    {i + 1}. {s.title}
                  </h3>
                  <p className="mt-1 text-sm text-graphite">{s.explanation}</p>
                  <div className="mt-2">
                    {method === "nearest-neighbor" && <NNView problem={solvedProblem} state={s.state as any} />}
                    {method === "branch-and-bound" && <BnBView problem={solvedProblem} state={s.state as any} />}
                  </div>
                </div>
              ))}
            </div>
          )}

          <StepControls
            index={stepIndex}
            total={activeSteps.length}
            onChange={setStepIndex}
            onShowFullSolution={() => setShowFull(true)}
            onReset={() => setShowFull(false)}
          />
        </section>
      )}
    </div>
  );
}
