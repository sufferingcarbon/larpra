import { LPProblem } from "../types/lp";
import { InitialMethod, TransportationProblemInput } from "../types/transportation";
import { AssignmentProblemInput } from "../types/assignment";
import { GraphInput, MSTMethod } from "../types/network";
import { TSPProblemInput } from "../types/tsp";
import { CPMMode, CPMProblemInput } from "../types/cpm";
import { BranchingRule, IPProblem, NodeSelection } from "../types/integer";
import { QueuingProblem } from "../types/queuing";
import { GameInput } from "../types/game";
import { MatrixInput } from "../types/matrix";

/**
 * larpra file format, schemaVersion 1.
 *
 * One JSON envelope for every module:
 *
 *   { "app": "larpra", "schemaVersion": 1, "module": "cpm", "kind": "problem" | "solution",
 *     "exportedAt": "2026-09-20T12:00:00.000Z",
 *     "options": { ... how to solve it (method, mode, start city …) },
 *     "problem": { ... the inputs, exactly as the module's input form holds them },
 *     "solution": { ... only when kind is "solution": the module's whole result, every step included } }
 *
 * A "solution" file is also a valid "problem" file — importing it loads the inputs and ignores the solution.
 * Convention used throughout: `null` stands for ∞ / "no edge" (JSON has no Infinity).
 */
export const APP_ID = "larpra" as const;
export const SCHEMA_VERSION = 1;
export const MAX_FILE_BYTES = 5 * 1024 * 1024;

export const MODULE_KEYS = ["lp", "transportation", "assignment", "network", "tsp", "cpm", "integer", "queuing", "game", "matrix"] as const;
export type ModuleKey = (typeof MODULE_KEYS)[number];

export const MODULE_LABELS: Record<ModuleKey, string> = {
  lp: "Linear Programming",
  transportation: "Transportation Problem",
  assignment: "Assignment Problem",
  network: "Network & Routing",
  tsp: "Traveling Salesman",
  cpm: "CPM / PERT",
  integer: "Integer Programming",
  queuing: "Queuing Models",
  game: "Game Theory",
  matrix: "Matrix / Linear Equations",
};

export type FileKind = "problem" | "solution";

export const LP_METHODS = ["graphical", "simplex"] as const;
export type LPMethod = (typeof LP_METHODS)[number];
export const TRANSPORTATION_METHODS: readonly InitialMethod[] = ["northwest-corner", "least-cost", "vogel"];
export const TSP_METHODS = ["nearest-neighbor", "branch-and-bound"] as const;
export type TSPMethod = (typeof TSP_METHODS)[number];
export const CPM_MODES: readonly CPMMode[] = ["cpm", "pert"];
export const MST_METHODS: readonly MSTMethod[] = ["kruskal", "prim"];
export const IP_NODE_SELECTIONS: readonly NodeSelection[] = ["depth-first", "best-bound"];
export const IP_BRANCHING_RULES: readonly BranchingRule[] = ["lowest-index", "most-fractional"];

export type NetworkProblem =
  | { type: "shortest-path"; graph: GraphInput; source: string }
  | { type: "mst"; graph: GraphInput; method: MSTMethod; startNode: string }
  | { type: "max-flow"; graph: GraphInput; source: string; sink: string };

/** What a module page hands to the exporter and gets back from the importer. */
export interface PayloadMap {
  lp: { problem: LPProblem; options: { method?: LPMethod } };
  transportation: { problem: TransportationProblemInput; options: { method?: InitialMethod } };
  assignment: { problem: AssignmentProblemInput; options: Record<string, never> };
  network: { problem: NetworkProblem; options: Record<string, never> };
  tsp: { problem: TSPProblemInput; options: { method?: TSPMethod; startCity?: string } };
  cpm: { problem: CPMProblemInput; options: { mode?: CPMMode } };
  integer: {
    problem: IPProblem;
    options: { nodeSelection?: NodeSelection; branching?: BranchingRule; tightenIntegerObjective?: boolean; nodeLimit?: number };
  };
  queuing: { problem: QueuingProblem; options: Record<string, never> };
  game: { problem: GameInput; options: Record<string, never> };
  matrix: { problem: MatrixInput; options: Record<string, never> };
}

export interface Envelope {
  app: typeof APP_ID;
  schemaVersion: number;
  module: ModuleKey;
  kind: FileKind;
  exportedAt: string;
  options: Record<string, unknown>;
  problem: unknown;
  solution?: unknown;
}
