import { describe, it, expect } from "vitest";
import { Fraction } from "../../utils/fraction";
import { jsonReplacer, toJson } from "../serialize";
import { buildExportText, exportFilename, parseExportText } from "../file";
import { APP_ID, MAX_FILE_BYTES, MODULE_KEYS, ModuleKey, NetworkProblem, PayloadMap, SCHEMA_VERSION } from "../schema";

import { lpExamples } from "../../algorithms/lp/examples";
import { solveSimplex } from "../../algorithms/lp/simplex";
import { solveGraphical } from "../../algorithms/lp/graphical";
import { transportationExamples } from "../../algorithms/transportation/examples";
import { solveTransportation } from "../../algorithms/transportation/solve";
import { assignmentExamples } from "../../algorithms/assignment/examples";
import { solveAssignment } from "../../algorithms/assignment/solve";
import { shortestPathExamples, mstExamples, maxFlowExamples } from "../../algorithms/network/examples";
import { solveDijkstra, solveMST, solveMaxFlow } from "../../algorithms/network/solve";
import { tspExamples } from "../../algorithms/tsp/examples";
import { solveNearestNeighbor, solveTSPBranchAndBound } from "../../algorithms/tsp/solve";
import { cpmExamples } from "../../algorithms/cpm/examples";
import { solveCPM } from "../../algorithms/cpm/solve";
import { ipExamples } from "../../algorithms/integer/examples";
import { solveIP } from "../../algorithms/integer/branchAndBound";
import { mm1Examples, mmcExamples } from "../../algorithms/queuing/examples";
import { solveMM1, solveMMc } from "../../algorithms/queuing/solve";
import { gameExamples } from "../../algorithms/game/examples";
import { solveGame } from "../../algorithms/game/solve";
import { matrixExamples } from "../../algorithms/matrix/examples";
import { solveMatrix } from "../../algorithms/matrix/solve";

/* ---------- one payload + solver per example, per module ---------- */

type Case = { label: string; module: ModuleKey; payload: any; solve: () => { steps: unknown[] } };

const cases: Case[] = [
  ...lpExamples.map((ex): Case => {
    const method = ex.problem.variables.length === 2 ? "graphical" : "simplex";
    return {
      label: `lp: ${ex.name}`,
      module: "lp",
      payload: { problem: ex.problem, options: { method } },
      solve: () => (method === "graphical" ? solveGraphical(ex.problem) : solveSimplex(ex.problem)),
    };
  }),
  ...transportationExamples.map((ex): Case => ({
    label: `transportation: ${ex.name}`,
    module: "transportation",
    payload: { problem: ex.problem, options: { method: "vogel" } },
    solve: () => solveTransportation(ex.problem, "vogel"),
  })),
  ...assignmentExamples.map((ex): Case => ({
    label: `assignment: ${ex.name}`,
    module: "assignment",
    payload: { problem: ex.problem, options: {} },
    solve: () => solveAssignment(ex.problem),
  })),
  ...shortestPathExamples.map((ex): Case => ({
    label: `network/shortest-path: ${ex.name}`,
    module: "network",
    payload: { problem: { type: "shortest-path", graph: ex.problem.graph, source: ex.problem.source }, options: {} },
    solve: () => solveDijkstra(ex.problem),
  })),
  ...mstExamples.map((ex): Case => ({
    label: `network/mst: ${ex.name}`,
    module: "network",
    payload: { problem: { type: "mst", graph: ex.graph, method: "prim", startNode: ex.defaultStartNode }, options: {} },
    solve: () => solveMST({ graph: ex.graph, method: "prim", startNode: ex.defaultStartNode }),
  })),
  ...maxFlowExamples.map((ex): Case => ({
    label: `network/max-flow: ${ex.name}`,
    module: "network",
    payload: { problem: { type: "max-flow", graph: ex.problem.graph, source: ex.problem.source, sink: ex.problem.sink }, options: {} },
    solve: () => solveMaxFlow(ex.problem),
  })),
  ...tspExamples.flatMap((ex): Case[] => [
    {
      label: `tsp/nn: ${ex.name}`,
      module: "tsp",
      payload: { problem: ex.problem, options: { method: "nearest-neighbor", startCity: ex.problem.cities[0] } },
      solve: () => solveNearestNeighbor(ex.problem, ex.problem.cities[0]),
    },
    {
      label: `tsp/bnb: ${ex.name}`,
      module: "tsp",
      payload: { problem: ex.problem, options: { method: "branch-and-bound", startCity: ex.problem.cities[0] } },
      solve: () => solveTSPBranchAndBound(ex.problem),
    },
  ]),
  ...cpmExamples.map((ex): Case => ({
    label: `cpm: ${ex.name}`,
    module: "cpm",
    payload: { problem: ex.problem, options: { mode: ex.mode } },
    solve: () => solveCPM(ex.problem, ex.mode),
  })),
  ...ipExamples.map((ex): Case => ({
    label: `integer: ${ex.name}`,
    module: "integer",
    payload: { problem: ex.problem, options: {} },
    solve: () => solveIP(ex.problem),
  })),
  ...mm1Examples.map((ex): Case => ({
    label: `queuing/mm1: ${ex.name}`,
    module: "queuing",
    payload: { problem: { model: "mm1", params: ex.problem }, options: {} },
    solve: () => solveMM1(ex.problem),
  })),
  ...mmcExamples.map((ex): Case => ({
    label: `queuing/mmc: ${ex.name}`,
    module: "queuing",
    payload: { problem: { model: "mmc", params: ex.problem }, options: {} },
    solve: () => solveMMc(ex.problem),
  })),
  ...gameExamples.map((ex): Case => ({
    label: `game: ${ex.name}`,
    module: "game",
    payload: { problem: ex.problem, options: {} },
    solve: () => solveGame(ex.problem),
  })),
  ...matrixExamples.map((ex): Case => ({
    label: `matrix: ${ex.name}`,
    module: "matrix",
    payload: { problem: ex.problem, options: {} },
    solve: () => solveMatrix(ex.problem),
  })),
];

const NOW = new Date(2026, 8, 20, 14, 5, 9);

describe("Serialization", () => {
  it("turns bigint, Fraction, non-finite numbers, Map and Set into JSON-safe values", () => {
    expect(jsonReplacer("", 12345678901234567890n)).toBe("12345678901234567890");
    expect(jsonReplacer("", new Fraction(3, 2))).toBe("3/2");
    expect(jsonReplacer("", new Fraction(6, 3))).toBe("2");
    expect(jsonReplacer("", Infinity)).toBeNull();
    expect(jsonReplacer("", -Infinity)).toBeNull();
    expect(jsonReplacer("", NaN)).toBeNull();
    expect(jsonReplacer("", new Map([["a", 1]]))).toEqual({ a: 1 });
    expect(jsonReplacer("", new Set([1, 2]))).toEqual([1, 2]);
    expect(jsonReplacer("", 7)).toBe(7);
  });

  it("stringifies a structure holding all of them without throwing", () => {
    const text = toJson({ f: new Fraction(1, 3), b: 5n, inf: Infinity, m: new Map([["k", new Set([new Fraction(1, 2)])]]) });
    expect(JSON.parse(text)).toEqual({ f: "1/3", b: "5", inf: null, m: { k: ["1/2"] } });
  });

  it("a complete simplex result (exact Fractions inside) serialises with every step and no raw bigint fields", () => {
    const result = solveSimplex(lpExamples.find((e) => e.problem.variables.length > 2)?.problem ?? lpExamples[0].problem);
    const text = toJson(result);
    const back = JSON.parse(text);
    expect(back.steps).toHaveLength(result.steps.length);
    expect(text).not.toMatch(/"num"\s*:/);
    expect(text).not.toMatch(/"den"\s*:/);
  });
});

describe("Problem files: every built-in example survives export → import unchanged", () => {
  it("covers all ten modules", () => {
    expect(new Set(cases.map((c) => c.module))).toEqual(new Set(MODULE_KEYS));
    expect(cases.length).toBeGreaterThanOrEqual(30);
  });

  cases.forEach((c) => {
    it(c.label, () => {
      const built = buildExportText(c.module, c.payload, { now: NOW });
      expect(built.ok).toBe(true);
      if (!built.ok) return;
      expect(built.kind).toBe("problem");
      const parsed = parseExportText(built.text, c.module);
      expect(parsed.ok).toBe(true);
      if (!parsed.ok) return;
      expect(parsed.kind).toBe("problem");
      expect(parsed.hasSolution).toBe(false);
      expect(parsed.payload.problem).toEqual(c.payload.problem);
      expect(parsed.payload.options).toEqual(c.payload.options);
    });
  });
});

describe("Solution files: the whole result travels, and the inputs load back losslessly", () => {
  // one solution file per module is enough to prove the mechanism; each also re-solves identically
  const firstOfEach = MODULE_KEYS.map((m) => cases.find((c) => c.module === m)!);

  firstOfEach.forEach((c) => {
    it(`${c.module}: ${c.label}`, () => {
      const result = c.solve();
      const built = buildExportText(c.module, c.payload, { result, now: NOW });
      expect(built.ok).toBe(true);
      if (!built.ok) return;
      expect(built.kind).toBe("solution");
      expect(built.filename).toBe(`larpra-${c.module}-solution-20260920-1405.json`);

      const raw = JSON.parse(built.text);
      expect(raw.app).toBe(APP_ID);
      expect(raw.schemaVersion).toBe(SCHEMA_VERSION);
      expect(raw.module).toBe(c.module);
      expect(raw.kind).toBe("solution");
      expect(raw.exportedAt).toBe(NOW.toISOString());
      expect(raw.solution.steps).toHaveLength(result.steps.length);
      expect(raw.solution.steps[0]).toHaveProperty("title");
      expect(raw.solution.steps[0]).toHaveProperty("explanation");

      const parsed = parseExportText(built.text, c.module);
      expect(parsed.ok).toBe(true);
      if (!parsed.ok) return;
      expect(parsed.hasSolution).toBe(true);
      expect(parsed.payload.problem).toEqual(c.payload.problem);

      // re-solving the imported problem reproduces the exported result exactly
      const again =
        c.module === "lp"
          ? (c.payload.options.method === "graphical" ? solveGraphical : solveSimplex)(parsed.payload.problem as any)
          : c.solve();
      expect(toJson(again)).toBe(toJson(result));
    });
  });

  it("the largest solutions (branch & bound, transportation, simplex) export and stay valid JSON", () => {
    for (const c of cases.filter((x) => x.label.startsWith("tsp/bnb") || x.label.startsWith("transportation") || x.label.startsWith("lp"))) {
      const built = buildExportText(c.module, c.payload, { result: c.solve(), now: NOW });
      expect(built.ok, c.label).toBe(true);
      if (built.ok) expect(() => JSON.parse(built.text), c.label).not.toThrow();
    }
  });
});

describe("Format details", () => {
  it("builds file names from module, kind and local time", () => {
    expect(exportFilename("cpm", "solution", NOW)).toBe("larpra-cpm-solution-20260920-1405.json");
    expect(exportFilename("network", "problem", new Date(2027, 0, 3, 9, 7))).toBe("larpra-network-problem-20270103-0907.json");
  });

  it("writes null for a missing TSP edge (∞) and reads it back as Infinity", () => {
    const payload: PayloadMap["tsp"] = {
      problem: { cities: ["A", "B", "C"], symmetric: false, distances: [[0, 4, Infinity], [3, 0, 5], [2, Infinity, 0]] },
      options: {},
    };
    const built = buildExportText("tsp", payload, { now: NOW });
    expect(built.ok).toBe(true);
    if (!built.ok) return;
    expect(JSON.parse(built.text).problem.distances[0]).toEqual([0, 4, null]);
    const parsed = parseExportText(built.text, "tsp");
    expect(parsed.ok && parsed.payload.problem.distances[0][2]).toBe(Infinity);
    expect(parsed.ok && parsed.payload.problem.distances[2][1]).toBe(Infinity);
  });

  it("keeps TSP coordinates", () => {
    const withCoords = tspExamples.find((e) => e.problem.coordinates)!;
    const built = buildExportText("tsp", { problem: withCoords.problem, options: {} }, { now: NOW });
    const parsed = built.ok ? parseExportText(built.text, "tsp") : null;
    expect(parsed?.ok && parsed.payload.problem.coordinates).toEqual(withCoords.problem.coordinates);
  });

  it("CPM: blank cells are simply absent, so a half-filled table still round-trips", () => {
    const payload: PayloadMap["cpm"] = {
      problem: { activities: [{ name: "A", predecessors: [] }, { name: "B", duration: 3, predecessors: ["A"] }] },
      options: { mode: "cpm" },
    };
    const built = buildExportText("cpm", payload, { now: NOW });
    expect(built.ok).toBe(true);
    if (!built.ok) return;
    const raw = JSON.parse(built.text);
    expect("duration" in raw.problem.activities[0]).toBe(false);
    const parsed = parseExportText(built.text, "cpm");
    expect(parsed.ok && parsed.payload.problem).toEqual(payload.problem);
  });

  it("CPM: when options.mode is missing it is inferred (three-point estimates → pert)", () => {
    const text = JSON.stringify({
      app: "larpra", schemaVersion: 1, module: "cpm", kind: "problem",
      problem: { activities: [{ name: "A", optimistic: 1, mostLikely: 2, pessimistic: 3, predecessors: [] }] },
    });
    const parsed = parseExportText(text, "cpm");
    expect(parsed.ok && parsed.payload.options.mode).toBe("pert");
  });

  it("network MST: startNode defaults to the first node when omitted", () => {
    const text = JSON.stringify({
      app: "larpra", schemaVersion: 1, module: "network", kind: "problem",
      problem: { type: "mst", method: "kruskal", graph: { directed: false, nodes: ["X", "Y"], edges: [{ from: "X", to: "Y", weight: 2 }] } },
    });
    const parsed = parseExportText(text, "network");
    expect(parsed.ok && (parsed.payload.problem as Extract<NetworkProblem, { type: "mst" }>).startNode).toBe("X");
  });

  it("a solution file is also a valid problem file (the solution is simply ignored)", () => {
    const c = cases.find((x) => x.module === "assignment")!;
    const built = buildExportText("assignment", c.payload, { result: c.solve(), now: NOW });
    const parsed = built.ok ? parseExportText(built.text, "assignment") : null;
    expect(parsed?.ok).toBe(true);
    expect(parsed?.ok && Object.keys(parsed.payload)).toEqual(["problem", "options"]);
  });

  it("tolerates a UTF-8 byte-order mark at the start of the file", () => {
    const c = cases.find((x) => x.module === "cpm")!;
    const built = buildExportText("cpm", c.payload, { now: NOW });
    expect(built.ok && parseExportText("\uFEFF" + built.text, "cpm").ok).toBe(true);
  });
});

describe("Refusing bad files, with a reason a person can act on", () => {
  const cpmPayload = cases.find((c) => c.module === "cpm")!.payload;
  const good = () => {
    const b = buildExportText("cpm", cpmPayload, { now: NOW });
    if (!b.ok) throw new Error("setup failed");
    return JSON.parse(b.text) as Record<string, any>;
  };
  const err = (text: string, m: ModuleKey = "cpm") => {
    const r = parseExportText(text, m);
    if (r.ok) throw new Error("expected a rejection");
    return r;
  };

  it("not JSON", () => expect(err("hello {").error).toBe("That file isn't valid JSON."));
  it("JSON but not an object", () => expect(err("[1,2]").error).toContain("expected a JSON object"));
  it("someone else's JSON", () => expect(err(JSON.stringify({ hello: 1 })).error).toContain("isn't a larpra file"));
  it("no schemaVersion", () => {
    const d = good(); delete d.schemaVersion;
    expect(err(JSON.stringify(d)).error).toContain("no valid schemaVersion");
  });
  it("schemaVersion 0 and 1.5 are invalid", () => {
    expect(err(JSON.stringify({ ...good(), schemaVersion: 0 })).error).toContain("no valid schemaVersion");
    expect(err(JSON.stringify({ ...good(), schemaVersion: 1.5 })).error).toContain("no valid schemaVersion");
  });
  it("a newer schemaVersion asks the user to update", () => {
    const r = err(JSON.stringify({ ...good(), schemaVersion: SCHEMA_VERSION + 1 }));
    expect(r.error).toContain("newer version of larpra");
    expect(r.error).toContain(`format ${SCHEMA_VERSION + 1}`);
  });
  it("an unknown module", () => expect(err(JSON.stringify({ ...good(), module: "quantum" })).error).toContain("unknown module"));
  it("a file for a different module says which one to open", () => {
    const r = err(JSON.stringify(good()), "lp");
    expect(r.error).toBe("That file is a CPM / PERT problem — open CPM / PERT to load it.");
    const sol = { ...good(), kind: "solution" };
    expect(err(JSON.stringify(sol), "tsp").error).toContain("CPM / PERT solution");
  });
  it("an invalid kind", () => expect(err(JSON.stringify({ ...good(), kind: "backup" })).error).toContain('"kind"'));
  it("an oversized file", () => expect(err("x".repeat(MAX_FILE_BYTES + 1)).error).toContain("too large"));

  it("LP: wrong number of objective coefficients names the field and the counts", () => {
    const lp = cases.find((c) => c.module === "lp")!.payload;
    const b = buildExportText("lp", lp, { now: NOW });
    if (!b.ok) throw new Error("setup");
    const d = JSON.parse(b.text);
    d.problem.objective = [1];
    const r = err(JSON.stringify(d), "lp");
    expect(r.details?.[0]).toContain("problem.objective must have 2 values (has 1)");
  });
  it("LP: bad relation and missing rhs are both reported", () => {
    const lp = cases.find((c) => c.module === "lp")!.payload;
    const d = JSON.parse((buildExportText("lp", lp, { now: NOW }) as any).text);
    d.problem.constraints[0].relation = "<>";
    delete d.problem.constraints[1].rhs;
    const r = err(JSON.stringify(d), "lp");
    expect(r.details!.join(" | ")).toContain("problem.constraints[0].relation must be one of: <=, >=, =");
    expect(r.details!.join(" | ")).toContain("problem.constraints[1].rhs must be a number");
  });
  it("a number cell that is null is reported as blank (only TSP distances may be null)", () => {
    const lp = cases.find((c) => c.module === "lp")!.payload;
    const d = JSON.parse((buildExportText("lp", lp, { now: NOW }) as any).text);
    d.problem.objective[0] = null;
    expect(err(JSON.stringify(d), "lp").details![0]).toContain("problem.objective[0] must be a number (it is blank)");
  });
  it("numbers beyond ±1e12 are out of range", () => {
    const a = cases.find((c) => c.module === "assignment")!.payload;
    const d = JSON.parse((buildExportText("assignment", a, { now: NOW }) as any).text);
    d.problem.costs[0][0] = 1e13;
    expect(err(JSON.stringify(d), "assignment").details![0]).toContain("out of range");
  });
  it("Transportation: a cost row with the wrong width is rejected", () => {
    const t = cases.find((c) => c.module === "transportation")!.payload;
    const d = JSON.parse((buildExportText("transportation", t, { now: NOW }) as any).text);
    d.problem.costs[0].pop();
    expect(err(JSON.stringify(d), "transportation").details![0]).toMatch(/problem\.costs\[0\] must have \d+ values/);
  });
  it("Network: unknown problem type and a non-numeric edge weight", () => {
    const n = cases.find((c) => c.module === "network")!.payload;
    const d = JSON.parse((buildExportText("network", n, { now: NOW }) as any).text);
    d.problem.type = "transshipment";
    expect(err(JSON.stringify(d), "network").details!.join(" ")).toContain("problem.type must be one of");
    const e = JSON.parse((buildExportText("network", n, { now: NOW }) as any).text);
    e.problem.graph.edges[0].weight = "heavy";
    expect(err(JSON.stringify(e), "network").details![0]).toContain("edges[0].weight must be a number");
  });
  it("Game Theory: a payoff table with the wrong shape, and a non-boolean zeroSum flag, are rejected", () => {
    const g = cases.find((c) => c.module === "game")!.payload;
    const d = JSON.parse((buildExportText("game", g, { now: NOW }) as any).text);
    d.problem.payoffB[0].pop();
    expect(err(JSON.stringify(d), "game").details![0]).toMatch(/problem\.payoffB\[0\] must have \d+ values/);
    const e = JSON.parse((buildExportText("game", g, { now: NOW }) as any).text);
    e.problem.zeroSum = "yes";
    expect(err(JSON.stringify(e), "game").details![0]).toContain("problem.zeroSum must be true or false");
  });
  it("Game Theory: payoffs may be negative and fractional and survive the round trip exactly", () => {
    const problem = { rowNames: ["A", "B"], colNames: ["X", "Y"], payoffA: [[-1.5, 2], [0.25, -3]], payoffB: [[1.5, -2], [-0.25, 3]], zeroSum: true };
    const built = buildExportText("game", { problem, options: {} }, { now: NOW });
    expect(built.ok).toBe(true);
    if (!built.ok) return;
    const back = parseExportText(built.text, "game");
    expect(back.ok).toBe(true);
    if (back.ok) expect(back.payload.problem).toEqual(problem);
  });
  it("Matrix: a ragged matrix row is rejected", () => {
    const m = cases.find((c) => c.module === "matrix")!.payload;
    const d = JSON.parse((buildExportText("matrix", m, { now: NOW }) as any).text);
    d.problem.matrix[0].pop();
    expect(err(JSON.stringify(d), "matrix").details!.join(" ")).toMatch(/every row must have the same number of columns/);
  });
  it("Matrix: a wrong-length rhs is rejected", () => {
    const solveCase = matrixExamples.find((e) => e.problem.operation === "gaussian")!;
    const built = buildExportText("matrix", { problem: solveCase.problem, options: {} }, { now: NOW });
    const d = JSON.parse((built as any).text);
    d.problem.rhs.pop();
    expect(err(JSON.stringify(d), "matrix").details![0]).toMatch(/problem\.rhs must have \d+ values/);
  });
  it("Matrix: an unrecognized operation is rejected", () => {
    const m = cases.find((c) => c.module === "matrix")!.payload;
    const d = JSON.parse((buildExportText("matrix", m, { now: NOW }) as any).text);
    d.problem.operation = "invert-with-magic";
    expect(err(JSON.stringify(d), "matrix").details!.join(" ")).toContain("problem.operation must be one of");
  });
  it("Matrix: entries may be negative and fractional and survive the round trip exactly", () => {
    const problem = { operation: "gaussian" as const, matrix: [[1.5, -2], [-0.25, 3]], rhs: [2.5, -1] };
    const built = buildExportText("matrix", { problem, options: {} }, { now: NOW });
    expect(built.ok).toBe(true);
    if (!built.ok) return;
    const back = parseExportText(built.text, "matrix");
    expect(back.ok).toBe(true);
    if (back.ok) expect(back.payload.problem).toEqual(problem);
  });
  it("TSP: a ragged distance matrix is rejected", () => {
    const t = cases.find((c) => c.module === "tsp")!.payload;
    const d = JSON.parse((buildExportText("tsp", t, { now: NOW }) as any).text);
    d.problem.distances[1].pop();
    expect(err(JSON.stringify(d), "tsp").details![0]).toMatch(/problem\.distances\[1\] must have \d+ values/);
  });
  it("CPM: a null duration is rejected (absent is fine, null means blank)", () => {
    const d = good();
    d.problem.activities[0].duration = null;
    expect(err(JSON.stringify(d)).details![0]).toContain("problem.activities[0].duration must be a number (it is blank)");
  });
  it("very long text is rejected", () => {
    const d = good();
    d.problem.activities[0].name = "x".repeat(500);
    expect(err(JSON.stringify(d)).details![0]).toContain("too long");
  });
  it("lists at most 8 problems, then counts the rest", () => {
    const d = good();
    d.problem.activities = Array.from({ length: 20 }, () => ({ name: 5, predecessors: [] }));
    const r = err(JSON.stringify(d));
    expect(r.details).toHaveLength(9);
    expect(r.details![8]).toMatch(/…and \d+ more problems?\./);
  });

  it("ignores unknown keys instead of carrying them into the app", () => {
    const d = good();
    d.problem.evil = "x";
    d.problem.activities[0].extra = 1;
    const r = parseExportText(JSON.stringify(d), "cpm");
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect("evil" in r.payload.problem).toBe(false);
      expect("extra" in r.payload.problem.activities[0]).toBe(false);
    }
  });

  it("a __proto__ key in the file can't pollute Object.prototype or leak into the payload", () => {
    const text =
      '{"app":"larpra","schemaVersion":1,"module":"cpm","kind":"problem","__proto__":{"polluted":true},' +
      '"options":{"__proto__":{"polluted":true}},"problem":{"__proto__":{"polluted":true},"activities":[{"name":"A","duration":1,"predecessors":[],"__proto__":{"polluted":true}}]}}';
    const r = parseExportText(text, "cpm");
    expect(r.ok).toBe(true);
    expect(({} as any).polluted).toBeUndefined();
    if (r.ok) {
      expect(Object.keys(r.payload.problem)).toEqual(["activities"]);
      expect(Object.keys(r.payload.problem.activities[0]).sort()).toEqual(["duration", "name", "predecessors"]);
    }
  });
});

describe("Export-time guard: a file that couldn't be re-imported is never produced", () => {
  it("refuses an LP with a blank (NaN) coefficient and says where", () => {
    const lp = structuredClone(cases.find((c) => c.module === "lp")!.payload);
    lp.problem.objective[1] = NaN;
    const built = buildExportText("lp", lp, { now: NOW });
    expect(built.ok).toBe(false);
    if (!built.ok) expect(built.errors[0]).toContain("problem.objective[1] must be a number (it is blank)");
  });
  it("refuses a problem whose dimensions disagree (e.g. a supply list shorter than the sources)", () => {
    const t = structuredClone(cases.find((c) => c.module === "transportation")!.payload);
    t.problem.supply.pop();
    expect(buildExportText("transportation", t, { now: NOW }).ok).toBe(false);
  });
});
