import { Fraction } from "../utils/fraction";

/**
 * JSON.stringify replacer that makes every larpra value serialisable:
 *   bigint → decimal string          Fraction → exact "3/2" (or "3")
 *   ±Infinity, NaN → null (the file-format convention for ∞ / no edge)
 *   Map → object, Set → array
 */
export function jsonReplacer(_key: string, value: unknown): unknown {
  if (typeof value === "bigint") return value.toString();
  if (value instanceof Fraction) return value.den === 1n ? value.num.toString() : `${value.num}/${value.den}`;
  if (typeof value === "number" && !Number.isFinite(value)) return null;
  if (value instanceof Map) return Object.fromEntries(value);
  if (value instanceof Set) return [...value];
  return value;
}

export function toJson(value: unknown, indent = 2): string {
  return JSON.stringify(value, jsonReplacer, indent);
}
