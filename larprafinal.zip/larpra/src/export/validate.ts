import { LPConstraint, LPProblem } from "../types/lp";
import { TransportationProblemInput } from "../types/transportation";
import { AssignmentProblemInput } from "../types/assignment";
import { GraphInput } from "../types/network";
import { TSPProblemInput } from "../types/tsp";
import { CPMActivityInput } from "../types/cpm";
import { inferMode } from "../algorithms/cpm/standardize";
import { IPProblem, VAR_TYPES, VarType } from "../types/integer";
import { QueuingProblem } from "../types/queuing";
import { GameInput } from "../types/game";
import { MatrixInput, MATRIX_OPERATIONS } from "../types/matrix";
import {
  CPM_MODES,
  IP_BRANCHING_RULES,
  IP_NODE_SELECTIONS,
  LP_METHODS,
  ModuleKey,
  MST_METHODS,
  NetworkProblem,
  PayloadMap,
  TRANSPORTATION_METHODS,
  TSP_METHODS,
} from "./schema";

export type ParseResult<T> = { ok: true; value: T } | { ok: false; errors: string[] };

const MAX_ITEMS = 1000;
const MAX_STRING = 200;
const MAX_ERRORS = 8;
/** Numbers beyond this can't be handled exactly by the solvers, so an imported file may not contain them. */
const LIMIT = 1e12;

/**
 * Structural validation only: shapes, types, dimensions, enums, finite numbers in range.
 * (Whether a problem is *solvable* — balanced, non-negative, acyclic … — stays the job of each
 * module's own validator, so the app shows the same messages for imported and typed problems.)
 * The parsers copy known fields into fresh objects, so unknown keys in a file are dropped.
 */
class Reader {
  errors: string[] = [];
  private overflow = 0;

  fail(msg: string) {
    if (this.errors.length < MAX_ERRORS) this.errors.push(msg);
    else this.overflow++;
  }

  finish<T>(value: T): ParseResult<T> {
    if (this.errors.length === 0) return { ok: true, value };
    const errors = this.overflow > 0 ? [...this.errors, `…and ${this.overflow} more problem${this.overflow === 1 ? "" : "s"}.`] : this.errors;
    return { ok: false, errors };
  }

  record(v: unknown, path: string): Record<string, unknown> | null {
    if (typeof v !== "object" || v === null || Array.isArray(v)) {
      this.fail(`${path} must be an object.`);
      return null;
    }
    return v as Record<string, unknown>;
  }

  array(v: unknown, path: string, min = 0, max = MAX_ITEMS): unknown[] | null {
    if (!Array.isArray(v)) {
      this.fail(`${path} must be a list.`);
      return null;
    }
    if (v.length < min || v.length > max) {
      this.fail(`${path} must have between ${min} and ${max} items (has ${v.length}).`);
      return null;
    }
    return v;
  }

  string(v: unknown, path: string): string | null {
    if (typeof v !== "string") {
      this.fail(`${path} must be text.`);
      return null;
    }
    if (v.length > MAX_STRING) {
      this.fail(`${path} is too long (over ${MAX_STRING} characters).`);
      return null;
    }
    return v;
  }

  finite(v: unknown, path: string): number | null {
    if (typeof v !== "number" || !Number.isFinite(v)) {
      this.fail(`${path} must be a number${v === null ? " (it is blank)" : ""}.`);
      return null;
    }
    if (Math.abs(v) > LIMIT) {
      this.fail(`${path} is out of range (must be between −1e12 and 1e12).`);
      return null;
    }
    return v;
  }

  /** A number that may be absent (undefined). null is NOT accepted — it would mean "blank". */
  optFinite(v: unknown, path: string): number | undefined {
    return v === undefined ? undefined : this.finite(v, path) ?? undefined;
  }

  bool(v: unknown, path: string): boolean | null {
    if (typeof v !== "boolean") {
      this.fail(`${path} must be true or false.`);
      return null;
    }
    return v;
  }

  oneOf<T extends string>(v: unknown, path: string, allowed: readonly T[]): T | null {
    if (typeof v === "string" && (allowed as readonly string[]).includes(v)) return v as T;
    this.fail(`${path} must be one of: ${allowed.join(", ")}.`);
    return null;
  }

  optOneOf<T extends string>(v: unknown, path: string, allowed: readonly T[]): T | undefined {
    return v === undefined ? undefined : this.oneOf(v, path, allowed) ?? undefined;
  }

  strings(v: unknown, path: string, min = 0, max = MAX_ITEMS): string[] | null {
    const arr = this.array(v, path, min, max);
    if (!arr) return null;
    return arr.map((x, i) => this.string(x, `${path}[${i}]`) ?? "");
  }

  numbers(v: unknown, path: string, length?: number): number[] | null {
    const arr = this.array(v, path);
    if (!arr) return null;
    if (length !== undefined && arr.length !== length) {
      this.fail(`${path} must have ${length} values (has ${arr.length}).`);
      return null;
    }
    return arr.map((x, i) => this.finite(x, `${path}[${i}]`) ?? 0);
  }

  matrix(v: unknown, path: string, rows?: number, cols?: number, nullIsInfinity = false): number[][] | null {
    const arr = this.array(v, path);
    if (!arr) return null;
    if (rows !== undefined && arr.length !== rows) {
      this.fail(`${path} must have ${rows} rows (has ${arr.length}).`);
      return null;
    }
    const out: number[][] = [];
    arr.forEach((row, i) => {
      const rp = `${path}[${i}]`;
      const ra = this.array(row, rp);
      if (!ra) return;
      if (cols !== undefined && ra.length !== cols) {
        this.fail(`${rp} must have ${cols} values (has ${ra.length}).`);
        return;
      }
      out.push(ra.map((x, j) => (nullIsInfinity && x === null ? Infinity : this.finite(x, `${rp}[${j}]`) ?? 0)));
    });
    return out;
  }

  /** `options` may be absent; if present it must be an object. */
  options(v: unknown): Record<string, unknown> {
    return v === undefined ? {} : this.record(v, "options") ?? {};
  }
}

/* ------------------------------------------------------------------ */

export function parseLP(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["lp"]> {
  const r = new Reader();
  const o = r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: LPProblem = { sense: "max", objective: [], variables: [], constraints: [] };
  if (p) {
    const sense = r.oneOf(p.sense, "problem.sense", ["max", "min"] as const);
    const variables = r.strings(p.variables, "problem.variables", 1, 50);
    const n = variables?.length;
    const objective = r.numbers(p.objective, "problem.objective", n);
    const constraints: LPConstraint[] = [];
    r.array(p.constraints, "problem.constraints", 0, 200)?.forEach((c, i) => {
      const path = `problem.constraints[${i}]`;
      const cr = r.record(c, path);
      if (!cr) return;
      const coeffs = r.numbers(cr.coeffs, `${path}.coeffs`, n);
      const relation = r.oneOf(cr.relation, `${path}.relation`, ["<=", ">=", "="] as const);
      const rhs = r.finite(cr.rhs, `${path}.rhs`);
      const label = cr.label === undefined ? undefined : r.string(cr.label, `${path}.label`) ?? undefined;
      if (coeffs && relation && rhs !== null) constraints.push({ coeffs, relation, rhs, ...(label !== undefined ? { label } : {}) });
    });
    problem = { sense: sense ?? "max", variables: variables ?? [], objective: objective ?? [], constraints };
  }
  const method = r.optOneOf(o.method, "options.method", LP_METHODS);
  return r.finish({ problem, options: method ? { method } : {} });
}

export function parseTransportation(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["transportation"]> {
  const r = new Reader();
  const o = r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: TransportationProblemInput = { sourceNames: [], destNames: [], costs: [], supply: [], demand: [] };
  if (p) {
    const sourceNames = r.strings(p.sourceNames, "problem.sourceNames", 0, 50);
    const destNames = r.strings(p.destNames, "problem.destNames", 0, 50);
    const costs = r.matrix(p.costs, "problem.costs", sourceNames?.length, destNames?.length);
    const supply = r.numbers(p.supply, "problem.supply", sourceNames?.length);
    const demand = r.numbers(p.demand, "problem.demand", destNames?.length);
    problem = {
      sourceNames: sourceNames ?? [],
      destNames: destNames ?? [],
      costs: costs ?? [],
      supply: supply ?? [],
      demand: demand ?? [],
    };
  }
  const method = r.optOneOf(o.method, "options.method", TRANSPORTATION_METHODS);
  return r.finish({ problem, options: method ? { method } : {} });
}

export function parseAssignment(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["assignment"]> {
  const r = new Reader();
  r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: AssignmentProblemInput = { workerNames: [], taskNames: [], costs: [] };
  if (p) {
    const workerNames = r.strings(p.workerNames, "problem.workerNames", 0, 50);
    const taskNames = r.strings(p.taskNames, "problem.taskNames", 0, 50);
    const costs = r.matrix(p.costs, "problem.costs", workerNames?.length, taskNames?.length);
    problem = { workerNames: workerNames ?? [], taskNames: taskNames ?? [], costs: costs ?? [] };
  }
  return r.finish({ problem, options: {} });
}

function parseGraph(r: Reader, raw: unknown, path: string): GraphInput {
  const g = r.record(raw, path);
  const graph: GraphInput = { nodes: [], edges: [], directed: false };
  if (!g) return graph;
  graph.nodes = r.strings(g.nodes, `${path}.nodes`, 0, 500) ?? [];
  graph.directed = r.bool(g.directed, `${path}.directed`) ?? false;
  r.array(g.edges, `${path}.edges`, 0, 5000)?.forEach((e, i) => {
    const ep = `${path}.edges[${i}]`;
    const er = r.record(e, ep);
    if (!er) return;
    const from = r.string(er.from, `${ep}.from`);
    const to = r.string(er.to, `${ep}.to`);
    const weight = r.finite(er.weight, `${ep}.weight`);
    if (from !== null && to !== null && weight !== null) graph.edges.push({ from, to, weight });
  });
  return graph;
}

export function parseNetwork(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["network"]> {
  const r = new Reader();
  r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: NetworkProblem = { type: "shortest-path", graph: { nodes: [], edges: [], directed: true }, source: "" };
  if (p) {
    const type = r.oneOf(p.type, "problem.type", ["shortest-path", "mst", "max-flow"] as const);
    const graph = parseGraph(r, p.graph, "problem.graph");
    if (type === "mst") {
      const method = r.oneOf(p.method, "problem.method", MST_METHODS);
      const startNode = p.startNode === undefined ? graph.nodes[0] ?? "" : r.string(p.startNode, "problem.startNode") ?? "";
      problem = { type, graph, method: method ?? "kruskal", startNode };
    } else if (type === "max-flow") {
      problem = { type, graph, source: r.string(p.source, "problem.source") ?? "", sink: r.string(p.sink, "problem.sink") ?? "" };
    } else if (type === "shortest-path") {
      problem = { type, graph, source: r.string(p.source, "problem.source") ?? "" };
    }
  }
  return r.finish({ problem, options: {} });
}

export function parseTSP(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["tsp"]> {
  const r = new Reader();
  const o = r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: TSPProblemInput = { cities: [], distances: [], symmetric: false };
  if (p) {
    const cities = r.strings(p.cities, "problem.cities", 0, 50);
    // null in a distance cell means "no edge" (∞), the same convention the editor uses for a blank cell
    const distances = r.matrix(p.distances, "problem.distances", cities?.length, cities?.length, true);
    const symmetric = r.bool(p.symmetric, "problem.symmetric");
    problem = { cities: cities ?? [], distances: distances ?? [], symmetric: symmetric ?? false };
    if (p.coordinates !== undefined) {
      const c = r.record(p.coordinates, "problem.coordinates");
      if (c) {
        const coordinates: Record<string, { x: number; y: number }> = {};
        Object.entries(c).forEach(([city, pt]) => {
          const pr = r.record(pt, `problem.coordinates.${city}`);
          if (!pr) return;
          const x = r.finite(pr.x, `problem.coordinates.${city}.x`);
          const y = r.finite(pr.y, `problem.coordinates.${city}.y`);
          if (x !== null && y !== null) coordinates[city] = { x, y };
        });
        problem.coordinates = coordinates;
      }
    }
  }
  const method = r.optOneOf(o.method, "options.method", TSP_METHODS);
  const startCity = o.startCity === undefined ? undefined : r.string(o.startCity, "options.startCity") ?? undefined;
  return r.finish({ problem, options: { ...(method ? { method } : {}), ...(startCity !== undefined ? { startCity } : {}) } });
}

export function parseCPM(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["cpm"]> {
  const r = new Reader();
  const o = r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  const activities: CPMActivityInput[] = [];
  if (p) {
    r.array(p.activities, "problem.activities", 0, MAX_ITEMS)?.forEach((a, i) => {
      const path = `problem.activities[${i}]`;
      const ar = r.record(a, path);
      if (!ar) return;
      const name = r.string(ar.name, `${path}.name`);
      const predecessors = r.strings(ar.predecessors, `${path}.predecessors`, 0, MAX_ITEMS);
      const act: CPMActivityInput = { name: name ?? "", predecessors: predecessors ?? [] };
      // blank cells are simply absent from the file, so a half-filled table survives a round trip
      for (const key of ["duration", "optimistic", "mostLikely", "pessimistic"] as const) {
        const v = r.optFinite(ar[key], `${path}.${key}`);
        if (v !== undefined) act[key] = v;
      }
      activities.push(act);
    });
  }
  const problem = { activities };
  const mode = r.optOneOf(o.mode, "options.mode", CPM_MODES);
  return r.finish({ problem, options: { mode: mode ?? inferMode(problem) } });
}

export function parseIP(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["integer"]> {
  const r = new Reader();
  const o = r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: IPProblem = { sense: "max", objective: [], variables: [], constraints: [] };
  if (p) {
    const sense = r.oneOf(p.sense, "problem.sense", ["max", "min"] as const);
    const variables = r.strings(p.variables, "problem.variables", 1, 50);
    const n = variables?.length;
    const objective = r.numbers(p.objective, "problem.objective", n);
    const constraints: LPConstraint[] = [];
    r.array(p.constraints, "problem.constraints", 0, 200)?.forEach((c, i) => {
      const path = `problem.constraints[${i}]`;
      const cr = r.record(c, path);
      if (!cr) return;
      const coeffs = r.numbers(cr.coeffs, `${path}.coeffs`, n);
      const relation = r.oneOf(cr.relation, `${path}.relation`, ["<=", ">=", "="] as const);
      const rhs = r.finite(cr.rhs, `${path}.rhs`);
      const label = cr.label === undefined ? undefined : r.string(cr.label, `${path}.label`) ?? undefined;
      if (coeffs && relation && rhs !== null) constraints.push({ coeffs, relation, rhs, ...(label !== undefined ? { label } : {}) });
    });
    let varTypes: VarType[] | undefined;
    if (p.varTypes !== undefined) {
      const arr = r.array(p.varTypes, "problem.varTypes", 0, n ?? MAX_ITEMS);
      if (arr) varTypes = arr.map((v, i) => r.oneOf(v, `problem.varTypes[${i}]`, VAR_TYPES) ?? "integer");
    }
    problem = { sense: sense ?? "max", variables: variables ?? [], objective: objective ?? [], constraints, ...(varTypes ? { varTypes } : {}) };
  }
  const nodeSelection = r.optOneOf(o.nodeSelection, "options.nodeSelection", IP_NODE_SELECTIONS);
  const branching = r.optOneOf(o.branching, "options.branching", IP_BRANCHING_RULES);
  const tightenIntegerObjective = o.tightenIntegerObjective === undefined ? undefined : r.bool(o.tightenIntegerObjective, "options.tightenIntegerObjective") ?? undefined;
  const nodeLimit = r.optFinite(o.nodeLimit, "options.nodeLimit");
  return r.finish({
    problem,
    options: {
      ...(nodeSelection ? { nodeSelection } : {}),
      ...(branching ? { branching } : {}),
      ...(tightenIntegerObjective !== undefined ? { tightenIntegerObjective } : {}),
      ...(nodeLimit !== undefined ? { nodeLimit } : {}),
    },
  });
}

export function parseQueuing(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["queuing"]> {
  const r = new Reader();
  r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: QueuingProblem = { model: "mm1", params: { lambda: 0, mu: 0, maxN: 10 } };
  if (p) {
    const model = r.oneOf(p.model, "problem.model", ["mm1", "mmc"] as const);
    const params = r.record(p.params, "problem.params");
    const lambda = r.finite(params?.lambda, "problem.params.lambda") ?? 0;
    const mu = r.finite(params?.mu, "problem.params.mu") ?? 0;
    const maxN = r.finite(params?.maxN, "problem.params.maxN") ?? 10;
    if (model === "mmc") {
      const servers = r.finite(params?.servers, "problem.params.servers") ?? 1;
      problem = { model: "mmc", params: { lambda, mu, servers, maxN } };
    } else if (model === "mm1") {
      problem = { model: "mm1", params: { lambda, mu, maxN } };
    }
  }
  return r.finish({ problem, options: {} });
}

export function parseGame(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["game"]> {
  const r = new Reader();
  r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: GameInput = { rowNames: [], colNames: [], payoffA: [], payoffB: [], zeroSum: false };
  if (p) {
    const rowNames = r.strings(p.rowNames, "problem.rowNames", 0, 50);
    const colNames = r.strings(p.colNames, "problem.colNames", 0, 50);
    const payoffA = r.matrix(p.payoffA, "problem.payoffA", rowNames?.length, colNames?.length);
    const payoffB = r.matrix(p.payoffB, "problem.payoffB", rowNames?.length, colNames?.length);
    const zeroSum = r.bool(p.zeroSum, "problem.zeroSum");
    problem = { rowNames: rowNames ?? [], colNames: colNames ?? [], payoffA: payoffA ?? [], payoffB: payoffB ?? [], zeroSum: zeroSum ?? false };
  }
  return r.finish({ problem, options: {} });
}

export function parseMatrix(problemRaw: unknown, optionsRaw: unknown): ParseResult<PayloadMap["matrix"]> {
  const r = new Reader();
  r.options(optionsRaw);
  const p = r.record(problemRaw, "problem");
  let problem: MatrixInput = { operation: "gaussian", matrix: [[0]] };
  if (p) {
    const operation = r.oneOf(p.operation, "problem.operation", MATRIX_OPERATIONS);
    const rows = r.array(p.matrix, "problem.matrix", 1, 6);
    const matrix = rows ? rows.map((row, i) => r.numbers(row, `problem.matrix[${i}]`) ?? []) : [[0]];
    const cols = matrix[0]?.length;
    if (matrix.some((row) => row.length !== cols)) r.fail("problem.matrix: every row must have the same number of columns");
    const rhs = p.rhs === undefined ? undefined : r.numbers(p.rhs, "problem.rhs", matrix.length) ?? undefined;
    problem = { operation: operation ?? "gaussian", matrix, ...(rhs !== undefined ? { rhs } : {}) };
  }
  return r.finish({ problem, options: {} });
}

export const PARSERS: { [K in ModuleKey]: (problem: unknown, options: unknown) => ParseResult<PayloadMap[K]> } = {
  lp: parseLP,
  transportation: parseTransportation,
  assignment: parseAssignment,
  network: parseNetwork,
  tsp: parseTSP,
  cpm: parseCPM,
  integer: parseIP,
  queuing: parseQueuing,
  game: parseGame,
  matrix: parseMatrix,
};
