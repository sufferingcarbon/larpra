import {
  APP_ID,
  Envelope,
  FileKind,
  MAX_FILE_BYTES,
  MODULE_KEYS,
  MODULE_LABELS,
  ModuleKey,
  PayloadMap,
  SCHEMA_VERSION,
} from "./schema";
import { toJson } from "./serialize";
import { PARSERS } from "./validate";

export type BuildResult =
  | { ok: true; text: string; filename: string; kind: FileKind }
  | { ok: false; errors: string[] };

export type ParseFileResult<K extends ModuleKey> =
  | { ok: true; payload: PayloadMap[K]; kind: FileKind; exportedAt: string | null; hasSolution: boolean }
  | { ok: false; error: string; details?: string[] };

const pad = (n: number) => String(n).padStart(2, "0");

/** larpra-cpm-solution-20260920-1405.json */
export function exportFilename(module: ModuleKey, kind: FileKind, now: Date): string {
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
  return `${APP_ID}-${module}-${kind}-${stamp}.json`;
}

/**
 * Build the text of a larpra file. Pass `result` to make it a "solution" file (the whole result,
 * every step included). The finished text is parsed back through the importer before it is handed
 * out, so a file that can't be re-imported (say, a half-filled table) is refused here rather than
 * discovered later.
 */
export function buildExportText<K extends ModuleKey>(
  module: K,
  payload: PayloadMap[K],
  options: { result?: unknown; now?: Date } = {}
): BuildResult {
  const now = options.now ?? new Date();
  const kind: FileKind = options.result !== undefined ? "solution" : "problem";
  const envelope: Envelope = {
    app: APP_ID,
    schemaVersion: SCHEMA_VERSION,
    module,
    kind,
    exportedAt: now.toISOString(),
    options: payload.options,
    problem: payload.problem,
    ...(kind === "solution" ? { solution: options.result } : {}),
  };
  const text = toJson(envelope);
  const check = parseExportText(text, module);
  if (!check.ok) return { ok: false, errors: check.details && check.details.length > 0 ? check.details : [check.error] };
  return { ok: true, text, filename: exportFilename(module, kind, now), kind };
}

/** Read a larpra file, checking it is ours, a version we understand, and for the module that asked. */
export function parseExportText<K extends ModuleKey>(rawText: string, expected: K): ParseFileResult<K> {
  if (rawText.length > MAX_FILE_BYTES) {
    return { ok: false, error: `That file is too large (over ${MAX_FILE_BYTES / (1024 * 1024)} MB).` };
  }
  const text = rawText.charCodeAt(0) === 0xfeff ? rawText.slice(1) : rawText;
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { ok: false, error: "That file isn't valid JSON." };
  }
  if (typeof data !== "object" || data === null || Array.isArray(data)) {
    return { ok: false, error: "That file isn't a larpra file (expected a JSON object)." };
  }
  const d = data as Record<string, unknown>;
  if (d.app !== APP_ID) return { ok: false, error: "That file isn't a larpra file (its \"app\" field isn't \"larpra\")." };

  const version = d.schemaVersion;
  if (typeof version !== "number" || !Number.isInteger(version) || version < 1) {
    return { ok: false, error: "That file has no valid schemaVersion." };
  }
  if (version > SCHEMA_VERSION) {
    return {
      ok: false,
      error: `That file was made by a newer version of larpra (file format ${version}; this version reads format ${SCHEMA_VERSION}). Update larpra to open it.`,
    };
  }

  const mod = d.module;
  if (typeof mod !== "string" || !(MODULE_KEYS as readonly string[]).includes(mod)) {
    return { ok: false, error: `That file is for an unknown module (${JSON.stringify(mod)}).` };
  }
  if (mod !== expected) {
    const label = MODULE_LABELS[mod as ModuleKey];
    return { ok: false, error: `That file is a ${label} ${d.kind === "solution" ? "solution" : "problem"} — open ${label} to load it.` };
  }
  if (d.kind !== "problem" && d.kind !== "solution") {
    return { ok: false, error: `That file's "kind" must be "problem" or "solution".` };
  }

  const parsed = PARSERS[expected](d.problem, d.options);
  if (!parsed.ok) return { ok: false, error: "That file's problem data isn't valid:", details: parsed.errors };
  return {
    ok: true,
    payload: parsed.value,
    kind: d.kind,
    exportedAt: typeof d.exportedAt === "string" ? d.exportedAt : null,
    hasSolution: d.kind === "solution" && d.solution !== undefined,
  };
}
