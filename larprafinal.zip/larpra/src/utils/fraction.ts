/**
 * A minimal exact-rational-arithmetic type.
 *
 * The simplex, transportation and Hungarian engines all reduce to a long
 * sequence of add/subtract/multiply/divide operations on the same numbers.
 * Doing that in IEEE floats eventually produces values like 2.9999999999996
 * that break optimality tests ("is this <= 0?"). Representing every number
 * as an exact fraction of two BigInts removes that entire failure mode —
 * the only rounding that happens is in the final display layer.
 */

function gcd(a: bigint, b: bigint): bigint {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b) {
    [a, b] = [b, a % b];
  }
  return a === 0n ? 1n : a;
}

export class Fraction {
  readonly num: bigint;
  readonly den: bigint;

  constructor(num: bigint | number, den: bigint | number = 1n) {
    let n = typeof num === "number" ? Fraction.fromFloatParts(num) : { n: num, d: 1n };
    let d = typeof den === "number" ? Fraction.fromFloatParts(den) : { n: den, d: 1n };
    // combine num/den with n.d / d.d
    let finalNum = n.n * d.d;
    let finalDen = n.d * d.n;
    if (finalDen === 0n) throw new Error("Fraction: division by zero");
    if (finalDen < 0n) {
      finalNum = -finalNum;
      finalDen = -finalDen;
    }
    const g = gcd(finalNum, finalDen);
    this.num = finalNum / g;
    this.den = finalDen / g;
  }

  private static fromFloatParts(x: number): { n: bigint; d: bigint } {
    if (Number.isInteger(x)) return { n: BigInt(x), d: 1n };
    // Convert a finite decimal (what every UI input produces) exactly.
    const s = x.toString();
    if (s.includes("e") || s.includes("E")) {
      // Fallback for scientific notation: scale by a large power of ten.
      const scale = 1_000_000_000;
      return { n: BigInt(Math.round(x * scale)), d: BigInt(scale) };
    }
    const [intPart, fracPart = ""] = s.replace("-", "").split(".");
    const sign = x < 0 ? -1n : 1n;
    const d = 10n ** BigInt(fracPart.length);
    const n = sign * (BigInt(intPart) * d + BigInt(fracPart || "0"));
    return { n, d };
  }

  static from(x: number | bigint | Fraction): Fraction {
    if (x instanceof Fraction) return x;
    return new Fraction(x);
  }

  add(other: Fraction | number): Fraction {
    const o = Fraction.from(other);
    return new Fraction(this.num * o.den + o.num * this.den, this.den * o.den);
  }

  sub(other: Fraction | number): Fraction {
    const o = Fraction.from(other);
    return new Fraction(this.num * o.den - o.num * this.den, this.den * o.den);
  }

  mul(other: Fraction | number): Fraction {
    const o = Fraction.from(other);
    return new Fraction(this.num * o.num, this.den * o.den);
  }

  div(other: Fraction | number): Fraction {
    const o = Fraction.from(other);
    if (o.num === 0n) throw new Error("Fraction: division by zero");
    return new Fraction(this.num * o.den, this.den * o.num);
  }

  neg(): Fraction {
    return new Fraction(-this.num, this.den);
  }

  isZero(): boolean {
    return this.num === 0n;
  }

  isPositive(): boolean {
    return this.num > 0n;
  }

  isNegative(): boolean {
    return this.num < 0n;
  }

  compare(other: Fraction | number): number {
    const o = Fraction.from(other);
    const left = this.num * o.den;
    const right = o.num * this.den;
    if (left < right) return -1;
    if (left > right) return 1;
    return 0;
  }

  equals(other: Fraction | number): boolean {
    return this.compare(other) === 0;
  }

  gt(other: Fraction | number): boolean {
    return this.compare(other) > 0;
  }

  gte(other: Fraction | number): boolean {
    return this.compare(other) >= 0;
  }

  lt(other: Fraction | number): boolean {
    return this.compare(other) < 0;
  }

  lte(other: Fraction | number): boolean {
    return this.compare(other) <= 0;
  }

  toNumber(): number {
    return Number(this.num) / Number(this.den);
  }

  /** Human-friendly display: integers plain, otherwise a reduced a/b, falling back to a short decimal for ugly denominators. */
  toDisplay(maxDecimals = 4): string {
    if (this.den === 1n) return this.num.toString();
    const decimal = this.toNumber();
    const rounded = Number(decimal.toFixed(maxDecimals));
    // If the decimal representation round-trips cleanly within tolerance, prefer it — it's more
    // readable than a fraction like 173/49 for a student scanning a tableau.
    if (Math.abs(rounded - decimal) < 1e-9) {
      return this.den <= 100n ? `${this.num}/${this.den}` : rounded.toString();
    }
    return `${this.num}/${this.den}`;
  }

  toString(): string {
    return this.toDisplay();
  }

  static ZERO = new Fraction(0n);
  static ONE = new Fraction(1n);
}

export function frac(x: number | bigint): Fraction {
  return Fraction.from(x);
}
