import { MM1Input, MMcInput } from "../../types/queuing";

export interface MM1Example {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: MM1Input;
}

export interface MMcExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: MMcInput;
}

export const mm1Examples: MM1Example[] = [
  {
    name: "Call center (1 operator)",
    difficulty: "beginner",
    description: "Calls arrive at 5/hour; a single operator handles 10/hour on average.",
    problem: { lambda: 5, mu: 10, maxN: 15 },
  },
  {
    name: "Copy shop counter",
    difficulty: "beginner",
    description: "Customers arrive at 8/hour; the one clerk serves 12/hour on average.",
    problem: { lambda: 8, mu: 12, maxN: 15 },
  },
  {
    name: "Overloaded help desk",
    difficulty: "intermediate",
    description: "Tickets arrive at 9/hour against a single agent's 10/hour service rate — high utilization, long waits.",
    problem: { lambda: 9, mu: 10, maxN: 25 },
  },
  {
    name: "Near-saturated print server",
    difficulty: "difficult",
    description: "Jobs arrive at 19/hour, the printer processes 20/hour — ρ close to 1, so the tail of the distribution matters.",
    problem: { lambda: 19, mu: 20, maxN: 40 },
  },
];

export const mmcExamples: MMcExample[] = [
  {
    name: "Bank (4 tellers)",
    difficulty: "beginner",
    description: "Customers arrive at 20/hour; each of 4 tellers serves 6/hour on average.",
    problem: { lambda: 20, mu: 6, servers: 4, maxN: 20 },
  },
  {
    name: "Small clinic (2 doctors)",
    difficulty: "intermediate",
    description: "Patients arrive at 7/hour; each of 2 doctors sees 5/hour on average.",
    problem: { lambda: 7, mu: 5, servers: 2, maxN: 20 },
  },
  {
    name: "Airport check-in (6 counters)",
    difficulty: "intermediate",
    description: "Passengers arrive at 50/hour across 6 counters, each processing 10/hour.",
    problem: { lambda: 50, mu: 10, servers: 6, maxN: 30 },
  },
  {
    name: "Call center under load (5 agents)",
    difficulty: "difficult",
    description: "Calls arrive at 48/hour against 5 agents each handling 10/hour — ρ = 0.96, near saturation.",
    problem: { lambda: 48, mu: 10, servers: 5, maxN: 40 },
  },
];
