import { MM1Input, MMcInput } from "../../types/queuing";

export const MAX_N_LIMIT = 100;
export const MAX_SERVERS = 50;

export function validateMM1(input: MM1Input): string[] {
  const errors: string[] = [];
  if (!Number.isFinite(input.lambda) || input.lambda <= 0) errors.push("Arrival rate λ must be a positive number.");
  if (!Number.isFinite(input.mu) || input.mu <= 0) errors.push("Service rate μ must be a positive number.");
  if (!Number.isFinite(input.maxN) || !Number.isInteger(input.maxN) || input.maxN < 1) {
    errors.push("The distribution cutoff must be a positive whole number.");
  } else if (input.maxN > MAX_N_LIMIT) {
    errors.push(`The distribution cutoff can't exceed ${MAX_N_LIMIT}.`);
  }
  return errors;
}

export function validateMMc(input: MMcInput): string[] {
  const errors: string[] = [];
  if (!Number.isFinite(input.lambda) || input.lambda <= 0) errors.push("Arrival rate λ must be a positive number.");
  if (!Number.isFinite(input.mu) || input.mu <= 0) errors.push("Service rate μ (per server) must be a positive number.");
  if (!Number.isFinite(input.servers) || !Number.isInteger(input.servers) || input.servers < 1) {
    errors.push("Number of servers c must be a positive whole number.");
  } else if (input.servers > MAX_SERVERS) {
    errors.push(`Number of servers can't exceed ${MAX_SERVERS}.`);
  }
  if (!Number.isFinite(input.maxN) || !Number.isInteger(input.maxN) || input.maxN < 1) {
    errors.push("The distribution cutoff must be a positive whole number.");
  } else if (input.maxN > MAX_N_LIMIT) {
    errors.push(`The distribution cutoff can't exceed ${MAX_N_LIMIT}.`);
  }
  return errors;
}
