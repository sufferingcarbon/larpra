import { AlgorithmStep } from "../../types/lp";
import { MMcInput, QueuingDistributionRow, QueuingMetricsPartial, QueuingResult, QueuingState } from "../../types/queuing";
import { Fraction, frac } from "../../utils/fraction";
import { erlangB, factorial, fracPow, offeredLoadTerms } from "./erlang";
import { validateMMc } from "./common";

function toDisplay(m: Partial<Record<keyof QueuingMetricsPartial, Fraction>>): QueuingMetricsPartial {
  return {
    offeredLoad: m.offeredLoad?.toDisplay() ?? null,
    rho: m.rho?.toDisplay() ?? null,
    p0: m.p0?.toDisplay() ?? null,
    probWait: m.probWait?.toDisplay() ?? null,
    erlangB: m.erlangB?.toDisplay() ?? null,
    Lq: m.Lq?.toDisplay() ?? null,
    L: m.L?.toDisplay() ?? null,
    Wq: m.Wq?.toDisplay() ?? null,
    W: m.W?.toDisplay() ?? null,
  };
}

function snapshot(opts: {
  stepKind: string;
  phase: QueuingState["phase"];
  lambda: Fraction;
  mu: Fraction;
  servers: number;
  metrics: Partial<Record<keyof QueuingMetricsPartial, Fraction>>;
  distribution?: QueuingDistributionRow[] | null;
  justComputed?: string | null;
}): QueuingState {
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    model: "mmc",
    lambda: opts.lambda.toDisplay(),
    mu: opts.mu.toDisplay(),
    servers: opts.servers,
    metrics: toDisplay(opts.metrics),
    distribution: opts.distribution ?? null,
    justComputed: opts.justComputed ?? null,
  };
}

/**
 * Solves the M/M/c queue: Poisson arrivals at rate λ, c identical parallel servers each
 * with exponential service at rate μ, a single shared unlimited-capacity FCFS queue.
 * Uses the standard Erlang-C derivation for P0, the wait probability, Lq, and Little's Law
 * for the rest; also reports Erlang B (the companion no-waiting-room loss system) as an
 * informational cross-check, since it's built from the same offered-load terms.
 */
export function solveMMc(input: MMcInput): QueuingResult {
  const errors = validateMMc(input);
  if (errors.length > 0) return { status: "invalid", steps: [], notes: errors };

  const lambda = frac(input.lambda);
  const mu = frac(input.mu);
  const c = input.servers;
  const maxN = input.maxN;
  const steps: AlgorithmStep<QueuingState>[] = [];
  const m: Partial<Record<keyof QueuingMetricsPartial, Fraction>> = {};

  steps.push({
    title: `Set up the M/M/${c} queue`,
    explanation: `Arrivals follow a Poisson process at λ = ${lambda.toDisplay()} per unit time; ${c} identical servers, each exponential at rate μ = ${mu.toDisplay()} per unit time, share a single FCFS queue with unlimited capacity.`,
    state: snapshot({ stepKind: "setup", phase: "setup", lambda, mu, servers: c, metrics: m }),
    why: "With c identical servers, a customer only waits if all c are already busy — the model still reduces to a birth-death process, but the 'death rate' (total service completion rate) grows with the number of busy servers, up to a cap of cμ once every server is occupied.",
  });

  const a = lambda.div(mu); // offered load, in erlangs
  m.offeredLoad = a;
  steps.push({
    title: `Compute the offered load a = ${a.toDisplay()}`,
    explanation: `a = λ/μ = ${lambda.toDisplay()}/${mu.toDisplay()} = ${a.toDisplay()} erlangs — the average number of customers that would be in service if there were no limit on servers. This is the quantity every formula below is built from.`,
    state: snapshot({ stepKind: "offered-load", phase: "setup", lambda, mu, servers: c, metrics: m, justComputed: "offeredLoad" }),
  });

  const rho = a.div(c);
  m.rho = rho;
  if (!rho.lt(1)) {
    steps.push({
      title: `Check stability — unstable (ρ = ${rho.toDisplay()})`,
      explanation: `ρ = a/c = ${a.toDisplay()}/${c} = ${rho.toDisplay()} ≥ 1: total arrivals outpace the combined service capacity of all ${c} servers. The queue grows without bound and no steady-state distribution exists.`,
      state: snapshot({ stepKind: "unstable", phase: "stability", lambda, mu, servers: c, metrics: m }),
    });
    return {
      status: "unstable",
      steps,
      notes: [
        `The system is unstable (ρ = a/c = ${rho.toDisplay()} ≥ 1). Add servers, increase μ, or reduce λ so that λ < cμ before steady-state metrics can be computed.`,
      ],
    };
  }

  steps.push({
    title: `Check stability — ρ = ${rho.toDisplay()}`,
    explanation: `Per-server utilization ρ = a/c = ${a.toDisplay()}/${c} = ${rho.toDisplay()}. Since ρ < 1, the ${c} servers together can keep up with arrivals on average, so a steady state exists.`,
    state: snapshot({ stepKind: "rho", phase: "stability", lambda, mu, servers: c, metrics: m, justComputed: "rho" }),
    why: "ρ = a/c < 1 (equivalently λ < cμ) is the M/M/c stability condition — the combined maximum service rate cμ must exceed the arrival rate, or the queue has no steady state.",
  });

  const terms = offeredLoadTerms(a, c); // a^n/n! for n = 0..c
  const sumBelowC = terms.slice(0, c).reduce((s, t) => s.add(t), Fraction.ZERO); // Σ_{n=0}^{c-1}
  const waitTerm = terms[c].div(Fraction.ONE.sub(rho)); // (a^c/c!) * 1/(1-ρ)
  const p0 = Fraction.ONE.div(sumBelowC.add(waitTerm));
  m.p0 = p0;
  steps.push({
    title: `Compute P0 = ${p0.toDisplay()}`,
    explanation: `P0 = [ Σₙ₌₀^${c - 1} aⁿ/n! + (a^${c}/${c}!)·(1/(1−ρ)) ]⁻¹ = ${p0.toDisplay()} — the steady-state probability every server is idle.`,
    state: snapshot({ stepKind: "p0", phase: "core", lambda, mu, servers: c, metrics: m, justComputed: "p0" }),
    why: "P0 comes from normalizing the birth-death steady-state equations: each of the c 'light traffic' states (0..c−1) contributes aⁿ/n!, and the geometric tail of 'all servers busy' states (n ≥ c) sums to (a^c/c!)/(1−ρ) — together they must add up to 1/P0.",
  });

  const probWait = waitTerm.mul(p0); // Erlang C
  m.probWait = probWait;
  steps.push({
    title: `Compute the Erlang C wait probability = ${probWait.toDisplay()}`,
    explanation: `C(${c}, ${a.toDisplay()}) = (a^${c}/${c}!)·(1/(1−ρ))·P0 = ${probWait.toDisplay()} — the probability an arriving customer finds all ${c} servers busy and must wait.`,
    state: snapshot({ stepKind: "erlang-c", phase: "core", lambda, mu, servers: c, metrics: m, justComputed: "probWait" }),
  });

  const Lq = probWait.mul(rho).div(Fraction.ONE.sub(rho));
  m.Lq = Lq;
  steps.push({
    title: `Compute Lq = ${Lq.toDisplay()}`,
    explanation: `Lq = C(${c}, a)·ρ/(1−ρ) = ${probWait.toDisplay()} × ${rho.toDisplay()}/${Fraction.ONE.sub(rho).toDisplay()} = ${Lq.toDisplay()} — the expected number of customers waiting in the queue.`,
    state: snapshot({ stepKind: "Lq", phase: "core", lambda, mu, servers: c, metrics: m, justComputed: "Lq" }),
  });

  const Wq = Lq.div(lambda);
  m.Wq = Wq;
  steps.push({
    title: `Compute Wq = ${Wq.toDisplay()}`,
    explanation: `By Little's Law, Wq = Lq/λ = ${Lq.toDisplay()}/${lambda.toDisplay()} = ${Wq.toDisplay()} — the expected time a customer spends waiting before an available server picks them up.`,
    state: snapshot({ stepKind: "Wq", phase: "littles-law", lambda, mu, servers: c, metrics: m, justComputed: "Wq" }),
    why: "Little's Law applies to the queue alone just as well as to the whole system — it only needs a stable, steady-state process, not any particular arrival or service distribution.",
  });

  const W = Wq.add(Fraction.ONE.div(mu));
  m.W = W;
  steps.push({
    title: `Compute W = ${W.toDisplay()}`,
    explanation: `W = Wq + 1/μ = ${Wq.toDisplay()} + ${Fraction.ONE.div(mu).toDisplay()} = ${W.toDisplay()} — expected time waiting plus the expected service time itself.`,
    state: snapshot({ stepKind: "W", phase: "littles-law", lambda, mu, servers: c, metrics: m, justComputed: "W" }),
  });

  const L = lambda.mul(W);
  m.L = L;
  steps.push({
    title: `Compute L = ${L.toDisplay()}`,
    explanation: `By Little's Law, L = λW = ${lambda.toDisplay()} × ${W.toDisplay()} = ${L.toDisplay()} — the expected number of customers in the system, waiting or in service. (Equivalently, Lq + a.)`,
    state: snapshot({ stepKind: "L", phase: "littles-law", lambda, mu, servers: c, metrics: m, justComputed: "L" }),
  });

  const eb = erlangB(c, a);
  m.erlangB = eb;
  steps.push({
    title: `Compute Erlang B (informational) = ${eb.toDisplay()}`,
    explanation: `B(${c}, ${a.toDisplay()}) = (a^${c}/${c}!) / Σₙ₌₀^${c} aⁿ/n! = ${eb.toDisplay()}. This is the blocking probability of the companion loss system — the same ${c} servers with no waiting room at all, so a customer who finds every server busy is turned away instead of queued. It is not a metric of this waiting-room queue, but it's a standard cross-check (Erlang B is always ≤ Erlang C, since a queue that lets customers wait never turns more of them away than one that doesn't).`,
    state: snapshot({ stepKind: "erlang-b", phase: "core", lambda, mu, servers: c, metrics: m, justComputed: "erlangB" }),
  });

  const distribution: QueuingDistributionRow[] = [];
  let cumulative = Fraction.ZERO;
  for (let n = 0; n <= maxN; n++) {
    const pn = n < c ? p0.mul(fracPow(a, n)).div(frac(factorial(n))) : p0.mul(fracPow(a, n)).div(frac(factorial(c)).mul(fracPow(frac(c), n - c)));
    cumulative = cumulative.add(pn);
    distribution.push({ n, pn: pn.toDisplay(), cumulative: cumulative.toDisplay() });
  }
  steps.push({
    title: "Compute the steady-state distribution",
    explanation: `Pn = P0·aⁿ/n! for n < ${c} (still filling servers), and Pn = P0·aⁿ/(${c}!·${c}ⁿ⁻${c}) for n ≥ ${c} (every server busy, the excess waits in line) — shown for n = 0…${maxN}.`,
    state: snapshot({ stepKind: "distribution", phase: "distribution", lambda, mu, servers: c, metrics: m, distribution }),
    why: "Below c customers, each arrival finds another idle server, so the death rate at state n is nμ (like c independent M/M/1's) — giving the same aⁿ/n! shape as a single busy server would. From c on, every server is saturated, so the death rate caps at cμ, and the tail becomes geometric with ratio ρ = a/c.",
  });

  steps.push({
    title: "Summary",
    explanation: `ρ = ${rho.toDisplay()}, P0 = ${p0.toDisplay()}, Erlang C = ${probWait.toDisplay()}, Erlang B = ${eb.toDisplay()}, L = ${L.toDisplay()}, Lq = ${Lq.toDisplay()}, W = ${W.toDisplay()}, Wq = ${Wq.toDisplay()}.`,
    state: snapshot({ stepKind: "done", phase: "done", lambda, mu, servers: c, metrics: m, distribution }),
  });

  const notes: string[] = [];
  if (rho.toNumber() > 0.9) {
    notes.push(`Utilization is high (ρ = ${rho.toDisplay()}) — waits are long and grow steeply with any further increase in λ.`);
  }

  return { status: "optimal", steps, metrics: toDisplay(m), distribution, notes };
}
