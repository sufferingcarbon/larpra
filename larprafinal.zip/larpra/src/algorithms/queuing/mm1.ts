import { AlgorithmStep } from "../../types/lp";
import { MM1Input, QueuingDistributionRow, QueuingMetricsPartial, QueuingResult, QueuingState } from "../../types/queuing";
import { Fraction, frac } from "../../utils/fraction";
import { fracPow } from "./erlang";
import { validateMM1 } from "./common";

function toDisplay(m: Partial<Record<keyof QueuingMetricsPartial, Fraction>>): QueuingMetricsPartial {
  return {
    offeredLoad: m.offeredLoad?.toDisplay() ?? null,
    rho: m.rho?.toDisplay() ?? null,
    p0: m.p0?.toDisplay() ?? null,
    probWait: null,
    erlangB: null,
    Lq: m.Lq?.toDisplay() ?? null,
    L: m.L?.toDisplay() ?? null,
    Wq: m.Wq?.toDisplay() ?? null,
    W: m.W?.toDisplay() ?? null,
  };
}

function snapshot(opts: {
  stepKind: string;
  phase: QueuingState["phase"];
  lambda: Fraction;
  mu: Fraction;
  metrics: Partial<Record<keyof QueuingMetricsPartial, Fraction>>;
  distribution?: QueuingDistributionRow[] | null;
  justComputed?: string | null;
}): QueuingState {
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    model: "mm1",
    lambda: opts.lambda.toDisplay(),
    mu: opts.mu.toDisplay(),
    servers: null,
    metrics: toDisplay(opts.metrics),
    distribution: opts.distribution ?? null,
    justComputed: opts.justComputed ?? null,
  };
}

/**
 * Solves the M/M/1 queue: Poisson arrivals at rate λ, one server with exponential
 * service at rate μ, unlimited queue capacity, FCFS discipline. Every quantity below
 * is a standard closed-form result of the birth-death steady-state analysis.
 */
export function solveMM1(input: MM1Input): QueuingResult {
  const errors = validateMM1(input);
  if (errors.length > 0) return { status: "invalid", steps: [], notes: errors };

  const lambda = frac(input.lambda);
  const mu = frac(input.mu);
  const maxN = input.maxN;
  const steps: AlgorithmStep<QueuingState>[] = [];
  const m: Partial<Record<keyof QueuingMetricsPartial, Fraction>> = {};

  steps.push({
    title: "Set up the M/M/1 queue",
    explanation: `Arrivals follow a Poisson process at λ = ${lambda.toDisplay()} per unit time; a single server serves them one at a time, FCFS, with exponentially distributed service times at rate μ = ${mu.toDisplay()} per unit time.`,
    state: snapshot({ stepKind: "setup", phase: "setup", lambda, mu, metrics: m }),
    why: "The M/M/1 model assumes memoryless (exponential) inter-arrival and service times — the 'M' in Kendall's notation. That memorylessness is what makes the queue a birth-death process with a clean closed-form steady state, instead of needing simulation.",
  });

  const rho = lambda.div(mu);
  m.rho = rho;
  m.offeredLoad = rho; // for M/M/1, offered load = utilization (single server)

  if (!rho.lt(1)) {
    steps.push({
      title: `Check stability — unstable (ρ = ${rho.toDisplay()})`,
      explanation: `ρ = λ/μ = ${rho.toDisplay()} ≥ 1: customers arrive at least as fast as the server can finish them. The queue grows without bound and no steady-state distribution exists.`,
      state: snapshot({ stepKind: "unstable", phase: "stability", lambda, mu, metrics: m }),
    });
    return {
      status: "unstable",
      steps,
      notes: [
        `The system is unstable (ρ = λ/μ = ${rho.toDisplay()} ≥ 1). Increase the service rate μ or reduce the arrival rate λ so that λ < μ before steady-state metrics can be computed.`,
      ],
    };
  }

  steps.push({
    title: `Check stability — ρ = ${rho.toDisplay()}`,
    explanation: `Traffic intensity ρ = λ/μ = ${lambda.toDisplay()}/${mu.toDisplay()} = ${rho.toDisplay()}. Since ρ < 1, the server finishes work faster than it arrives on average, so a steady state exists — ρ also doubles as the server's long-run utilization.`,
    state: snapshot({ stepKind: "rho", phase: "stability", lambda, mu, metrics: m, justComputed: "rho" }),
    why: "ρ < 1 is exactly the condition that keeps the underlying birth-death chain positive recurrent — without it, the balance equations that produce Pn have no valid (summing-to-1) solution.",
  });

  const p0 = Fraction.ONE.sub(rho);
  m.p0 = p0;
  steps.push({
    title: `Compute P0 = ${p0.toDisplay()}`,
    explanation: `P0 = 1 − ρ = ${p0.toDisplay()} is the steady-state probability the system is completely empty (no customer waiting or in service).`,
    state: snapshot({ stepKind: "p0", phase: "core", lambda, mu, metrics: m, justComputed: "p0" }),
  });

  const L = rho.div(p0);
  m.L = L;
  steps.push({
    title: `Compute L = ${L.toDisplay()}`,
    explanation: `L = ρ / (1 − ρ) = ${rho.toDisplay()} / ${p0.toDisplay()} = ${L.toDisplay()} — the expected number of customers in the system (waiting plus in service).`,
    state: snapshot({ stepKind: "L", phase: "core", lambda, mu, metrics: m, justComputed: "L" }),
  });

  const Lq = L.mul(rho);
  m.Lq = Lq;
  steps.push({
    title: `Compute Lq = ${Lq.toDisplay()}`,
    explanation: `Lq = ρ·L = ${rho.toDisplay()} × ${L.toDisplay()} = ${Lq.toDisplay()} — the expected number of customers waiting in the queue (excluding the one being served).`,
    state: snapshot({ stepKind: "Lq", phase: "core", lambda, mu, metrics: m, justComputed: "Lq" }),
    why: "Lq = ρ·L follows because on average a fraction ρ of the time the server is busy, and L already counts the customer in service; subtracting that occupied-server contribution (ρ·1) from L gives the same result as ρ²/(1−ρ) directly.",
  });

  const W = L.div(lambda);
  m.W = W;
  steps.push({
    title: `Compute W = ${W.toDisplay()}`,
    explanation: `By Little's Law, W = L / λ = ${L.toDisplay()} / ${lambda.toDisplay()} = ${W.toDisplay()} — the expected time a customer spends in the system.`,
    state: snapshot({ stepKind: "W", phase: "littles-law", lambda, mu, metrics: m, justComputed: "W" }),
    why: "Little's Law (L = λW) holds for any stable queueing system in steady state, regardless of the arrival or service distributions — it's a conservation-of-customers argument, not specific to M/M/1.",
  });

  const Wq = Lq.div(lambda);
  m.Wq = Wq;
  steps.push({
    title: `Compute Wq = ${Wq.toDisplay()}`,
    explanation: `Again by Little's Law, Wq = Lq / λ = ${Lq.toDisplay()} / ${lambda.toDisplay()} = ${Wq.toDisplay()} — the expected time a customer spends waiting before service begins. (Equivalently, W − 1/μ.)`,
    state: snapshot({ stepKind: "Wq", phase: "littles-law", lambda, mu, metrics: m, justComputed: "Wq" }),
  });

  const distribution: QueuingDistributionRow[] = [];
  let cumulative = Fraction.ZERO;
  for (let n = 0; n <= maxN; n++) {
    const pn = p0.mul(fracPow(rho, n));
    cumulative = cumulative.add(pn);
    distribution.push({ n, pn: pn.toDisplay(), cumulative: cumulative.toDisplay() });
  }
  steps.push({
    title: "Compute the steady-state distribution",
    explanation: `Pn = (1 − ρ)ρⁿ for n = 0…${maxN}, geometric with ratio ρ = ${rho.toDisplay()} — each additional customer in the system is ρ times less likely than the one before it.`,
    state: snapshot({ stepKind: "distribution", phase: "distribution", lambda, mu, metrics: m, distribution }),
    why: "Pn = (1−ρ)ρⁿ falls straight out of the birth-death balance equations for M/M/1 (constant birth rate λ, constant death rate μ at every state n ≥ 1): each Pn is P0 times the product of the birth/death rate ratios up to state n, which telescopes to a single ρⁿ.",
  });

  steps.push({
    title: "Summary",
    explanation: `ρ = ${rho.toDisplay()}, P0 = ${p0.toDisplay()}, L = ${L.toDisplay()}, Lq = ${Lq.toDisplay()}, W = ${W.toDisplay()}, Wq = ${Wq.toDisplay()}.`,
    state: snapshot({ stepKind: "done", phase: "done", lambda, mu, metrics: m, distribution }),
  });

  const notes: string[] = [];
  if (rho.toNumber() > 0.9) {
    notes.push(`Utilization is high (ρ = ${rho.toDisplay()}) — waits are long and grow steeply with any further increase in λ.`);
  }

  return { status: "optimal", steps, metrics: toDisplay(m), distribution, notes };
}
