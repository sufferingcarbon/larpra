export { solveMM1 } from "./mm1";
export { solveMMc } from "./mmc";
