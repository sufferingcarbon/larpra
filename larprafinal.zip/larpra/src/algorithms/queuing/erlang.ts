import { Fraction, frac } from "../../utils/fraction";

/** n! as an exact BigInt. Callers keep n small (server counts, distribution cutoffs are validated below 200). */
export function factorial(n: number): bigint {
  let r = 1n;
  for (let i = 2; i <= n; i++) r *= BigInt(i);
  return r;
}

/** base^exp for a non-negative integer exponent, exact. */
export function fracPow(base: Fraction, exp: number): Fraction {
  let r = Fraction.ONE;
  for (let i = 0; i < exp; i++) r = r.mul(base);
  return r;
}

/**
 * The building block shared by P0, Erlang C and Erlang B: a^n / n! for n = 0..upTo (inclusive).
 * Returned as a list so callers can both sum a prefix and read off the last term.
 */
export function offeredLoadTerms(a: Fraction, upTo: number): Fraction[] {
  const terms: Fraction[] = [];
  for (let n = 0; n <= upTo; n++) {
    terms.push(fracPow(a, n).div(frac(factorial(n))));
  }
  return terms;
}

/**
 * Erlang B: the blocking probability in the companion M/M/c/c loss system (c servers,
 * no waiting room — an arrival that finds every server busy is turned away, not queued).
 * B(c, a) = (a^c / c!) / Σ_{k=0}^{c} a^k / k!
 * Included as an informational cross-check alongside the M/M/c queue's own Erlang-C wait
 * probability; it is not itself a metric of the waiting-room M/M/c queue.
 */
export function erlangB(c: number, a: Fraction): Fraction {
  const terms = offeredLoadTerms(a, c);
  const numerator = terms[c];
  const denominator = terms.reduce((s, t) => s.add(t), Fraction.ZERO);
  return numerator.div(denominator);
}
