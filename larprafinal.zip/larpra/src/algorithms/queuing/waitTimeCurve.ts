/**
 * Closed-form waiting-time distributions, sampled for the wait-time CDF chart.
 * These are standard exact results of the M/M/1 and M/M/c analyses (not simulated,
 * not approximated) — plain floating point is appropriate here because the output
 * only ever feeds an SVG curve, never a reported metric.
 */

export interface CdfPoint {
  t: number;
  value: number;
}

/**
 * M/M/1: time in system W ~ Exponential(μ − λ), so P(W ≤ t) = 1 − e^(−(μ−λ)t).
 * Time in queue Wq has an atom of size (1−ρ) at t=0 (arrives to an empty system) and
 * P(Wq ≤ t) = 1 − ρ·e^(−(μ−λ)t) for t ≥ 0.
 */
export function mm1WaitCurves(lambda: number, mu: number, points = 60): { system: CdfPoint[]; queue: CdfPoint[] } {
  const rate = mu - lambda;
  const rho = lambda / mu;
  const tMax = 5 / rate;
  const system: CdfPoint[] = [];
  const queue: CdfPoint[] = [];
  for (let i = 0; i <= points; i++) {
    const t = (tMax * i) / points;
    system.push({ t, value: 1 - Math.exp(-rate * t) });
    queue.push({ t, value: 1 - rho * Math.exp(-rate * t) });
  }
  return { system, queue };
}

/**
 * M/M/c: time waiting in queue Wq has an atom of size (1 − C) at t=0, where C is the
 * Erlang-C probability of waiting at all, and P(Wq ≤ t) = 1 − C·e^(−(cμ−λ)t) for t ≥ 0.
 * (The system time W's exact CDF for c > 1 involves a further sum over server states;
 * only the queue-wait CDF, which has this clean single-exponential form, is charted.)
 */
export function mmcQueueWaitCurve(lambda: number, mu: number, c: number, probWait: number, points = 60): CdfPoint[] {
  const rate = c * mu - lambda;
  const tMax = 5 / rate;
  const curve: CdfPoint[] = [];
  for (let i = 0; i <= points; i++) {
    const t = (tMax * i) / points;
    curve.push({ t, value: 1 - probWait * Math.exp(-rate * t) });
  }
  return curve;
}
