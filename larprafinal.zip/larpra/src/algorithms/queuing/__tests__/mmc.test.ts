import { describe, it, expect } from "vitest";
import { solveMMc } from "../mmc";

// Small clinic (λ=7, μ=5, c=2) hand-derived exactly:
// a = 7/5, ρ = 7/10, P0 = 3/17, Erlang C = 49/85, Lq = 343/255, Wq = 49/255,
// W = 20/51, L = 140/51, Erlang B = 49/169.
describe("solveMMc — small clinic (λ=7, μ=5, c=2), hand-derived exact fractions", () => {
  const result = solveMMc({ lambda: 7, mu: 5, servers: 2, maxN: 5 });

  it("is optimal (stable)", () => {
    expect(result.status).toBe("optimal");
  });

  it("matches the exact offered load and utilization", () => {
    expect(result.metrics?.offeredLoad).toBe("7/5");
    expect(result.metrics?.rho).toBe("7/10");
  });

  it("matches every exact metric derived by hand", () => {
    expect(result.metrics?.p0).toBe("3/17");
    expect(result.metrics?.probWait).toBe("49/85");
    expect(result.metrics?.Lq).toBe("343/255");
    expect(result.metrics?.Wq).toBe("49/255");
    expect(result.metrics?.W).toBe("20/51");
    expect(result.metrics?.L).toBe("140/51");
    expect(result.metrics?.erlangB).toBe("49/169");
  });

  it("Erlang B never exceeds Erlang C (a loss system blocks at least as much as a queue turns away)", () => {
    const toNum = (s: string) => {
      const [n, d] = s.split("/").map(Number);
      return d === undefined ? n : n / d;
    };
    expect(toNum(result.metrics!.erlangB!)).toBeLessThanOrEqual(toNum(result.metrics!.probWait!));
  });

  it("computes the boundary of the distribution consistently across the n<c / n>=c formulas", () => {
    // P0 = 3/17, P1 = P0*a = (3/17)(7/5) = 21/85, P2 (n=c=2) = P0*a^2/(c!*c^0) = (3/17)(49/25)/2 = 147/850
    expect(result.distribution?.[0]).toEqual({ n: 0, pn: "3/17", cumulative: "3/17" });
    expect(result.distribution?.[1].pn).toBe("21/85");
    expect(result.distribution?.[2].pn).toBe("147/850");
  });

  it("emits the expected sequence of step kinds", () => {
    const kinds = result.steps.map((s) => s.state.stepKind);
    expect(kinds).toEqual([
      "setup",
      "offered-load",
      "rho",
      "p0",
      "erlang-c",
      "Lq",
      "Wq",
      "W",
      "L",
      "erlang-b",
      "distribution",
      "done",
    ]);
  });
});

// Bank (λ=20, μ=6, c=4) cross-checked against an independent floating-point implementation.
describe("solveMMc — bank with 4 tellers (λ=20, μ=6, c=4)", () => {
  const result = solveMMc({ lambda: 20, mu: 6, servers: 4, maxN: 10 });
  const num = (s: string | null | undefined) => {
    if (!s) return NaN;
    if (s.includes("/")) {
      const [n, d] = s.split("/").map(Number);
      return n / d;
    }
    return Number(s);
  };
  const close = (actual: string | null | undefined, expected: number, tol = 1e-6) =>
    expect(Math.abs(num(actual) - expected)).toBeLessThan(tol);

  it("matches an independently computed floating-point reference within tolerance", () => {
    expect(result.status).toBe("optimal");
    close(result.metrics?.rho, 0.8333333333333334);
    close(result.metrics?.p0, 0.021310181531176);
    close(result.metrics?.probWait, 0.6577216521967904);
    close(result.metrics?.Lq, 3.2886082609839526);
    close(result.metrics?.Wq, 0.16443041304919764);
    close(result.metrics?.W, 0.33109707971586433);
    close(result.metrics?.L, 6.621941594317287);
    close(result.metrics?.erlangB, 0.2425771395303707);
  });

  it("Little's Law holds internally: L = λW and Lq = λWq", () => {
    close(result.metrics?.L, 20 * num(result.metrics?.W));
    close(result.metrics?.Lq, 20 * num(result.metrics?.Wq));
  });
});

describe("solveMMc — unstable system (a >= c)", () => {
  it("reports 'unstable' when offered load meets or exceeds the number of servers", () => {
    const result = solveMMc({ lambda: 100, mu: 5, servers: 4, maxN: 10 }); // a=20, c=4
    expect(result.status).toBe("unstable");
    expect(result.metrics).toBeUndefined();
    expect(result.notes[0]).toMatch(/unstable/i);
  });
});

describe("solveMMc — reduces to M/M/1 when c=1", () => {
  it("matches the single-server formulas exactly", () => {
    const result = solveMMc({ lambda: 5, mu: 10, servers: 1, maxN: 5 });
    expect(result.metrics?.rho).toBe("1/2");
    expect(result.metrics?.p0).toBe("1/2");
    expect(result.metrics?.L).toBe("1");
    expect(result.metrics?.Lq).toBe("1/2");
  });
});

describe("solveMMc — invalid input", () => {
  it("reports validation errors instead of throwing on a bad server count", () => {
    const result = solveMMc({ lambda: 20, mu: 6, servers: 0, maxN: 10 });
    expect(result.status).toBe("invalid");
    expect(result.steps).toEqual([]);
  });
});
