import { describe, it, expect } from "vitest";
import { factorial, fracPow, offeredLoadTerms, erlangB } from "../erlang";
import { Fraction, frac } from "../../../utils/fraction";

describe("factorial", () => {
  it("computes small factorials exactly as bigint", () => {
    expect(factorial(0)).toBe(1n);
    expect(factorial(1)).toBe(1n);
    expect(factorial(5)).toBe(120n);
    expect(factorial(10)).toBe(3628800n);
  });
});

describe("fracPow", () => {
  it("raises a fraction to a non-negative integer power exactly", () => {
    expect(fracPow(new Fraction(2n, 3n), 0).equals(Fraction.ONE)).toBe(true);
    expect(fracPow(new Fraction(2n, 3n), 3).toDisplay()).toBe("8/27");
    expect(fracPow(new Fraction(5n), 2).toDisplay()).toBe("25");
  });
});

describe("offeredLoadTerms", () => {
  it("returns a^n/n! for n = 0..upTo", () => {
    const terms = offeredLoadTerms(frac(2), 3);
    expect(terms.map((t) => t.toDisplay())).toEqual(["1", "2", "2", "4/3"]);
    // 2^0/0!=1, 2^1/1!=2, 2^2/2!=2, 2^3/3!=8/6=4/3
  });
});

describe("erlangB", () => {
  it("matches the classic Erlang-B table value for a=1, c=1 (B = a/(1+a) = 1/2)", () => {
    expect(erlangB(1, frac(1)).toDisplay()).toBe("1/2");
  });

  it("matches a hand-computed c=2 case (a = 7/5): B = 49/169", () => {
    expect(erlangB(2, new Fraction(7n, 5n)).toDisplay()).toBe("49/169");
  });

  it("is monotonically increasing in offered load for fixed c", () => {
    const low = erlangB(3, frac(1)).toNumber();
    const high = erlangB(3, frac(4)).toNumber();
    expect(high).toBeGreaterThan(low);
  });
});
