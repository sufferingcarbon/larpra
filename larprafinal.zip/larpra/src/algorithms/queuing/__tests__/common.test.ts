import { describe, it, expect } from "vitest";
import { validateMM1, validateMMc, MAX_N_LIMIT, MAX_SERVERS } from "../common";

describe("validateMM1", () => {
  it("accepts a well-formed input", () => {
    expect(validateMM1({ lambda: 5, mu: 10, maxN: 15 })).toEqual([]);
  });

  it("rejects non-positive rates", () => {
    expect(validateMM1({ lambda: 0, mu: 10, maxN: 15 }).length).toBeGreaterThan(0);
    expect(validateMM1({ lambda: 5, mu: -1, maxN: 15 }).length).toBeGreaterThan(0);
  });

  it("rejects a non-integer or out-of-range distribution cutoff", () => {
    expect(validateMM1({ lambda: 5, mu: 10, maxN: 2.5 }).length).toBeGreaterThan(0);
    expect(validateMM1({ lambda: 5, mu: 10, maxN: MAX_N_LIMIT + 1 }).length).toBeGreaterThan(0);
  });

  it("rejects non-finite values instead of throwing", () => {
    expect(validateMM1({ lambda: NaN, mu: 10, maxN: 15 }).length).toBeGreaterThan(0);
    expect(validateMM1({ lambda: 5, mu: Infinity, maxN: 15 }).length).toBeGreaterThan(0);
  });
});

describe("validateMMc", () => {
  it("accepts a well-formed input", () => {
    expect(validateMMc({ lambda: 20, mu: 6, servers: 4, maxN: 20 })).toEqual([]);
  });

  it("rejects a non-positive or non-integer server count", () => {
    expect(validateMMc({ lambda: 20, mu: 6, servers: 0, maxN: 20 }).length).toBeGreaterThan(0);
    expect(validateMMc({ lambda: 20, mu: 6, servers: 2.5, maxN: 20 }).length).toBeGreaterThan(0);
    expect(validateMMc({ lambda: 20, mu: 6, servers: MAX_SERVERS + 1, maxN: 20 }).length).toBeGreaterThan(0);
  });

  it("collects more than one error at once", () => {
    const errors = validateMMc({ lambda: -1, mu: -1, servers: 0, maxN: -1 });
    expect(errors.length).toBeGreaterThanOrEqual(4);
  });
});
