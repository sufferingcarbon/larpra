import { describe, it, expect } from "vitest";
import { mm1WaitCurves, mmcQueueWaitCurve } from "../waitTimeCurve";

describe("mm1WaitCurves", () => {
  const { system, queue } = mm1WaitCurves(5, 10); // ρ=1/2

  it("starts both curves at t=0 with the correct atoms", () => {
    expect(system[0].value).toBeCloseTo(0, 10); // P(W<=0)=0, W is purely continuous
    expect(queue[0].value).toBeCloseTo(0.5, 10); // P(Wq<=0) = 1-ρ = 0.5
  });

  it("is monotonically non-decreasing and approaches 1", () => {
    for (let i = 1; i < system.length; i++) {
      expect(system[i].value).toBeGreaterThanOrEqual(system[i - 1].value);
      expect(queue[i].value).toBeGreaterThanOrEqual(queue[i - 1].value);
    }
    expect(system[system.length - 1].value).toBeGreaterThan(0.99);
    expect(queue[queue.length - 1].value).toBeGreaterThan(0.99);
  });
});

describe("mmcQueueWaitCurve", () => {
  it("starts at 1 - C(c,a) and approaches 1", () => {
    const probWait = 0.6577216521967904; // bank example
    const curve = mmcQueueWaitCurve(20, 6, 4, probWait);
    expect(curve[0].value).toBeCloseTo(1 - probWait, 10);
    expect(curve[curve.length - 1].value).toBeGreaterThan(0.99);
  });
});
