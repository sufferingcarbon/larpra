import { describe, it, expect } from "vitest";
import { solveMM1 } from "../mm1";

describe("solveMM1 — call center (λ=5, μ=10), textbook values", () => {
  const result = solveMM1({ lambda: 5, mu: 10, maxN: 5 });

  it("is optimal (stable) with ρ = 1/2", () => {
    expect(result.status).toBe("optimal");
    expect(result.metrics?.rho).toBe("1/2");
  });

  it("matches hand-derived exact metrics", () => {
    expect(result.metrics?.p0).toBe("1/2");
    expect(result.metrics?.L).toBe("1");
    expect(result.metrics?.Lq).toBe("1/2");
    expect(result.metrics?.W).toBe("1/5");
    expect(result.metrics?.Wq).toBe("1/10");
  });

  it("computes the geometric distribution Pn = (1-ρ)ρⁿ exactly", () => {
    expect(result.distribution?.[0]).toEqual({ n: 0, pn: "1/2", cumulative: "1/2" });
    expect(result.distribution?.[1]).toEqual({ n: 1, pn: "1/4", cumulative: "3/4" });
    expect(result.distribution?.[2]).toEqual({ n: 2, pn: "1/8", cumulative: "7/8" });
  });

  it("emits the expected sequence of step kinds", () => {
    const kinds = result.steps.map((s) => s.state.stepKind);
    expect(kinds).toEqual(["setup", "rho", "p0", "L", "Lq", "W", "Wq", "distribution", "done"]);
  });

  it("every step carries a title and explanation", () => {
    for (const s of result.steps) {
      expect(s.title.length).toBeGreaterThan(0);
      expect(s.explanation.length).toBeGreaterThan(0);
    }
  });
});

describe("solveMM1 — unstable system (λ ≥ μ)", () => {
  it("reports 'unstable' and stops after the stability check, without computing metrics", () => {
    const result = solveMM1({ lambda: 10, mu: 5, maxN: 10 });
    expect(result.status).toBe("unstable");
    expect(result.metrics).toBeUndefined();
    expect(result.distribution).toBeUndefined();
    expect(result.notes[0]).toMatch(/unstable/i);
    const kinds = result.steps.map((s) => s.state.stepKind);
    expect(kinds).toEqual(["setup", "unstable"]);
  });

  it("treats ρ = 1 (λ = μ) as unstable too, not a degenerate stable case", () => {
    const result = solveMM1({ lambda: 5, mu: 5, maxN: 10 });
    expect(result.status).toBe("unstable");
  });
});

describe("solveMM1 — high utilization warning", () => {
  it("flags a near-saturated system (ρ = 0.95) with a warning note", () => {
    const result = solveMM1({ lambda: 19, mu: 20, maxN: 10 });
    expect(result.status).toBe("optimal");
    expect(result.notes.some((n) => /high/i.test(n))).toBe(true);
  });

  it("does not warn for a comfortably stable system", () => {
    const result = solveMM1({ lambda: 2, mu: 10, maxN: 10 });
    expect(result.notes.length).toBe(0);
  });
});

describe("solveMM1 — invalid input", () => {
  it("reports validation errors instead of throwing on a non-positive rate", () => {
    const result = solveMM1({ lambda: 0, mu: 10, maxN: 10 });
    expect(result.status).toBe("invalid");
    expect(result.steps).toEqual([]);
    expect(result.notes.length).toBeGreaterThan(0);
  });

  it("reports validation errors for a bad distribution cutoff", () => {
    const result = solveMM1({ lambda: 5, mu: 10, maxN: -1 });
    expect(result.status).toBe("invalid");
  });
});
