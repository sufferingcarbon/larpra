import { LPProblem } from "../../types/lp";
import { Fraction } from "../../utils/fraction";
import { solveLPExact } from "../lp/simplex";
import { FMatrix, maxOf, minOf } from "./common";

/**
 * Zero-sum games (Player 2's payoff is the negative of Player 1's).
 *
 * Player 1 picks a mixed strategy p to maximize the worst case (over columns) of p·A[:,j]; Player 2 picks q to
 * minimize the best case of A[i,:]·q. Von Neumann's minimax theorem says both optima are the same number v — the
 * value of the game — and that the pair of optimal strategies is exactly a Nash equilibrium. Both optimizations
 * are linear programs, and they are each other's duals.
 */

export interface SecurityLevels {
  rowMins: Fraction[];
  colMaxs: Fraction[];
  maximin: Fraction;
  minimax: Fraction;
  maximinRows: number[];
  minimaxCols: number[];
  saddleCells: [number, number][];
}

export function securityLevels(A: FMatrix): SecurityLevels {
  const m = A.length;
  const n = A[0].length;
  const rowMins = A.map((row) => minOf(row));
  const colMaxs = Array.from({ length: n }, (_, j) => maxOf(A.map((row) => row[j])));
  const maximin = maxOf(rowMins);
  const minimax = minOf(colMaxs);
  const saddleCells: [number, number][] = [];
  for (let i = 0; i < m; i++) for (let j = 0; j < n; j++) if (A[i][j].equals(rowMins[i]) && A[i][j].equals(colMaxs[j])) saddleCells.push([i, j]);
  return {
    rowMins,
    colMaxs,
    maximin,
    minimax,
    maximinRows: rowMins.map((v, i) => (v.equals(maximin) ? i : -1)).filter((i) => i >= 0),
    minimaxCols: colMaxs.map((v, j) => (v.equals(minimax) ? j : -1)).filter((j) => j >= 0),
    saddleCells,
  };
}

export interface ZeroSumLPs {
  /** The constant c added to every payoff so all are ≥ 1. */
  shift: Fraction;
  rowLP: LPProblem;
  colLP: LPProblem;
}

/**
 * The standard positive-payoff transformation. With A' = A + c > 0 the value v' of A' is positive, and
 *   Player 1:  minimize Σ y   s.t.  Σ_i A'[i][j]·y_i ≥ 1 for every column j,   y ≥ 0        (y = p / v')
 *   Player 2:  maximize Σ z   s.t.  Σ_j A'[i][j]·z_j ≤ 1 for every row i,      z ≥ 0        (z = q / v')
 * These are dual to each other, and both optima equal 1 / v'.
 */
export function buildZeroSumLPs(A: FMatrix, rowNames: string[], colNames: string[]): ZeroSumLPs {
  const m = A.length;
  const n = A[0].length;
  const low = minOf(A.flat());
  const shift = low.lte(0) ? Fraction.ONE.sub(low) : Fraction.ZERO;
  // toNumber of a terminating decimal is the double that prints as that decimal, so the LP layer re-reads it exactly.
  const As = A.map((row) => row.map((x) => x.add(shift).toNumber()));
  const rowLP: LPProblem = {
    sense: "min",
    variables: Array.from({ length: m }, (_, i) => `y${i + 1}`),
    objective: new Array(m).fill(1),
    constraints: colNames.map((c, j) => ({ coeffs: As.map((row) => row[j]), relation: ">=", rhs: 1, label: `vs ${c}` })),
  };
  const colLP: LPProblem = {
    sense: "max",
    variables: Array.from({ length: n }, (_, j) => `z${j + 1}`),
    objective: new Array(n).fill(1),
    constraints: rowNames.map((r, i) => ({ coeffs: [...As[i]], relation: "<=", rhs: 1, label: `vs ${r}` })),
  };
  return { shift, rowLP, colLP };
}

export interface ZeroSumSolution {
  /** The LP optima themselves (y = p/v′, z = q/v′). */
  y: Fraction[];
  z: Fraction[];
  p: Fraction[];
  q: Fraction[];
  value: Fraction;
  /** Σy and Σz — equal by LP duality (this is checked, not assumed). */
  rowObjective: Fraction;
  colObjective: Fraction;
}

export function solveZeroSumLPs(lps: ZeroSumLPs): ZeroSumSolution {
  const r = solveLPExact(lps.rowLP);
  const c = solveLPExact(lps.colLP);
  if (r.status !== "optimal" || c.status !== "optimal" || !r.values || !c.values || !r.objective || !c.objective) {
    throw new Error("The zero-sum linear programs did not solve to optimality (this should be impossible for positive payoffs).");
  }
  if (!r.objective.equals(c.objective)) {
    throw new Error("Internal check failed: the two zero-sum LPs disagree, violating LP duality.");
  }
  const S = r.objective;
  return {
    y: r.values,
    z: c.values,
    p: r.values.map((y) => y.div(S)),
    q: c.values.map((z) => z.div(S)),
    value: Fraction.ONE.div(S).sub(lps.shift),
    rowObjective: r.objective,
    colObjective: c.objective,
  };
}
