import { Equilibrium, SupportAttempt, SupportEnumInfo, SupportOutcome } from "../../types/game";
import { Fraction } from "../../utils/fraction";
import { binomial, colPayoffs, combinations, exact, exactList, expectedPayoff, FMatrix, names, rowPayoffs, toNum } from "./common";
import { solveLinearSystem } from "./linalg";

/** Builds an Equilibrium record from full-length exact probability vectors. */
export function makeEquilibrium(A: FMatrix, B: FMatrix, p: Fraction[], q: Fraction[]): Equilibrium {
  const supportRows = p.map((x, i) => (x.isPositive() ? i : -1)).filter((i) => i >= 0);
  const supportCols = q.map((x, j) => (x.isPositive() ? j : -1)).filter((j) => j >= 0);
  return {
    kind: supportRows.length === 1 && supportCols.length === 1 ? "pure" : "mixed",
    p: p.map(exact),
    q: q.map(exact),
    pNum: p.map(toNum),
    qNum: q.map(toNum),
    payoffA: exact(expectedPayoff(A, p, q)),
    payoffB: exact(expectedPayoff(B, p, q)),
    supportRows,
    supportCols,
  };
}

/** "2·x1 − 1·x2" with signs folded into the operators. */
function linear(coeffs: Fraction[], vars: string[]): string {
  return coeffs
    .map((c, k) => {
      const mag = exact(c.isNegative() ? c.neg() : c);
      const term = `${mag}·${vars[k]}`;
      return k === 0 ? (c.isNegative() ? `−${term}` : term) : `${c.isNegative() ? "−" : "+"} ${term}`;
    })
    .join(" ");
}

export interface SupportEnumeration {
  /** One entry per support size k = 1..min(m, n), in that order. */
  bySize: { size: number; info: SupportEnumInfo; equilibria: Equilibrium[] }[];
  equilibria: Equilibrium[];
  pairsTotal: number;
}

/**
 * Support enumeration for a bimatrix game. For every pair of supports (I, J) with |I| = |J| = k:
 *   1. Player 2's mix q on J must make Player 1 indifferent among the rows of I:  A[i]·q = u for i ∈ I, Σq = 1
 *   2. Player 1's mix p on I must make Player 2 indifferent among the columns of J: p·B[:,j] = v for j ∈ J, Σp = 1
 *   3. p and q must be strictly positive on their supports (that is what "support" means)
 *   4. no row outside I may pay Player 1 more than u against q, and no column outside J may pay Player 2 more
 *      than v against p (otherwise someone would deviate — the best-response condition)
 * Steps 1–2 are square linear systems (k+1 equations, k+1 unknowns), solved exactly.
 *
 * Only equal-size supports are tried: in a nondegenerate game every equilibrium has equal-size supports, so this
 * is exhaustive there. (See degeneracy.ts for when that guarantee does not apply.)
 */
export function enumerateSupports(A: FMatrix, B: FMatrix, rowNames: string[], colNames: string[]): SupportEnumeration {
  const m = A.length;
  const n = A[0].length;
  const kMax = Math.min(m, n);
  const pairsTotal = binomial(m + n, m) - 1;
  const bySize: SupportEnumeration["bySize"] = [];
  const all: Equilibrium[] = [];

  for (let k = 1; k <= kMax; k++) {
    const attempts: SupportAttempt[] = [];
    const tally: Partial<Record<SupportOutcome, number>> = {};
    const found: Equilibrium[] = [];

    for (const I of combinations(m, k)) {
      for (const J of combinations(n, k)) {
        const att = tryPair(A, B, I, J, rowNames, colNames);
        attempts.push(att.attempt);
        tally[att.attempt.outcome] = (tally[att.attempt.outcome] ?? 0) + 1;
        if (att.equilibrium) found.push(att.equilibrium);
      }
    }
    all.push(...found);
    bySize.push({
      size: k,
      equilibria: found,
      info: { size: k, pairsThisSize: binomial(m, k) * binomial(n, k), pairsTotal, attempts, tally },
    });
  }
  return { bySize, equilibria: all, pairsTotal };
}

function tryPair(A: FMatrix, B: FMatrix, I: number[], J: number[], rowNames: string[], colNames: string[]): { attempt: SupportAttempt; equilibrium: Equilibrium | null } {
  const m = A.length;
  const n = B[0].length;
  const k = I.length;
  const rn = I.map((i) => rowNames[i]);
  const cn = J.map((j) => colNames[j]);
  const equations: string[] = [];
  const base = { rows: I, cols: J };
  const fail = (outcome: SupportOutcome, detail: string) => ({ attempt: { ...base, outcome, detail, equations }, equilibrium: null });

  // --- Player 2's mix q on J: every row in I earns the same u ---
  const qVars = cn.map((c) => `q(${c})`);
  I.forEach((i, r) => equations.push(`${rn[r]}: ${linear(J.map((j) => A[i][j]), qVars)} = u`));
  equations.push(`${qVars.join(" + ")} = 1`);
  const Mq: Fraction[][] = [...I.map((i) => [...J.map((j) => A[i][j]), Fraction.ONE.neg()]), [...J.map(() => Fraction.ONE), Fraction.ZERO]];
  const rq = [...I.map(() => Fraction.ZERO), Fraction.ONE];
  const sq = solveLinearSystem(Mq, rq, k + 1);
  if (sq.kind === "none") return fail("no-solution-q", "The indifference equations for Player 2's mix are contradictory — no solution.");
  if (sq.kind === "many") return fail("non-unique-q", "The indifference equations for Player 2's mix have infinitely many solutions (a degenerate situation).");
  const qOn = sq.x.slice(0, k);
  const u = sq.x[k];
  if (qOn.some((x) => !x.isPositive())) {
    return fail("nonpositive-q", `Player 2's mix would be ${exactList(qOn)} on {${names(colNames, J)}} — not every probability is positive.`);
  }

  // --- Player 1's mix p on I: every column in J earns the same v ---
  const pVars = rn.map((r) => `p(${r})`);
  J.forEach((j, c) => equations.push(`${cn[c]}: ${linear(I.map((i) => B[i][j]), pVars)} = v`));
  equations.push(`${pVars.join(" + ")} = 1`);
  const Mp: Fraction[][] = [...J.map((j) => [...I.map((i) => B[i][j]), Fraction.ONE.neg()]), [...I.map(() => Fraction.ONE), Fraction.ZERO]];
  const rp = [...J.map(() => Fraction.ZERO), Fraction.ONE];
  const sp = solveLinearSystem(Mp, rp, k + 1);
  if (sp.kind === "none") return fail("no-solution-p", `Player 2's mix ${exactList(qOn)} works, but the indifference equations for Player 1's mix are contradictory.`);
  if (sp.kind === "many") return fail("non-unique-p", `Player 2's mix ${exactList(qOn)} works, but the indifference equations for Player 1's mix have infinitely many solutions (a degenerate situation).`);
  const pOn = sp.x.slice(0, k);
  const v = sp.x[k];
  if (pOn.some((x) => !x.isPositive())) {
    return fail("nonpositive-p", `q = ${exactList(qOn)}, but Player 1's mix would be ${exactList(pOn)} on {${names(rowNames, I)}} — not every probability is positive.`);
  }

  // --- best-response check against every strategy outside the supports ---
  const q: Fraction[] = new Array(n).fill(Fraction.ZERO);
  const p: Fraction[] = new Array(m).fill(Fraction.ZERO);
  J.forEach((j, c) => (q[j] = qOn[c]));
  I.forEach((i, r) => (p[i] = pOn[r]));
  const rowVals = rowPayoffs(A, q);
  for (let i = 0; i < m; i++) {
    if (!I.includes(i) && rowVals[i].gt(u)) {
      return fail("row-deviation", `p = ${exactList(pOn)}, q = ${exactList(qOn)}, but row ${rowNames[i]} would pay Player 1 ${exact(rowVals[i])} > ${exact(u)}, so Player 1 would deviate.`);
    }
  }
  const colVals = colPayoffs(B, p);
  for (let j = 0; j < n; j++) {
    if (!J.includes(j) && colVals[j].gt(v)) {
      return fail("col-deviation", `p = ${exactList(pOn)}, q = ${exactList(qOn)}, but column ${colNames[j]} would pay Player 2 ${exact(colVals[j])} > ${exact(v)}, so Player 2 would deviate.`);
    }
  }

  const eq = makeEquilibrium(A, B, p, q);
  return {
    attempt: {
      ...base,
      outcome: "equilibrium",
      detail: `Equilibrium: p = ${exactList(pOn)} on {${names(rowNames, I)}}, q = ${exactList(qOn)} on {${names(colNames, J)}}; payoffs (${eq.payoffA}, ${eq.payoffB}).`,
      equations,
    },
    equilibrium: eq,
  };
}
