import { DegeneracyInfo } from "../../types/game";
import { Fraction } from "../../utils/fraction";
import { combinations, FMatrix, minOf, names } from "./common";
import { solveLinearSystem } from "./linalg";

/**
 * Exact degeneracy test.
 *
 * A two-player game is *nondegenerate* when no mixed strategy has more pure best responses (for the opponent)
 * than the size of its own support. For nondegenerate games, every Nash equilibrium has supports of equal
 * size, so equal-size support enumeration is exhaustive; in a degenerate game (typically ties in payoffs) it
 * can miss equilibria — including whole continua of them.
 *
 * The test uses the standard polytope form of the same condition. Shift the opponent's payoffs so they are all
 * ≥ 1 (this changes no best response) and take P = { x ≥ 0 : Cᵀ-rows · x ≤ 1 }, where x = p / (best payoff).
 * A vertex of P has "tight" constraints: x_i = 0 (strategy i is *not* in the support) and constraint j at equality
 * (opponent's strategy j is a best response). The game is degenerate exactly when some vertex of P (or of the
 * matching polytope for the other player) has more than d tight constraints — more best responses than support
 * size. Vertices are found by solving every d×d subsystem exactly.
 */

interface Witness {
  support: number[];
  bestResponses: number[];
}

/** Looks for a degenerate vertex of { x ∈ R^d : x ≥ 0, C·x ≤ 1 }, C > 0 (rows of C = the opponent's strategies). */
function findDegenerateVertex(C: FMatrix): Witness | null {
  const p = C.length; // opponent strategies (best-response constraints)
  const d = C[0].length; // this player's strategies
  const total = d + p;
  // constraint index c < d : x_c ≥ 0 ; index d + r : C[r]·x ≤ 1
  for (const chosen of combinations(total, d)) {
    const M: Fraction[][] = chosen.map((c) => {
      if (c < d) return Array.from({ length: d }, (_, k) => (k === c ? Fraction.ONE : Fraction.ZERO));
      return C[c - d];
    });
    const rhs = chosen.map((c) => (c < d ? Fraction.ZERO : Fraction.ONE));
    const sol = solveLinearSystem(M, rhs, d);
    if (sol.kind !== "unique") continue;
    const x = sol.x;
    if (x.some((v) => v.isNegative())) continue;
    const lhs = C.map((row) => row.reduce((s, c, k) => s.add(c.mul(x[k])), Fraction.ZERO));
    if (lhs.some((v) => v.gt(1))) continue;
    const tightBR = lhs.map((v, r) => (v.equals(1) ? r : -1)).filter((r) => r >= 0);
    const support = x.map((v, k) => (v.isPositive() ? k : -1)).filter((k) => k >= 0);
    const zeroCount = d - support.length;
    if (zeroCount + tightBR.length > d) return { support, bestResponses: tightBR };
  }
  return null;
}

const describe = (who: string, all: string[], support: number[]) =>
  support.length === 1 ? `When ${who} plays {${names(all, support)}},` : `When ${who} mixes over {${names(all, support)}},`;

export function checkDegeneracy(A: FMatrix, B: FMatrix, rowNames: string[], colNames: string[]): DegeneracyInfo {
  const m = A.length;
  const n = A[0].length;
  const shift = (M: FMatrix) => {
    const c = Fraction.ONE.sub(minOf(M.flat()));
    return M.map((row) => row.map((x) => x.add(c)));
  };

  // Player 1's mixed strategies p: Player 2's best responses are the columns j maximizing Σ_i p_i B[i][j].
  const Bs = shift(B);
  const BT: FMatrix = Array.from({ length: n }, (_, j) => Bs.map((row) => row[j])); // n × m
  const w1 = findDegenerateVertex(BT);
  if (w1) {
    return {
      degenerate: true,
      witness: `${describe("Player 1", rowNames, w1.support)} Player 2 has ${w1.bestResponses.length} best responses ({${names(colNames, w1.bestResponses)}}) — more than the ${w1.support.length} strateg${w1.support.length === 1 ? "y" : "ies"} in its support.`,
    };
  }
  // Player 2's mixed strategies q: Player 1's best responses are the rows i maximizing Σ_j A[i][j] q_j.
  const As = shift(A);
  const w2 = findDegenerateVertex(As);
  if (w2) {
    return {
      degenerate: true,
      witness: `${describe("Player 2", colNames, w2.support)} Player 1 has ${w2.bestResponses.length} best responses ({${names(rowNames, w2.bestResponses)}}) — more than the ${w2.support.length} strateg${w2.support.length === 1 ? "y" : "ies"} in its support.`,
    };
  }
  return { degenerate: false, witness: null };
}
