import { AlgorithmStep } from "../../types/lp";
import {
  DegeneracyInfo,
  DominanceInfo,
  Equilibrium,
  GameInput,
  GameResult,
  GameState,
  SupportEnumInfo,
  SupportOutcome,
  ZeroSumInfo,
} from "../../types/game";
import { Fraction } from "../../utils/fraction";
import { exact, exactList, names, toFractionMatrix, validateGame } from "./common";
import { colBestResponses, pureEquilibria, rowBestResponses } from "./bestResponse";
import { findDominantCol, findDominantRow, iteratedElimination } from "./dominance";
import { checkDegeneracy } from "./degeneracy";
import { enumerateSupports, makeEquilibrium } from "./supportEnumeration";
import { buildZeroSumLPs, securityLevels, solveZeroSumLPs } from "./zeroSum";
import { isNashEquilibrium } from "./verify";

const plural = (n: number, one: string, many: string) => (n === 1 ? one : many);

const OUTCOME_LABEL: Record<SupportOutcome, [string, string]> = {
  equilibrium: ["equilibrium", "equilibria"],
  "no-solution-q": ["contradictory indifference equations for Player 2's mix", "contradictory indifference equations for Player 2's mix"],
  "non-unique-q": ["underdetermined equations for Player 2's mix", "underdetermined equations for Player 2's mix"],
  "nonpositive-q": ["Player 2's mix has a non-positive probability", "Player 2's mix has a non-positive probability"],
  "no-solution-p": ["contradictory indifference equations for Player 1's mix", "contradictory indifference equations for Player 1's mix"],
  "non-unique-p": ["underdetermined equations for Player 1's mix", "underdetermined equations for Player 1's mix"],
  "nonpositive-p": ["Player 1's mix has a non-positive probability", "Player 1's mix has a non-positive probability"],
  "row-deviation": ["Player 1 would deviate to a row outside the support", "Player 1 would deviate to a row outside the support"],
  "col-deviation": ["Player 2 would deviate to a column outside the support", "Player 2 would deviate to a column outside the support"],
};

function tallySentence(tally: SupportEnumInfo["tally"]): string {
  const parts = (Object.keys(OUTCOME_LABEL) as SupportOutcome[])
    .filter((k) => (tally[k] ?? 0) > 0)
    .map((k) => {
      const c = tally[k]!;
      return `${c} ${k === "equilibrium" ? plural(c, OUTCOME_LABEL[k][0], OUTCOME_LABEL[k][1]) : `rejected: ${OUTCOME_LABEL[k][0]}`}`;
    });
  return parts.join("; ");
}

const eqLine = (e: Equilibrium, rowNames: string[], colNames: string[]) => {
  const fmt = (probs: string[], all: string[]) =>
    probs
      .map((x, i) => (x === "0" ? null : x === "1" ? all[i] : `${x} ${all[i]}`))
      .filter(Boolean)
      .join(" + ");
  return `(${fmt(e.p, rowNames)}) vs (${fmt(e.q, colNames)}) — payoffs (${e.payoffA}, ${e.payoffB})`;
};

/**
 * Solves a two-player normal-form game: pure-strategy equilibria by best-response marking, dominance analysis,
 * (for zero-sum games) the minimax linear programs, and every Nash equilibrium — pure or mixed — by exact support
 * enumeration. Deterministic; every number is an exact fraction.
 */
export function solveGame(input: GameInput): GameResult {
  const errors = validateGame(input);
  if (errors.length > 0) return { status: "invalid", steps: [], equilibria: [], notes: errors };

  const A = toFractionMatrix(input.payoffA);
  const B = toFractionMatrix(input.payoffB);
  const rowNames = input.rowNames.map((s) => s.trim());
  const colNames = input.colNames.map((s) => s.trim());
  const m = rowNames.length;
  const n = colNames.length;
  const zeroSum = input.zeroSum;

  const aDisp = A.map((row) => row.map((x) => x.toDisplay()));
  const bDisp = B.map((row) => row.map((x) => x.toDisplay()));
  const snap = (over: Partial<GameState> & Pick<GameState, "phase" | "stepKind">): GameState => ({
    rowNames,
    colNames,
    a: aDisp,
    b: bDisp,
    zeroSum,
    rowBR: null,
    colBR: null,
    highlightCells: [],
    eliminatedRows: [],
    eliminatedCols: [],
    dominance: null,
    zeroSumInfo: null,
    degeneracy: null,
    supports: null,
    equilibria: [],
    ...over,
  });

  const steps: AlgorithmStep<GameState>[] = [];
  const notes: string[] = [];

  /* ---------------------------------------------------------------- setup */
  steps.push({
    title: zeroSum ? `Set up the zero-sum game (${m} × ${n})` : `Set up the game (${m} × ${n})`,
    explanation: `Player 1 chooses a row (${rowNames.join(", ")}); Player 2 chooses a column (${colNames.join(", ")}). Each cell lists (Player 1's payoff, Player 2's payoff). ${
      zeroSum
        ? "The game is zero-sum: Player 2's payoff is always the negative of Player 1's."
        : "The game is general-sum: the two payoffs are independent."
    }`,
    state: snap({ phase: "setup", stepKind: "setup" }),
    why: "A Nash equilibrium is a pair of strategies (possibly randomized) in which neither player can gain by changing only their own strategy. Nash's theorem guarantees at least one exists in every finite game — sometimes only with randomization. larpra looks for equilibria in increasing generality: pure strategies, then dominance, then mixed strategies by support enumeration.",
  });

  /* -------------------------------------------------------- best responses */
  const rowBR = rowBestResponses(A);
  const colBR = colBestResponses(B);
  const pure = pureEquilibria(rowBR, colBR);

  steps.push({
    title: "Player 1's best responses",
    explanation: `For each column, Player 1's best response is the row with the highest first payoff (ties mark every maximizer): ${colNames
      .map((c, j) => `against ${c} → ${rowNames.filter((_, i) => rowBR[i][j]).join(" or ")}`)
      .join("; ")}.`,
    state: snap({ phase: "best-response", stepKind: "row-br", rowBR }),
    why: "A best response is the strategy that maximizes a player's payoff given what the opponent does. Marking them cell by cell turns 'can either player gain by deviating?' into a visual check.",
  });

  steps.push({
    title: "Player 2's best responses",
    explanation: `For each row, Player 2's best response is the column with the highest second payoff: ${rowNames
      .map((r, i) => `against ${r} → ${colNames.filter((_, j) => colBR[i][j]).join(" or ")}`)
      .join("; ")}.`,
    state: snap({ phase: "best-response", stepKind: "col-br", rowBR, colBR }),
  });

  steps.push({
    title: pure.length > 0 ? `Pure-strategy equilibria: ${pure.length} found` : "Pure-strategy equilibria: none",
    explanation:
      pure.length > 0
        ? `A cell marked as a best response by both players is an equilibrium — neither can gain by deviating alone: ${pure
            .map(([i, j]) => `(${rowNames[i]}, ${colNames[j]}) with payoffs (${aDisp[i][j]}, ${bDisp[i][j]})`)
            .join("; ")}.`
        : "No cell is a best response for both players at once, so there is no equilibrium in pure strategies. Any equilibrium must involve randomizing.",
    state: snap({ phase: "pure", stepKind: "pure-equilibria", rowBR, colBR, highlightCells: pure }),
    why: "This check is exact and complete for pure strategies: an equilibrium in pure strategies is precisely a cell that is a mutual best response.",
  });

  /* ------------------------------------------------------------- dominance */
  const domRow = findDominantRow(A);
  const domCol = findDominantCol(B);
  const { rounds, rows: remRows, cols: remCols } = iteratedElimination(A, B);
  const domSummary: DominanceInfo = {
    dominantRow: domRow,
    dominantCol: domCol,
    round: null,
    eliminations: [],
  };
  const domText = (who: string, dom: typeof domRow, all: string[]) =>
    dom ? `${who} has a ${dom.kind === "strict" ? "strictly" : "weakly"} dominant strategy: ${all[dom.index]}.` : `${who} has no dominant strategy.`;
  let domExplanation = `${domText("Player 1", domRow, rowNames)} ${domText("Player 2", domCol, colNames)}`;
  if (domRow?.kind === "strict" && domCol?.kind === "strict") {
    domExplanation += ` Each player's best move doesn't depend on what the other does, so (${rowNames[domRow.index]}, ${colNames[domCol.index]}) is the unique equilibrium of the game, in pure or mixed strategies.`;
  } else if (domRow?.kind === "weak" || domCol?.kind === "weak") {
    domExplanation += " Weak dominance does not rule out other equilibria, so larpra never uses it to remove strategies.";
  }
  domExplanation += rounds.length === 0 ? " No strategy is strictly dominated by another, so nothing can be eliminated." : " Now removing strictly dominated strategies, round by round.";
  steps.push({
    title: "Dominance analysis",
    explanation: domExplanation,
    state: snap({ phase: "dominance", stepKind: "dominant", rowBR, colBR, dominance: domSummary }),
    why: "Strategy X strictly dominates Y when X pays strictly more than Y against every opponent strategy. A strictly dominated strategy is never a best response, so it can't be played in any equilibrium (pure or mixed). A dominant strategy dominates all the others.",
  });

  const elimRows: number[] = [];
  const elimCols: number[] = [];
  rounds.forEach((rd, idx) => {
    elimRows.push(...rd.eliminations.filter((e) => e.player === 1).map((e) => e.index));
    elimCols.push(...rd.eliminations.filter((e) => e.player === 2).map((e) => e.index));
    const last = idx === rounds.length - 1;
    let text = `Eliminated this round: ${rd.eliminations
      .map((e) => (e.player === 1 ? `Player 1's ${rowNames[e.index]} (strictly dominated by ${rowNames[e.by]})` : `Player 2's ${colNames[e.index]} (strictly dominated by ${colNames[e.by]})`))
      .join("; ")}.`;
    if (last) {
      text +=
        remRows.length === 1 && remCols.length === 1
          ? ` Nothing else can be removed: the game reduces to the single cell (${rowNames[remRows[0]]}, ${colNames[remCols[0]]}), which is therefore the unique equilibrium (the game is dominance-solvable).`
          : ` No strategy left is strictly dominated. Remaining game: rows {${names(rowNames, remRows)}}, columns {${names(colNames, remCols)}}.`;
    }
    steps.push({
      title: `Iterated dominance — round ${rd.round}`,
      explanation: text,
      state: snap({
        phase: "dominance",
        stepKind: "dominance-round",
        rowBR,
        colBR,
        eliminatedRows: [...elimRows],
        eliminatedCols: [...elimCols],
        dominance: { dominantRow: null, dominantCol: null, round: rd.round, eliminations: rd.eliminations },
      }),
      why: idx === 0 ? "Removing a strictly dominated strategy can make others dominated in the smaller game — that is why the process repeats. The order of removal never changes the final result for strict dominance." : undefined,
    });
  });

  /* -------------------------------------------------------------- zero-sum */
  let lpEquilibrium: Equilibrium | null = null;
  let gameValue: Fraction | null = null;
  if (zeroSum) {
    const sec = securityLevels(A);
    const zsBase: ZeroSumInfo = {
      rowMins: sec.rowMins.map((x) => x.toDisplay()),
      colMaxs: sec.colMaxs.map((x) => x.toDisplay()),
      maximin: sec.maximin.toDisplay(),
      minimax: sec.minimax.toDisplay(),
      maximinRows: sec.maximinRows,
      minimaxCols: sec.minimaxCols,
      saddleCells: sec.saddleCells,
      shift: null,
      rowLP: null,
      colLP: null,
      rowLPObjective: null,
      colLPObjective: null,
      value: null,
      p: null,
      q: null,
    };
    const hasSaddle = sec.maximin.equals(sec.minimax);
    steps.push({
      title: hasSaddle ? `Security levels — saddle point, value ${sec.maximin.toDisplay()}` : "Security levels — no saddle point",
      explanation: `Player 1's worst case in each row is ${sec.rowMins.map((x, i) => `${rowNames[i]}: ${x.toDisplay()}`).join(", ")}; the best of these (maximin) is ${sec.maximin.toDisplay()}. Player 1's best case in each column is ${sec.colMaxs
        .map((x, j) => `${colNames[j]}: ${x.toDisplay()}`)
        .join(", ")}; Player 2 wants the smallest of these (minimax) = ${sec.minimax.toDisplay()}. ${
        hasSaddle
          ? `They are equal, so the game has a pure saddle point: the value is ${sec.maximin.toDisplay()} and the saddle cell${plural(sec.saddleCells.length, " is", "s are")} ${sec.saddleCells.map(([i, j]) => `(${rowNames[i]}, ${colNames[j]})`).join(", ")}.`
          : `Maximin < minimax, so pure strategies can't guarantee a value; the game needs mixed strategies, found with linear programming next.`
      }`,
      state: snap({ phase: "zero-sum", stepKind: "security", rowBR, colBR, highlightCells: sec.saddleCells, zeroSumInfo: zsBase }),
      why: "Maximin is the most Player 1 can guarantee using a single row; minimax is the least Player 2 can hold Player 1 to using a single column. Always maximin ≤ minimax; when they are equal the common value is a saddle point and an equilibrium in pure strategies.",
    });

    const lps = buildZeroSumLPs(A, rowNames, colNames);
    const sol = solveZeroSumLPs(lps);
    gameValue = sol.value;
    const zsWithRow: ZeroSumInfo = { ...zsBase, shift: lps.shift.toDisplay(), rowLP: lps.rowLP };
    steps.push({
      title: "Player 1's linear program (maximin)",
      explanation: `${
        lps.shift.isZero() ? "All payoffs are already positive, so no shift is needed." : `Add c = ${lps.shift.toDisplay()} to every payoff so all are positive (this shifts the game's value by c and changes no optimal strategy).`
      } With y_i = p_i / v′, where v′ is the shifted game's value, maximizing v′ means minimizing Σy subject to Σ_i A′[i][j]·y_i ≥ 1 for every column j, y ≥ 0. Solving it exactly gives y = ${exactList(sol.y)} and Σy = ${exact(sol.rowObjective)}.`,
      state: snap({ phase: "zero-sum", stepKind: "lp-row", rowBR, colBR, zeroSumInfo: zsWithRow }),
      why: "Requiring every column to pay at least v′ (= 1 after scaling by v′) is exactly the statement that Player 1's mix guarantees v′ against every pure reply of Player 2 — hence against every mixed reply too. The simplex replay below shows the exact tableaux.",
    });

    const zsWithBoth: ZeroSumInfo = { ...zsWithRow, colLP: lps.colLP, rowLPObjective: exact(sol.rowObjective) };
    steps.push({
      title: "Player 2's linear program (minimax, the dual)",
      explanation: `With z_j = q_j / v′, minimizing the value Player 2 concedes means maximizing Σz subject to Σ_j A′[i][j]·z_j ≤ 1 for every row i, z ≥ 0. This LP is the dual of Player 1's. Solving it exactly gives z = ${exactList(sol.z)} and Σz = ${exact(sol.colObjective)}.`,
      state: snap({ phase: "zero-sum", stepKind: "lp-col", rowBR, colBR, zeroSumInfo: zsWithBoth }),
      why: "Player 2's problem is the mirror image of Player 1's; that the two optima match (strong duality) is the minimax theorem in linear-programming form.",
    });

    const zsFinal: ZeroSumInfo = { ...zsWithBoth, colLPObjective: exact(sol.colObjective), value: exact(sol.value), p: sol.p.map(exact), q: sol.q.map(exact) };
    if (!isNashEquilibrium(A, B, sol.p, sol.q)) throw new Error("Internal check failed: the LP strategies are not an equilibrium.");
    lpEquilibrium = makeEquilibrium(A, B, sol.p, sol.q);
    steps.push({
      title: `Optimal strategies — value of the game = ${exact(sol.value)}`,
      explanation: `Σy = Σz = ${exact(sol.rowObjective)} (the LP duality check passes), so v′ = 1/Σy = ${exact(Fraction.ONE.div(sol.rowObjective))} and the value is v = v′ − c = ${exact(sol.value)}. Player 1's optimal mix is p = y/Σy = ${exactList(sol.p)}; Player 2's is q = z/Σz = ${exactList(sol.q)}. Together they form a Nash equilibrium (checked directly), and every equilibrium of a zero-sum game pays Player 1 exactly ${exact(sol.value)}.`,
      state: snap({ phase: "zero-sum", stepKind: "zero-sum-solution", rowBR, colBR, zeroSumInfo: zsFinal, equilibria: [lpEquilibrium] }),
      why: "If the optimal strategies are not unique the LP returns one of them (a vertex of the optimal set); support enumeration below lists the equilibria it can isolate.",
    });
  }

  /* --------------------------------------------------- support enumeration */
  const degeneracy: DegeneracyInfo = checkDegeneracy(A, B, rowNames, colNames);
  const enumeration = enumerateSupports(A, B, rowNames, colNames);

  steps.push({
    title: `Support enumeration — ${enumeration.pairsTotal} support pairs to try`,
    explanation: `In an equilibrium (p, q), Player 1 mixes over a support I of rows and Player 2 over a support J of columns. In a nondegenerate game the two supports always have the same size, so larpra tries every pair (I, J) with |I| = |J| = k — Σ_k C(${m},k)·C(${n},k) = ${enumeration.pairsTotal} pairs here — solving for the mixes that make each player indifferent, then checking nobody wants to deviate. ${
      degeneracy.degenerate
        ? `Degeneracy check: this game IS degenerate. ${degeneracy.witness} Equal-size support enumeration finds every isolated equilibrium it can, but it may not describe all of them (equilibria can form continua).`
        : "Degeneracy check: this game is nondegenerate (no strategy has more best responses than its support size), so equal-size support enumeration is exhaustive."
    }`,
    state: snap({ phase: "supports", stepKind: "supports-overview", rowBR, colBR, degeneracy, equilibria: [] }),
    why: "If a player mixes over several strategies, each of them must earn the same expected payoff against the opponent's mix — otherwise the player would drop the weaker ones. Those equalities are linear equations in the opponent's probabilities, which is why each candidate support pair reduces to two small linear systems.",
  });

  const soFar: Equilibrium[] = [];
  for (const level of enumeration.bySize) {
    soFar.push(...level.equilibria);
    const k = level.size;
    const info = level.info;
    steps.push({
      title: `Supports of size ${k} — ${info.pairsThisSize} ${plural(info.pairsThisSize, "pair", "pairs")}, ${level.equilibria.length} ${plural(level.equilibria.length, "equilibrium", "equilibria")}`,
      explanation: `${info.pairsThisSize} ${plural(info.pairsThisSize, "pair", "pairs")} of size-${k} supports tried: ${tallySentence(info.tally)}.${
        level.equilibria.length > 0 ? ` Equilibri${level.equilibria.length === 1 ? "um" : "a"}: ${level.equilibria.map((e) => eqLine(e, rowNames, colNames)).join("; ")}.` : ""
      }`,
      state: snap({
        phase: "supports",
        stepKind: "supports-size",
        rowBR,
        colBR,
        highlightCells: k === 1 ? level.equilibria.map((e) => [e.supportRows[0], e.supportCols[0]] as [number, number]) : [],
        degeneracy,
        supports: info,
        equilibria: [...soFar],
      }),
      why:
        k === 1
          ? "Size-1 supports are pure strategy profiles. The indifference equations shrink to q = (1) and p = (1), so only the best-response check remains — the same test as the pure-equilibrium step, which is why the two always agree."
          : "For each pair, Player 2's probabilities are chosen so Player 1 is indifferent among the rows in I (and Player 1's so that Player 2 is indifferent among the columns in J). A candidate fails if the equations have no unique solution, if any probability isn't strictly positive, or if a strategy outside the support pays more.",
    });
  }

  /* --------------------------------------------------------------- summary */
  const finalEq: Equilibrium[] = [...soFar];
  if (lpEquilibrium && !finalEq.some((e) => e.p.join() === lpEquilibrium!.p.join() && e.q.join() === lpEquilibrium!.q.join())) {
    finalEq.push(lpEquilibrium);
    notes.push("The minimax linear program produced an optimal pair whose supports have different sizes; support enumeration doesn't try those, so it is listed separately (possible only in a degenerate zero-sum game).");
  }
  if (degeneracy.degenerate) {
    notes.push(`Degenerate game: ${degeneracy.witness} The list below contains every equilibrium with equal-size supports; there may be more (including a continuum of equilibria).`);
  }
  const oddNote = !degeneracy.degenerate ? ` As it must be for a nondegenerate game, the number of equilibria (${finalEq.length}) is odd.` : "";
  steps.push({
    title: finalEq.length === 0 ? "No equilibrium found" : `All Nash equilibria — ${finalEq.length} found`,
    explanation:
      finalEq.length === 0
        ? "No support pair produced an equilibrium. Nash's theorem guarantees one exists, so this can only happen for a degenerate game whose equilibria have supports of different sizes."
        : `${finalEq.map((e, i) => `${i + 1}. ${eqLine(e, rowNames, colNames)}`).join(" ")}${oddNote}${
            gameValue ? ` Every equilibrium pays Player 1 the game's value, ${exact(gameValue)}.` : ""
          }`,
    state: snap({
      phase: "summary",
      stepKind: "summary",
      rowBR,
      colBR,
      highlightCells: finalEq.filter((e) => e.kind === "pure").map((e) => [e.supportRows[0], e.supportCols[0]] as [number, number]),
      eliminatedRows: [...elimRows],
      eliminatedCols: [...elimCols],
      degeneracy,
      equilibria: finalEq,
    }),
    why: "Nash's theorem guarantees at least one equilibrium in every finite game. For nondegenerate games the count is always odd (generic games have 1, 3, 5, … equilibria).",
  });

  return {
    status: "solved",
    steps,
    equilibria: finalEq,
    degeneracy,
    ...(gameValue ? { value: exact(gameValue) } : {}),
    notes,
  };
}

