import { Fraction } from "../../utils/fraction";

/**
 * Exact linear-system solving over Fractions (Gauss–Jordan elimination).
 *
 * Support enumeration needs to solve small square "indifference" systems many times; every one is solved
 * exactly, so "this system has no solution / has many solutions" is a definite answer, never a
 * near-singular-matrix judgment call.
 */
export type LinearSolve =
  | { kind: "unique"; x: Fraction[] }
  | { kind: "none" } // inconsistent: no solution at all
  | { kind: "many" }; // consistent but underdetermined: infinitely many solutions

/** Solves M·x = rhs, where M has rows.length equations and `cols` unknowns. Inputs are not modified. */
export function solveLinearSystem(M: Fraction[][], rhs: Fraction[], cols: number): LinearSolve {
  const rows = M.length;
  const A: Fraction[][] = M.map((row, i) => [...row, rhs[i]]);
  const pivotCols: number[] = [];
  let r = 0;
  for (let c = 0; c < cols && r < rows; c++) {
    let p = -1;
    for (let i = r; i < rows; i++) {
      if (!A[i][c].isZero()) {
        p = i;
        break;
      }
    }
    if (p === -1) continue;
    [A[r], A[p]] = [A[p], A[r]];
    const pv = A[r][c];
    A[r] = A[r].map((x) => x.div(pv));
    for (let i = 0; i < rows; i++) {
      if (i !== r && !A[i][c].isZero()) {
        const f = A[i][c];
        A[i] = A[i].map((x, k) => x.sub(f.mul(A[r][k])));
      }
    }
    pivotCols.push(c);
    r++;
  }
  // an all-zero coefficient row with a non-zero right-hand side is a contradiction
  for (let i = r; i < rows; i++) {
    if (!A[i][cols].isZero()) return { kind: "none" };
  }
  if (pivotCols.length < cols) return { kind: "many" };
  const x: Fraction[] = new Array(cols).fill(Fraction.ZERO);
  pivotCols.forEach((c, i) => {
    x[c] = A[i][cols];
  });
  return { kind: "unique", x };
}
