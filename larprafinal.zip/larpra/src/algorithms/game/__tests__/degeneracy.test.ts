import { describe, expect, it } from "vitest";
import { checkDegeneracy } from "../degeneracy";
import { toFractionMatrix } from "../common";
import { gameExamples } from "../examples";

const fm = toFractionMatrix;
const check = (A: number[][], B: number[][]) =>
  checkDegeneracy(fm(A), fm(B), A.map((_, i) => `R${i + 1}`), A[0].map((_, j) => `C${j + 1}`));

describe("exact degeneracy test", () => {
  it("built-in nondegenerate examples", () => {
    for (const name of ["Prisoner's Dilemma", "Matching Pennies", "Battle of the Sexes", "Stag Hunt", "Chicken", "Rock-Paper-Scissors", "Three-way coordination game", "Zero-sum game needing the LP", "Solvable by iterated dominance"]) {
      const ex = gameExamples.find((e) => e.name === name)!.problem;
      expect(check(ex.payoffA, ex.payoffB).degenerate, name).toBe(false);
    }
  });

  it("the indifferent-row-player example is degenerate, with a witness naming the tie", () => {
    const ex = gameExamples.find((e) => e.name.startsWith("Indifferent"))!.problem;
    const r = check(ex.payoffA, ex.payoffB);
    expect(r.degenerate).toBe(true);
    expect(r.witness).toContain("best responses");
  });

  it("a tie inside one row of Player 2's payoffs makes the game degenerate (a pure strategy with two best responses)", () => {
    const r = check([[1, 2], [3, 4]], [[5, 5], [1, 0]]);
    expect(r.degenerate).toBe(true);
    expect(r.witness).toContain("Player 1 plays {R1}");
    expect(r.witness).toContain("2 best responses");
  });

  it("a tie inside one column of Player 1's payoffs makes it degenerate from Player 2's side", () => {
    const r = check([[7, 1], [7, 2]], [[1, 0], [0, 1]]);
    expect(r.degenerate).toBe(true);
    expect(r.witness).toContain("Player 2");
  });

  it("a tie that only appears for a *mixed* strategy is caught too", () => {
    // Column payoffs to Player 2 when Player 1 mixes 50/50 over R1,R2: C1 → 2, C2 → 2, C3 → 2 : three best responses vs a two-strategy support
    const r = check([[0, 0, 0], [0, 0, 0]], [[1, 3, 2], [3, 1, 2]]);
    expect(r.degenerate).toBe(true);
    expect(r.witness).toContain("mixes over {R1, R2}");
    expect(r.witness).toContain("3 best responses");
  });

  it("is unchanged by adding a constant to all payoffs or scaling them by a positive number", () => {
    const A = [[3, 0, 1], [0, 2, 1], [1, 1, 0]];
    const B = [[1, 0, 2], [2, 1, 0], [0, 3, 1]];
    const base = check(A, B).degenerate;
    expect(check(A.map((r) => r.map((x) => x + 17)), B.map((r) => r.map((x) => x - 4))).degenerate).toBe(base);
    expect(check(A.map((r) => r.map((x) => x * 3)), B.map((r) => r.map((x) => x * 5))).degenerate).toBe(base);
  });

  it("1 × 1 and 1 × n games do not throw", () => {
    expect(check([[1]], [[1]]).degenerate).toBe(false);
    expect(check([[1, 2, 3]], [[4, 4, 1]]).degenerate).toBe(true); // Player 2 has two best responses to Player 1's only strategy
    expect(check([[1, 2, 3]], [[4, 5, 1]]).degenerate).toBe(false);
  });
});
