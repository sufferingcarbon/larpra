import { describe, expect, it } from "vitest";
import { buildZeroSumLPs, securityLevels, solveZeroSumLPs } from "../zeroSum";
import { toFractionMatrix } from "../common";
import { solveGame } from "../solve";
import { solveSimplex } from "../../lp/simplex";
import { gameExamples } from "../examples";
import { game, nashViolation, parseFrac, rng, randomMatrix } from "./helpers";

const fm = toFractionMatrix;
const lpFor = (A: number[][]) => {
  const names = (n: number, p: string) => Array.from({ length: n }, (_, i) => `${p}${i + 1}`);
  return buildZeroSumLPs(fm(A), names(A.length, "R"), names(A[0].length, "C"));
};

describe("security levels", () => {
  it("saddle-point example: maximin = minimax = 3 at cell (C, Z)", () => {
    const A = gameExamples.find((e) => e.name === "Saddle-point zero-sum game")!.problem.payoffA;
    const s = securityLevels(fm(A));
    expect(s.rowMins.map((x) => x.toDisplay())).toEqual(["1", "0", "3"]);
    expect(s.colMaxs.map((x) => x.toDisplay())).toEqual(["7", "4", "3"]);
    expect(s.maximin.toDisplay()).toBe("3");
    expect(s.minimax.toDisplay()).toBe("3");
    expect(s.maximinRows).toEqual([2]);
    expect(s.minimaxCols).toEqual([2]);
    expect(s.saddleCells).toEqual([[2, 2]]);
  });

  it("Rock-Paper-Scissors: maximin −1 < minimax 1, no saddle", () => {
    const s = securityLevels(fm([[0, -1, 1], [1, 0, -1], [-1, 1, 0]]));
    expect(s.maximin.toDisplay()).toBe("-1");
    expect(s.minimax.toDisplay()).toBe("1");
    expect(s.saddleCells).toEqual([]);
  });

  it("several saddle points are all reported (they share one value)", () => {
    const s = securityLevels(fm([[2, 2], [2, 2]]));
    expect(s.saddleCells).toHaveLength(4);
  });

  it("maximin ≤ minimax always (60 random games)", () => {
    const rand = rng(5);
    for (let t = 0; t < 60; t++) {
      const s = securityLevels(fm(randomMatrix(rand, 2 + Math.floor(rand() * 3), 2 + Math.floor(rand() * 3), -9, 9)));
      expect(s.maximin.lte(s.minimax)).toBe(true);
    }
  });
});

describe("the two linear programs", () => {
  it("Matching Pennies: shift c = 2, LPs have coefficients [[3,1],[1,3]], value 0, p = q = 1/2", () => {
    const lps = lpFor([[1, -1], [-1, 1]]);
    expect(lps.shift.toDisplay()).toBe("2");
    expect(lps.rowLP.sense).toBe("min");
    expect(lps.rowLP.objective).toEqual([1, 1]);
    expect(lps.rowLP.constraints.map((c) => [c.coeffs, c.relation, c.rhs])).toEqual([[[3, 1], ">=", 1], [[1, 3], ">=", 1]]);
    expect(lps.colLP.sense).toBe("max");
    expect(lps.colLP.constraints.map((c) => [c.coeffs, c.relation, c.rhs])).toEqual([[[3, 1], "<=", 1], [[1, 3], "<=", 1]]);
    const s = solveZeroSumLPs(lps);
    expect(s.value.toDisplay()).toBe("0");
    expect(s.p.map((x) => x.toDisplay())).toEqual(["1/2", "1/2"]);
    expect(s.q.map((x) => x.toDisplay())).toEqual(["1/2", "1/2"]);
    expect(s.rowObjective.equals(s.colObjective)).toBe(true);
  });

  it("no shift when every payoff is already positive", () => {
    const lps = lpFor([[3, 1], [2, 5]]);
    expect(lps.shift.toDisplay()).toBe("0");
    expect(lps.rowLP.constraints[0].coeffs).toEqual([3, 2]);
  });

  it("exactly matches the closed form for a 2×2 game with decimal payoffs: value −1/50, p = (3/5, 2/5), q = (7/10, 3/10)", () => {
    const A = [[0.1, -0.3], [-0.2, 0.4]];
    const lps = lpFor(A);
    // shifted coefficients are clean decimals, not 1.4000000000000001-style float noise
    expect(lps.shift.toDisplay()).toBe("13/10");
    expect(lps.rowLP.constraints[0].coeffs).toEqual([1.4, 1.1]);
    const s = solveZeroSumLPs(lps);
    expect(s.value.toDisplay()).toBe("-1/50");
    expect(s.p.map((x) => x.toDisplay())).toEqual(["3/5", "2/5"]);
    expect(s.q.map((x) => x.toDisplay())).toEqual(["7/10", "3/10"]);
  });

  it("the 3 × 4 example: value 8/17 with the exact strategies", () => {
    const A = gameExamples.find((e) => e.name === "Zero-sum game needing the LP")!.problem.payoffA;
    const s = solveZeroSumLPs(lpFor(A));
    expect(s.value.toDisplay()).toBe("8/17");
    expect(s.p.map((x) => x.toDisplay())).toEqual(["5/17", "4/51", "32/51"]);
    expect(s.q.map((x) => x.toDisplay())).toEqual(["2/17", "5/17", "10/17", "0"]);
  });

  it("the LPs are real problems the existing simplex solver can replay step by step, reaching the same optimum", () => {
    const lps = lpFor([[4, 0, 0, -2], [-1, 6, -2, 6], [-1, 0, 1, 4]]);
    const solved = solveZeroSumLPs(lps);
    const rowReplay = solveSimplex(lps.rowLP);
    const colReplay = solveSimplex(lps.colLP);
    expect(rowReplay.status === "optimal" || rowReplay.status === "alternate_optima").toBe(true);
    expect(rowReplay.steps.length).toBeGreaterThan(1);
    expect(rowReplay.optimalValue).toBeCloseTo(solved.rowObjective.toNumber(), 9);
    expect(colReplay.optimalValue).toBeCloseTo(solved.colObjective.toNumber(), 9);
  });

  it("strong duality holds on 120 random zero-sum games, and the LP pair is a Nash equilibrium", () => {
    const rand = rng(31337);
    for (let t = 0; t < 120; t++) {
      const m = 1 + Math.floor(rand() * 5);
      const n = 1 + Math.floor(rand() * 5);
      const A = randomMatrix(rand, m, n, -8, 8);
      const s = solveZeroSumLPs(lpFor(A));
      expect(s.rowObjective.equals(s.colObjective)).toBe(true);
      const p = s.p.map((x) => x.toDisplay());
      const q = s.q.map((x) => x.toDisplay());
      expect(nashViolation(A, A.map((r) => r.map((x) => 0 - x)), s.p.map((x) => `${x.num}/${x.den}`), s.q.map((x) => `${x.num}/${x.den}`)), JSON.stringify({ A, p, q })).toBeNull();
    }
  });
});

describe("zero-sum solve, end to end", () => {
  it("every equilibrium pays Player 1 the value of the game (the minimax theorem), 100 random games", () => {
    const rand = rng(2718);
    for (let t = 0; t < 100; t++) {
      const A = randomMatrix(rand, 2 + Math.floor(rand() * 3), 2 + Math.floor(rand() * 3), -6, 6);
      const r = solveGame(game(A));
      expect(r.status).toBe("solved");
      expect(r.value).toBeDefined();
      const v = parseFrac(r.value!);
      for (const e of r.equilibria) {
        expect(parseFrac(e.payoffA).equals(v), JSON.stringify(A)).toBe(true);
        expect(parseFrac(e.payoffB).equals(v.neg())).toBe(true);
      }
    }
  });

  it("a nondegenerate zero-sum game has exactly one equilibrium", () => {
    const rand = rng(4242);
    let checked = 0;
    for (let t = 0; t < 120; t++) {
      const r = solveGame(game(randomMatrix(rand, 2 + Math.floor(rand() * 3), 2 + Math.floor(rand() * 3), -20, 20)));
      if (r.degeneracy!.degenerate) continue;
      checked++;
      expect(r.equilibria).toHaveLength(1);
    }
    expect(checked).toBeGreaterThan(40);
  });

  it("the LP's step sequence appears in order: security levels, Player 1's LP, Player 2's LP, solution", () => {
    const r = solveGame(gameExamples.find((e) => e.name === "Zero-sum game needing the LP")!.problem);
    const kinds = r.steps.map((s) => s.state.stepKind);
    const at = (k: string) => kinds.indexOf(k);
    expect(at("security")).toBeGreaterThan(-1);
    expect(at("lp-row")).toBe(at("security") + 1);
    expect(at("lp-col")).toBe(at("lp-row") + 1);
    expect(at("zero-sum-solution")).toBe(at("lp-col") + 1);
    expect(at("supports-overview")).toBeGreaterThan(at("zero-sum-solution"));
    // nothing appears before it is computed
    expect(r.steps[at("security")].state.zeroSumInfo!.rowLP).toBeNull();
    expect(r.steps[at("lp-row")].state.zeroSumInfo!.colLP).toBeNull();
    expect(r.steps[at("lp-row")].state.zeroSumInfo!.value).toBeNull();
    expect(r.steps[at("lp-col")].state.zeroSumInfo!.colLP).not.toBeNull();
    expect(r.steps[at("lp-col")].state.zeroSumInfo!.value).toBeNull();
    const last = r.steps[at("zero-sum-solution")].state.zeroSumInfo!;
    expect(last.value).toBe("8/17");
    expect(last.rowLPObjective).toBe(last.colLPObjective);
  });

  it("general-sum games never get zero-sum steps", () => {
    const r = solveGame(gameExamples.find((e) => e.name === "Battle of the Sexes")!.problem);
    expect(r.steps.some((s) => s.state.phase === "zero-sum")).toBe(false);
    expect(r.value).toBeUndefined();
  });

  it("solving a game flagged zero-sum and the same game entered as general-sum give the same equilibria", () => {
    const A = [[3, -2, 4], [-1, 5, -3]];
    const zs = solveGame(game(A));
    const gs = solveGame({ ...game(A), zeroSum: false });
    const key = (r: typeof zs) => r.equilibria.map((e) => `${e.p}|${e.q}`).sort();
    expect(key(zs)).toEqual(key(gs));
  });
});
