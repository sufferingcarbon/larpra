import { describe, expect, it } from "vitest";
import { Fraction, frac } from "../../../utils/fraction";
import { solveLinearSystem } from "../linalg";

const F = (rows: number[][]) => rows.map((r) => r.map((x) => frac(x)));
const V = (v: number[]) => v.map((x) => frac(x));

describe("exact linear-system solver", () => {
  it("solves a 2×2 system with a non-integer solution exactly", () => {
    // 2x + y = 1 ; x + 3y = 1  →  x = 2/5, y = 1/5
    const r = solveLinearSystem(F([[2, 1], [1, 3]]), V([1, 1]), 2);
    expect(r.kind).toBe("unique");
    if (r.kind === "unique") {
      expect(r.x[0].equals(new Fraction(2n, 5n))).toBe(true);
      expect(r.x[1].equals(new Fraction(1n, 5n))).toBe(true);
    }
  });

  it("needs a row swap when the leading coefficient is zero", () => {
    const r = solveLinearSystem(F([[0, 1], [1, 0]]), V([3, 4]), 2);
    expect(r.kind).toBe("unique");
    if (r.kind === "unique") expect(r.x.map((x) => x.toDisplay())).toEqual(["4", "3"]);
  });

  it("reports a contradiction as 'none'", () => {
    // x + y = 1 ; x + y = 2
    expect(solveLinearSystem(F([[1, 1], [1, 1]]), V([1, 2]), 2).kind).toBe("none");
  });

  it("reports an underdetermined but consistent system as 'many'", () => {
    // x + y = 1 ; 2x + 2y = 2
    expect(solveLinearSystem(F([[1, 1], [2, 2]]), V([1, 2]), 2).kind).toBe("many");
    // fewer equations than unknowns
    expect(solveLinearSystem(F([[1, 1, 1]]), V([1]), 3).kind).toBe("many");
  });

  it("solves an overdetermined but consistent system", () => {
    const r = solveLinearSystem(F([[1, 0], [0, 1], [1, 1]]), V([1, 2, 3]), 2);
    expect(r.kind).toBe("unique");
  });

  it("does not modify its inputs", () => {
    const M = F([[2, 1], [1, 3]]);
    const rhs = V([1, 1]);
    solveLinearSystem(M, rhs, 2);
    expect(M[0][0].toDisplay()).toBe("2");
    expect(rhs[0].toDisplay()).toBe("1");
  });

  it("stays exact where floating point would not (a 6×6 Hilbert-like system)", () => {
    const n = 6;
    const M: Fraction[][] = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => new Fraction(1n, BigInt(i + j + 1))));
    const x = Array.from({ length: n }, (_, i) => frac(i + 1));
    const rhs = M.map((row) => row.reduce((s, a, j) => s.add(a.mul(x[j])), Fraction.ZERO));
    const r = solveLinearSystem(M, rhs, n);
    expect(r.kind).toBe("unique");
    if (r.kind === "unique") r.x.forEach((v, i) => expect(v.equals(x[i])).toBe(true));
  });
});
