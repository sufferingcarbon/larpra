import { describe, expect, it } from "vitest";
import { findDominantCol, findDominantRow, iteratedElimination } from "../dominance";
import { toFractionMatrix } from "../common";
import { gameExamples } from "../examples";
import { solveGame } from "../solve";
import { game, nashViolation, sortedKeys } from "./helpers";

const fm = toFractionMatrix;

describe("dominant strategies", () => {
  it("Prisoner's Dilemma: Defect is strictly dominant for both players", () => {
    expect(findDominantRow(fm([[-1, -3], [0, -2]]))).toEqual({ index: 1, kind: "strict" });
    expect(findDominantCol(fm([[-1, 0], [-3, -2]]))).toEqual({ index: 1, kind: "strict" });
  });

  it("finds a weakly (not strictly) dominant strategy when payoffs tie somewhere", () => {
    // row 0 ≥ row 1 everywhere, strictly in column 1
    expect(findDominantRow(fm([[1, 1], [1, 0]]))).toEqual({ index: 0, kind: "weak" });
  });

  it("identical rows dominate neither strictly nor weakly", () => {
    expect(findDominantRow(fm([[1, 2], [1, 2]]))).toBeNull();
  });

  it("no dominant strategy in Matching Pennies or Battle of the Sexes", () => {
    expect(findDominantRow(fm([[1, -1], [-1, 1]]))).toBeNull();
    expect(findDominantCol(fm([[1, 0], [0, 2]]))).toBeNull();
  });

  it("a player with a single strategy has no 'dominant' strategy to report", () => {
    expect(findDominantRow(fm([[1, 2, 3]]))).toBeNull();
    expect(findDominantCol(fm([[1], [2]]))).toBeNull();
  });
});

describe("iterated elimination of strictly dominated strategies", () => {
  const ex = gameExamples.find((e) => e.name === "Solvable by iterated dominance")!.problem;
  const A = fm(ex.payoffA);
  const B = fm(ex.payoffB);

  it("removes Right, Top, Left, Bottom — one per round, in that order — leaving (Middle, Center)", () => {
    const { rounds, rows, cols } = iteratedElimination(A, B);
    expect(rounds.map((r) => r.eliminations.map((e) => `${e.player}:${e.index}`))).toEqual([["2:2"], ["1:0"], ["2:0"], ["1:2"]]);
    expect(rows).toEqual([1]);
    expect(cols).toEqual([1]);
  });

  it("records a dominator that survives the round", () => {
    const { rounds } = iteratedElimination(A, B);
    rounds.forEach((r) => r.eliminations.forEach((e) => expect(typeof e.by).toBe("number")));
    // Top (row 0) is dominated by Middle (row 1) and by Bottom (row 2); the first survivor is reported
    expect(rounds[1].eliminations[0]).toEqual({ player: 1, index: 0, by: 1 });
  });

  it("removes everything strictly dominated at once (both players in one round)", () => {
    const { rounds } = iteratedElimination(fm([[-1, -3], [0, -2]]), fm([[-1, 0], [-3, -2]]));
    expect(rounds).toHaveLength(1);
    expect(rounds[0].eliminations.map((e) => `${e.player}:${e.index}`).sort()).toEqual(["1:0", "2:0"]);
  });

  it("never removes a weakly dominated strategy", () => {
    // row 0 weakly dominates row 1, but not strictly
    expect(iteratedElimination(fm([[1, 1], [1, 0]]), fm([[0, 0], [0, 0]])).rounds).toEqual([]);
  });

  it("never eliminates every strategy of a player, even in all-equal games", () => {
    const r = iteratedElimination(fm([[5, 5], [5, 5]]), fm([[5, 5], [5, 5]]));
    expect(r.rows.length).toBeGreaterThan(0);
    expect(r.cols.length).toBeGreaterThan(0);
  });

  it("the equilibrium of the fully reduced game is the equilibrium of the whole game", () => {
    const r = solveGame(ex);
    expect(r.equilibria).toHaveLength(1);
    expect(r.equilibria[0].p).toEqual(["0", "1", "0"]);
    expect(r.equilibria[0].q).toEqual(["0", "1", "0"]);
    expect(nashViolation(ex.payoffA, ex.payoffB, r.equilibria[0].p, r.equilibria[0].q)).toBeNull();
  });
});

describe("dominance never changes the equilibria (property, 150 random games)", () => {
  it("every equilibrium puts probability 0 on every strictly dominated strategy, and the reduced game has the same equilibria", () => {
    let seed = 99;
    const rand = () => ((seed = (seed * 48271) % 2147483647) / 2147483647);
    let withElimination = 0;
    for (let t = 0; t < 150; t++) {
      const m = 2 + Math.floor(rand() * 3);
      const n = 2 + Math.floor(rand() * 3);
      const A = Array.from({ length: m }, () => Array.from({ length: n }, () => Math.floor(rand() * 8)));
      const B = Array.from({ length: m }, () => Array.from({ length: n }, () => Math.floor(rand() * 8)));
      const full = solveGame(game(A, B));
      const { rows, cols, rounds } = iteratedElimination(fm(A), fm(B));
      if (rounds.length === 0) continue;
      withElimination++;
      // every equilibrium of the full game lives inside the surviving strategies
      for (const e of full.equilibria) {
        e.p.forEach((x, i) => { if (!rows.includes(i)) expect(x).toBe("0"); });
        e.q.forEach((x, j) => { if (!cols.includes(j)) expect(x).toBe("0"); });
      }
      // and solving the reduced game directly gives the same set (embedded back)
      const sub = solveGame(game(rows.map((i) => cols.map((j) => A[i][j])), rows.map((i) => cols.map((j) => B[i][j]))));
      const embedded = sub.equilibria.map((e) => ({
        p: A.map((_, i) => (rows.includes(i) ? e.p[rows.indexOf(i)] : "0")),
        q: A[0].map((_, j) => (cols.includes(j) ? e.q[cols.indexOf(j)] : "0")),
      }));
      // degenerate games may list different equal-size equilibria in the sub-game; the property is exact only for nondegenerate ones
      if (!full.degeneracy!.degenerate && !sub.degeneracy!.degenerate) expect(sortedKeys(embedded)).toEqual(sortedKeys(full.equilibria));
    }
    expect(withElimination).toBeGreaterThan(20);
  });
});
