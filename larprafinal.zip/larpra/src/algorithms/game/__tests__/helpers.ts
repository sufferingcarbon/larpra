import { Fraction, frac } from "../../../utils/fraction";
import { GameInput } from "../../../types/game";

/** "3/4" → Fraction (the solver writes every probability exactly, so tests can re-read it exactly). */
export function parseFrac(s: string): Fraction {
  const [n, d] = s.split("/");
  return new Fraction(BigInt(n), BigInt(d ?? "1"));
}

/**
 * An independent statement of the Nash condition, written separately from the solver's own checks:
 * returns null when (p, q) is an equilibrium of (A, B), otherwise a sentence saying which condition fails.
 */
export function nashViolation(A: number[][], B: number[][], p: string[], q: string[]): string | null {
  const P = p.map(parseFrac);
  const Q = q.map(parseFrac);
  const m = A.length;
  const n = A[0].length;
  const sum = (v: Fraction[]) => v.reduce((s, x) => s.add(x), Fraction.ZERO);
  if (!sum(P).equals(1)) return "p does not sum to 1";
  if (!sum(Q).equals(1)) return "q does not sum to 1";
  if (P.some((x) => x.isNegative()) || Q.some((x) => x.isNegative())) return "negative probability";
  const rowVal: Fraction[] = [];
  for (let i = 0; i < m; i++) {
    let s = Fraction.ZERO;
    for (let j = 0; j < n; j++) s = s.add(frac(A[i][j]).mul(Q[j]));
    rowVal.push(s);
  }
  const colVal: Fraction[] = [];
  for (let j = 0; j < n; j++) {
    let s = Fraction.ZERO;
    for (let i = 0; i < m; i++) s = s.add(frac(B[i][j]).mul(P[i]));
    colVal.push(s);
  }
  const rBest = rowVal.reduce((a, b) => (b.gt(a) ? b : a));
  const cBest = colVal.reduce((a, b) => (b.gt(a) ? b : a));
  for (let i = 0; i < m; i++) if (P[i].isPositive() && !rowVal[i].equals(rBest)) return `row ${i} is played but is not a best response`;
  for (let j = 0; j < n; j++) if (Q[j].isPositive() && !colVal[j].equals(cBest)) return `column ${j} is played but is not a best response`;
  return null;
}

/** Expected payoff pᵀ M q, exact. */
export function expected(M: number[][], p: string[], q: string[]): Fraction {
  let s = Fraction.ZERO;
  p.forEach((pi, i) => q.forEach((qj, j) => (s = s.add(parseFrac(pi).mul(frac(M[i][j])).mul(parseFrac(qj))))));
  return s;
}

export function game(A: number[][], B?: number[][]): GameInput {
  return {
    rowNames: A.map((_, i) => `R${i + 1}`),
    colNames: A[0].map((_, j) => `C${j + 1}`),
    payoffA: A,
    payoffB: B ?? A.map((r) => r.map((x) => 0 - x)),
    zeroSum: B === undefined,
  };
}

/** Small deterministic PRNG (mulberry32) so random tests are reproducible. */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function randomMatrix(rand: () => number, m: number, n: number, lo: number, hi: number): number[][] {
  return Array.from({ length: m }, () => Array.from({ length: n }, () => lo + Math.floor(rand() * (hi - lo + 1))));
}

export const sortedKeys = (eqs: { p: string[]; q: string[] }[]) => eqs.map((e) => `${e.p.join(",")}|${e.q.join(",")}`).sort();
