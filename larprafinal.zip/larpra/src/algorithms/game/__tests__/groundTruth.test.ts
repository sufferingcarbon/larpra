import { describe, expect, it } from "vitest";
import { solveGame } from "../solve";
import { gameExamples } from "../examples";
import { GT_CASES } from "./fixtures/groundTruth";
import { nashViolation, parseFrac } from "./helpers";
import { GameInput } from "../../../types/game";

/**
 * Cross-validation against tools/game_ground_truth.py's independent oracle: brute-force pure equilibria, an
 * LP-based degeneracy test (a different method from the app's vertex test), nashpy's vertex enumeration
 * cross-checked against a separate exact Python support enumeration (complete equilibrium lists for
 * nondegenerate games), and scipy.linprog for zero-sum values. 206 cases: the 11 built-in examples plus seeded
 * random games in six families.
 */
const toInput = (c: (typeof GT_CASES)[number]): GameInput => ({
  rowNames: c.A.map((_, i) => `R${i + 1}`),
  colNames: c.A[0].map((_, j) => `C${j + 1}`),
  payoffA: c.A,
  payoffB: c.B,
  zeroSum: c.zeroSum,
});

const fracToNumber = (s: string) => {
  const f = parseFrac(s);
  return Number(f.num) / Number(f.den);
};

describe(`ground truth (${GT_CASES.length} cases)`, () => {
  it("the classic cases in the fixture are the app's built-in examples, matrix for matrix", () => {
    const classics = GT_CASES.filter((c) => c.family === "classic");
    expect(classics.length).toBe(gameExamples.length);
    for (const ex of gameExamples) {
      const c = classics.find((k) => k.label === ex.name);
      expect(c, ex.name).toBeDefined();
      expect(c!.A).toEqual(ex.problem.payoffA);
      expect(c!.B).toEqual(ex.problem.payoffB);
    }
  });

  for (const c of GT_CASES) {
    describe(`${c.label} [${c.family}]`, () => {
      const r = solveGame(toInput(c));

      it("solves", () => expect(r.status).toBe("solved"));

      it("pure equilibria match brute force", () => {
        const got = r.equilibria
          .filter((e) => e.kind === "pure")
          .map((e) => [e.supportRows[0], e.supportCols[0]])
          .sort((x, y) => x[0] - y[0] || x[1] - y[1]);
        const want = [...c.pure].sort((x, y) => x[0] - y[0] || x[1] - y[1]);
        expect(got).toEqual(want);
      });

      it("degeneracy verdict matches the LP oracle", () => {
        expect(r.degeneracy?.degenerate).toBe(c.degenerate);
      });

      it("every reported equilibrium satisfies the Nash conditions exactly", () => {
        for (const e of r.equilibria) expect(nashViolation(c.A, c.B, e.p, e.q)).toBeNull();
      });

      if (!c.degenerate && c.equilibria) {
        it("finds exactly the oracle's equilibria (odd count, Wilson)", () => {
          expect(r.equilibria.length).toBe(c.equilibria!.length);
          expect(r.equilibria.length % 2).toBe(1);
          for (const [wp, wq] of c.equilibria!) {
            const hit = r.equilibria.some(
              (e) => e.pNum.every((x, i) => Math.abs(x - wp[i]) < 1e-5) && e.qNum.every((x, j) => Math.abs(x - wq[j]) < 1e-5)
            );
            expect(hit, `missing p=${wp} q=${wq}`).toBe(true);
          }
        });
      }

      if (c.zeroSum && c.value !== null) {
        it("game value matches the LP oracle", () => {
          expect(r.value).toBeDefined();
          expect(fracToNumber(r.value!)).toBeCloseTo(c.value!, 7);
          for (const e of r.equilibria) expect(fracToNumber(e.payoffA)).toBeCloseTo(c.value!, 7);
        });
      }
    });
  }
});
