import { describe, expect, it } from "vitest";
import { solveGame } from "../solve";
import { validateGame, MAX_STRATEGIES } from "../common";
import { gameExamples } from "../examples";
import { GameInput } from "../../../types/game";
import { game, nashViolation, parseFrac, randomMatrix, rng, sortedKeys } from "./helpers";

const ex = (name: string) => gameExamples.find((e) => e.name === name)!.problem;

describe("input validation", () => {
  const ok: GameInput = ex("Battle of the Sexes");
  const errs = (patch: Partial<GameInput>) => validateGame({ ...ok, ...patch });

  it("accepts every built-in example", () => {
    for (const e of gameExamples) expect(validateGame(e.problem), e.name).toEqual([]);
  });
  it("needs at least one strategy per player", () => {
    expect(errs({ rowNames: [], payoffA: [], payoffB: [] })[0]).toContain("at least one strategy");
  });
  it(`caps each player at ${MAX_STRATEGIES} strategies`, () => {
    const names = Array.from({ length: MAX_STRATEGIES + 1 }, (_, i) => `s${i}`);
    const M = names.map(() => names.map(() => 0));
    expect(validateGame({ rowNames: names, colNames: names, payoffA: M, payoffB: M, zeroSum: false }).join(" ")).toContain(`at most ${MAX_STRATEGIES}`);
  });
  it("rejects blank and duplicate strategy names", () => {
    expect(errs({ rowNames: ["", "b"] }).join(" ")).toContain("needs a name");
    expect(errs({ colNames: ["x", "x "] }).join(" ")).toContain("must be distinct");
  });
  it("rejects ragged or wrongly sized payoff tables", () => {
    expect(errs({ payoffA: [[1, 2], [3]] }).join(" ")).toContain("2 × 2");
    expect(errs({ payoffB: [[1, 2]] }).join(" ")).toContain("2 × 2");
  });
  it("rejects blank (NaN), infinite, huge and scientific-notation payoffs", () => {
    expect(errs({ payoffA: [[NaN, 0], [0, 1]] }).join(" ")).toContain("must be a number");
    expect(errs({ payoffA: [[Infinity, 0], [0, 1]] }).join(" ")).toContain("must be a number");
    expect(errs({ payoffA: [[1e7, 0], [0, 1]] }).join(" ")).toContain("between");
    expect(errs({ payoffA: [[1e-7, 0], [0, 1]] }).join(" ")).toContain("scientific notation");
  });
  it("accepts six-decimal payoffs", () => {
    expect(errs({ payoffA: [[0.000001, 0], [0, 1]] })).toEqual([]);
  });
  it("zero-sum mode demands B = −A exactly", () => {
    expect(errs({ zeroSum: true }).join(" ")).toContain("negatives");
    expect(validateGame(ex("Matching Pennies"))).toEqual([]);
    expect(validateGame({ ...ex("Matching Pennies"), payoffB: [[-1, 1], [1, -1.0000001]] }).join(" ")).toContain("negatives");
  });
  it("solveGame reports the errors instead of solving", () => {
    const r = solveGame({ ...ok, rowNames: ["a", "a"] });
    expect(r.status).toBe("invalid");
    expect(r.steps).toEqual([]);
    expect(r.notes.join(" ")).toContain("distinct");
  });
});

describe("solveGame on the built-in examples", () => {
  it("every example solves, every step has a title and explanation, and every equilibrium passes an independent Nash check", () => {
    for (const e of gameExamples) {
      const r = solveGame(e.problem);
      expect(r.status, e.name).toBe("solved");
      expect(r.equilibria.length, e.name).toBeGreaterThan(0);
      for (const s of r.steps) {
        expect(s.title.length, `${e.name}: title`).toBeGreaterThan(0);
        expect(s.explanation.length, `${e.name}: explanation`).toBeGreaterThan(0);
      }
      for (const q of r.equilibria) expect(nashViolation(e.problem.payoffA, e.problem.payoffB, q.p, q.q), e.name).toBeNull();
    }
  });

  it("expected equilibrium counts: PD 1, MP 1, BoS 3, Stag Hunt 3, Chicken 3, RPS 1, IESDS 1, saddle 1, LP 1, coordination 7", () => {
    const counts: Record<string, number> = {
      "Prisoner's Dilemma": 1,
      "Matching Pennies": 1,
      "Battle of the Sexes": 3,
      "Saddle-point zero-sum game": 1,
      "Stag Hunt": 3,
      Chicken: 3,
      "Rock-Paper-Scissors": 1,
      "Solvable by iterated dominance": 1,
      "Zero-sum game needing the LP": 1,
      "Three-way coordination game": 7,
    };
    for (const [name, c] of Object.entries(counts)) expect(solveGame(ex(name)).equilibria, name).toHaveLength(c);
  });

  it("nondegenerate games have an odd number of equilibria (Wilson's theorem)", () => {
    for (const e of gameExamples) {
      const r = solveGame(e.problem);
      if (!r.degeneracy!.degenerate) expect(r.equilibria.length % 2, e.name).toBe(1);
    }
  });

  it("the degenerate example is flagged, keeps its two pure equilibria, and the notes explain the caveat", () => {
    const r = solveGame(ex("Indifferent row player (degenerate)"));
    expect(r.degeneracy!.degenerate).toBe(true);
    expect(sortedKeys(r.equilibria)).toEqual(["0,1|0,1", "1,0|1,0"]);
    expect(r.notes.join(" ")).toContain("Degenerate game");
    const overview = r.steps.find((s) => s.state.stepKind === "supports-overview")!;
    expect(overview.explanation).toContain("IS degenerate");
    // a genuinely missing equilibrium: p = (3/4, 1/4) against q = (1, 0) is one (Player 1 is indifferent, and Left is Player 2's best reply)
    expect(nashViolation(ex("Indifferent row player (degenerate)").payoffA, ex("Indifferent row player (degenerate)").payoffB, ["3/4", "1/4"], ["1", "0"])).toBeNull();
  });

  it("Prisoner's Dilemma and the iterated-dominance example say so in the dominance steps", () => {
    const pd = solveGame(ex("Prisoner's Dilemma"));
    expect(pd.steps.find((s) => s.state.stepKind === "dominant")!.explanation).toContain("unique equilibrium");
    const it = solveGame(ex("Solvable by iterated dominance"));
    expect(it.steps.filter((s) => s.state.stepKind === "dominance-round")).toHaveLength(4);
    expect(it.steps.find((s) => s.title.includes("round 4"))!.explanation).toContain("dominance-solvable");
    const rounds = it.steps.filter((s) => s.state.stepKind === "dominance-round");
    expect(rounds[3].state.eliminatedRows).toEqual([0, 2]);
    expect(rounds[3].state.eliminatedCols).toEqual([2, 0]);
  });
});

describe("step structure (the UI renders exactly what the solver computed)", () => {
  it("starts with setup, marks best responses in order, and only then reports pure equilibria", () => {
    const r = solveGame(ex("Battle of the Sexes"));
    expect(r.steps.slice(0, 4).map((s) => s.state.stepKind)).toEqual(["setup", "row-br", "col-br", "pure-equilibria"]);
    expect(r.steps[0].state.rowBR).toBeNull();
    expect(r.steps[1].state.rowBR).not.toBeNull();
    expect(r.steps[1].state.colBR).toBeNull();
    expect(r.steps[2].state.colBR).not.toBeNull();
    expect(r.steps[0].state.highlightCells).toEqual([]);
    expect(r.steps[3].state.highlightCells).toEqual([[0, 0], [1, 1]]);
  });

  it("ends with the support-size steps then the summary; equilibria accumulate as sizes are processed", () => {
    const r = solveGame(ex("Three-way coordination game"));
    const sizes = r.steps.filter((s) => s.state.stepKind === "supports-size");
    expect(sizes.map((s) => s.state.supports!.size)).toEqual([1, 2, 3]);
    expect(sizes.map((s) => s.state.equilibria.length)).toEqual([3, 6, 7]);
    expect(r.steps[r.steps.length - 1].state.stepKind).toBe("summary");
    expect(r.steps[r.steps.length - 1].state.equilibria).toHaveLength(7);
    expect(r.steps.find((s) => s.state.stepKind === "supports-overview")!.state.equilibria).toEqual([]);
  });

  it("the pure-equilibrium step agrees with the size-1 supports (two independent routes to the same set)", () => {
    for (const e of gameExamples) {
      const r = solveGame(e.problem);
      const viaBR = r.steps.find((s) => s.state.stepKind === "pure-equilibria")!.state.highlightCells.map(([i, j]) => `${i},${j}`).sort();
      const viaSupports = r.steps.find((s) => s.state.stepKind === "supports-size")!.state.equilibria.map((q) => `${q.supportRows[0]},${q.supportCols[0]}`).sort();
      expect(viaSupports, e.name).toEqual(viaBR);
    }
  });

  it("is deterministic: solving twice yields byte-identical JSON", () => {
    for (const e of gameExamples) expect(JSON.stringify(solveGame(e.problem))).toBe(JSON.stringify(solveGame(e.problem)));
  });

  it("the result survives JSON (no bigint, no Fraction objects left inside)", () => {
    const text = JSON.stringify(solveGame(ex("Zero-sum game needing the LP")));
    expect(text).not.toMatch(/"num"\s*:/);
    expect(text).not.toMatch(/"den"\s*:/);
  });
});

describe("edge cases", () => {
  it("1 × 1 game", () => {
    const r = solveGame(game([[3]], [[4]]));
    expect(r.status).toBe("solved");
    expect(r.equilibria).toHaveLength(1);
    expect(r.equilibria[0].payoffA).toBe("3");
    expect(r.equilibria[0].payoffB).toBe("4");
  });

  it("1 × n and m × 1 games: the lone player's opponent simply picks the best cell", () => {
    const wide = solveGame(game([[1, 2, 3]], [[5, 9, 4]]));
    expect(sortedKeys(wide.equilibria)).toEqual(["1|0,1,0"]);
    const tall = solveGame(game([[1], [7], [3]], [[0], [0], [0]]));
    expect(sortedKeys(tall.equilibria)).toEqual(["0,1,0|1"]);
  });

  it("all-zero game: every cell is an equilibrium, flagged degenerate", () => {
    const r = solveGame(game([[0, 0], [0, 0]], [[0, 0], [0, 0]]));
    expect(r.degeneracy!.degenerate).toBe(true);
    expect(r.equilibria.length).toBeGreaterThanOrEqual(4);
  });

  it("payoffs with decimals are solved exactly (no float residue in the answers)", () => {
    const r = solveGame(game([[0.5, 0], [0, 0.25]], [[0.25, 0], [0, 0.5]]));
    // BoS scaled by 1/4: same equilibria as Battle of the Sexes with payoffs (2,1)/(1,2) scaled by 1/4 → mixed (2/3,1/3) vs (1/3,2/3)
    expect(sortedKeys(r.equilibria)).toEqual(["0,1|0,1", "1,0|1,0", "2/3,1/3|1/3,2/3"]);
    expect(r.equilibria.find((e) => e.kind === "mixed")!.payoffA).toBe("1/6");
  });

  it("negative and mixed-sign payoffs work", () => {
    const r = solveGame(game([[-5, 3], [2, -7]], [[4, -1], [-6, 8]]));
    expect(r.status).toBe("solved");
    for (const q of r.equilibria) expect(nashViolation([[-5, 3], [2, -7]], [[4, -1], [-6, 8]], q.p, q.q)).toBeNull();
  });

  it("the largest allowed game (6 × 6) solves quickly", () => {
    const rand = rng(777);
    const A = randomMatrix(rand, 6, 6, -50, 50);
    const B = randomMatrix(rand, 6, 6, -50, 50);
    const t0 = Date.now();
    const r = solveGame(game(A, B));
    expect(r.status).toBe("solved");
    expect(Date.now() - t0).toBeLessThan(15000);
    expect(r.steps.find((s) => s.state.stepKind === "supports-overview")!.title).toContain("923 support pairs");
    for (const q of r.equilibria) expect(nashViolation(A, B, q.p, q.q)).toBeNull();
  });

  it("strategy names are trimmed and used in the explanations", () => {
    const g = ex("Battle of the Sexes");
    const r = solveGame({ ...g, rowNames: [" Opera ", "Football"] });
    expect(r.steps[0].explanation).toContain("Opera, Football");
  });
});

describe("invariances (150 random general-sum games)", () => {
  it("equilibrium strategies don't change when payoffs are shifted by a constant or scaled by a positive one", () => {
    const rand = rng(1618);
    let compared = 0;
    for (let t = 0; t < 150; t++) {
      const m = 2 + Math.floor(rand() * 3);
      const n = 2 + Math.floor(rand() * 3);
      const A = randomMatrix(rand, m, n, -9, 9);
      const B = randomMatrix(rand, m, n, -9, 9);
      const base = solveGame(game(A, B));
      const moved = solveGame(game(A.map((r) => r.map((x) => 3 * x + 11)), B.map((r) => r.map((x) => 2 * x - 5))));
      expect(base.degeneracy!.degenerate).toBe(moved.degeneracy!.degenerate);
      expect(sortedKeys(base.equilibria)).toEqual(sortedKeys(moved.equilibria));
      compared++;
      // and the payoffs transform accordingly
      base.equilibria.forEach((e) => {
        const twin = moved.equilibria.find((x) => x.p.join() === e.p.join() && x.q.join() === e.q.join())!;
        expect(parseFrac(twin.payoffA).equals(parseFrac(e.payoffA).mul(3).add(11))).toBe(true);
        expect(parseFrac(twin.payoffB).equals(parseFrac(e.payoffB).mul(2).sub(5))).toBe(true);
      });
    }
    expect(compared).toBe(150);
  });

  it("swapping the players (transposing the game) swaps the equilibria", () => {
    const rand = rng(90210);
    for (let t = 0; t < 60; t++) {
      const m = 2 + Math.floor(rand() * 3);
      const n = 2 + Math.floor(rand() * 3);
      const A = randomMatrix(rand, m, n, -9, 9);
      const B = randomMatrix(rand, m, n, -9, 9);
      const T = (M: number[][]) => M[0].map((_, j) => M.map((r) => r[j]));
      const a = solveGame(game(A, B));
      const b = solveGame(game(T(B), T(A)));
      if (a.degeneracy!.degenerate) continue;
      expect(sortedKeys(b.equilibria)).toEqual(sortedKeys(a.equilibria.map((e) => ({ p: e.q, q: e.p }))));
    }
  });

  it("reordering a player's strategies reorders the equilibria without changing them", () => {
    const rand = rng(42);
    for (let t = 0; t < 50; t++) {
      const A = randomMatrix(rand, 3, 3, -9, 9);
      const B = randomMatrix(rand, 3, 3, -9, 9);
      const perm = [2, 0, 1];
      const a = solveGame(game(A, B));
      const b = solveGame(game(perm.map((i) => A[i]), perm.map((i) => B[i])));
      if (a.degeneracy!.degenerate) continue;
      const mapped = a.equilibria.map((e) => ({ p: perm.map((i) => e.p[i]), q: e.q }));
      expect(sortedKeys(b.equilibria)).toEqual(sortedKeys(mapped));
    }
  });

  it("every reported equilibrium satisfies the Nash condition, and the count is odd whenever the game is nondegenerate", () => {
    const rand = rng(8675309);
    let nondeg = 0;
    for (let t = 0; t < 200; t++) {
      const m = 1 + Math.floor(rand() * 4);
      const n = 1 + Math.floor(rand() * 4);
      const A = randomMatrix(rand, m, n, -4, 4);
      const B = randomMatrix(rand, m, n, -4, 4);
      const r = solveGame(game(A, B));
      for (const e of r.equilibria) expect(nashViolation(A, B, e.p, e.q), JSON.stringify({ A, B, e })).toBeNull();
      if (!r.degeneracy!.degenerate) {
        nondeg++;
        expect(r.equilibria.length % 2, JSON.stringify({ A, B })).toBe(1);
      }
    }
    expect(nondeg).toBeGreaterThan(50);
  });
});
