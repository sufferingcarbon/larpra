import { describe, expect, it } from "vitest";
import { enumerateSupports } from "../supportEnumeration";
import { toFractionMatrix } from "../common";
import { gameExamples } from "../examples";
import { binomial } from "../common";
import { nashViolation, sortedKeys } from "./helpers";

const fm = toFractionMatrix;
const run = (name: string) => {
  const g = gameExamples.find((e) => e.name === name)!.problem;
  return { g, r: enumerateSupports(fm(g.payoffA), fm(g.payoffB), g.rowNames, g.colNames) };
};

describe("support enumeration — exact equilibria of the classic games", () => {
  it("Battle of the Sexes: (Opera,Opera), (Football,Football) and the mixed (2/3, 1/3) vs (1/3, 2/3)", () => {
    const { r } = run("Battle of the Sexes");
    expect(sortedKeys(r.equilibria)).toEqual(["0,1|0,1", "1,0|1,0", "2/3,1/3|1/3,2/3"]);
    const mixed = r.equilibria.find((e) => e.kind === "mixed")!;
    expect(mixed.payoffA).toBe("2/3");
    expect(mixed.payoffB).toBe("2/3");
    expect(mixed.supportRows).toEqual([0, 1]);
  });

  it("Matching Pennies: the only equilibrium is 1/2 – 1/2 with value 0", () => {
    const { r } = run("Matching Pennies");
    expect(sortedKeys(r.equilibria)).toEqual(["1/2,1/2|1/2,1/2"]);
    expect(r.equilibria[0].payoffA).toBe("0");
  });

  it("Rock-Paper-Scissors: the only equilibrium is 1/3 each", () => {
    const { r } = run("Rock-Paper-Scissors");
    expect(sortedKeys(r.equilibria)).toEqual(["1/3,1/3,1/3|1/3,1/3,1/3"]);
  });

  it("Prisoner's Dilemma: only (Defect, Defect) — and no mixed equilibrium", () => {
    const { r } = run("Prisoner's Dilemma");
    expect(sortedKeys(r.equilibria)).toEqual(["0,1|0,1"]);
    expect(r.equilibria[0].kind).toBe("pure");
    expect(r.equilibria[0].payoffA).toBe("-2");
  });

  it("Stag Hunt: two pure equilibria plus the mixed one at 3/4 Stag", () => {
    const { r } = run("Stag Hunt");
    expect(sortedKeys(r.equilibria)).toEqual(["0,1|0,1", "1,0|1,0", "3/4,1/4|3/4,1/4"]);
    expect(r.equilibria.find((e) => e.kind === "mixed")!.payoffA).toBe("3");
  });

  it("Chicken: (Swerve, Straight), (Straight, Swerve) and the mixed 9/10 – 1/10", () => {
    const { r } = run("Chicken");
    expect(sortedKeys(r.equilibria)).toEqual(["0,1|1,0", "1,0|0,1", "9/10,1/10|9/10,1/10"]);
    expect(r.equilibria.find((e) => e.kind === "mixed")!.payoffA).toBe("-1/10");
  });

  it("three-way coordination: 7 equilibria, mixed ones with probabilities proportional to 1/d", () => {
    const { r } = run("Three-way coordination game");
    expect(r.equilibria).toHaveLength(7);
    expect(sortedKeys(r.equilibria)).toContain("2/11,3/11,6/11|2/11,3/11,6/11");
    expect(sortedKeys(r.equilibria)).toContain("2/5,3/5,0|2/5,3/5,0");
    expect(r.equilibria.find((e) => e.p.join() === "2/11,3/11,6/11")!.payoffA).toBe("6/11");
  });
});

describe("support enumeration — bookkeeping", () => {
  it("tries exactly C(m+n, m) − 1 support pairs, split by size as Σ C(m,k)·C(n,k)", () => {
    const { r, g } = run("Zero-sum game needing the LP"); // 3 × 4
    expect(r.pairsTotal).toBe(binomial(7, 3) - 1);
    expect(r.bySize.map((s) => s.info.attempts.length)).toEqual([12, 18, 4]);
    expect(r.bySize.map((s) => s.info.pairsThisSize)).toEqual([12, 18, 4]);
    expect(r.bySize.reduce((s, x) => s + x.info.attempts.length, 0)).toBe(r.pairsTotal);
    expect(g.rowNames).toHaveLength(3);
  });

  it("tallies every attempt by outcome; the tally always adds up", () => {
    for (const ex of gameExamples) {
      const r = enumerateSupports(fm(ex.problem.payoffA), fm(ex.problem.payoffB), ex.problem.rowNames, ex.problem.colNames);
      for (const level of r.bySize) {
        const total = Object.values(level.info.tally).reduce((s, x) => s + (x ?? 0), 0);
        expect(total, ex.name).toBe(level.info.attempts.length);
        expect(level.info.tally.equilibrium ?? 0, ex.name).toBe(level.equilibria.length);
      }
    }
  });

  it("Matching Pennies, size 1: every pure profile is rejected — two by Player 1's deviation, two by Player 2's", () => {
    const { r } = run("Matching Pennies");
    expect(r.bySize[0].info.tally).toEqual({ "row-deviation": 2, "col-deviation": 2 });
    expect(r.bySize[1].info.tally).toEqual({ equilibrium: 1 });
  });

  it("Battle of the Sexes, size 1: the two off-diagonal cells are rejected because Player 1 would switch", () => {
    const { r } = run("Battle of the Sexes");
    expect(r.bySize[0].info.tally).toEqual({ equilibrium: 2, "row-deviation": 2 });
  });

  it("writes the indifference equations it solved, with signs folded into the operators", () => {
    const { r } = run("Matching Pennies");
    const eq = r.bySize[1].info.attempts[0];
    expect(eq.outcome).toBe("equilibrium");
    expect(eq.equations).toEqual([
      "Heads: 1·q(Heads) − 1·q(Tails) = u",
      "Tails: −1·q(Heads) + 1·q(Tails) = u",
      "q(Heads) + q(Tails) = 1",
      "Heads: −1·p(Heads) + 1·p(Tails) = v",
      "Tails: 1·p(Heads) − 1·p(Tails) = v",
      "p(Heads) + p(Tails) = 1",
    ]);
    const bos = run("Battle of the Sexes").r.bySize[1].info.attempts[0];
    expect(bos.equations[0]).toBe("Opera: 2·q(Opera) + 0·q(Football) = u");
    expect(bos.equations[3]).toBe("Opera: 1·p(Opera) + 0·p(Football) = v");
  });

  it("explains a rejection with the numbers involved", () => {
    const { r } = run("Battle of the Sexes");
    const rejected = r.bySize[0].info.attempts.find((a) => a.outcome === "row-deviation")!;
    expect(rejected.detail).toContain("would pay Player 1");
    expect(rejected.detail).toMatch(/> /);
  });

  it("flags 'non-positive probability' when the indifference solution leaves the simplex", () => {
    // Row a strictly dominates row b, so no positive q can make them indifferent: 3q1 + q2 = q1 → q = (−1, 2)
    const A = [[3, 1], [1, 0]];
    const B = [[0, 1], [1, 0]];
    const r = enumerateSupports(fm(A), fm(B), ["a", "b"], ["c", "d"]);
    const outcomes = r.bySize[1].info.attempts.map((x) => x.outcome);
    expect(outcomes).toEqual(["nonpositive-q"]);
    expect(r.bySize[1].info.attempts[0].detail).toContain("(-1, 2)");
    expect(r.bySize[1].info.attempts[0].detail).toContain("not every probability is positive");
  });

  it("reports contradictory and underdetermined indifference equations by name", () => {
    // identical rows in A with different values -> contradiction; identical rows with equal values -> many
    const contradictory = enumerateSupports(fm([[1, 1], [2, 2]]), fm([[0, 0], [0, 0]]), ["a", "b"], ["c", "d"]);
    expect(contradictory.bySize[1].info.attempts[0].outcome).toBe("no-solution-q");
    const many = enumerateSupports(fm([[2, 2], [2, 2]]), fm([[1, 0], [0, 1]]), ["a", "b"], ["c", "d"]);
    expect(many.bySize[1].info.attempts[0].outcome).toBe("non-unique-q");
  });

  it("is deterministic: the same game gives identical attempts in the same order", () => {
    const a = run("Three-way coordination game").r;
    const b = run("Three-way coordination game").r;
    expect(JSON.stringify(a)).toBe(JSON.stringify(b));
  });

  it("every equilibrium it reports satisfies the Nash condition (independent check)", () => {
    for (const ex of gameExamples) {
      const r = enumerateSupports(fm(ex.problem.payoffA), fm(ex.problem.payoffB), ex.problem.rowNames, ex.problem.colNames);
      for (const e of r.equilibria) expect(nashViolation(ex.problem.payoffA, ex.problem.payoffB, e.p, e.q), ex.name).toBeNull();
    }
  });
});
