import { describe, expect, it } from "vitest";
import { colBestResponses, pureEquilibria, rowBestResponses } from "../bestResponse";
import { toFractionMatrix } from "../common";

const fm = toFractionMatrix;

describe("best responses and pure equilibria", () => {
  it("Prisoner's Dilemma: Defect is the best response everywhere; (Defect, Defect) is the only pure equilibrium", () => {
    const A = fm([[-1, -3], [0, -2]]);
    const B = fm([[-1, 0], [-3, -2]]);
    expect(rowBestResponses(A)).toEqual([[false, false], [true, true]]);
    expect(colBestResponses(B)).toEqual([[false, true], [false, true]]);
    expect(pureEquilibria(rowBestResponses(A), colBestResponses(B))).toEqual([[1, 1]]);
  });

  it("Battle of the Sexes: the two coordination cells, and nothing else", () => {
    const A = fm([[2, 0], [0, 1]]);
    const B = fm([[1, 0], [0, 2]]);
    expect(pureEquilibria(rowBestResponses(A), colBestResponses(B))).toEqual([[0, 0], [1, 1]]);
  });

  it("Matching Pennies has no pure equilibrium", () => {
    const A = fm([[1, -1], [-1, 1]]);
    const B = fm([[-1, 1], [1, -1]]);
    expect(pureEquilibria(rowBestResponses(A), colBestResponses(B))).toEqual([]);
  });

  it("ties mark every maximizer", () => {
    const A = fm([[2, 2], [2, 2]]);
    expect(rowBestResponses(A)).toEqual([[true, true], [true, true]]);
    const B = fm([[1, 1, 0]]);
    expect(colBestResponses(B)).toEqual([[true, true, false]]);
  });

  it("decimal payoffs are compared exactly: 0.3 ties with 0.3, and 0.3 loses to 0.31", () => {
    const A = fm([[0.3, 0.31], [0.3, 0.1]]);
    expect(rowBestResponses(A)).toEqual([[true, true], [true, false]]);
    const tiny = fm([[0.000001, 0.000002]]);
    expect(colBestResponses(tiny)).toEqual([[false, true]]);
  });

  it("a 1 × n game: Player 2 picks the best column, Player 1 has one strategy", () => {
    const A = fm([[1, 5, 2]]);
    const B = fm([[3, 9, 9]]);
    expect(pureEquilibria(rowBestResponses(A), colBestResponses(B))).toEqual([[0, 1], [0, 2]]);
  });
});
