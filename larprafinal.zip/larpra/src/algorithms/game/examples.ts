import { GameInput } from "../../types/game";

export interface GameExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: GameInput;
}

/** Zero-sum helper: only Player 1's payoffs are written; Player 2's are their exact negatives (0 − x, so no −0). */
const zeroSum = (rowNames: string[], colNames: string[], A: number[][]): GameInput => ({
  rowNames,
  colNames,
  payoffA: A,
  payoffB: A.map((row) => row.map((x) => 0 - x)),
  zeroSum: true,
});

export const gameExamples: GameExample[] = [
  {
    name: "Prisoner's Dilemma",
    difficulty: "beginner",
    description: "Two suspects each choose to Cooperate (stay silent) or Defect. Payoffs are negative years in prison. Defect is strictly dominant for both — the unique equilibrium is mutual defection, even though mutual cooperation is better for both.",
    problem: {
      rowNames: ["Cooperate", "Defect"],
      colNames: ["Cooperate", "Defect"],
      payoffA: [
        [-1, -3],
        [0, -2],
      ],
      payoffB: [
        [-1, 0],
        [-3, -2],
      ],
      zeroSum: false,
    },
  },
  {
    name: "Matching Pennies",
    difficulty: "beginner",
    description: "Player 1 wins if the two coins match, Player 2 wins if they differ. No pure equilibrium exists; the only equilibrium has both players mixing 50/50, and the value is 0.",
    problem: zeroSum(["Heads", "Tails"], ["Heads", "Tails"], [
      [1, -1],
      [-1, 1],
    ]),
  },
  {
    name: "Battle of the Sexes",
    difficulty: "beginner",
    description: "A couple wants to go out together but prefers different events (Opera for Player 1, Football for Player 2). Two pure coordination equilibria plus a mixed one — three equilibria in all.",
    problem: {
      rowNames: ["Opera", "Football"],
      colNames: ["Opera", "Football"],
      payoffA: [
        [2, 0],
        [0, 1],
      ],
      payoffB: [
        [1, 0],
        [0, 2],
      ],
      zeroSum: false,
    },
  },
  {
    name: "Saddle-point zero-sum game",
    difficulty: "beginner",
    description: "A 3 × 3 zero-sum game whose maximin equals its minimax (both 3): the cell (C, Z) is a pure saddle point, and the LP confirms the same value and strategies.",
    problem: zeroSum(["A", "B", "C"], ["X", "Y", "Z"], [
      [6, 2, 1],
      [7, 0, 1],
      [4, 4, 3],
    ]),
  },
  {
    name: "Stag Hunt",
    difficulty: "intermediate",
    description: "Hunters can go for a Stag (needs both) or a Hare (safe). Two pure equilibria — one payoff-dominant, one risk-dominant — plus a mixed equilibrium at 3/4 Stag.",
    problem: {
      rowNames: ["Stag", "Hare"],
      colNames: ["Stag", "Hare"],
      payoffA: [
        [4, 0],
        [3, 3],
      ],
      payoffB: [
        [4, 3],
        [0, 3],
      ],
      zeroSum: false,
    },
  },
  {
    name: "Chicken",
    difficulty: "intermediate",
    description: "Two drivers head for each other; whoever swerves 'loses', but two Straights crash. Two pure equilibria (one swerves) and a mixed one in which each swerves with probability 9/10.",
    problem: {
      rowNames: ["Swerve", "Straight"],
      colNames: ["Swerve", "Straight"],
      payoffA: [
        [0, -1],
        [1, -10],
      ],
      payoffB: [
        [0, 1],
        [-1, -10],
      ],
      zeroSum: false,
    },
  },
  {
    name: "Rock-Paper-Scissors",
    difficulty: "intermediate",
    description: "The classic 3 × 3 zero-sum cycle. No pure equilibrium; the unique equilibrium mixes 1/3 each, with value 0.",
    problem: zeroSum(["Rock", "Paper", "Scissors"], ["Rock", "Paper", "Scissors"], [
      [0, -1, 1],
      [1, 0, -1],
      [-1, 1, 0],
    ]),
  },
  {
    name: "Solvable by iterated dominance",
    difficulty: "intermediate",
    description: "A 3 × 3 game in which deleting strictly dominated strategies four times in a row (Right, Top, Left, Bottom) leaves the single cell (Middle, Center) — found without solving any equation.",
    problem: {
      rowNames: ["Top", "Middle", "Bottom"],
      colNames: ["Left", "Center", "Right"],
      payoffA: [
        [1, 2, 9],
        [2, 4, 0],
        [5, 3, 1],
      ],
      payoffB: [
        [4, 3, 2],
        [2, 4, 1],
        [1, 5, 0],
      ],
      zeroSum: false,
    },
  },
  {
    name: "Zero-sum game needing the LP",
    difficulty: "difficult",
    description: "A 3 × 4 zero-sum game with no saddle point (value 8/17). The optimal mixed strategies come from the pair of dual linear programs, solved with the exact simplex engine.",
    problem: zeroSum(["R1", "R2", "R3"], ["C1", "C2", "C3", "C4"], [
      [4, 0, 0, -2],
      [-1, 6, -2, 6],
      [-1, 0, 1, 4],
    ]),
  },
  {
    name: "Three-way coordination game",
    difficulty: "difficult",
    description: "Both players win only by choosing the same option, with different rewards. Every non-empty subset of options supports an equilibrium: 7 equilibria in all — 3 pure, 3 mixing two options, 1 mixing all three.",
    problem: {
      rowNames: ["Red", "Green", "Blue"],
      colNames: ["Red", "Green", "Blue"],
      payoffA: [
        [3, 0, 0],
        [0, 2, 0],
        [0, 0, 1],
      ],
      payoffB: [
        [3, 0, 0],
        [0, 2, 0],
        [0, 0, 1],
      ],
      zeroSum: false,
    },
  },
  {
    name: "Indifferent row player (degenerate)",
    difficulty: "difficult",
    description: "Player 1 earns 2 whatever anyone does, so any mix is a best response for them — a degenerate game with a continuum of equilibria. larpra detects this, finds the equilibria it can, and says exactly why the list may be incomplete.",
    problem: {
      rowNames: ["Up", "Down"],
      colNames: ["Left", "Right"],
      payoffA: [
        [2, 2],
        [2, 2],
      ],
      payoffB: [
        [1, 0],
        [0, 1],
      ],
      zeroSum: false,
    },
  },
];
