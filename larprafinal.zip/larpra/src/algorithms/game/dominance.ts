import { DominanceElimination } from "../../types/game";
import { FMatrix } from "./common";

/**
 * Strict dominance between *pure* strategies. Row k strictly dominates row i (over the columns still in play)
 * when k pays strictly more than i against every one of them; a strictly dominated strategy is never part of
 * any Nash equilibrium, pure or mixed, so removing it changes nothing about the equilibria — and removal is
 * order-independent, which is why "iterated elimination" has one well-defined answer.
 *
 * (Domination by a *mixture* of other strategies is not checked here; it can only make the game look larger
 * than necessary — the equilibrium search always runs on the full game, so no equilibrium is ever missed.)
 */

const rowDominates = (A: FMatrix, k: number, i: number, cols: number[]) => cols.every((j) => A[k][j].gt(A[i][j]));
const colDominates = (B: FMatrix, l: number, j: number, rows: number[]) => rows.every((i) => B[i][l].gt(B[i][j]));

const rowWeaklyDominates = (A: FMatrix, k: number, i: number) => {
  let strictSomewhere = false;
  for (let j = 0; j < A[0].length; j++) {
    if (A[k][j].lt(A[i][j])) return false;
    if (A[k][j].gt(A[i][j])) strictSomewhere = true;
  }
  return strictSomewhere;
};
const colWeaklyDominates = (B: FMatrix, l: number, j: number) => {
  let strictSomewhere = false;
  for (let i = 0; i < B.length; i++) {
    if (B[i][l].lt(B[i][j])) return false;
    if (B[i][l].gt(B[i][j])) strictSomewhere = true;
  }
  return strictSomewhere;
};

export interface DominantStrategy {
  index: number;
  kind: "strict" | "weak";
}

/** A strategy that dominates every other strategy of the same player (in the full game). null if there is none. */
export function findDominantRow(A: FMatrix): DominantStrategy | null {
  const m = A.length;
  const n = A[0].length;
  if (m < 2) return null;
  const all = Array.from({ length: n }, (_, j) => j);
  for (const kind of ["strict", "weak"] as const) {
    for (let i = 0; i < m; i++) {
      const others = Array.from({ length: m }, (_, k) => k).filter((k) => k !== i);
      const ok = others.every((k) => (kind === "strict" ? rowDominates(A, i, k, all) : rowWeaklyDominates(A, i, k)));
      if (ok) return { index: i, kind };
    }
  }
  return null;
}

export function findDominantCol(B: FMatrix): DominantStrategy | null {
  const m = B.length;
  const n = B[0].length;
  if (n < 2) return null;
  const all = Array.from({ length: m }, (_, i) => i);
  for (const kind of ["strict", "weak"] as const) {
    for (let j = 0; j < n; j++) {
      const others = Array.from({ length: n }, (_, l) => l).filter((l) => l !== j);
      const ok = others.every((l) => (kind === "strict" ? colDominates(B, j, l, all) : colWeaklyDominates(B, j, l)));
      if (ok) return { index: j, kind };
    }
  }
  return null;
}

export interface DominanceRound {
  round: number;
  eliminations: DominanceElimination[];
  /** Strategies still in play after this round. */
  remainingRows: number[];
  remainingCols: number[];
}

/**
 * Iterated elimination of strictly dominated strategies. Each round removes, simultaneously, every strategy that
 * is strictly dominated *within the game left by the previous round*, and records a dominator that is itself not
 * being removed that round (one always exists, since strict dominance is transitive and the game is finite).
 */
export function iteratedElimination(A: FMatrix, B: FMatrix): { rounds: DominanceRound[]; rows: number[]; cols: number[] } {
  let rows = Array.from({ length: A.length }, (_, i) => i);
  let cols = Array.from({ length: A[0].length }, (_, j) => j);
  const rounds: DominanceRound[] = [];

  for (;;) {
    const domRows = rows.filter((i) => rows.some((k) => k !== i && rowDominates(A, k, i, cols)));
    const domCols = cols.filter((j) => cols.some((l) => l !== j && colDominates(B, l, j, rows)));
    if (domRows.length === 0 && domCols.length === 0) break;

    const eliminations: DominanceElimination[] = [];
    for (const i of domRows) {
      const dominators = rows.filter((k) => k !== i && rowDominates(A, k, i, cols));
      eliminations.push({ player: 1, index: i, by: dominators.find((k) => !domRows.includes(k)) ?? dominators[0] });
    }
    for (const j of domCols) {
      const dominators = cols.filter((l) => l !== j && colDominates(B, l, j, rows));
      eliminations.push({ player: 2, index: j, by: dominators.find((l) => !domCols.includes(l)) ?? dominators[0] });
    }
    rows = rows.filter((i) => !domRows.includes(i));
    cols = cols.filter((j) => !domCols.includes(j));
    rounds.push({ round: rounds.length + 1, eliminations, remainingRows: rows, remainingCols: cols });
  }
  return { rounds, rows, cols };
}
