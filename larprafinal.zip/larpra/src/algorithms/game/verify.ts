import { Fraction } from "../../utils/fraction";
import { colPayoffs, FMatrix, maxOf, rowPayoffs } from "./common";

/**
 * Direct check of the Nash condition: every strategy played with positive probability must be a best response
 * to the opponent's mix. Used by the solver as a last safeguard on the zero-sum LP output.
 */
export function isNashEquilibrium(A: FMatrix, B: FMatrix, p: Fraction[], q: Fraction[]): boolean {
  if (!p.reduce((s, x) => s.add(x), Fraction.ZERO).equals(1) || !q.reduce((s, x) => s.add(x), Fraction.ZERO).equals(1)) return false;
  if (p.some((x) => x.isNegative()) || q.some((x) => x.isNegative())) return false;
  const rv = rowPayoffs(A, q);
  const cv = colPayoffs(B, p);
  const rbest = maxOf(rv);
  const cbest = maxOf(cv);
  return p.every((x, i) => x.isZero() || rv[i].equals(rbest)) && q.every((x, j) => x.isZero() || cv[j].equals(cbest));
}
