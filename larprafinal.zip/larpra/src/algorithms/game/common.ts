import { GameInput } from "../../types/game";
import { Fraction, frac } from "../../utils/fraction";

/** Support enumeration tries C(m+n, m) − 1 support pairs, so the size is capped to keep every solution small and printable. */
export const MAX_STRATEGIES = 6;
/** Payoffs must be exact decimals of moderate size (the exact-arithmetic layer parses the printed decimal). */
export const MAX_ABS_PAYOFF = 1e6;

export type FMatrix = Fraction[][];

export function validateGame(input: GameInput): string[] {
  const errors: string[] = [];
  const m = input.rowNames.length;
  const n = input.colNames.length;

  if (m < 1 || n < 1) {
    errors.push("Each player needs at least one strategy.");
    return errors;
  }
  if (m > MAX_STRATEGIES || n > MAX_STRATEGIES) {
    errors.push(`Each player can have at most ${MAX_STRATEGIES} strategies.`);
  }
  const checkNames = (names: string[], who: string) => {
    if (names.some((s) => s.trim() === "")) errors.push(`Every ${who} strategy needs a name.`);
    else if (new Set(names.map((s) => s.trim())).size !== names.length) errors.push(`${who} strategy names must be distinct.`);
  };
  checkNames(input.rowNames, "Player 1's");
  checkNames(input.colNames, "Player 2's");

  const shapeOk = (M: number[][]) => M.length === m && M.every((row) => row.length === n);
  if (!shapeOk(input.payoffA) || !shapeOk(input.payoffB)) {
    errors.push(`The payoff tables must be ${m} × ${n} (one entry per row/column pair).`);
    return errors;
  }

  let bad = false;
  let tooBig = false;
  let tooFine = false;
  for (const M of [input.payoffA, input.payoffB]) {
    for (const row of M) {
      for (const x of row) {
        if (!Number.isFinite(x)) bad = true;
        else if (Math.abs(x) > MAX_ABS_PAYOFF) tooBig = true;
        else if (String(x).includes("e")) tooFine = true;
      }
    }
  }
  if (bad) errors.push("Every payoff must be a number (no blank cells).");
  if (tooBig) errors.push(`Payoffs must be between −${MAX_ABS_PAYOFF.toLocaleString("en-US")} and ${MAX_ABS_PAYOFF.toLocaleString("en-US")}.`);
  if (tooFine) errors.push("Payoffs must be ordinary decimals (at most 6 decimal places, no scientific notation).");
  if (bad || tooBig || tooFine) return errors;

  if (input.zeroSum) {
    const mismatch = input.payoffA.some((row, i) => row.some((a, j) => !frac(a).add(frac(input.payoffB[i][j])).isZero()));
    if (mismatch) errors.push("A zero-sum game needs Player 2's payoffs to be exactly the negatives of Player 1's.");
  }
  return errors;
}

export function toFractionMatrix(M: number[][]): FMatrix {
  return M.map((row) => row.map((x) => frac(x)));
}

/** All k-element subsets of {0..n−1}, in lexicographic order. */
export function combinations(n: number, k: number): number[][] {
  const out: number[][] = [];
  const cur: number[] = [];
  const rec = (start: number) => {
    if (cur.length === k) {
      out.push([...cur]);
      return;
    }
    for (let i = start; i <= n - (k - cur.length); i++) {
      cur.push(i);
      rec(i + 1);
      cur.pop();
    }
  };
  rec(0);
  return out;
}

export function binomial(n: number, k: number): number {
  if (k < 0 || k > n) return 0;
  let r = 1;
  for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i;
  return Math.round(r);
}

/** Exact text: "3", "-1/3". Never rounded — probabilities are always shown in full. */
export function exact(f: Fraction): string {
  return f.den === 1n ? f.num.toString() : `${f.num}/${f.den}`;
}

export function exactList(v: Fraction[]): string {
  return `(${v.map(exact).join(", ")})`;
}

/** Player 1's expected payoff x·A·y (and Player 2's with B). */
export function expectedPayoff(M: FMatrix, p: Fraction[], q: Fraction[]): Fraction {
  let s = Fraction.ZERO;
  for (let i = 0; i < p.length; i++) {
    if (p[i].isZero()) continue;
    for (let j = 0; j < q.length; j++) {
      if (!q[j].isZero()) s = s.add(p[i].mul(M[i][j]).mul(q[j]));
    }
  }
  return s;
}

/** Row i's expected payoff against the mixed strategy q. */
export function rowPayoffs(A: FMatrix, q: Fraction[]): Fraction[] {
  return A.map((row) => row.reduce((s, a, j) => (q[j].isZero() ? s : s.add(a.mul(q[j]))), Fraction.ZERO));
}

/** Column j's expected payoff (to Player 2) against the mixed strategy p. */
export function colPayoffs(B: FMatrix, p: Fraction[]): Fraction[] {
  const n = B[0].length;
  const out: Fraction[] = [];
  for (let j = 0; j < n; j++) {
    let s = Fraction.ZERO;
    for (let i = 0; i < B.length; i++) if (!p[i].isZero()) s = s.add(p[i].mul(B[i][j]));
    out.push(s);
  }
  return out;
}

export function maxOf(v: Fraction[]): Fraction {
  return v.reduce((best, x) => (x.gt(best) ? x : best));
}
export function minOf(v: Fraction[]): Fraction {
  return v.reduce((best, x) => (x.lt(best) ? x : best));
}

/** Plain decimal for drawing only (never used in any decision). */
export function toNum(f: Fraction): number {
  return f.toNumber();
}

export function unitVector(n: number, i: number): Fraction[] {
  return Array.from({ length: n }, (_, k) => (k === i ? Fraction.ONE : Fraction.ZERO));
}

export const names = (all: string[], idx: number[]) => idx.map((i) => all[i]).join(", ");
