import { FMatrix, maxOf } from "./common";

/**
 * Pure best responses. rowBR[i][j] is true when row i maximizes Player 1's payoff *in column j*;
 * colBR[i][j] is true when column j maximizes Player 2's payoff *in row i*. Ties mark every maximizer.
 * A cell marked by both is a pure-strategy Nash equilibrium: neither player can gain by deviating alone.
 */
export function rowBestResponses(A: FMatrix): boolean[][] {
  const m = A.length;
  const n = A[0].length;
  const out = Array.from({ length: m }, () => new Array<boolean>(n).fill(false));
  for (let j = 0; j < n; j++) {
    const best = maxOf(A.map((row) => row[j]));
    for (let i = 0; i < m; i++) out[i][j] = A[i][j].equals(best);
  }
  return out;
}

export function colBestResponses(B: FMatrix): boolean[][] {
  const m = B.length;
  const n = B[0].length;
  const out = Array.from({ length: m }, () => new Array<boolean>(n).fill(false));
  for (let i = 0; i < m; i++) {
    const best = maxOf(B[i]);
    for (let j = 0; j < n; j++) out[i][j] = B[i][j].equals(best);
  }
  return out;
}

export function pureEquilibria(rowBR: boolean[][], colBR: boolean[][]): [number, number][] {
  const cells: [number, number][] = [];
  rowBR.forEach((row, i) => row.forEach((r, j) => r && colBR[i][j] && cells.push([i, j])));
  return cells;
}
