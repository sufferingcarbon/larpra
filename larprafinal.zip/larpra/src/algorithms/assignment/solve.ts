import { AlgorithmStep } from "../../types/lp";
import { AssignmentProblemInput, AssignmentResult, AssignmentTableauState } from "../../types/assignment";
import { padToSquare, validateProblem } from "./standardize";
import { AssignmentTableau } from "./tableau";
import { balanceStep } from "./common";
import { rowReductionStep, colReductionStep, runHungarianMatching } from "./hungarian";

export function solveAssignment(problem: AssignmentProblemInput): AssignmentResult {
  const errors = validateProblem(problem);
  if (errors.length > 0) {
    return {
      status: "invalid",
      steps: [],
      notes: errors,
      workerNames: problem.workerNames,
      taskNames: problem.taskNames,
    };
  }

  const padded = padToSquare(problem);
  const tab = new AssignmentTableau(padded);
  const steps: AlgorithmStep<AssignmentTableauState>[] = [balanceStep(tab, padded)];

  steps.push(rowReductionStep(tab));
  steps.push(colReductionStep(tab));

  const { steps: matchSteps, matching } = runHungarianMatching(tab);
  steps.push(...matchSteps);

  const origM = problem.workerNames.length;
  const origN = problem.taskNames.length;

  const assignment: Record<string, string> = {};
  const unassignedWorkers: string[] = [];
  const unassignedTasks: string[] = [];
  const assignedTaskIdx = new Set<number>();

  for (let i = 0; i < origM; i++) {
    const j = matching[i];
    if (j !== null && j < origN) {
      assignment[problem.workerNames[i]] = problem.taskNames[j];
      assignedTaskIdx.add(j);
    } else {
      unassignedWorkers.push(problem.workerNames[i]);
    }
  }
  for (let j = 0; j < origN; j++) {
    if (!assignedTaskIdx.has(j)) unassignedTasks.push(problem.taskNames[j]);
  }

  const notes: string[] = [];
  if (unassignedWorkers.length > 0) {
    notes.push(
      `${unassignedWorkers.join(", ")} ${unassignedWorkers.length === 1 ? "is" : "are"} matched to a dummy task and ${unassignedWorkers.length === 1 ? "gets" : "get"} no real assignment (more workers than tasks).`
    );
  }
  if (unassignedTasks.length > 0) {
    notes.push(
      `${unassignedTasks.join(", ")} ${unassignedTasks.length === 1 ? "is" : "are"} left unassigned — matched only to a dummy worker (more tasks than workers).`
    );
  }

  let totalCost = 0;
  for (const [worker, task] of Object.entries(assignment)) {
    const i = problem.workerNames.indexOf(worker);
    const j = problem.taskNames.indexOf(task);
    totalCost += problem.costs[i][j];
  }

  return {
    status: "optimal",
    steps,
    totalCost,
    assignment,
    notes,
    workerNames: problem.workerNames,
    taskNames: problem.taskNames,
  };
}
