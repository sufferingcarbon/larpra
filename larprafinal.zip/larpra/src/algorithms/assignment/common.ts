import { AlgorithmStep } from "../../types/lp";
import { AssignmentTableauState } from "../../types/assignment";
import { PaddedProblem } from "./standardize";
import { AssignmentTableau } from "./tableau";

/** Emits the square-check step shared by every run, whether or not padding was needed. */
export function balanceStep(
  tab: AssignmentTableau,
  padded: PaddedProblem
): AlgorithmStep<AssignmentTableauState> {
  const emptyMatching = new Array(tab.n).fill(null);

  if (!padded.dummy) {
    return {
      title: "Square check",
      explanation: `There are ${tab.workerNames.length} workers and ${tab.taskNames.length} tasks — the cost matrix is already square, so the Hungarian algorithm can proceed directly.`,
      state: tab.snapshot({ stepKind: "balance-check", phase: "balance", matching: emptyMatching }),
    };
  }

  const { type, names } = padded.dummy;
  const explanation =
    type === "task"
      ? `There are more workers (${tab.workerNames.length - names.length}) than tasks (${tab.taskNames.length - names.length}), so ${names.length === 1 ? "a dummy task" : `${names.length} dummy tasks`} (${names.join(", ")}) ${names.length === 1 ? "is" : "are"} added with zero cost for every worker. Any worker matched to a dummy task in the final solution simply gets no real assignment.`
      : `There are more tasks (${tab.taskNames.length - names.length}) than workers (${tab.workerNames.length - names.length}), so ${names.length === 1 ? "a dummy worker" : `${names.length} dummy workers`} (${names.join(", ")}) ${names.length === 1 ? "is" : "are"} added with zero cost for every task. Any task matched to a dummy worker in the final solution simply goes unassigned.`;

  return {
    title: `Square check — ${names.length === 1 ? "dummy" : `${names.length} dummies`} added`,
    explanation,
    state: tab.snapshot({
      stepKind: "balance-check",
      phase: "balance",
      matching: emptyMatching,
      dummyNote: `${names.join(", ")}: zero cost, added to square up the matrix.`,
    }),
    why: "The Hungarian algorithm's row/column reduction and zero-covering steps are only defined for a square matrix. A zero-cost dummy row or column is the standard fix — it can absorb one worker or task without affecting the true minimum cost of the real assignments.",
  };
}
