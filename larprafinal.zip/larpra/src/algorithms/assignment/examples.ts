import { AssignmentProblemInput } from "../../types/assignment";

export interface AssignmentExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: AssignmentProblemInput;
}

export const assignmentExamples: AssignmentExample[] = [
  {
    name: "Classic 4×4 (balanced)",
    difficulty: "intermediate",
    description:
      "A textbook square assignment (four workers, four machines) — reduces cleanly and needs only one covering pass before a perfect zero-cost matching appears. Optimum: 41.",
    problem: {
      workerNames: ["A", "B", "C", "D"],
      taskNames: ["Job 1", "Job 2", "Job 3", "Job 4"],
      costs: [
        [8, 26, 17, 11],
        [13, 28, 4, 26],
        [38, 19, 18, 15],
        [19, 26, 24, 10],
      ],
    },
  },
  {
    name: "5 workers, 5 tasks",
    difficulty: "intermediate",
    description:
      "A larger square problem, cross-validated against scipy.optimize.linear_sum_assignment — good for watching several augmenting-path attempts chain together. Optimum: 33.",
    problem: {
      workerNames: ["W1", "W2", "W3", "W4", "W5"],
      taskNames: ["T1", "T2", "T3", "T4", "T5"],
      costs: [
        [12, 7, 9, 15, 11],
        [8, 6, 13, 10, 9],
        [14, 10, 7, 8, 13],
        [6, 9, 12, 5, 10],
        [11, 13, 8, 9, 6],
      ],
    },
  },
  {
    name: "4 workers, 5 tasks (unbalanced + several covering rounds)",
    difficulty: "difficult",
    description:
      "More tasks than workers, so a zero-cost dummy worker is auto-added first — and the highly-proportional costs mean the first covering pass falls well short of a full matching, needing several rounds of \"cover, find the smallest uncovered value, adjust\" before a perfect zero-cost matching appears. Cross-validated with scipy. Optimum: 20.",
    problem: {
      workerNames: ["W1", "W2", "W3", "W4"],
      taskNames: ["T1", "T2", "T3", "T4", "T5"],
      costs: [
        [1, 2, 3, 4, 5],
        [2, 4, 6, 8, 10],
        [3, 6, 9, 12, 15],
        [4, 8, 12, 16, 20],
      ],
    },
  },
];
