import { describe, it, expect } from "vitest";
import { validateProblem, padToSquare } from "../standardize";
import { AssignmentProblemInput } from "../../../types/assignment";

describe("validateProblem", () => {
  it("accepts a well-formed square problem", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["A", "B"],
      taskNames: ["T1", "T2"],
      costs: [
        [1, 2],
        [3, 4],
      ],
    };
    expect(validateProblem(problem)).toEqual([]);
  });

  it("flags a missing worker", () => {
    const problem: AssignmentProblemInput = { workerNames: [], taskNames: ["T1"], costs: [] };
    expect(validateProblem(problem).length).toBeGreaterThan(0);
  });

  it("flags a mismatched cost row length", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["A", "B"],
      taskNames: ["T1", "T2"],
      costs: [[1, 2], [3]],
    };
    expect(validateProblem(problem).some((e) => e.includes("Cost row"))).toBe(true);
  });

  it("flags a negative cost", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["A"],
      taskNames: ["T1"],
      costs: [[-5]],
    };
    expect(validateProblem(problem).some((e) => e.includes("negative"))).toBe(true);
  });
});

describe("padToSquare", () => {
  it("leaves an already-square problem untouched", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["A", "B"],
      taskNames: ["T1", "T2"],
      costs: [
        [1, 2],
        [3, 4],
      ],
    };
    const padded = padToSquare(problem);
    expect(padded.dummy).toBeNull();
    expect(padded.workerNames).toEqual(["A", "B"]);
    expect(padded.taskNames).toEqual(["T1", "T2"]);
  });

  it("adds dummy tasks when there are more workers than tasks", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["A", "B", "C"],
      taskNames: ["T1"],
      costs: [[1], [2], [3]],
    };
    const padded = padToSquare(problem);
    expect(padded.dummy?.type).toBe("task");
    expect(padded.taskNames.length).toBe(3);
    expect(padded.costs.every((row) => row.length === 3)).toBe(true);
    // Dummy columns carry zero cost.
    padded.costs.forEach((row) => expect(row[row.length - 1].isZero()).toBe(true));
  });

  it("adds dummy workers when there are more tasks than workers", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["A"],
      taskNames: ["T1", "T2", "T3"],
      costs: [[1, 2, 3]],
    };
    const padded = padToSquare(problem);
    expect(padded.dummy?.type).toBe("worker");
    expect(padded.workerNames.length).toBe(3);
    expect(padded.costs.length).toBe(3);
    // Dummy rows carry zero cost.
    expect(padded.costs[1].every((c) => c.isZero())).toBe(true);
    expect(padded.costs[2].every((c) => c.isZero())).toBe(true);
  });
});
