import { describe, it, expect } from "vitest";
import { solveAssignment } from "../solve";
import { AssignmentProblemInput } from "../../../types/assignment";

describe("solveAssignment — 4x4 classic (hand-verified)", () => {
  // Ground truth: 41, independently cross-checked with scipy.optimize.linear_sum_assignment
  // (pairs: A→Job1, B→Job3, C→Job2, D→Job4).
  const problem: AssignmentProblemInput = {
    workerNames: ["A", "B", "C", "D"],
    taskNames: ["Job 1", "Job 2", "Job 3", "Job 4"],
    costs: [
      [8, 26, 17, 11],
      [13, 28, 4, 26],
      [38, 19, 18, 15],
      [19, 26, 24, 10],
    ],
  };

  it("reaches the true optimum of 41", () => {
    const result = solveAssignment(problem);
    expect(result.status).toBe("optimal");
    expect(result.totalCost).toBe(41);
  });

  it("matches the known optimal pairing", () => {
    const result = solveAssignment(problem);
    expect(result.assignment).toEqual({
      A: "Job 1",
      B: "Job 3",
      C: "Job 2",
      D: "Job 4",
    });
  });

  it("assigns every worker to a distinct task exactly once", () => {
    const result = solveAssignment(problem);
    const tasks = Object.values(result.assignment ?? {});
    expect(tasks.length).toBe(4);
    expect(new Set(tasks).size).toBe(4);
  });

  it("emits the square-check, both reductions, and a final optimal step", () => {
    const result = solveAssignment(problem);
    const kinds = result.steps.map((s) => s.state.stepKind);
    expect(kinds).toContain("balance-check");
    expect(kinds).toContain("row-reduction");
    expect(kinds).toContain("col-reduction");
    expect(kinds).toContain("optimal");
    const optimalStep = result.steps.find((s) => s.state.stepKind === "optimal");
    expect((optimalStep!.state as any).isOptimal).toBe(true);
  });

  it("shows every augmentation attempt as its own step", () => {
    const result = solveAssignment(problem);
    const matchSteps = result.steps.filter(
      (s) => s.state.stepKind === "match-success" || s.state.stepKind === "match-fail"
    );
    // At least one attempt per worker is required to reach a full 4-worker matching.
    expect(matchSteps.length).toBeGreaterThanOrEqual(4);
    matchSteps.forEach((s) => {
      expect((s.state as any).currentRow).not.toBeNull();
    });
  });
});

describe("solveAssignment — 5x5 (scipy-validated)", () => {
  // Ground truth: 33, independently verified with scipy.optimize.linear_sum_assignment
  // (pairs: W1→T2, W2→T1, W3→T3, W4→T4, W5→T5).
  const problem: AssignmentProblemInput = {
    workerNames: ["W1", "W2", "W3", "W4", "W5"],
    taskNames: ["T1", "T2", "T3", "T4", "T5"],
    costs: [
      [12, 7, 9, 15, 11],
      [8, 6, 13, 10, 9],
      [14, 10, 7, 8, 13],
      [6, 9, 12, 5, 10],
      [11, 13, 8, 9, 6],
    ],
  };

  it("reaches the true optimum of 33", () => {
    const result = solveAssignment(problem);
    expect(result.status).toBe("optimal");
    expect(result.totalCost).toBe(33);
  });

  it("matches scipy's optimal pairing", () => {
    const result = solveAssignment(problem);
    expect(result.assignment).toEqual({
      W1: "T2",
      W2: "T1",
      W3: "T3",
      W4: "T4",
      W5: "T5",
    });
  });
});

describe("solveAssignment — unbalanced 4x5, needs several covering rounds", () => {
  // Ground truth: 20, independently verified with scipy.optimize.linear_sum_assignment
  // directly on the rectangular matrix (pairs: W1→T4, W2→T3, W3→T2, W4→T1; T5 unassigned).
  const problem: AssignmentProblemInput = {
    workerNames: ["W1", "W2", "W3", "W4"],
    taskNames: ["T1", "T2", "T3", "T4", "T5"],
    costs: [
      [1, 2, 3, 4, 5],
      [2, 4, 6, 8, 10],
      [3, 6, 9, 12, 15],
      [4, 8, 12, 16, 20],
    ],
  };

  it("pads with a dummy worker and reaches the true optimum of 20", () => {
    const result = solveAssignment(problem);
    expect(result.status).toBe("optimal");
    expect(result.totalCost).toBe(20);
    const balanceStep = result.steps.find((s) => s.state.stepKind === "balance-check");
    expect(balanceStep).toBeDefined();
    expect((balanceStep!.state as any).dummyNote).not.toBeNull();
  });

  it("matches scipy's optimal pairing and leaves one task unassigned", () => {
    const result = solveAssignment(problem);
    expect(result.assignment).toEqual({
      W1: "T4",
      W2: "T3",
      W3: "T2",
      W4: "T1",
    });
    expect(result.notes.some((n) => n.includes("T5"))).toBe(true);
  });

  it("needs multiple cover/adjust rounds before a perfect matching appears", () => {
    const result = solveAssignment(problem);
    const adjustSteps = result.steps.filter((s) => s.state.stepKind === "adjust");
    expect(adjustSteps.length).toBeGreaterThan(1);
  });
});

describe("solveAssignment — invalid input", () => {
  it("reports validation errors instead of throwing", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["W1", "W2"],
      taskNames: ["T1"],
      costs: [[5]],
    };
    const result = solveAssignment(problem);
    expect(result.status).toBe("invalid");
    expect(result.notes.length).toBeGreaterThan(0);
    expect(result.steps).toEqual([]);
  });
});

describe("solveAssignment — tie-breaking / alternate optima", () => {
  // Every worker costs exactly the same for every task within a row-shifted pattern,
  // so multiple assignments share the optimal cost. Any valid perfect matching found
  // must still be a bijection and must hit the true minimum.
  const problem: AssignmentProblemInput = {
    workerNames: ["W1", "W2", "W3"],
    taskNames: ["T1", "T2", "T3"],
    costs: [
      [5, 5, 5],
      [5, 5, 5],
      [5, 5, 5],
    ],
  };

  it("still finds a valid bijective assignment at the true optimum", () => {
    const result = solveAssignment(problem);
    expect(result.status).toBe("optimal");
    expect(result.totalCost).toBe(15);
    const tasks = Object.values(result.assignment ?? {});
    expect(new Set(tasks).size).toBe(3);
  });
});

describe("solveAssignment — exact (non-integer) costs", () => {
  it("keeps totals exact for decimal costs, avoiding float drift", () => {
    const problem: AssignmentProblemInput = {
      workerNames: ["W1", "W2", "W3"],
      taskNames: ["T1", "T2", "T3"],
      costs: [
        [1.1, 2.2, 3.3],
        [4.4, 1.1, 2.2],
        [3.3, 4.4, 1.1],
      ],
    };
    const result = solveAssignment(problem);
    expect(result.status).toBe("optimal");
    expect(result.totalCost).toBeCloseTo(3.3, 10);
  });
});
