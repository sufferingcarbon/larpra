import { Fraction } from "../../utils/fraction";
import { AssignmentPhase, AssignmentTableauState, Cell } from "../../types/assignment";
import { PaddedProblem } from "./standardize";

/** Mutable working state shared by every phase of the Hungarian algorithm. */
export class AssignmentTableau {
  workerNames: string[];
  taskNames: string[];
  /** Fixed reference matrix — the padded costs before any reduction, in original units. */
  originalCosts: Fraction[][];
  /** The matrix actually being reduced/adjusted as the algorithm runs. */
  costs: Fraction[][];

  rowReductions: (Fraction | null)[] | null = null;
  colReductions: (Fraction | null)[] | null = null;

  constructor(padded: PaddedProblem) {
    this.workerNames = padded.workerNames;
    this.taskNames = padded.taskNames;
    this.originalCosts = padded.costs;
    this.costs = padded.costs.map((row) => row.slice());
  }

  get n() {
    return this.workerNames.length;
  }

  /** Cost, in original units, of a matching expressed as matching[i] = j | null. */
  costOfMatching(matching: (number | null)[]): Fraction {
    let sum = Fraction.ZERO;
    for (let i = 0; i < this.n; i++) {
      const j = matching[i];
      if (j !== null) sum = sum.add(this.originalCosts[i][j]);
    }
    return sum;
  }

  snapshot(opts: {
    stepKind: string;
    phase: AssignmentPhase;
    matching: (number | null)[];
    currentRow?: number | null;
    visitedCols?: boolean[] | null;
    augmentingPath?: Cell[] | null;
    coveredRows?: boolean[] | null;
    coveredCols?: boolean[] | null;
    lineCount?: number | null;
    uncoveredMin?: Fraction | null;
    dummyNote?: string | null;
    isOptimal?: boolean;
  }): AssignmentTableauState {
    return {
      phase: opts.phase,
      stepKind: opts.stepKind,
      workerNames: this.workerNames,
      taskNames: this.taskNames,
      originalCosts: this.originalCosts.map((row) => row.map((c) => c.toDisplay())),
      costs: this.costs.map((row) => row.map((c) => c.toDisplay())),
      rowReductions: this.rowReductions ? this.rowReductions.map((r) => (r ? r.toDisplay() : null)) : null,
      colReductions: this.colReductions ? this.colReductions.map((c) => (c ? c.toDisplay() : null)) : null,
      coveredRows: opts.coveredRows ?? null,
      coveredCols: opts.coveredCols ?? null,
      lineCount: opts.lineCount ?? null,
      matching: opts.matching.slice(),
      currentRow: opts.currentRow ?? null,
      visitedCols: opts.visitedCols ?? null,
      augmentingPath: opts.augmentingPath ?? null,
      uncoveredMin: opts.uncoveredMin ? opts.uncoveredMin.toDisplay() : null,
      currentCost: this.costOfMatching(opts.matching).toDisplay(),
      isOptimal: opts.isOptimal ?? false,
      dummyNote: opts.dummyNote ?? null,
    };
  }
}
