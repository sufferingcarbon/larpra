import { Fraction, frac } from "../../utils/fraction";
import { AssignmentProblemInput } from "../../types/assignment";

export function validateProblem(problem: AssignmentProblemInput): string[] {
  const errors: string[] = [];
  const m = problem.workerNames.length;
  const n = problem.taskNames.length;

  if (m === 0) errors.push("Add at least one worker.");
  if (n === 0) errors.push("Add at least one task.");
  if (problem.costs.length !== m) {
    errors.push(`Cost matrix has ${problem.costs.length} rows, expected ${m}.`);
  } else {
    problem.costs.forEach((row, i) => {
      if (row.length !== n) errors.push(`Cost row ${i + 1} has ${row.length} entries, expected ${n}.`);
      row.forEach((c, j) => {
        if (Number.isNaN(c)) errors.push(`Cost at worker ${i + 1}, task ${j + 1} is missing.`);
        if (c < 0) errors.push(`Cost at worker ${i + 1}, task ${j + 1} is negative.`);
      });
    });
  }

  return errors;
}

export interface PaddedProblem {
  workerNames: string[];
  taskNames: string[];
  costs: Fraction[][];
  /** Non-null when a dummy worker/task was added to square up a rectangular cost matrix. */
  dummy: { type: "worker" | "task"; names: string[] } | null;
}

/**
 * The Hungarian algorithm needs a square cost matrix. If there are more
 * workers than tasks (or vice versa), pad the smaller side with zero-cost
 * dummy rows/columns — any worker or task matched to a dummy in the final
 * solution simply gets no real assignment.
 */
export function padToSquare(problem: AssignmentProblemInput): PaddedProblem {
  const workerNames = problem.workerNames.slice();
  const taskNames = problem.taskNames.slice();
  const costs = problem.costs.map((row) => row.map(frac));
  const m = workerNames.length;
  const n = taskNames.length;

  if (m === n) {
    return { workerNames, taskNames, costs, dummy: null };
  }

  if (m < n) {
    const added: string[] = [];
    for (let k = m; k < n; k++) {
      const name = `Dummy Worker ${k - m + 1}`;
      workerNames.push(name);
      costs.push(taskNames.map(() => Fraction.ZERO));
      added.push(name);
    }
    return { workerNames, taskNames, costs, dummy: { type: "worker", names: added } };
  }

  const added: string[] = [];
  for (let k = n; k < m; k++) {
    const name = `Dummy Task ${k - n + 1}`;
    taskNames.push(name);
    costs.forEach((row) => row.push(Fraction.ZERO));
    added.push(name);
  }
  return { workerNames, taskNames, costs, dummy: { type: "task", names: added } };
}
