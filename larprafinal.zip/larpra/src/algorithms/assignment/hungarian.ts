import { AlgorithmStep } from "../../types/lp";
import { AssignmentTableauState, Cell } from "../../types/assignment";
import { Fraction } from "../../utils/fraction";
import { AssignmentTableau } from "./tableau";

/** Subtracts each row's minimum from that row. Every row of a padded matrix is non-empty, so a minimum always exists. */
export function rowReductionStep(tab: AssignmentTableau): AlgorithmStep<AssignmentTableauState> {
  const n = tab.n;
  const mins: Fraction[] = tab.costs.map((row) => row.reduce((m, c) => (c.lt(m) ? c : m), row[0]));
  tab.costs = tab.costs.map((row, i) => row.map((c) => c.sub(mins[i])));
  tab.rowReductions = mins;

  const emptyMatching = new Array(n).fill(null);
  return {
    title: "Row reduction",
    explanation:
      `Subtract each row's smallest entry from every entry in that row: ` +
      tab.workerNames.map((w, i) => `${w} −${mins[i].toDisplay()}`).join(", ") +
      `. Every row now has at least one zero, and no cost can go negative.`,
    state: tab.snapshot({ stepKind: "row-reduction", phase: "reduction", matching: emptyMatching }),
    why: "Subtracting a constant from an entire row shifts every assignment cost that uses that row by the same amount, so it never changes which assignment is cheapest — only the zero pattern the rest of the algorithm searches for.",
  };
}

/** Subtracts each column's minimum from that column, using the already row-reduced matrix. */
export function colReductionStep(tab: AssignmentTableau): AlgorithmStep<AssignmentTableauState> {
  const n = tab.n;
  const mins: Fraction[] = [];
  for (let j = 0; j < n; j++) {
    let m = tab.costs[0][j];
    for (let i = 1; i < n; i++) if (tab.costs[i][j].lt(m)) m = tab.costs[i][j];
    mins.push(m);
  }
  tab.costs = tab.costs.map((row) => row.map((c, j) => c.sub(mins[j])));
  tab.colReductions = mins;

  const emptyMatching = new Array(n).fill(null);
  const allAlreadyZero = mins.every((m) => m.isZero());
  return {
    title: "Column reduction",
    explanation: allAlreadyZero
      ? `Every column already contains a zero after the row reduction, so column reduction subtracts 0 everywhere and leaves the matrix unchanged.`
      : `Subtract each column's smallest entry from every entry in that column: ` +
        tab.taskNames.map((t, j) => `${t} −${mins[j].toDisplay()}`).join(", ") +
        `. Every column now also has at least one zero.`,
    state: tab.snapshot({ stepKind: "col-reduction", phase: "reduction", matching: emptyMatching }),
    why: "Same reasoning as row reduction, applied to columns: shifting a whole column by a constant never changes which assignment is optimal, but it guarantees every row AND every column has a zero to search for a matching among.",
  };
}

/**
 * Attempts one augmenting-path search (Kuhn's algorithm) rooted at `row`,
 * over the zero cells of `costs`. Mutates `matchColToRow` in place on
 * success. Returns the path of (row, col) edges actually used in the
 * successful chain, or an empty array if no augmenting path exists yet.
 */
function tryAugment(
  row: number,
  costs: Fraction[][],
  matchColToRow: (number | null)[],
  visitedCols: boolean[],
  path: Cell[]
): boolean {
  const n = costs.length;
  for (let c = 0; c < n; c++) {
    if (visitedCols[c] || !costs[row][c].isZero()) continue;
    visitedCols[c] = true;
    path.push({ row, col: c });
    const occupant = matchColToRow[c];
    if (occupant === null || tryAugment(occupant, costs, matchColToRow, visitedCols, path)) {
      matchColToRow[c] = row;
      return true;
    }
    path.pop();
  }
  return false;
}

function toRowMatching(matchColToRow: (number | null)[], n: number): (number | null)[] {
  const matchRowToCol: (number | null)[] = new Array(n).fill(null);
  for (let c = 0; c < n; c++) {
    const r = matchColToRow[c];
    if (r !== null) matchRowToCol[r] = c;
  }
  return matchRowToCol;
}

/**
 * König's theorem: given a maximum matching (one full pass of augmenting
 * attempts over every row), the minimum vertex cover is (unreached rows) ∪
 * (reached columns), reached via alternation from every currently unmatched
 * row. This always has exactly as many lines as the matching has edges.
 */
function computeMinCover(
  costs: Fraction[][],
  matchColToRow: (number | null)[],
  n: number
): { coveredRows: boolean[]; coveredCols: boolean[] } {
  const matchRowToCol = toRowMatching(matchColToRow, n);
  const reachedRows = new Array(n).fill(false);
  const reachedCols = new Array(n).fill(false);

  for (let r = 0; r < n; r++) if (matchRowToCol[r] === null) reachedRows[r] = true;

  let changed = true;
  while (changed) {
    changed = false;
    for (let r = 0; r < n; r++) {
      if (!reachedRows[r]) continue;
      for (let c = 0; c < n; c++) {
        if (costs[r][c].isZero() && !reachedCols[c]) {
          reachedCols[c] = true;
          changed = true;
        }
      }
    }
    for (let c = 0; c < n; c++) {
      if (!reachedCols[c]) continue;
      const r = matchColToRow[c];
      if (r !== null && !reachedRows[r]) {
        reachedRows[r] = true;
        changed = true;
      }
    }
  }

  return {
    coveredRows: reachedRows.map((reached) => !reached),
    coveredCols: reachedCols.slice(),
  };
}

function findMinUncovered(costs: Fraction[][], coveredRows: boolean[], coveredCols: boolean[], n: number): Fraction {
  let min: Fraction | null = null;
  for (let r = 0; r < n; r++) {
    if (coveredRows[r]) continue;
    for (let c = 0; c < n; c++) {
      if (coveredCols[c]) continue;
      if (min === null || costs[r][c].lt(min)) min = costs[r][c];
    }
  }
  if (min === null) {
    throw new Error("No uncovered cell found — the Hungarian algorithm's covering invariant was violated.");
  }
  return min;
}

export interface HungarianMatchResult {
  steps: AlgorithmStep<AssignmentTableauState>[];
  matching: (number | null)[]; // matching[i] = j, row -> col
}

/**
 * Runs the covering/matching phase to completion: repeatedly attempts an
 * augmenting path for every currently-unmatched row (one step each), and
 * whenever a full pass leaves the matching short of size n, covers the
 * zeros with the minimum number of lines and creates new zeros by
 * subtracting the smallest uncovered value from every uncovered cell (and
 * adding it back wherever two lines cross).
 */
export function runHungarianMatching(tab: AssignmentTableau, maxIterations = 200): HungarianMatchResult {
  const n = tab.n;
  const steps: AlgorithmStep<AssignmentTableauState>[] = [];
  const matchColToRow: (number | null)[] = new Array(n).fill(null);

  for (let iter = 0; iter < maxIterations; iter++) {
    for (let row = 0; row < n; row++) {
      const alreadyMatched = matchColToRow.includes(row);
      if (alreadyMatched) continue;

      const visitedCols = new Array(n).fill(false);
      const path: Cell[] = [];
      const success = tryAugment(row, tab.costs, matchColToRow, visitedCols, path);
      const matchRowToCol = toRowMatching(matchColToRow, n);

      steps.push({
        title: success
          ? `Augment: ${tab.workerNames[row]} joins the matching`
          : `${tab.workerNames[row]} — no augmenting path yet`,
        explanation: success
          ? describeAugmentingPath(tab, path)
          : `Starting from ${tab.workerNames[row]}, every zero cell leads only to tasks already claimed by other workers with no way to bump them elsewhere — no augmenting path exists yet. The matrix will need adjusting before ${tab.workerNames[row]} can be matched.`,
        operation: success ? `augment(row=${row})` : undefined,
        state: tab.snapshot({
          stepKind: success ? "match-success" : "match-fail",
          phase: "matching",
          matching: matchRowToCol,
          currentRow: row,
          visitedCols,
          augmentingPath: path.length > 0 ? path : null,
        }),
        why: "Kuhn's algorithm: search outward from a free worker through zero-cost edges; whenever a candidate task is already taken, try to re-route its current worker to a different free task instead. If that chain succeeds, flipping every edge along it grows the matching by exactly one pair.",
      });
    }

    const matchedCount = matchColToRow.filter((x) => x !== null).length;
    const matchRowToCol = toRowMatching(matchColToRow, n);

    if (matchedCount === n) {
      steps.push({
        title: "Optimal assignment found",
        explanation: `Every worker is now matched to a distinct task through a zero-cost cell — a complete assignment has been found using only zero-reduced-cost pairs, which is exactly the Hungarian algorithm's optimality condition. Total cost = ${tab.costOfMatching(matchRowToCol).toDisplay()}.`,
        state: tab.snapshot({ stepKind: "optimal", phase: "matching", matching: matchRowToCol, isOptimal: true }),
        why: "Row/column reduction only ever subtracts constants, so it never changes which assignment is cheapest — it only reveals a zero-cost pattern. A perfect matching within that zero pattern therefore has the same total cost in the reduced matrix (namely 0) as the minimum possible total in the original matrix.",
      });
      return { steps, matching: matchRowToCol };
    }

    const { coveredRows, coveredCols } = computeMinCover(tab.costs, matchColToRow, n);
    steps.push({
      title: `Cover zeros — ${matchedCount} line${matchedCount === 1 ? "" : "s"} needed`,
      explanation:
        `The largest matching found through zero cells so far covers ${matchedCount} of ${n} workers, and by König's theorem the minimum number of lines needed to cover every zero equals that matching size: ` +
        `${coveredRows.filter(Boolean).length} row line(s) and ${coveredCols.filter(Boolean).length} column line(s). ` +
        `Since ${matchedCount} < ${n}, no full assignment is possible yet — the matrix needs more zeros.`,
      state: tab.snapshot({
        stepKind: "cover-lines",
        phase: "matching",
        matching: matchRowToCol,
        coveredRows,
        coveredCols,
        lineCount: matchedCount,
      }),
      why: "König's theorem guarantees the minimum line cover of the zeros always has exactly as many lines as the maximum matching among them — so as long as fewer than n lines are needed, no perfect matching (and hence no fully zero-cost assignment) can exist yet.",
    });

    const minUncovered = findMinUncovered(tab.costs, coveredRows, coveredCols, n);
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        const rowCov = coveredRows[r];
        const colCov = coveredCols[c];
        if (!rowCov && !colCov) tab.costs[r][c] = tab.costs[r][c].sub(minUncovered);
        else if (rowCov && colCov) tab.costs[r][c] = tab.costs[r][c].add(minUncovered);
      }
    }

    steps.push({
      title: `Adjust matrix by ${minUncovered.toDisplay()}`,
      explanation:
        `The smallest uncovered value is ${minUncovered.toDisplay()}. Subtract it from every uncovered cell (creating at least one new zero) and add it back to every cell covered twice (where a row line and a column line cross), so no cost already at a covered line changes. Cells covered by exactly one line are left as they are.`,
      operation: `adjust(min=${minUncovered.toDisplay()})`,
      state: tab.snapshot({
        stepKind: "adjust",
        phase: "matching",
        matching: matchRowToCol,
        coveredRows,
        coveredCols,
        lineCount: matchedCount,
        uncoveredMin: minUncovered,
      }),
      why: "This is the only step that changes the zero pattern. It's equivalent to subtracting the constant from every uncovered row and adding it to every covered column (or vice versa) — a combination of row/column shifts, so it still never changes which assignment is optimal.",
    });
  }

  throw new Error("Hungarian algorithm did not converge within the iteration limit — check for a cycling bug.");
}

function describeAugmentingPath(tab: AssignmentTableau, path: Cell[]): string {
  if (path.length === 1) {
    const { row, col } = path[0];
    return `${tab.workerNames[row]} has a free zero-cost task, ${tab.taskNames[col]} — assign it directly.`;
  }
  const parts = path.map((cell, idx) => {
    const worker = tab.workerNames[cell.row];
    const task = tab.taskNames[cell.col];
    const isLast = idx === path.length - 1;
    return isLast
      ? `${worker} takes the now-free ${task}`
      : `${worker} tries ${task} (currently held by ${tab.workerNames[path[idx + 1].row]})`;
  });
  return `An augmenting path was found: ${parts.join("; ")}. Shifting every worker one step along this chain grows the matching by one pair without unassigning anyone.`;
}
