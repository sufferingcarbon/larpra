import { AlgorithmStep } from "../../types/lp";
import { MatrixAnswer, MatrixInput, MatrixResult, MatrixState } from "../../types/matrix";
import { exact, gridOf, toFMatrix, toFVector, validateMatrix } from "./common";
import { buildCofactorTree } from "./determinant";
import { invertMatrix } from "./inverse";
import { solveLinearSystem } from "./linearSystem";
import { rankAndNullspace } from "./rank";
import { solveEigen } from "./eigenvalues";
import { parseExact } from "./determinant";

/**
 * Orchestrator for the Matrix / Linear Equations module: validates the input, converts every entry to an exact
 * Fraction, dispatches to the sub-solver for the requested operation, and collects its steps into one MatrixResult.
 * As in every other module, the sub-solvers push the steps directly — this function does not synthesize any.
 */
export function solveMatrix(input: MatrixInput): MatrixResult {
  const errors = validateMatrix(input);
  if (errors.length > 0) {
    return { status: "invalid", operation: input.operation, steps: [], answer: {}, notes: errors };
  }

  const A = toFMatrix(input.matrix);
  const aGrid = gridOf(A);
  const steps: AlgorithmStep<MatrixState>[] = [];

  const snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">): MatrixState => ({
    operation: input.operation,
    a: aGrid,
    b: input.rhs ? gridOf([toFVector(input.rhs)])[0] : null,
    tableau: null,
    pivots: null,
    solution: null,
    determinant: null,
    inverse: null,
    nullspace: null,
    eigen: null,
    ...over,
  });

  let answer: MatrixAnswer = {};

  switch (input.operation) {
    case "gaussian": {
      const b = toFVector(input.rhs!);
      const solution = solveLinearSystem(A, b, snap, steps);
      answer = { solution };
      break;
    }
    case "determinant": {
      const tree = buildCofactorTree(A);
      steps.push({
        title: `det(A), expanded along row 1`,
        explanation:
          A.length === 1
            ? `A 1 × 1 matrix's determinant is just its single entry: det(A) = ${tree.value}.`
            : A.length === 2
              ? `For a 2 × 2 matrix [[a, b], [c, d]], det(A) = ad − bc. ${tree.formula}.`
              : A.length === 3
                ? `For a 3 × 3 matrix, det(A) = a(ei − fh) − b(di − fg) + c(dh − eg) (Sarrus' rule in cofactor form). ${tree.formula}.`
                : `Expanding along row 1: det(A) = Σⱼ a₁ⱼ·Cⱼ, where Cⱼ = (−1)^(1+j)·det(minorⱼ). ${tree.formula}.`,
        state: snap({
          phase: "determinant",
          stepKind: "determinant",
          determinant: { root: tree, focusTerm: null, value: tree.value, invertible: parseExact(tree.value).num !== 0n },
        }),
        why: A.length <= 3 ? "This closed form is the cofactor expansion along row 1, simplified for small n." : "Cofactor expansion along any fixed row or column gives the same determinant; row 1 is used here for a deterministic, reproducible tree.",
      });
      if (A.length >= 2) {
        tree.terms.forEach((term, i) => {
          steps.push({
            title: `Cofactor C${term.col + 1}: minor from removing row 1, column ${term.col + 1}`,
            explanation: `C${term.col + 1} = ${term.sign === "−" ? "−" : ""}det(minor₁,${term.col + 1}) = ${term.sign}${term.minor.value}. Its contribution to det(A) is a₁,${term.col + 1}·C${term.col + 1} = ${term.entry}·(${term.sign}${term.minor.value}) = ${term.contribution}.`,
            state: snap({
              phase: "determinant",
              stepKind: "cofactor-term",
              determinant: { root: tree, focusTerm: i, value: tree.value, invertible: parseExact(tree.value).num !== 0n },
            }),
          });
        });
      }
      const invertible = parseExact(tree.value).num !== 0n;
      steps.push({
        title: `det(A) = ${tree.value}${invertible ? " — A is invertible" : " — A is singular"}`,
        explanation: `det(A) = ${tree.value}. A square matrix is invertible exactly when its determinant is non-zero, so A is ${invertible ? "invertible" : "singular (not invertible)"}.`,
        state: snap({
          phase: "summary",
          stepKind: "summary",
          determinant: { root: tree, focusTerm: null, value: tree.value, invertible },
        }),
      });
      answer = { determinant: tree.value };
      break;
    }
    case "inverse": {
      const { singular, inverse } = invertMatrix(A, snap, steps);
      answer = { inverse: { inverse: inverse ? gridOf(inverse) : null, singular } };
      break;
    }
    case "rank": {
      const r = rankAndNullspace(A, snap, steps);
      answer = {
        rank: {
          rank: r.rank,
          nullity: r.nullity,
          pivotCols: r.pivotCols,
          freeCols: r.freeCols,
          nullspaceBasis: r.basis.map((v) => v.map(exact)),
        },
      };
      break;
    }
    case "eigen": {
      const info = solveEigen(A, snap, steps);
      answer = { eigen: { polynomial: info.polynomial!.text, eigenvalues: info.eigenvalues, eigenvectors: info.eigenvectors } };
      break;
    }
  }

  return { status: "solved", operation: input.operation, steps, answer, notes: [] };
}
