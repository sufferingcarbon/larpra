import { describe, expect, it } from "vitest";
import { solveMatrix } from "../solve";
import { matrixExamples } from "../examples";
import { validateMatrix, MAX_DIM, MAX_EIGEN_DIM } from "../common";

describe("validateMatrix", () => {
  it("accepts a valid gaussian input", () => {
    expect(validateMatrix({ operation: "gaussian", matrix: [[1, 2], [3, 4]], rhs: [1, 2] })).toEqual([]);
  });

  it("rejects gaussian input with no rhs", () => {
    const errors = validateMatrix({ operation: "gaussian", matrix: [[1, 2], [3, 4]] });
    expect(errors.length).toBeGreaterThan(0);
  });

  it("rejects a mismatched rhs length", () => {
    const errors = validateMatrix({ operation: "gaussian", matrix: [[1, 2], [3, 4]], rhs: [1] });
    expect(errors.length).toBeGreaterThan(0);
  });

  it("rejects ragged rows", () => {
    const errors = validateMatrix({ operation: "rank", matrix: [[1, 2], [3]] });
    expect(errors.length).toBeGreaterThan(0);
  });

  it("rejects non-square input for determinant/inverse/eigen", () => {
    for (const operation of ["determinant", "inverse", "eigen"] as const) {
      const errors = validateMatrix({ operation, matrix: [[1, 2, 3], [4, 5, 6]] });
      expect(errors.length, operation).toBeGreaterThan(0);
    }
  });

  it("accepts non-square input for rank and gaussian", () => {
    expect(validateMatrix({ operation: "rank", matrix: [[1, 2, 3], [4, 5, 6]] })).toEqual([]);
    expect(validateMatrix({ operation: "gaussian", matrix: [[1, 2, 3], [4, 5, 6]], rhs: [1, 2] })).toEqual([]);
  });

  it("rejects a matrix larger than MAX_DIM", () => {
    const big = Array.from({ length: MAX_DIM + 1 }, () => Array.from({ length: MAX_DIM + 1 }, () => 1));
    const errors = validateMatrix({ operation: "rank", matrix: big });
    expect(errors.some((e) => e.includes(String(MAX_DIM)))).toBe(true);
  });

  it("rejects eigenvalues on a matrix larger than MAX_EIGEN_DIM", () => {
    const n = MAX_EIGEN_DIM + 1;
    const M = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));
    const errors = validateMatrix({ operation: "eigen", matrix: M });
    expect(errors.some((e) => e.includes(String(MAX_EIGEN_DIM)))).toBe(true);
  });

  it("rejects non-finite or absurdly large entries", () => {
    expect(validateMatrix({ operation: "rank", matrix: [[NaN, 1]] }).length).toBeGreaterThan(0);
    expect(validateMatrix({ operation: "rank", matrix: [[1e9, 1]] }).length).toBeGreaterThan(0);
  });

  it("rejects an unrecognized operation", () => {
    const errors = validateMatrix({ operation: "bogus" as any, matrix: [[1]] });
    expect(errors.length).toBeGreaterThan(0);
  });

  it("rejects an empty matrix", () => {
    expect(validateMatrix({ operation: "rank", matrix: [] }).length).toBeGreaterThan(0);
  });
});

describe("solveMatrix: invalid input", () => {
  it("returns status 'invalid' with notes, and no steps, for a bad input", () => {
    const r = solveMatrix({ operation: "gaussian", matrix: [[1, 2], [3, 4]] });
    expect(r.status).toBe("invalid");
    expect(r.steps).toEqual([]);
    expect(r.notes.length).toBeGreaterThan(0);
  });
});

describe("solveMatrix: dispatch by operation", () => {
  it("gaussian returns a SolutionInfo", () => {
    const r = solveMatrix({ operation: "gaussian", matrix: [[2, 1], [1, -1]], rhs: [5, 1] });
    expect(r.status).toBe("solved");
    expect(r.answer.solution?.kind).toBe("unique");
    expect(r.answer.solution?.x).toEqual(["2", "1"]);
  });

  it("determinant returns the exact value and marks invertibility", () => {
    const r = solveMatrix({ operation: "determinant", matrix: [[1, 2, 3], [0, 1, 4], [1, 3, 7]] });
    expect(r.status).toBe("solved");
    expect(r.answer.determinant).toBe("0");
    const summary = r.steps.find((s) => s.state.stepKind === "summary");
    expect((summary!.state.determinant as any).invertible).toBe(false);
  });

  it("inverse returns the inverse and a singular flag", () => {
    const r = solveMatrix({ operation: "inverse", matrix: [[4, 7], [2, 6]] });
    expect(r.status).toBe("solved");
    expect(r.answer.inverse?.singular).toBe(false);
    expect(r.answer.inverse?.inverse).not.toBeNull();
  });

  it("rank returns rank, nullity, pivot/free columns, and a nullspace basis", () => {
    const r = solveMatrix({ operation: "rank", matrix: [[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]] });
    expect(r.status).toBe("solved");
    expect(r.answer.rank?.rank).toBe(2);
    expect(r.answer.rank?.nullity).toBe(2);
  });

  it("eigen returns the polynomial text and eigenvalues/eigenvectors", () => {
    const r = solveMatrix({ operation: "eigen", matrix: [[2, 1], [1, 2]] });
    expect(r.status).toBe("solved");
    expect(r.answer.eigen?.polynomial).toContain("λ");
    expect(r.answer.eigen?.eigenvalues.map((e) => e.text).sort()).toEqual(["1", "3"]);
  });
});

describe("solveMatrix: every built-in example produces well-formed steps", () => {
  for (const ex of matrixExamples) {
    it(ex.name, () => {
      const r = solveMatrix(ex.problem);
      expect(r.status, ex.name).toBe("solved");
      expect(r.steps.length, ex.name).toBeGreaterThan(0);
      for (const step of r.steps) {
        expect(step.title, ex.name).toBeTruthy();
        expect(step.explanation, ex.name).toBeTruthy();
        expect(step.state.operation, ex.name).toBe(ex.problem.operation);
      }
    });
  }
});

describe("solveMatrix: determinism", () => {
  it("solving the same input twice produces identical steps", () => {
    const input = { operation: "eigen" as const, matrix: [[2, 0, 0], [0, 0, -1], [0, 1, 0]] };
    const r1 = solveMatrix(input);
    const r2 = solveMatrix(input);
    expect(JSON.stringify(r1.steps)).toBe(JSON.stringify(r2.steps));
    expect(JSON.stringify(r1.answer)).toBe(JSON.stringify(r2.answer));
  });
});

describe("solveMatrix: answer shapes", () => {
  it("every determinant example's answer is a parseable exact string", () => {
    for (const ex of matrixExamples.filter((e) => e.problem.operation === "determinant")) {
      const r = solveMatrix(ex.problem);
      expect(typeof r.answer.determinant).toBe("string");
    }
  });
});
