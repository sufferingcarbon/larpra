import { describe, expect, it } from "vitest";
import { Fraction } from "../../../utils/fraction";
import { toFMatrix, exact } from "../common";
import { buildCofactorTree, detValue, parseExact } from "../determinant";

const det = (M: number[][]) => detValue(toFMatrix(M));

describe("detValue", () => {
  it("1×1", () => {
    expect(det([[7]]).toNumber()).toBe(7);
  });

  it("2×2 closed form (ad - bc)", () => {
    expect(det([[4, 3], [6, 3]]).toNumber()).toBe(4 * 3 - 3 * 6);
  });

  it("3×3 via cofactor expansion", () => {
    expect(det([[2, -1, 3], [0, 4, 5], [1, 2, -2]]).toNumber()).toBe(-53);
  });

  it("larger matrices via recursive cofactor expansion", () => {
    const M = [[1, 2, 0, 3], [4, 0, 1, 2], [0, 1, 2, 1], [2, 3, 1, 0]];
    expect(det(M).toNumber()).toBe(79);
  });

  it("det = 0 for a singular matrix (linearly dependent rows)", () => {
    expect(det([[1, 2, 3], [0, 1, 4], [1, 3, 7]]).isZero()).toBe(true);
    expect(det([[1, 2], [2, 4]]).isZero()).toBe(true);
  });

  it("det(AB) = det(A)det(B)", () => {
    const A = [[1, 2], [3, 4]];
    const B = [[5, 6], [7, 8]];
    const mul = (X: number[][], Y: number[][]) => X.map((row, i) => Y[0].map((_, j) => row.reduce((s, x, k) => s + x * Y[k][j], 0)));
    expect(det(mul(A, B)).toNumber()).toBe(det(A).toNumber() * det(B).toNumber());
  });

  it("det(A⁻¹) = 1/det(A)", () => {
    expect(det([[2, 0], [0, 4]]).toNumber()).toBe(8);
    expect(det([[0.5, 0], [0, 0.25]]).toNumber()).toBeCloseTo(1 / 8);
  });

  it("does not accumulate floating-point error on fractional entries", () => {
    // 1/3 as entered via a decimal input field: 0.333333333 (finite decimal), not the true mathematical 1/3.
    // The point of this test is that whatever exact decimal was entered is carried through with zero additional
    // rounding error, not that a JS float literal equals a true rational.
    const d = detValue(toFMatrix([[0.5, 0.25], [0.25, 0.5]]));
    // 0.5*0.5 - 0.25*0.25 = 0.25 - 0.0625 = 0.1875 = 3/16, exactly
    expect(d.equals(new Fraction(3, 16))).toBe(true);
  });

  it("row scaling multiplies the determinant", () => {
    const base = det([[1, 2], [3, 4]]);
    const scaled = det([[2, 4], [3, 4]]); // row 1 scaled by 2
    expect(scaled.toNumber()).toBe(base.toNumber() * 2);
  });
});

describe("buildCofactorTree", () => {
  it("1×1 uses the '1x1' method with no terms", () => {
    const tree = buildCofactorTree(toFMatrix([[5]]));
    expect(tree.method).toBe("1x1");
    expect(tree.terms).toEqual([]);
    expect(tree.value).toBe("5");
  });

  it("2×2 uses the closed form 'ad - bc'", () => {
    const tree = buildCofactorTree(toFMatrix([[4, 3], [6, 3]]));
    expect(tree.method).toBe("2x2");
    expect(tree.formula).toContain("ad − bc");
    expect(tree.value).toBe("−6");
  });

  it("3×3 at the top level uses the closed-form Sarrus expansion with 3 terms", () => {
    const tree = buildCofactorTree(toFMatrix([[2, -1, 3], [0, 4, 5], [1, 2, -2]]));
    expect(tree.method).toBe("3x3-closed-form");
    expect(tree.terms).toHaveLength(3);
    expect(tree.value).toBe("−53");
  });

  it("a 3×3 minor nested inside a 4×4 uses the general expansion, not the closed form (closed form is top-level only, per spec)", () => {
    const tree = buildCofactorTree(toFMatrix([[1, 0, 0, 0], [0, 2, -1, 3], [0, 0, 4, 5], [0, 1, 2, -2]]));
    expect(tree.terms).toHaveLength(1);
    expect(tree.terms[0].minor.method).toBe("expansion");
  });

  it("general n×n expansion skips zero entries in row 1 (sparse row optimization)", () => {
    const tree = buildCofactorTree(toFMatrix([[0, 0, 5, 0, 0], [1, 2, 3, 4, 5], [5, 4, 3, 2, 1], [1, 1, 1, 1, 1], [2, 3, 1, 0, 4]]));
    expect(tree.method).toBe("expansion");
    expect(tree.terms).toHaveLength(1);
    expect(tree.terms[0].col).toBe(2);
  });

  it("every term's stored contribution sums exactly to the reported determinant", () => {
    const cases = [
      [[1, 2, 0, 3], [4, 0, 1, 2], [0, 1, 2, 1], [2, 3, 1, 0]],
      [[3, 1, -2, 0, 4], [0, 2, 1, -1, 3], [1, 0, 0, 2, -1], [2, -3, 1, 0, 1], [0, 1, 2, 3, -2]],
    ];
    for (const M of cases) {
      const tree = buildCofactorTree(toFMatrix(M));
      if (tree.terms.length === 0) continue;
      const sum = tree.terms.reduce((s, t) => s.add(parseExact(t.contribution)), Fraction.ZERO);
      expect(sum.equals(parseExact(tree.value)), JSON.stringify(M)).toBe(true);
    }
  });

  it("sign alternates correctly across columns: +, −, +, − ...", () => {
    const tree = buildCofactorTree(toFMatrix([[1, 2, 3, 4, 5], [2, 1, 0, 1, 2], [0, 1, 2, 0, 1], [1, 0, 1, 2, 0], [3, 2, 1, 0, 1]]));
    tree.terms.forEach((t) => {
      expect(t.sign).toBe(t.col % 2 === 0 ? "+" : "−");
    });
  });

  it("matches detValue for a battery of pseudo-random small matrices", () => {
    let s = 42;
    const rng = () => {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      return (s % 13) - 6;
    };
    for (let trial = 0; trial < 20; trial++) {
      const n = 2 + (trial % 3);
      const M = Array.from({ length: n }, () => Array.from({ length: n }, () => rng()));
      const Mf = toFMatrix(M);
      const tree = buildCofactorTree(Mf);
      expect(parseExact(tree.value).equals(detValue(Mf)), JSON.stringify(M)).toBe(true);
    }
  });
});

describe("parseExact / exact round-trip", () => {
  it("round-trips integers and fractions through exact() and parseExact()", () => {
    const vals = [new Fraction(0), new Fraction(-6), new Fraction(1, 3), new Fraction(-5, 7)];
    for (const v of vals) expect(parseExact(exact(v)).equals(v)).toBe(true);
  });
});
