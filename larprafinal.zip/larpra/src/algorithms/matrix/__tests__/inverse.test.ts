import { describe, expect, it } from "vitest";
import { Fraction } from "../../../utils/fraction";
import { toFMatrix, exact, matMul, isIdentity } from "../common";
import { invertMatrix } from "../inverse";
import { MatrixState } from "../../../types/matrix";

const snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">): MatrixState => ({
  operation: "inverse",
  a: [],
  b: null,
  tableau: null,
  pivots: null,
  solution: null,
  determinant: null,
  inverse: null,
  nullspace: null,
  eigen: null,
  ...over,
});

const invert = (M: number[][]) => {
  const A = toFMatrix(M);
  const steps: any[] = [];
  const result = invertMatrix(A, snap, steps);
  return { A, ...result, steps };
};

describe("invertMatrix", () => {
  it("inverts a 2×2 matrix exactly", () => {
    const { inverse, singular } = invert([[4, 7], [2, 6]]);
    expect(singular).toBe(false);
    // det = 24-14=10; inverse = 1/10 [[6,-7],[-2,4]]
    expect(inverse!.map((r) => r.map(exact))).toEqual([
      ["3/5", "−7/10"],
      ["−1/5", "2/5"],
    ]);
  });

  it("inverts a 3×3 matrix with non-integer entries", () => {
    const { A, inverse, singular } = invert([[2, 0, 1], [1, 3, 2], [0, 1, 1]]);
    expect(singular).toBe(false);
    const product = matMul(A, inverse!);
    expect(isIdentity(product)).toBe(true);
  });

  it("(A⁻¹)⁻¹ = A", () => {
    const { inverse: inv1 } = invert([[4, 7], [2, 6]]);
    const steps: any[] = [];
    const inv2 = invertMatrix(inv1!, snap, steps).inverse!;
    expect(inv2.map((r) => r.map(exact))).toEqual([
      ["4", "7"],
      ["2", "6"],
    ]);
  });

  it("A · A⁻¹ = I exactly, for several matrices", () => {
    const cases = [[[4, 7], [2, 6]], [[2, 0, 1], [1, 3, 2], [0, 1, 1]], [[1, 2], [3, 5]], [[5]]];
    for (const M of cases) {
      const { A, inverse } = invert(M);
      expect(isIdentity(matMul(A, inverse!)), JSON.stringify(M)).toBe(true);
      expect(isIdentity(matMul(inverse!, A)), JSON.stringify(M)).toBe(true);
    }
  });

  it("rejects a singular matrix, with the correct rank reported", () => {
    const { singular, inverse, steps } = invert([[1, 2, 3], [0, 1, 1], [2, 3, 5]]);
    expect(singular).toBe(true);
    expect(inverse).toBeNull();
    expect(steps.some((s) => s.state.stepKind === "singular")).toBe(true);
  });

  it("rejects the zero matrix and a rank-1 matrix", () => {
    expect(invert([[0, 0], [0, 0]]).singular).toBe(true);
    expect(invert([[1, 2], [2, 4]]).singular).toBe(true);
  });

  it("1×1 inverse is the reciprocal", () => {
    const { inverse } = invert([[4]]);
    expect(inverse!.map((r) => r.map(exact))).toEqual([["1/4"]]);
  });

  it("handles a matrix that needs a row swap during forward elimination", () => {
    const { A, inverse, singular } = invert([[0, 1], [1, 0]]);
    expect(singular).toBe(false);
    expect(isIdentity(matMul(A, inverse!))).toBe(true);
  });

  it("verified flag in the final step reflects an exact A·A⁻¹ = I check", () => {
    const { steps } = invert([[4, 7], [2, 6]]);
    const verifyStep = steps.find((s) => s.state.stepKind === "inverse-verify");
    expect(verifyStep).toBeDefined();
    expect(verifyStep!.state.inverse.verified).toBe(true);
  });

  it("4×4 invertible matrix round-trips", () => {
    const M = [[2, 0, 0, 1], [0, 3, 1, 0], [1, 0, 2, 0], [0, 1, 0, 4]];
    const { A, inverse, singular } = invert(M);
    expect(singular).toBe(false);
    expect(isIdentity(matMul(A, inverse!))).toBe(true);
  });

  it("negative and fractional-looking entries still invert exactly", () => {
    const { A, inverse, singular } = invert([[-2, 1], [1.5, -1]]);
    expect(singular).toBe(false);
    const product = matMul(A, inverse!);
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) expect(product[i][j].equals(i === j ? Fraction.ONE : Fraction.ZERO)).toBe(true);
  });
});
