import { describe, expect, it } from "vitest";
import { toFMatrix, matVec, exact } from "../common";
import { rankAndNullspace } from "../rank";
import { MatrixState } from "../../../types/matrix";

const snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">): MatrixState => ({
  operation: "rank",
  a: [],
  b: null,
  tableau: null,
  pivots: null,
  solution: null,
  determinant: null,
  inverse: null,
  nullspace: null,
  eigen: null,
  ...over,
});

const run = (M: number[][]) => {
  const A = toFMatrix(M);
  const steps: any[] = [];
  const result = rankAndNullspace(A, snap, steps);
  return { A, ...result, steps };
};

describe("rankAndNullspace", () => {
  it("full-rank square matrix has rank n and trivial nullspace", () => {
    const { rank, nullity, basis } = run([[1, 0], [0, 1]]);
    expect(rank).toBe(2);
    expect(nullity).toBe(0);
    expect(basis).toHaveLength(0);
  });

  it("rank-deficient square matrix", () => {
    const { rank, nullity } = run([[1, 2], [2, 4]]);
    expect(rank).toBe(1);
    expect(nullity).toBe(1);
  });

  it("full-rank rectangular (more rows than columns)", () => {
    const { rank, nullity } = run([[1, 0], [0, 1], [2, 3]]);
    expect(rank).toBe(2);
    expect(nullity).toBe(0);
  });

  it("rank-deficient rectangular matrix (3×4, rank 2)", () => {
    const { rank, nullity, pivotCols, freeCols } = run([[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]]);
    expect(rank).toBe(2);
    expect(nullity).toBe(2);
    expect(pivotCols).toHaveLength(2);
    expect(freeCols).toHaveLength(2);
  });

  it("rank + nullity = number of columns, for a battery of matrices", () => {
    const cases: number[][][] = [
      [[1, 2], [2, 4]],
      [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
      [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
      [[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]],
      [[2, 4, 6]],
      [[1], [2], [3]],
    ];
    for (const M of cases) {
      const { rank, nullity } = run(M);
      expect(rank + nullity, JSON.stringify(M)).toBe(M[0].length);
    }
  });

  it("every nullspace basis vector satisfies Av = 0 exactly", () => {
    const cases: number[][][] = [
      [[1, 2], [2, 4]],
      [[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]],
      [[1, 1, 1], [2, 2, 2], [3, 3, 3]],
    ];
    for (const M of cases) {
      const { A, basis } = run(M);
      for (const v of basis) {
        const Av = matVec(A, v);
        expect(Av.every((x) => x.isZero()), JSON.stringify(M)).toBe(true);
      }
    }
  });

  it("basis vectors span the nullspace: each has a 1 in its own free coordinate, 0 in the others' free coordinates", () => {
    const { basis, freeCols } = run([[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]]);
    basis.forEach((v, k) => {
      freeCols.forEach((fc, j) => {
        expect(exact(v[fc])).toBe(k === j ? "1" : "0");
      });
    });
  });

  it("the zero matrix has rank 0 and every standard basis vector in its nullspace", () => {
    const { rank, nullity, basis } = run([[0, 0], [0, 0]]);
    expect(rank).toBe(0);
    expect(nullity).toBe(2);
    expect(basis).toHaveLength(2);
  });

  it("a single non-zero row has rank 1", () => {
    const { rank, nullity } = run([[3, 6, 9]]);
    expect(rank).toBe(1);
    expect(nullity).toBe(2);
  });

  it("reports pivot columns left to right and free columns as the complement", () => {
    const { pivotCols, freeCols } = run([[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]]);
    const all = [...pivotCols, ...freeCols].sort((a, b) => a - b);
    expect(all).toEqual([0, 1, 2, 3]);
    expect(pivotCols.every((c, i) => i === 0 || c > pivotCols[i - 1])).toBe(true);
  });

  it("emits a nullspace step and a verification step when there are free variables", () => {
    const { steps } = run([[1, 2], [2, 4]]);
    expect(steps.some((s: any) => s.state.stepKind === "nullspace")).toBe(true);
    expect(steps.some((s: any) => s.state.stepKind === "nullspace-verify")).toBe(true);
  });

  it("emits the trivial-nullspace message when rank = n", () => {
    const { steps } = run([[1, 0], [0, 1]]);
    expect(steps.some((s: any) => s.title.includes("{0}"))).toBe(true);
  });
});
