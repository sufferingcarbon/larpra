import { describe, expect, it } from "vitest";
import { Fraction } from "../../../utils/fraction";
import { Tableau, toFMatrix, toFVector, exact, identity, matVec } from "../common";
import { forwardPhase, backwardPhase, reduce, snapshotTableau } from "../gaussianElimination";
import { solveLinearSystem, nullspaceFromRREF, parametricLines } from "../linearSystem";
import { MatrixState } from "../../../types/matrix";

const snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">): MatrixState => ({
  operation: "gaussian",
  a: [],
  b: null,
  tableau: null,
  pivots: null,
  solution: null,
  determinant: null,
  inverse: null,
  nullspace: null,
  eigen: null,
  ...over,
});

const solve = (A: number[][], b: number[]) => {
  const steps: any[] = [];
  const info = solveLinearSystem(toFMatrix(A), toFVector(b), snap, steps);
  return { info, steps };
};

describe("Tableau row operations", () => {
  it("swapRows exchanges both blocks", () => {
    const t = new Tableau(toFMatrix([[1, 2], [3, 4]]), toFMatrix([[5], [6]]));
    t.swapRows(0, 1);
    expect(t.left.map((r) => r.map(exact))).toEqual([["3", "4"], ["1", "2"]]);
    expect(t.right!.map((r) => r.map(exact))).toEqual([["6"], ["5"]]);
  });

  it("scaleRow multiplies every entry and rejects a zero factor", () => {
    const t = new Tableau(toFMatrix([[2, 4]]));
    t.scaleRow(0, new Fraction(1, 2));
    expect(t.left[0].map(exact)).toEqual(["1", "2"]);
    expect(() => t.scaleRow(0, Fraction.ZERO)).toThrow();
  });

  it("eliminate subtracts multiplier*source from target in both blocks", () => {
    const t = new Tableau(toFMatrix([[1, 1], [2, 3]]), toFMatrix([[1], [1]]));
    t.eliminate(1, 0, new Fraction(2));
    expect(t.left[1].map(exact)).toEqual(["0", "1"]);
    expect(t.right![1].map(exact)).toEqual(["−1"]);
  });
});

describe("forwardPhase / backwardPhase", () => {
  it("finds pivots leftmost-column-first and emits one step per operation", () => {
    const t = new Tableau(toFMatrix([[0, 2], [1, 1]]));
    const steps: any[] = [];
    const r = forwardPhase(t, { rightLabel: null }, snap, steps);
    expect(r.pivotCols).toEqual([0, 1]);
    // a swap step plus an eliminate step (the eliminate may be a no-op skip if already zero)
    expect(steps.some((s) => s.title.includes("Swap"))).toBe(true);
  });

  it("reports no-pivot columns without throwing", () => {
    const t = new Tableau(toFMatrix([[0, 0, 1], [0, 0, 2]]));
    const steps: any[] = [];
    const r = forwardPhase(t, { rightLabel: null }, snap, steps);
    expect(r.pivotCols).toEqual([2]);
    expect(steps.some((s) => s.state.stepKind === "no-pivot")).toBe(true);
  });

  it("backwardPhase reduces every pivot to 1 and clears above it (RREF)", () => {
    const t = new Tableau(toFMatrix([[2, 4, 2], [0, 1, 3]]));
    const steps: any[] = [];
    const fwd = forwardPhase(t, { rightLabel: null }, snap, steps);
    backwardPhase(t, fwd.pivotCols, fwd.pivotRows, { rightLabel: null }, snap, steps);
    // pivots are 1, and every other entry in a pivot column is 0
    for (const [k, col] of fwd.pivotCols.entries()) {
      expect(t.left[fwd.pivotRows[k]][col].equals(1)).toBe(true);
      for (let i = 0; i < t.rows; i++) if (i !== fwd.pivotRows[k]) expect(t.left[i][col].isZero()).toBe(true);
    }
  });

  it("reduce() runs forward only unless opts.reduced is set", () => {
    const t1 = new Tableau(toFMatrix([[2, 4], [1, 1]]));
    const stepsFwd: any[] = [];
    reduce(t1, { reduced: false, rightLabel: null }, snap, stepsFwd);
    expect(t1.left[0][0].equals(2)).toBe(true); // pivot not scaled to 1

    const t2 = new Tableau(toFMatrix([[2, 4], [1, 1]]));
    const stepsFull: any[] = [];
    reduce(t2, { reduced: true, rightLabel: null }, snap, stepsFull);
    expect(t2.left[0][0].equals(1)).toBe(true); // pivot scaled to 1 in RREF
  });

  it("snapshotTableau renders exact display strings and labels", () => {
    const t = new Tableau(toFMatrix([[1, 2], [3, 4]]), toFMatrix([[5], [6]]));
    const info = snapshotTableau(t, "b", { pivotRow: 0, pivotCol: 0, changedRows: [], zeroedCells: [] }, null);
    expect(info.left).toEqual([["1", "2"], ["3", "4"]]);
    expect(info.right).toEqual([["5"], ["6"]]);
    expect(info.colLabels).toEqual(["x1", "x2"]);
    expect(info.rightLabel).toBe("b");
  });
});

describe("solveLinearSystem: unique solutions", () => {
  it("solves a simple 2×2 system exactly", () => {
    const { info } = solve([[2, 1], [1, -1]], [5, 1]);
    expect(info.kind).toBe("unique");
    expect(info.x).toEqual(["2", "1"]);
  });

  it("solves a 3×3 system requiring a row swap", () => {
    const { info, steps } = solve([[0, 2, 1], [1, 1, 1], [2, 1, -1]], [4, 6, 1]);
    expect(info.kind).toBe("unique");
    expect(steps.some((s: any) => s.state.stepKind === "swap")).toBe(true);
  });

  it("produces exact fractions, never floating-point artifacts", () => {
    const { info } = solve([[3, 2], [1, -1]], [1, 2]);
    expect(info.x).toEqual(["1", "−1"]);
    const { info: info2 } = solve([[7, 3], [2, -5]], [1, 1]);
    // verify Ax = b exactly by re-substitution
    const x = info2.x!.map((s) => (s.includes("/") ? new Fraction(BigInt(s.replace("−", "-").split("/")[0]), BigInt(s.split("/")[1])) : new Fraction(BigInt(s.replace("−", "-")))));
    const A = toFMatrix([[7, 3], [2, -5]]);
    const bBack = matVec(A, x);
    expect(bBack.map((f) => f.toNumber())).toEqual([1, 1]);
  });

  it("1×1 trivial system", () => {
    const { info } = solve([[5]], [15]);
    expect(info.kind).toBe("unique");
    expect(info.x).toEqual(["3"]);
  });
});

describe("solveLinearSystem: no solution", () => {
  it("detects an inconsistent 2×2 system (parallel lines)", () => {
    const { info } = solve([[1, 2], [2, 4]], [3, 5]);
    expect(info.kind).toBe("none");
    expect(info.contradiction).toMatch(/^0 = /);
  });

  it("detects inconsistency in a 3×3 system", () => {
    const { info } = solve([[1, 1, 1], [2, -1, 3], [3, 0, 4]], [6, 2, 7]);
    expect(info.kind).toBe("none");
  });
});

describe("solveLinearSystem: infinitely many solutions", () => {
  it("detects a rank-deficient consistent 2×2 system", () => {
    const { info } = solve([[1, -2], [-2, 4]], [3, -6]);
    expect(info.kind).toBe("many");
    expect(info.basis).toHaveLength(1);
    expect(info.parametric).toHaveLength(2);
  });

  it("detects a 3×3 system with one free variable, and the particular + basis satisfy Ax=b / Av=0", () => {
    const A = [[1, 1, 1], [2, -1, 3], [3, 0, 4]];
    const { info } = solve(A, [6, 2, 8]);
    expect(info.kind).toBe("many");
    const Af = toFMatrix(A);
    const parseF = (s: string) => {
      const clean = s.replace("−", "-");
      const [n, d] = clean.split("/");
      return new Fraction(BigInt(n), BigInt(d ?? "1"));
    };
    const particular = info.particular!.map(parseF);
    const bBack = matVec(Af, particular);
    expect(bBack.map((f) => f.toNumber())).toEqual([6, 2, 8]);
    for (const basisVec of info.basis!) {
      const v = basisVec.map(parseF);
      const zero = matVec(Af, v);
      expect(zero.every((f) => f.isZero())).toBe(true);
    }
  });
});

describe("permutation invariance", () => {
  it("reordering the rows of a consistent system doesn't change the solution", () => {
    const A = [[2, 1], [1, -1]];
    const b = [5, 1];
    const { info: r1 } = solve(A, b);
    const { info: r2 } = solve([A[1], A[0]], [b[1], b[0]]);
    expect(r1.x).toEqual(r2.x);
  });
});

describe("nullspaceFromRREF / parametricLines", () => {
  it("builds one basis vector per free column with 1 in its own coordinate", () => {
    const rref = toFMatrix([[1, 0, 2], [0, 1, -3]]);
    const { freeCols, basis } = nullspaceFromRREF(rref, [0, 1], 3);
    expect(freeCols).toEqual([2]);
    expect(basis[0].map(exact)).toEqual(["−2", "3", "1"]);
  });

  it("parametricLines names free variables and combines pivot variables with signed terms", () => {
    const rref = toFMatrix([[1, 0, 2], [0, 1, -3]]);
    const { basis } = nullspaceFromRREF(rref, [0, 1], 3);
    const lines = parametricLines([Fraction.ZERO, Fraction.ZERO, Fraction.ZERO], basis, [2], 3);
    expect(lines[2]).toContain("free");
    expect(lines[0]).toContain("x1");
  });
});

describe("identity()", () => {
  it("builds the n×n identity as exact Fractions", () => {
    const I = identity(3);
    expect(I.map((r) => r.map(exact))).toEqual([
      ["1", "0", "0"],
      ["0", "1", "0"],
      ["0", "0", "1"],
    ]);
  });
});
