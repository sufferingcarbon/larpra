import { describe, expect, it } from "vitest";
import { GT_CASES } from "./fixtures/groundTruth";
import { matrixExamples } from "../examples";
import { solveMatrix } from "../solve";
import { toFMatrix } from "../common";
import { detValue } from "../determinant";
import { rankAndNullspace } from "../rank";
import { invertMatrix } from "../inverse";
import { solveLinearSystem } from "../linearSystem";
import { solveEigen } from "../eigenvalues";
import { MatrixState } from "../../../types/matrix";
import { Fraction } from "../../../utils/fraction";

/**
 * Cross-validation against tools/matrix_ground_truth.py's independent oracle: a from-scratch exact-Fraction
 * Gauss-Jordan and cofactor expansion written in Python (sharing no code with the TypeScript solver), with
 * numpy.linalg.det/eigvals as an additional float cross-check inside the generator itself. 90 cases: the 20
 * built-in examples plus 70 seeded random matrices across three families (square, rectangular systems, small
 * eigenvalue problems).
 */
const snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">): MatrixState => ({
  operation: "gaussian",
  a: [],
  b: null,
  tableau: null,
  pivots: null,
  solution: null,
  determinant: null,
  inverse: null,
  nullspace: null,
  eigen: null,
  ...over,
});

const parseFrac = (s: string): Fraction => {
  const clean = s.replace("−", "-");
  const [n, d] = clean.split("/");
  return new Fraction(BigInt(n), BigInt(d ?? "1"));
};

/** Same as parseFrac, but for strings from the Python fixture, which use an ASCII "-" rather than "−". */
const parseFracPlain = parseFrac;

describe(`ground truth (${GT_CASES.length} cases)`, () => {
  it("the builtin cases in the fixture are the app's built-in examples, matrix for matrix", () => {
    const builtinSystems = GT_CASES.filter((c) => c.family === "builtin-system");
    const systemExamples = matrixExamples.filter((e) => e.problem.operation === "gaussian");
    expect(builtinSystems.length).toBe(systemExamples.length);
    for (const ex of systemExamples) {
      const c = builtinSystems.find((k) => k.label === ex.name);
      expect(c, ex.name).toBeDefined();
      expect(c!.matrix).toEqual(ex.problem.matrix);
      expect(c!.rhs).toEqual(ex.problem.rhs);
    }

    const builtinMatrixOnly = GT_CASES.filter((c) => c.family === "builtin-matrix");
    const matrixOnlyExamples = matrixExamples.filter((e) => e.problem.operation !== "gaussian");
    expect(builtinMatrixOnly.length).toBe(matrixOnlyExamples.length);
    for (const ex of matrixOnlyExamples) {
      const c = builtinMatrixOnly.find((k) => k.label === ex.name);
      expect(c, ex.name).toBeDefined();
      expect(c!.matrix).toEqual(ex.problem.matrix);
    }
  });

  it("every built-in example in examples.ts is covered by the fixture", () => {
    for (const ex of matrixExamples) {
      const c = GT_CASES.find((k) => k.label === ex.name);
      expect(c, ex.name).toBeDefined();
    }
  });

  for (const c of GT_CASES) {
    it(`rank: ${c.label}`, () => {
      const A = toFMatrix(c.matrix);
      const steps: any[] = [];
      const r = rankAndNullspace(A, snap, steps);
      expect(r.rank, c.label).toBe(c.rank);
      // every basis vector must satisfy A*v = 0 (checked independently of the oracle too)
      for (const v of r.basis) {
        for (const row of A) {
          const s = row.reduce((acc, a, j) => acc.add(a.mul(v[j])), Fraction.ZERO);
          expect(s.isZero(), `${c.label}: A*v != 0`).toBe(true);
        }
      }
    });

    if (c.determinant !== undefined) {
      it(`determinant: ${c.label}`, () => {
        const A = toFMatrix(c.matrix);
        const got = detValue(A);
        const expected = parseFracPlain(c.determinant!);
        expect(got.equals(expected), `${c.label}: got ${got.toString()}, expected ${c.determinant}`).toBe(true);
      });

      it(`invertibility & inverse: ${c.label}`, () => {
        const A = toFMatrix(c.matrix);
        const steps: any[] = [];
        const { singular, inverse } = invertMatrix(A, snap, steps);
        expect(singular, c.label).toBe(c.singular);
        if (!c.singular) {
          expect(inverse).not.toBeNull();
          for (let i = 0; i < inverse!.length; i++)
            for (let j = 0; j < inverse!.length; j++) expect(inverse![i][j].toNumber()).toBeCloseTo(parseFrac(c.inverse![i][j]).toNumber(), 6);
        } else {
          expect(inverse).toBeNull();
        }
      });
    }

    if (c.rhs) {
      it(`Ax=b: ${c.label}`, () => {
        const A = toFMatrix(c.matrix);
        const b = c.rhs!.map((x) => Fraction.from(x));
        const steps: any[] = [];
        const info = solveLinearSystem(A, b, snap, steps);
        expect(info.kind, c.label).toBe(c.solutionKind);
        if (c.solutionKind === "unique") {
          expect(info.x).not.toBeNull();
          for (let i = 0; i < info.x!.length; i++) expect(parseFrac(info.x![i]).toNumber()).toBeCloseTo(parseFrac(c.solutionX![i]).toNumber(), 6);
        }
      });
    }

    if (c.eigenvaluesNumeric && c.matrix.length <= 4) {
      it(`eigenvalues (numeric cross-check): ${c.label}`, () => {
        const A = toFMatrix(c.matrix);
        const steps: any[] = [];
        const info = solveEigen(A, snap, steps);
        const got = info.eigenvalues
          .flatMap((e) => Array(e.multiplicity).fill([e.re, e.im]))
          .sort((a, b) => b[0] - a[0] || b[1] - a[1]);
        expect(got.length, c.label).toBe(c.eigenvaluesNumeric!.length);
        for (let i = 0; i < got.length; i++) {
          expect(got[i][0], `${c.label} re[${i}]`).toBeCloseTo(c.eigenvaluesNumeric![i][0], 3);
          expect(Math.abs(got[i][1]), `${c.label} |im[${i}]|`).toBeCloseTo(Math.abs(c.eigenvaluesNumeric![i][1]), 3);
        }
      });
    }
  }

  it("solveMatrix orchestrator agrees with the direct sub-solver calls for a spot sample", () => {
    for (const c of GT_CASES.filter((k) => k.family.startsWith("builtin")).slice(0, 5)) {
      if (c.rhs) {
        const r = solveMatrix({ operation: "gaussian", matrix: c.matrix, rhs: c.rhs });
        expect(r.status).toBe("solved");
        expect(r.answer.solution?.kind).toBe(c.solutionKind);
      }
    }
  });
});
