import { describe, expect, it } from "vitest";
import { Fraction } from "../../../utils/fraction";
import { toFMatrix, matVec, exact } from "../common";
import { characteristicPolynomial, findRoots, formatComplex, polynomialText, solveEigen } from "../eigenvalues";
import { MatrixState } from "../../../types/matrix";

const snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">): MatrixState => ({
  operation: "eigen",
  a: [],
  b: null,
  tableau: null,
  pivots: null,
  solution: null,
  determinant: null,
  inverse: null,
  nullspace: null,
  eigen: null,
  ...over,
});

const parseF = (s: string): Fraction => {
  const clean = s.replace("−", "-");
  const [n, d] = clean.split("/");
  return new Fraction(BigInt(n), BigInt(d ?? "1"));
};

const solve = (M: number[][]) => {
  const A = toFMatrix(M);
  const steps: any[] = [];
  const info = solveEigen(A, snap, steps);
  return { A, info, steps };
};

describe("characteristicPolynomial (Faddeev–LeVerrier)", () => {
  it("diagonal matrix: (λ-a)(λ-b) expanded", () => {
    const c = characteristicPolynomial(toFMatrix([[2, 0], [0, 3]]));
    expect(c.map((f) => f.toNumber())).toEqual([1, -5, 6]);
  });

  it("upper-triangular 3×3: roots are the diagonal entries", () => {
    const c = characteristicPolynomial(toFMatrix([[2, 1, 0], [0, 2, 0], [0, 0, 3]]));
    expect(c.map((f) => f.toNumber())).toEqual([1, -7, 16, -12]); // (λ-2)^2(λ-3)
  });

  it("rotation matrix: λ² + 1 (purely imaginary roots)", () => {
    const c = characteristicPolynomial(toFMatrix([[0, -1], [1, 0]]));
    expect(c.map((f) => f.toNumber())).toEqual([1, 0, 1]);
  });

  it("defective matrix [[1,1],[0,1]]: (λ-1)²", () => {
    const c = characteristicPolynomial(toFMatrix([[1, 1], [0, 1]]));
    expect(c.map((f) => f.toNumber())).toEqual([1, -2, 1]);
  });

  it("trace and determinant appear as the linear and constant coefficients (2×2 special case)", () => {
    const A = toFMatrix([[3, 1], [2, 4]]);
    const c = characteristicPolynomial(A);
    expect(c[1].toNumber()).toBe(-(3 + 4));
    expect(c[2].toNumber()).toBe(3 * 4 - 1 * 2);
  });

  it("1×1 matrix", () => {
    const c = characteristicPolynomial(toFMatrix([[7]]));
    expect(c.map((f) => f.toNumber())).toEqual([1, -7]);
  });
});

describe("polynomialText", () => {
  it("renders a standard quadratic", () => {
    expect(polynomialText([Fraction.ONE, new Fraction(-5), new Fraction(6)])).toBe("λ² − 5λ + 6");
  });

  it("omits a zero coefficient term", () => {
    expect(polynomialText([Fraction.ONE, Fraction.ZERO, Fraction.ONE])).toBe("λ² + 1");
  });

  it("renders a coefficient of 1 without a leading '1'", () => {
    expect(polynomialText([Fraction.ONE, new Fraction(-1)])).toBe("λ − 1");
  });
});

describe("findRoots", () => {
  it("finds two distinct rational roots", () => {
    const { roots } = findRoots([Fraction.ONE, new Fraction(-5), new Fraction(6)]); // (λ-2)(λ-3)
    expect(roots.map((r) => r.exactText).sort()).toEqual(["2", "3"]);
  });

  it("finds a repeated rational root with multiplicity 2", () => {
    const { roots } = findRoots([Fraction.ONE, new Fraction(-2), Fraction.ONE]); // (λ-1)^2
    expect(roots).toHaveLength(1);
    expect(roots[0].exactText).toBe("1");
    expect(roots[0].multiplicity).toBe(2);
  });

  it("falls back to the quadratic formula for irrational roots", () => {
    const { roots } = findRoots([Fraction.ONE, Fraction.ZERO, new Fraction(-2)]); // λ² - 2 = 0
    expect(roots).toHaveLength(2);
    expect(roots.every((r) => r.exactText === null)).toBe(true);
    expect(roots.map((r) => r.re).sort((a, b) => a - b)[0]).toBeCloseTo(-Math.sqrt(2), 6);
  });

  it("finds complex conjugate roots for a negative discriminant", () => {
    const { roots } = findRoots([Fraction.ONE, Fraction.ZERO, Fraction.ONE]); // λ² + 1 = 0 -> ±i
    expect(roots).toHaveLength(2);
    expect(roots.some((r) => Math.abs(r.re) < 1e-9 && Math.abs(r.im - 1) < 1e-9)).toBe(true);
    expect(roots.some((r) => Math.abs(r.re) < 1e-9 && Math.abs(r.im + 1) < 1e-9)).toBe(true);
  });

  it("cubic with one rational root, deflating to an exact quadratic", () => {
    // (λ-2)(λ²+1) = λ^3 -2λ^2 + λ - 2
    const { roots } = findRoots([Fraction.ONE, new Fraction(-2), Fraction.ONE, new Fraction(-2)]);
    expect(roots.some((r) => r.exactText === "2")).toBe(true);
    expect(roots.some((r) => Math.abs(r.im - 1) < 1e-6)).toBe(true);
    expect(roots.some((r) => Math.abs(r.im + 1) < 1e-6)).toBe(true);
  });

  it("degree-3 with no rational roots falls back to numeric roots", () => {
    // λ³ - λ - 1 = 0, one real irrational root ≈1.3247, two complex
    const { roots, method } = findRoots([Fraction.ONE, Fraction.ZERO, new Fraction(-1), new Fraction(-1)]);
    expect(roots).toHaveLength(3);
    expect(method.some((m) => m.includes("numerically"))).toBe(true);
    const real = roots.find((r) => Math.abs(r.im) < 1e-4);
    expect(real!.re).toBeCloseTo(1.3247, 3);
  });
});

describe("formatComplex", () => {
  it("formats a purely real number without an imaginary part", () => {
    expect(formatComplex(3, 0)).toBe("3");
  });

  it("formats a complex number with a + sign", () => {
    expect(formatComplex(1, 2)).toBe("1 + 2i");
  });

  it("formats a complex number with a − sign for negative imaginary part", () => {
    expect(formatComplex(1, -2)).toBe("1 − 2i");
  });
});

describe("solveEigen: full pipeline", () => {
  it("symmetric 2×2 matrix: real rational eigenvalues, exact eigenvectors satisfying Av=λv", () => {
    const { A, info } = solve([[2, 1], [1, 2]]);
    const texts = info.eigenvalues.map((e) => e.text).sort();
    expect(texts).toEqual(["1", "3"]);
    expect(info.eigenvalues.every((e) => e.exact)).toBe(true);
    info.eigenvectors.forEach((ev) => {
      const lambda = parseF(info.eigenvalues[ev.eigenvalueIndex].text);
      ev.basis.forEach((vStr) => {
        const v = vStr.map(parseF);
        const Av = matVec(A, v);
        const lambdaV = v.map((x) => x.mul(lambda));
        Av.forEach((x, i) => expect(x.equals(lambdaV[i])).toBe(true));
      });
    });
  });

  it("rotation matrix: complex eigenvalues ±i, no exact eigenvectors reported", () => {
    const { info } = solve([[0, -1], [1, 0]]);
    expect(info.eigenvalues).toHaveLength(2);
    expect(info.eigenvalues.every((e) => e.im !== 0)).toBe(true);
    expect(info.eigenvectors.every((ev) => !ev.exact)).toBe(true);
  });

  it("defective matrix: repeated eigenvalue with geometric multiplicity less than algebraic", () => {
    const { info } = solve([[1, 1], [0, 1]]);
    expect(info.eigenvalues).toHaveLength(1);
    expect(info.eigenvalues[0].multiplicity).toBe(2);
    expect(info.eigenvectors[0].geometricMultiplicity).toBe(1);
  });

  it("identity matrix: eigenvalue 1 with multiplicity n and full eigenspace", () => {
    const { info } = solve([[1, 0], [0, 1]]);
    expect(info.eigenvalues).toHaveLength(1);
    expect(info.eigenvalues[0].text).toBe("1");
    expect(info.eigenvalues[0].multiplicity).toBe(2);
    expect(info.eigenvectors[0].geometricMultiplicity).toBe(2);
  });

  it("for symmetric examples, eigenvalues are real, and eigenvectors from distinct eigenvalues are orthogonal", () => {
    // The spectral theorem guarantees eigenvectors from *different* eigenvalues are orthogonal; it does not
    // guarantee that an arbitrary basis chosen within one (repeated) eigenvalue's eigenspace is orthogonal
    // without an extra Gram-Schmidt step, which this module does not perform. So this only checks pairs whose
    // eigenvalues differ.
    const symm2 = [[2, 1], [1, 2]];
    const symm3 = [[2, 1, 1], [1, 2, 1], [1, 1, 2]];
    for (const M of [symm2, symm3]) {
      const { info } = solve(M);
      expect(info.eigenvalues.every((e) => e.im === 0), JSON.stringify(M)).toBe(true);
      const vectors: { lambda: string; v: Fraction[] }[] = [];
      info.eigenvectors.forEach((ev) => {
        const lambda = info.eigenvalues[ev.eigenvalueIndex].text;
        ev.basis.forEach((vStr) => vectors.push({ lambda, v: vStr.map(parseF) }));
      });
      for (let i = 0; i < vectors.length; i++)
        for (let j = i + 1; j < vectors.length; j++) {
          if (vectors[i].lambda === vectors[j].lambda) continue; // same eigenspace: not guaranteed orthogonal
          const dot = vectors[i].v.reduce((s, x, k) => s.add(x.mul(vectors[j].v[k])), Fraction.ZERO);
          expect(dot.isZero(), `${JSON.stringify(M)}: v${i}(λ=${vectors[i].lambda})·v${j}(λ=${vectors[j].lambda})`).toBe(true);
        }
    }
  });

  it("3×3 with one real root and a complex-conjugate pair: only the real one gets an exact eigenvector", () => {
    const { info } = solve([[2, 0, 0], [0, 0, -1], [0, 1, 0]]);
    expect(info.eigenvalues).toHaveLength(3);
    const real = info.eigenvalues.filter((e) => e.im === 0);
    const complex = info.eigenvalues.filter((e) => e.im !== 0);
    expect(real).toHaveLength(1);
    expect(complex).toHaveLength(2);
    const realIdx = info.eigenvalues.indexOf(real[0]);
    const realVec = info.eigenvectors.find((e) => e.eigenvalueIndex === realIdx);
    expect(realVec!.exact).toBe(true);
  });

  it("(A - λI)v = 0 holds exactly for a 3×3 symmetric matrix's eigenvectors", () => {
    const M = [[2, 1, 1], [1, 2, 1], [1, 1, 2]];
    const { A, info } = solve(M);
    info.eigenvectors.forEach((ev) => {
      if (!ev.exact) return;
      const lambda = parseF(info.eigenvalues[ev.eigenvalueIndex].text);
      ev.basis.forEach((vStr) => {
        const v = vStr.map(parseF);
        const Av = matVec(A, v);
        Av.forEach((x, i) => expect(x.equals(v[i].mul(lambda))).toBe(true));
      });
    });
  });

  it("eigenvalue count (with multiplicity) equals the matrix dimension", () => {
    const cases: number[][][] = [[[2, 1], [1, 2]], [[0, -1], [1, 0]], [[1, 1], [0, 1]], [[2, 0, 0], [0, 0, -1], [0, 1, 0]]];
    for (const M of cases) {
      const { info } = solve(M);
      const total = info.eigenvalues.reduce((s, e) => s + e.multiplicity, 0);
      expect(total, JSON.stringify(M)).toBe(M.length);
    }
  });
});

describe("exact()", () => {
  it("displays negative numbers with a real minus sign", () => {
    expect(exact(new Fraction(-3))).toBe("−3");
  });
});
