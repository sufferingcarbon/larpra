import { AlgorithmStep } from "../../types/lp";
import { EigenInfo, EigenvalueEntry, EigenvalueKind, EigenvectorEntry, MatrixState, PolynomialInfo } from "../../types/matrix";
import { Fraction } from "../../utils/fraction";
import { FMatrix, Tableau, exact, gridOf, identity, matMul, varLabels } from "./common";
import { forwardPhase, backwardPhase, snapshotTableau } from "./gaussianElimination";
import { nullspaceFromRREF } from "./linearSystem";

type Snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">) => MatrixState;

const NONE = { pivotRow: null, pivotCol: null, changedRows: [] as number[], zeroedCells: [] as [number, number][] };

/* ------------------------------------------------------------------ characteristic polynomial */

/**
 * Coefficients of det(λI − A) as an exact monic polynomial in λ, highest degree first: [1, c1, c2, ..., cn] means
 * λⁿ + c1λⁿ⁻¹ + ... + cn. Computed by the Faddeev–LeVerrier recursion, which needs only n matrix multiplications and
 * traces — far cheaper than symbolically expanding det(A − λI) — and is exact throughout since every entry stays a
 * Fraction.
 *
 *   M₀ = I,  c₀ = 1
 *   for k = 1..n:  Mₖ₋₁' = A·Mₖ₋₁,  cₖ = −trace(Mₖ₋₁') / k,  Mₖ = Mₖ₋₁' + cₖ·I
 */
export function characteristicPolynomial(A: FMatrix): Fraction[] {
  const n = A.length;
  let M = identity(n);
  const coeffs: Fraction[] = [Fraction.ONE];
  for (let k = 1; k <= n; k++) {
    const AM = matMul(A, M);
    let tr = Fraction.ZERO;
    for (let i = 0; i < n; i++) tr = tr.add(AM[i][i]);
    const ck = tr.div(Fraction.from(k)).neg();
    coeffs.push(ck);
    const I = identity(n);
    M = AM.map((row, i) => row.map((x, j) => x.add(ck.mul(I[i][j]))));
  }
  return coeffs;
}

const supSign = (c: Fraction, isFirst: boolean): string => (isFirst ? (c.isNegative() ? "−" : "") : c.isNegative() ? " − " : " + ");
const SUP: Record<string, string> = { "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶" };
const sup = (n: number) => String(n).split("").map((d) => SUP[d] ?? d).join("");

/** Renders coefficients [1, c1, ..., cn] as "λⁿ + c1λⁿ⁻¹ + ... + cn" in plain text, e.g. "λ² − 5λ + 6". */
export function polynomialText(coeffs: Fraction[]): string {
  const n = coeffs.length - 1;
  const parts: string[] = [];
  coeffs.forEach((c, i) => {
    const deg = n - i;
    if (c.isZero() && !(i === 0 && deg === 0)) return;
    const mag = c.isNegative() ? c.neg() : c;
    const magText = exact(mag);
    let term: string;
    if (deg === 0) term = magText;
    else if (deg === 1) term = magText === "1" ? "λ" : `${magText}λ`;
    else term = magText === "1" ? `λ${sup(deg)}` : `${magText}λ${sup(deg)}`;
    parts.push(`${supSign(c, parts.length === 0)}${term}`);
  });
  return parts.length === 0 ? "0" : parts.join("");
}

export function polynomialInfo(coeffs: Fraction[]): PolynomialInfo {
  return { coefficients: coeffs.map(exact), text: polynomialText(coeffs), degree: coeffs.length - 1 };
}

/* ------------------------------------------------------------------ root finding */

interface Root {
  re: number;
  im: number;
  exactText: string | null; // set when the root can be displayed exactly
  multiplicity: number;
}

/** Divides synthetically (deflates) a monic-leading polynomial by (λ − r), returning the quotient's coefficients. Exact only for rational r. */
function deflateRational(coeffs: Fraction[], r: Fraction): Fraction[] {
  const out: Fraction[] = [coeffs[0]];
  for (let i = 1; i < coeffs.length - 1; i++) out.push(coeffs[i].add(out[i - 1].mul(r)));
  return out; // drops the remainder (assumed zero — caller must have verified r is a root)
}

function evalPoly(coeffs: Fraction[], x: Fraction): Fraction {
  let v = coeffs[0];
  for (let i = 1; i < coeffs.length; i++) v = v.mul(x).add(coeffs[i]);
  return v;
}

/** All divisors (positive and negative) of a small integer, for the rational root test. */
function divisorsOf(n: bigint): bigint[] {
  const a = n < 0n ? -n : n;
  if (a === 0n) return [0n];
  const out: bigint[] = [];
  for (let d = 1n; d * d <= a; d++) {
    if (a % d === 0n) {
      out.push(d, -d);
      if (d !== a / d) out.push(a / d, -(a / d));
    }
  }
  return out;
}

/** Rational Root Theorem candidates p/q for a polynomial with integer (well, exact) coefficients. */
function rationalCandidates(coeffs: Fraction[]): Fraction[] {
  // Scale to a common denominator so coefficients are integers, then apply p | const, q | leading.
  let lcm = 1n;
  const g = (a: bigint, b: bigint): bigint => (b === 0n ? a : g(b, a % b));
  for (const c of coeffs) lcm = (lcm / g(lcm, c.den)) * c.den;
  const ints = coeffs.map((c) => (c.num * (lcm / c.den)));
  const leading = ints[0] < 0n ? -ints[0] : ints[0];
  const constant = ints[ints.length - 1] < 0n ? -ints[ints.length - 1] : ints[ints.length - 1];
  const ps = divisorsOf(constant);
  const qs = divisorsOf(leading);
  const seen = new Map<string, Fraction>();
  for (const p of ps)
    for (const q of qs) {
      if (q === 0n) continue;
      const f = new Fraction(p, q);
      seen.set(`${f.num}/${f.den}`, f);
    }
  return [...seen.values()];
}

/** Finds every exact rational root of `coeffs`, deflating after each, until no more remain or the degree drops below 1. */
function findRationalRoots(coeffs: Fraction[]): { roots: Root[]; remaining: Fraction[] } {
  let cur = coeffs;
  const roots: Root[] = [];
  while (cur.length - 1 >= 1) {
    const candidates = rationalCandidates(cur);
    let found: Fraction | null = null;
    for (const cand of candidates) {
      if (evalPoly(cur, cand).isZero()) {
        found = cand;
        break;
      }
    }
    if (!found) break;
    const existing = roots.find((r) => r.exactText === exact(found!));
    if (existing) existing.multiplicity++;
    else roots.push({ re: found.toNumber(), im: 0, exactText: exact(found), multiplicity: 1 });
    cur = deflateRational(cur, found);
  }
  return { roots, remaining: cur };
}

/** Roots of a monic quadratic λ² + bλ + c via the quadratic formula, exact when the discriminant is a perfect square. */
function quadraticRoots(b: Fraction, c: Fraction): { roots: Root[]; exact: boolean } {
  const disc = b.mul(b).sub(c.mul(4));
  const discNum = disc.toNumber();
  if (discNum >= 0) {
    const sqrtDisc = Math.sqrt(discNum);
    const asRational = tryExactSqrt(disc);
    if (asRational) {
      const r1 = b.neg().add(asRational).div(2);
      const r2 = b.neg().sub(asRational).div(2);
      const roots = mergeRealRoots([r1.toNumber(), r2.toNumber()], [exact(r1), exact(r2)]);
      return { roots, exact: true };
    }
    const r1 = (-b.toNumber() + sqrtDisc) / 2;
    const r2 = (-b.toNumber() - sqrtDisc) / 2;
    return { roots: mergeRealRoots([r1, r2], [null, null]), exact: false };
  }
  const re = -b.toNumber() / 2;
  const im = Math.sqrt(-discNum) / 2;
  return {
    roots: [
      { re, im, exactText: null, multiplicity: 1 },
      { re, im: -im, exactText: null, multiplicity: 1 },
    ],
    exact: false,
  };
}

function mergeRealRoots(values: number[], texts: (string | null)[]): Root[] {
  if (Math.abs(values[0] - values[1]) < 1e-9) return [{ re: values[0], im: 0, exactText: texts[0], multiplicity: 2 }];
  return values.map((v, i) => ({ re: v, im: 0, exactText: texts[i], multiplicity: 1 }));
}

/** If d = disc is a perfect square of a rational, returns that rational; else null. */
function tryExactSqrt(d: Fraction): Fraction | null {
  if (d.isNegative()) return null;
  const num = d.num * d.den; // sqrt(num/den) = sqrt(num*den)/den
  const r = isqrtBig(num);
  if (r * r !== num) return null;
  return new Fraction(r, d.den);
}

function isqrtBig(n: bigint): bigint {
  if (n < 0n) return -1n;
  if (n < 2n) return n;
  let x = n;
  let y = (x + 1n) / 2n;
  while (y < x) {
    x = y;
    y = (x + n / x) / 2n;
  }
  return x;
}

/** Numeric roots (Durand–Kern method) for cubics/quartics with no further rational roots. Returns real/complex pairs. */
function numericRoots(coeffs: Fraction[]): Root[] {
  const n = coeffs.length - 1;
  if (n === 0) return [];
  const c = coeffs.map((x) => x.toNumber());
  type Cx = [number, number];
  const cmul = (a: Cx, b: Cx): Cx => [a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]];
  const csub = (a: Cx, b: Cx): Cx => [a[0] - b[0], a[1] - b[1]];
  const cdiv = (a: Cx, b: Cx): Cx => {
    const d = b[0] * b[0] + b[1] * b[1];
    return [(a[0] * b[0] + a[1] * b[1]) / d, (a[1] * b[0] - a[0] * b[1]) / d];
  };
  const evalC = (x: Cx): Cx => {
    let v: Cx = [c[0], 0];
    for (let i = 1; i < c.length; i++) v = csub(cmul(v, x), [-c[i], 0]);
    return v;
  };
  // Durand-Kerner initial guesses spread on a circle away from 0/1 to avoid symmetric degeneracies.
  let roots: Cx[] = Array.from({ length: n }, (_, k) => {
    const ang = (2 * Math.PI * k) / n + 0.4;
    return [0.4 * Math.cos(ang) + 0.9, 0.4 * Math.sin(ang) + 0.6];
  });
  for (let iter = 0; iter < 500; iter++) {
    const next = roots.map((ri, i) => {
      let denom: Cx = [1, 0];
      for (let j = 0; j < n; j++) if (j !== i) denom = cmul(denom, csub(ri, roots[j]));
      return csub(ri, cdiv(evalC(ri), denom));
    });
    roots = next;
  }
  // cluster near-equal roots (multiplicity) and snap near-real ones
  const rounded = roots.map(([re, im]) => [Math.round(re * 1e7) / 1e7, Math.abs(im) < 1e-6 ? 0 : Math.round(im * 1e7) / 1e7] as Cx);
  const out: Root[] = [];
  for (const [re, im] of rounded) {
    const existing = out.find((r) => Math.abs(r.re - re) < 1e-5 && Math.abs(r.im - im) < 1e-5);
    if (existing) existing.multiplicity++;
    else out.push({ re, im, exactText: null, multiplicity: 1 });
  }
  return out;
}

/** Full root list for a monic polynomial of degree ≤ 4, preferring exact methods and falling back to numeric ones. */
export function findRoots(coeffs: Fraction[]): { roots: Root[]; method: string[] } {
  const method: string[] = [];
  const { roots: rational, remaining } = findRationalRoots(coeffs);
  if (rational.length > 0) {
    method.push(
      `Tried rational candidates (divisors of the constant term over divisors of the leading coefficient) and found ${rational.length === 1 ? "a rational root" : `${rational.length} rational roots`}: ${rational.map((r) => `λ = ${r.exactText}${r.multiplicity > 1 ? ` (×${r.multiplicity})` : ""}`).join(", ")}.`
    );
  }
  const deg = remaining.length - 1;
  if (deg === 0) return { roots: rational, method };
  if (deg === 1) {
    const r = remaining[0].isZero() ? Fraction.ZERO : remaining[1].neg().div(remaining[0]);
    method.push(`The remaining factor is linear: λ = ${exact(r)}.`);
    return { roots: [...rational, { re: r.toNumber(), im: 0, exactText: exact(r), multiplicity: 1 }], method };
  }
  if (deg === 2) {
    const { roots, exact: wasExact } = quadraticRoots(remaining[1], remaining[2]);
    method.push(
      wasExact
        ? `The remaining factor is quadratic; the quadratic formula gives ${roots.map((r) => `λ = ${r.exactText}`).join(", ")}.`
        : roots[0].im !== 0
          ? `The remaining factor is quadratic with a negative discriminant, so its roots are complex: λ = ${roots.map((r) => formatComplex(r.re, r.im)).join(", ")}.`
          : `The remaining factor is quadratic with an irrational discriminant; the quadratic formula gives λ ≈ ${roots.map((r) => r.re.toFixed(4)).join(", ")} (not exact).`
    );
    return { roots: [...rational, ...roots], method };
  }
  // degree 3 or 4 with no more rational roots: numeric
  const num = numericRoots(remaining);
  method.push(
    `The remaining degree-${deg} factor has no further rational roots; solving numerically gives ${num.map((r) => `λ ≈ ${formatComplex(r.re, r.im, 4)}`).join(", ")} (decimal approximation, not exact).`
  );
  return { roots: [...rational, ...num], method };
}

export function formatComplex(re: number, im: number, decimals = 6): string {
  const r = (x: number) => Number(x.toFixed(decimals));
  if (im === 0) return String(r(re));
  const sign = im < 0 ? "−" : "+";
  return `${r(re)} ${sign} ${r(Math.abs(im))}i`;
}

/* ------------------------------------------------------------------ orchestration */

function classify(r: Root, degree1or2Exact: boolean): EigenvalueKind {
  if (r.exactText !== null) return "rational";
  if (r.im !== 0) return degree1or2Exact ? "quadratic-complex" : "numeric-complex";
  return degree1or2Exact ? "quadratic-real" : "numeric-real";
}

/**
 * Full eigenvalue/eigenvector pipeline for n ≤ 4: characteristic polynomial (exact), root-finding (exact where
 * possible, numeric fallback for cubics/quartics with irrational or complex roots), then for each eigenvalue the
 * eigenspace via Gaussian elimination on A − λI. Real eigenvalues get an exact eigenvector basis when λ is exact;
 * complex or approximate eigenvalues are reported without an eigenvector basis (the elimination machinery here
 * is exact-Fraction only, so it cannot represent a complex or irrational shift).
 */
export function solveEigen(A: FMatrix, snap: Snap, steps: AlgorithmStep<MatrixState>[]): EigenInfo {
  const n = A.length;
  const labels = varLabels(n);

  steps.push({
    title: "Form the characteristic polynomial",
    explanation: `Eigenvalues are the roots of det(A − λI) = 0. Computing this by the Faddeev–LeVerrier recursion (A·Mₖ and its trace, k = 1..${n}) keeps every coefficient an exact fraction without expanding a symbolic determinant by hand.`,
    state: snap({ phase: "setup", stepKind: "setup", eigen: { polynomial: null, rootMethod: [], eigenvalues: [], eigenvectors: [], focus: null, shifted: null } }),
    why: "det(A − λI) is a degree-n polynomial in λ whose roots are exactly the values for which A − λI is singular, i.e. for which (A − λI)v = 0 has a non-zero solution v.",
  });

  const coeffs = characteristicPolynomial(A);
  const poly = polynomialInfo(coeffs);

  steps.push({
    title: `Characteristic polynomial: ${poly.text} = 0`,
    explanation: `det(A − λI) = ${poly.text}. Every coefficient is exact.`,
    state: snap({ phase: "polynomial", stepKind: "polynomial", eigen: { polynomial: poly, rootMethod: [], eigenvalues: [], eigenvectors: [], focus: null, shifted: null } }),
  });

  const { roots, method } = findRoots(coeffs);
  const isSmallDegree = n <= 2;
  const eigenvalues: EigenvalueEntry[] = roots
    .map((r) => ({
      text: r.exactText !== null ? r.exactText : formatComplex(r.re, r.im, r.im === 0 ? 6 : 4),
      kind: classify(r, isSmallDegree),
      exact: r.exactText !== null,
      multiplicity: r.multiplicity,
      re: r.re,
      im: r.im,
    }))
    .sort((a, b) => b.re - a.re || b.im - a.im);

  steps.push({
    title: `Solve for the roots`,
    explanation: method.join(" "),
    state: snap({ phase: "eigenvalues", stepKind: "roots", eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors: [], focus: null, shifted: null } }),
    why: "A degree-n polynomial has exactly n roots counted with multiplicity (the Fundamental Theorem of Algebra), possibly complex and possibly repeated.",
  });

  const eigenvectors: EigenvectorEntry[] = [];
  eigenvalues.forEach((ev, idx) => {
    if (!ev.exact || ev.im !== 0) {
      eigenvectors.push({ eigenvalueIndex: idx, exact: false, basis: [], geometricMultiplicity: null });
      steps.push({
        title: `λ = ${ev.text}: eigenvector not computed exactly`,
        explanation: `This eigenvalue is ${ev.im !== 0 ? "complex" : "irrational (only a decimal approximation is available)"}, so solving (A − λI)v = 0 exactly (with Fraction arithmetic) is not possible here. A numerical solver would be needed for its eigenvector.`,
        state: snap({
          phase: "eigenvectors",
          stepKind: "eigenvector-skip",
          eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors: [...eigenvectors], focus: idx, shifted: null },
        }),
      });
      return;
    }
    const lambda = parseExactFraction(ev.text);
    const shifted = A.map((row, i) => row.map((x, j) => (i === j ? x.sub(lambda) : x)));

    steps.push({
      title: `λ = ${ev.text}: form A − λI`,
      explanation: `Subtract ${ev.text} from each diagonal entry of A to form A − λI, then find its nullspace by Gaussian elimination.`,
      state: snap({
        phase: "eigenvectors",
        stepKind: "shift",
        eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors: [...eigenvectors], focus: idx, shifted: gridOf(shifted) },
      }),
    });

    const t = new Tableau(shifted);
    const fwd = forwardPhase(
      t,
      { rightLabel: null },
      (over) => snap({ ...over, eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors: [...eigenvectors], focus: idx, shifted: gridOf(shifted) } }),
      steps
    );
    if (fwd.pivotCols.length > 0) {
      backwardPhase(
        t,
        fwd.pivotCols,
        fwd.pivotRows,
        { rightLabel: null },
        (over) => snap({ ...over, eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors: [...eigenvectors], focus: idx, shifted: gridOf(shifted) } }),
        steps
      );
    }
    const { basis } = nullspaceFromRREF(t.left, fwd.pivotCols, n);
    const geo = basis.length;
    const entry: EigenvectorEntry = { eigenvalueIndex: idx, exact: true, basis: basis.map((v) => v.map(exact)), geometricMultiplicity: geo };
    eigenvectors.push(entry);

    steps.push({
      title: `λ = ${ev.text}: eigenspace has dimension ${geo}`,
      explanation:
        basis.length === 1
          ? `The nullspace of A − λI is spanned by v = (${basis[0].map(exact).join(", ")}). ${geo < ev.multiplicity ? `Algebraic multiplicity is ${ev.multiplicity} but geometric multiplicity is only ${geo}: A is defective for this eigenvalue.` : ""}`
          : basis.length === 0
            ? "Unexpected: the eigenspace is trivial. This should not happen for a genuine root of the characteristic polynomial; please report this input."
            : `The nullspace of A − λI has dimension ${geo}, spanned by ${basis.map((v, k) => `v${k + 1} = (${v.map(exact).join(", ")})`).join(", ")}.`,
      state: snap({
        phase: "eigenvectors",
        stepKind: "eigenvector-result",
        eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors: [...eigenvectors], focus: idx, shifted: gridOf(shifted) },
      }),
      why: "Every non-zero vector in the nullspace of A − λI satisfies Av = λv by definition, so it is an eigenvector for λ.",
    });
  });

  steps.push({
    title: "Summary",
    explanation: `${eigenvalues.length} eigenvalue${eigenvalues.length === 1 ? "" : "s"} (with multiplicity): ${eigenvalues.map((e) => `λ = ${e.text}${e.multiplicity > 1 ? ` (×${e.multiplicity})` : ""}`).join(", ")}.`,
    state: snap({ phase: "summary", stepKind: "summary", eigen: { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors, focus: null, shifted: null } }),
  });

  void labels;
  return { polynomial: poly, rootMethod: method, eigenvalues, eigenvectors, focus: null, shifted: null };
}

function parseExactFraction(s: string): Fraction {
  const clean = s.replace("−", "-");
  const [num, den] = clean.split("/");
  return new Fraction(BigInt(num), den === undefined ? 1n : BigInt(den));
}
