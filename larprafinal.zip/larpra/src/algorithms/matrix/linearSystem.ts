import { AlgorithmStep } from "../../types/lp";
import { MatrixState, SolutionInfo } from "../../types/matrix";
import { Fraction } from "../../utils/fraction";
import { FMatrix, FVector, Tableau, coeffTerm, exact, joinTerms, varLabels, vecOf } from "./common";
import { backwardPhase, forwardPhase, snapshotTableau } from "./gaussianElimination";

type Snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">) => MatrixState;

export interface NullspaceResult {
  freeCols: number[];
  basis: FVector[]; // one length-n vector per free column
}

/**
 * The nullspace basis from a matrix already in REDUCED row echelon form: for each free column f, set x_f = 1, the other
 * free variables to 0, and read each pivot variable off its row (x_pivot = −a[row][f]).
 */
export function nullspaceFromRREF(rref: FMatrix, pivotCols: number[], n: number): NullspaceResult {
  const pivotSet = new Set(pivotCols);
  const freeCols: number[] = [];
  for (let c = 0; c < n; c++) if (!pivotSet.has(c)) freeCols.push(c);
  const basis = freeCols.map((f) => {
    const v: FVector = new Array(n).fill(Fraction.ZERO);
    v[f] = Fraction.ONE;
    pivotCols.forEach((pc, row) => {
      v[pc] = rref[row][f].neg();
    });
    return v;
  });
  return { freeCols, basis };
}

/** Parametric lines for a solution set: "x1 = 2 − 1·t1" style, one per variable, with a free variable named t_k. */
export function parametricLines(particular: FVector, basis: FVector[], freeCols: number[], n: number): string[] {
  const labels = varLabels(n);
  const lines: string[] = [];
  for (let v = 0; v < n; v++) {
    const fi = freeCols.indexOf(v);
    if (fi !== -1) {
      lines.push(`${labels[v]} = t${fi + 1}   (free: t${fi + 1} is any number)`);
      continue;
    }
    const terms: string[] = [];
    if (!particular[v].isZero()) terms.push(exact(particular[v]));
    basis.forEach((b, k) => {
      if (!b[v].isZero()) terms.push(coeffTerm(b[v], `t${k + 1}`));
    });
    lines.push(`${labels[v]} = ${joinTerms(terms)}`);
  }
  return lines;
}

/**
 * Solves Ax = b by Gaussian elimination on [A | b] followed by back-substitution, emitting one step per row operation.
 * `steps` receives everything; the returned SolutionInfo is the classification.
 */
export function solveLinearSystem(A: FMatrix, b: FVector, snap: Snap, steps: AlgorithmStep<MatrixState>[]): SolutionInfo {
  const m = A.length;
  const n = A[0].length;
  const colLabels = varLabels(n);
  const aug = new Tableau(A, b.map((x) => [x]));

  steps.push({
    title: "Set up the augmented matrix [A | b]",
    explanation: `Write the ${m} equation${m === 1 ? "" : "s"} in ${n} unknown${n === 1 ? "" : "s"} as one augmented matrix: the coefficients on the left, the right-hand sides after the bar. Every row operation applied below acts on whole rows of this matrix, so it never changes the solutions.`,
    state: snap({ phase: "setup", stepKind: "setup", tableau: snapshotTableau(aug, "b", { pivotRow: null, pivotCol: null, changedRows: [], zeroedCells: [] }, null) }),
    why: "Gaussian elimination replaces the system by an equivalent one that is easy to read off. Row swaps, scaling a row by a non-zero number, and adding a multiple of one row to another are exactly the operations that preserve the solution set.",
  });

  // Forward elimination to row echelon form; the backward phase (below) then reduces upward so free variables read off cleanly.
  const fwd = forwardPhase(aug, { rightLabel: "b" }, snap, steps);
  const pivotCols = fwd.pivotCols;
  const rank = pivotCols.length;

  steps.push({
    title: `Row echelon form reached — ${rank} pivot${rank === 1 ? "" : "s"}`,
    explanation: `Forward elimination is finished. The pivots are in column${rank === 1 ? "" : "s"} ${pivotCols.map((c) => c + 1).join(", ") || "—"}, so rank(A) = ${rank}.${
      rank < n ? ` Columns ${freeOf(pivotCols, n).map((c) => c + 1).join(", ")} have no pivot: those unknowns are free.` : ""
    }`,
    state: snap({
      phase: "forward",
      stepKind: "echelon",
      tableau: snapshotTableau(aug, "b", { pivotRow: null, pivotCol: null, changedRows: [], zeroedCells: [] }, null),
      pivots: { pivotCols, freeCols: freeOf(pivotCols, n), rank, nullity: n - rank },
    }),
    why: "In row echelon form every pivot sits to the right of the pivot above it and has only zeros below. The number of pivots is the rank, and it is the same however you get there.",
  });

  // Consistency: a row of zeros on the left with a non-zero right-hand side reads 0 = c, which is impossible.
  let contradictionRow = -1;
  for (let i = 0; i < m; i++) {
    if (aug.left[i].every((x) => x.isZero()) && !aug.right![i][0].isZero()) {
      contradictionRow = i;
      break;
    }
  }
  if (contradictionRow !== -1) {
    const c = aug.right![contradictionRow][0];
    const text = `0 = ${exact(c)}`;
    const info: SolutionInfo = { kind: "none", x: null, particular: null, basis: null, parametric: null, contradiction: text, colLabels };
    steps.push({
      title: "Inconsistent: no solution",
      explanation: `Row ${contradictionRow + 1} has all zeros on the left but ${exact(c)} on the right, so it says ${text}. That is impossible for any values of the unknowns, hence the system has no solution.`,
      state: snap({
        phase: "solution",
        stepKind: "no-solution",
        tableau: snapshotTableau(aug, "b", { pivotRow: null, pivotCol: null, changedRows: [contradictionRow], zeroedCells: [] }, null),
        pivots: { pivotCols, freeCols: freeOf(pivotCols, n), rank, nullity: n - rank },
        solution: info,
      }),
      why: "The system is consistent exactly when rank(A) = rank([A | b]). Here appending b raised the rank, which is what a row reading 0 = c (c ≠ 0) means.",
    });
    return info;
  }

  // Back-substitution: Gauss–Jordan, so each pivot variable ends up isolated.
  steps.push({
    title: "Back-substitute (reduce upward)",
    explanation: "Now work from the last pivot upward: scale each pivot row so its pivot is 1, then clear the entries above it. This is back-substitution carried out on the tableau, so each pivot variable ends up alone in its row.",
    state: snap({
      phase: "backward",
      stepKind: "backward-intro",
      tableau: snapshotTableau(aug, "b", { pivotRow: null, pivotCol: null, changedRows: [], zeroedCells: [] }, null),
    }),
  });
  backwardPhase(aug, pivotCols, fwd.pivotRows, { rightLabel: "b" }, snap, steps);

  const rref = aug.left;
  const rhs = aug.right!.map((r) => r[0]);
  const { freeCols, basis } = nullspaceFromRREF(rref, pivotCols, n);

  const particular: FVector = new Array(n).fill(Fraction.ZERO);
  pivotCols.forEach((pc, row) => {
    particular[pc] = rhs[row];
  });

  if (freeCols.length === 0) {
    const info: SolutionInfo = { kind: "unique", x: vecOf(particular), particular: null, basis: null, parametric: null, contradiction: null, colLabels };
    steps.push({
      title: "Unique solution",
      explanation: `Every column has a pivot, so there are no free variables and the solution is unique: ${colLabels.map((l, j) => `${l} = ${exact(particular[j])}`).join(", ")}.`,
      state: snap({
        phase: "solution",
        stepKind: "unique-solution",
        tableau: snapshotTableau(aug, "b", { pivotRow: null, pivotCol: null, changedRows: [], zeroedCells: [] }, null),
        pivots: { pivotCols, freeCols: [], rank, nullity: 0 },
        solution: info,
      }),
      why: "rank(A) = rank([A | b]) = n means the system is consistent and has exactly one solution.",
    });
    return info;
  }

  const parametric = parametricLines(particular, basis, freeCols, n);
  const info: SolutionInfo = {
    kind: "many",
    x: null,
    particular: vecOf(particular),
    basis: basis.map(vecOf),
    parametric,
    contradiction: null,
    colLabels,
  };
  steps.push({
    title: `Infinitely many solutions (${freeCols.length} free variable${freeCols.length === 1 ? "" : "s"})`,
    explanation: `The system is consistent but rank(A) = ${rank} < n = ${n}, so ${freeCols.map((c) => colLabels[c]).join(", ")} ${freeCols.length === 1 ? "is a free variable" : "are free variables"} and may take any value. Setting them to zero gives the particular solution (${vecOf(particular).join(", ")}); every other solution adds a combination of the nullspace basis vectors.`,
    state: snap({
      phase: "solution",
      stepKind: "many-solutions",
      tableau: snapshotTableau(aug, "b", { pivotRow: null, pivotCol: null, changedRows: [], zeroedCells: [] }, null),
      pivots: { pivotCols, freeCols, rank, nullity: freeCols.length },
      solution: info,
    }),
    why: "The general solution of a consistent system is (one particular solution) + (any solution of Ax = 0). The free variables parametrize the second part.",
  });
  return info;
}

const freeOf = (pivotCols: number[], n: number): number[] => {
  const s = new Set(pivotCols);
  return Array.from({ length: n }, (_, c) => c).filter((c) => !s.has(c));
};
