import { AlgorithmStep } from "../../types/lp";
import { InverseInfo, MatrixState } from "../../types/matrix";
import { FMatrix, Tableau, gridOf, identity, isIdentity, matMul } from "./common";
import { backwardPhase, forwardPhase, snapshotTableau } from "./gaussianElimination";

type Snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">) => MatrixState;

const NONE = { pivotRow: null, pivotCol: null, changedRows: [] as number[], zeroedCells: [] as [number, number][] };

export interface InverseResult {
  singular: boolean;
  inverse: FMatrix | null;
}

/**
 * A⁻¹ by Gauss–Jordan elimination on [A | I]: row-reduce the left block to the identity and the same operations turn the
 * right block into A⁻¹. If a column has no pivot, A is singular (rank < n) and no inverse exists — the algorithm says so and
 * stops rather than producing a number.
 */
export function invertMatrix(A: FMatrix, snap: Snap, steps: AlgorithmStep<MatrixState>[]): InverseResult {
  const n = A.length;
  const original = gridOf(A);
  const t = new Tableau(A, identity(n));

  steps.push({
    title: "Set up [A | I]",
    explanation: `Place the ${n} × ${n} identity matrix to the right of A. Whatever row operations turn A into I will simultaneously turn I into A⁻¹.`,
    state: snap({
      phase: "setup",
      stepKind: "setup",
      tableau: snapshotTableau(t, "I", NONE, null),
      inverse: { original, inverse: null, product: null, verified: null },
    }),
    why: "Each row operation is multiplication on the left by an elementary matrix E. If E_k···E₂E₁·A = I, then E_k···E₂E₁ = A⁻¹, and applying the same operations to I produces exactly that product.",
  });

  const fwd = forwardPhase(t, { rightLabel: "I" }, snap, steps);

  if (fwd.pivotCols.length < n) {
    const missing = Array.from({ length: n }, (_, c) => c).filter((c) => !fwd.pivotCols.includes(c));
    steps.push({
      title: "A is singular — no inverse exists",
      explanation: `Elimination found only ${fwd.pivotCols.length} pivot${fwd.pivotCols.length === 1 ? "" : "s"} for ${n} columns (no pivot in column${missing.length === 1 ? "" : "s"} ${missing.map((c) => c + 1).join(", ")}), so rank(A) = ${fwd.pivotCols.length} < ${n} and A cannot be reduced to the identity. A matrix with rank below n has determinant 0 and no inverse.`,
      state: snap({
        phase: "inverse",
        stepKind: "singular",
        tableau: snapshotTableau(t, "I", NONE, null),
        pivots: { pivotCols: fwd.pivotCols, freeCols: missing, rank: fwd.pivotCols.length, nullity: n - fwd.pivotCols.length },
        inverse: { original, inverse: null, product: null, verified: null },
      }),
      why: "A is invertible exactly when it has n pivots, equivalently when det(A) ≠ 0, equivalently when Ax = 0 has only the zero solution.",
    });
    return { singular: true, inverse: null };
  }

  steps.push({
    title: "Forward elimination complete — A is upper triangular",
    explanation: `All ${n} columns have a pivot, so A is invertible. Now clear the entries above each pivot and scale each pivot row to 1, working from the bottom up.`,
    state: snap({ phase: "forward", stepKind: "echelon", tableau: snapshotTableau(t, "I", NONE, null) }),
  });

  backwardPhase(t, fwd.pivotCols, fwd.pivotRows, { rightLabel: "I" }, snap, steps);

  const inv = t.right!;
  const product = matMul(A, inv);
  const verified = isIdentity(t.left) && isIdentity(product);

  steps.push({
    title: "Left block is I — the right block is A⁻¹",
    explanation: "The left block has been reduced to the identity, so the right block is A⁻¹.",
    state: snap({
      phase: "inverse",
      stepKind: "inverse-result",
      tableau: snapshotTableau(t, "A⁻¹", NONE, null),
      inverse: { original, inverse: gridOf(inv), product: null, verified: null },
    }),
  });

  steps.push({
    title: verified ? "Verify: A · A⁻¹ = I" : "Verify: A · A⁻¹ ≠ I",
    explanation: verified
      ? "Multiplying A by the computed inverse, entry by entry in exact fractions, gives the identity matrix — the inverse is confirmed."
      : "Multiplying A by the computed inverse did not give the identity. This should never happen; please report the input.",
    state: snap({
      phase: "inverse",
      stepKind: "inverse-verify",
      tableau: snapshotTableau(t, "A⁻¹", NONE, null),
      inverse: { original, inverse: gridOf(inv), product: gridOf(product), verified },
    }),
    why: "Because every entry is an exact fraction, this check has no rounding tolerance: either every off-diagonal entry is exactly 0 and every diagonal entry exactly 1, or the inverse is wrong.",
  });

  return { singular: false, inverse: inv };
}

export type { InverseInfo };
