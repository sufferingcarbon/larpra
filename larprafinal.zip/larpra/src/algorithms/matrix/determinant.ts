import { CofactorNode, CofactorTerm } from "../../types/matrix";
import { Fraction } from "../../utils/fraction";
import { FMatrix, exact, gridOf, minorMatrix } from "./common";

/**
 * Determinant by cofactor (Laplace) expansion along row 1 — always row 1, so the same matrix always produces the same
 * tree. Every sub-determinant is exact.
 *
 *   1×1:  det = a
 *   2×2:  det = ad − bc
 *   3×3 (at the top level only): a(ei − fh) − b(di − fg) + c(dh − eg)      (the rule of Sarrus in cofactor form)
 *   n×n:  det = Σⱼ a₁ⱼ · Cⱼ,   Cⱼ = (−1)^(1+j) · det(minor₁ⱼ)
 *
 * An entry that is zero contributes nothing, so its minor is not expanded (this is also what keeps a 6×6 matrix with a
 * sparse first row cheap). The tree records exactly the terms that were evaluated.
 */

/** Plain numeric determinant with no tree, used by tests and by the characteristic-polynomial check. */
export function detValue(M: FMatrix): Fraction {
  const n = M.length;
  if (n === 1) return M[0][0];
  if (n === 2) return M[0][0].mul(M[1][1]).sub(M[0][1].mul(M[1][0]));
  let s = Fraction.ZERO;
  for (let j = 0; j < n; j++) {
    if (M[0][j].isZero()) continue;
    const c = detValue(minorMatrix(M, 0, j));
    s = j % 2 === 0 ? s.add(M[0][j].mul(c)) : s.sub(M[0][j].mul(c));
  }
  return s;
}

const paren = (f: Fraction) => (f.isNegative() ? `(${exact(f)})` : exact(f));

/** Builds the full expansion tree for M. `top` enables the 3×3 closed form (only at the root, per the spec). */
export function buildCofactorTree(M: FMatrix, top = true): CofactorNode {
  const n = M.length;
  const matrix = gridOf(M);

  if (n === 1) {
    return { matrix, value: exact(M[0][0]), method: "1x1", formula: `det = ${exact(M[0][0])}`, terms: [] };
  }

  if (n === 2) {
    const [a, b] = M[0];
    const [c, d] = M[1];
    const value = a.mul(d).sub(b.mul(c));
    return {
      matrix,
      value: exact(value),
      method: "2x2",
      formula: `ad − bc = ${paren(a)}·${paren(d)} − ${paren(b)}·${paren(c)} = ${exact(a.mul(d))} − ${paren(b.mul(c))} = ${exact(value)}`,
      terms: [],
    };
  }

  if (n === 3 && top) {
    const [[a, b, c], [d, e, f], [g, h, i]] = M;
    const t1 = a.mul(e.mul(i).sub(f.mul(h)));
    const t2 = b.mul(d.mul(i).sub(f.mul(g)));
    const t3 = c.mul(d.mul(h).sub(e.mul(g)));
    const value = t1.sub(t2).add(t3);
    return {
      matrix,
      value: exact(value),
      method: "3x3-closed-form",
      formula:
        `a(ei − fh) − b(di − fg) + c(dh − eg) = ` +
        `${paren(a)}(${paren(e)}·${paren(i)} − ${paren(f)}·${paren(h)}) − ${paren(b)}(${paren(d)}·${paren(i)} − ${paren(f)}·${paren(g)}) + ${paren(c)}(${paren(d)}·${paren(h)} − ${paren(e)}·${paren(g)}) = ` +
        `${exact(t1)} − ${paren(t2)} + ${paren(t3)} = ${exact(value)}`,
      terms: [
        { col: 0, entry: exact(a), sign: "+", minor: buildCofactorTree(minorMatrix(M, 0, 0), false), contribution: exact(t1) },
        { col: 1, entry: exact(b), sign: "−", minor: buildCofactorTree(minorMatrix(M, 0, 1), false), contribution: exact(t2.neg()) },
        { col: 2, entry: exact(c), sign: "+", minor: buildCofactorTree(minorMatrix(M, 0, 2), false), contribution: exact(t3) },
      ],
    };
  }

  // general expansion along row 1
  const terms: CofactorTerm[] = [];
  let total = Fraction.ZERO;
  const pieces: string[] = [];
  for (let j = 0; j < n; j++) {
    const entry = M[0][j];
    if (entry.isZero()) continue;
    const minor = buildCofactorTree(minorMatrix(M, 0, j), false);
    const minorVal = Fraction.from(parseExact(minor.value));
    const negative = j % 2 === 1;
    const contribution = negative ? entry.mul(minorVal).neg() : entry.mul(minorVal);
    total = total.add(contribution);
    terms.push({ col: j, entry: exact(entry), sign: negative ? "−" : "+", minor, contribution: exact(contribution) });
    pieces.push(`${negative ? "−" : "+"} ${paren(entry)}·${paren(minorVal)}`);
  }
  const shown = pieces.length === 0 ? "0" : pieces.join(" ").replace(/^\+ /, "");
  return {
    matrix,
    value: exact(total),
    method: "expansion",
    formula: `Σ a₁ⱼ·Cⱼ = ${shown} = ${exact(total)}`,
    terms,
  };
}

/** Parses the exact text produced by `exact` (with its Unicode minus) back into a Fraction. */
export function parseExact(s: string): Fraction {
  const clean = s.replace("−", "-");
  const [num, den] = clean.split("/");
  return new Fraction(BigInt(num), den === undefined ? 1n : BigInt(den));
}
