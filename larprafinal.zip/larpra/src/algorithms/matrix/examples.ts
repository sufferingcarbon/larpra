import { MatrixInput } from "../../types/matrix";

export interface MatrixExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: MatrixInput;
}

export const matrixExamples: MatrixExample[] = [
  {
    name: "2×2 system, unique solution",
    difficulty: "beginner",
    description: "A well-behaved 2×2 system. Forward elimination needs a single row operation, then one back-substitution step gives the unique solution.",
    problem: { operation: "gaussian", matrix: [[2, 1], [1, -1]], rhs: [5, 1] },
  },
  {
    name: "2×2 system, no solution",
    difficulty: "beginner",
    description: "Two parallel lines: the coefficient rows are proportional but the right-hand sides are not, so elimination produces a row reading 0 = c with c ≠ 0.",
    problem: { operation: "gaussian", matrix: [[1, 2], [2, 4]], rhs: [3, 5] },
  },
  {
    name: "2×2 system, infinitely many solutions",
    difficulty: "beginner",
    description: "The two equations describe the same line, so after elimination one row vanishes entirely, leaving one free variable and a line of solutions.",
    problem: { operation: "gaussian", matrix: [[1, -2], [-2, 4]], rhs: [3, -6] },
  },
  {
    name: "3×3 system, unique solution",
    difficulty: "intermediate",
    description: "A 3×3 system needing a row swap along the way (the first pivot column starts with a zero), then full back-substitution.",
    problem: { operation: "gaussian", matrix: [[0, 2, 1], [1, 1, 1], [2, 1, -1]], rhs: [4, 6, 1] },
  },
  {
    name: "3×3 system, no solution",
    difficulty: "intermediate",
    description: "Row 3 is the sum of rows 1 and 2 on the left but not on the right, so the system is inconsistent.",
    problem: { operation: "gaussian", matrix: [[1, 1, 1], [2, -1, 3], [3, 0, 4]], rhs: [6, 2, 7] },
  },
  {
    name: "3×3 system, infinitely many solutions",
    difficulty: "intermediate",
    description: "Row 3 is the sum of rows 1 and 2 exactly (including the right-hand side), so the system is consistent but underdetermined: one free variable.",
    problem: { operation: "gaussian", matrix: [[1, 1, 1], [2, -1, 3], [3, 0, 4]], rhs: [6, 2, 8] },
  },
  {
    name: "Determinant of a 2×2 matrix",
    difficulty: "beginner",
    description: "The closed form ad − bc.",
    problem: { operation: "determinant", matrix: [[4, 3], [6, 3]] },
  },
  {
    name: "Determinant of a 3×3 matrix",
    difficulty: "beginner",
    description: "Sarrus' rule in cofactor form: a(ei − fh) − b(di − fg) + c(dh − eg).",
    problem: { operation: "determinant", matrix: [[2, -1, 3], [0, 4, 5], [1, 2, -2]] },
  },
  {
    name: "Determinant of a singular matrix",
    difficulty: "intermediate",
    description: "Row 3 is row 1 plus row 2, so the determinant works out to exactly 0 and the matrix has no inverse.",
    problem: { operation: "determinant", matrix: [[1, 2, 3], [0, 1, 4], [1, 3, 7]] },
  },
  {
    name: "Determinant of a 4×4 matrix",
    difficulty: "difficult",
    description: "A sparse-ish 4×4 matrix, expanded along row 1 down to 3×3 and 2×2 minors.",
    problem: { operation: "determinant", matrix: [[1, 2, 0, 3], [4, 0, 1, 2], [0, 1, 2, 1], [2, 3, 1, 0]] },
  },
  {
    name: "Inverse of a 2×2 matrix",
    difficulty: "beginner",
    description: "Gauss-Jordan elimination on [A | I], verified by computing A · A⁻¹ exactly.",
    problem: { operation: "inverse", matrix: [[4, 7], [2, 6]] },
  },
  {
    name: "Inverse of a 3×3 matrix",
    difficulty: "intermediate",
    description: "A 3×3 invertible matrix; the fractions in the inverse do not simplify to whole numbers.",
    problem: { operation: "inverse", matrix: [[2, 0, 1], [1, 3, 2], [0, 1, 1]] },
  },
  {
    name: "Attempted inverse of a singular matrix",
    difficulty: "intermediate",
    description: "Column 3 is column 1 plus column 2, so elimination cannot produce a pivot in every column — the module says plainly that no inverse exists rather than dividing by zero.",
    problem: { operation: "inverse", matrix: [[1, 2, 3], [0, 1, 1], [2, 3, 5]] },
  },
  {
    name: "Rank and nullspace of a rank-deficient matrix",
    difficulty: "intermediate",
    description: "A 3×4 matrix whose third row is the sum of the first two, so the rank is only 2 and the nullspace has dimension 2.",
    problem: { operation: "rank", matrix: [[1, 2, 1, 3], [2, -1, 0, 1], [3, 1, 1, 4]] },
  },
  {
    name: "Rank of a full-rank rectangular matrix",
    difficulty: "beginner",
    description: "A 3×2 matrix whose two columns are independent: rank 2, nullspace {0}.",
    problem: { operation: "rank", matrix: [[1, 0], [0, 1], [2, 3]] },
  },
  {
    name: "Eigenvalues of a symmetric 2×2 matrix",
    difficulty: "beginner",
    description: "Real, rational eigenvalues with orthogonal eigenvectors — the well-behaved symmetric case.",
    problem: { operation: "eigen", matrix: [[2, 1], [1, 2]] },
  },
  {
    name: "Eigenvalues of a 2×2 rotation matrix (complex)",
    difficulty: "intermediate",
    description: "A 90° rotation has no real eigenvector — its eigenvalues are the purely imaginary ±i.",
    problem: { operation: "eigen", matrix: [[0, -1], [1, 0]] },
  },
  {
    name: "Eigenvalues of a defective 2×2 matrix",
    difficulty: "intermediate",
    description: "A repeated eigenvalue (λ = 1, multiplicity 2) with only a one-dimensional eigenspace — the matrix is defective and cannot be diagonalized.",
    problem: { operation: "eigen", matrix: [[1, 1], [0, 1]] },
  },
  {
    name: "Eigenvalues of a 3×3 matrix",
    difficulty: "difficult",
    description: "One real eigenvalue and a complex-conjugate pair, found by deflating the rational root and applying the quadratic formula to what remains.",
    problem: { operation: "eigen", matrix: [[2, 0, 0], [0, 0, -1], [0, 1, 0]] },
  },
  {
    name: "Eigenvalues of a symmetric 3×3 matrix",
    difficulty: "difficult",
    description: "A symmetric matrix, so all three eigenvalues are guaranteed real — here they come out as three distinct integers.",
    problem: { operation: "eigen", matrix: [[2, 1, 1], [1, 2, 1], [1, 1, 2]] },
  },
];
