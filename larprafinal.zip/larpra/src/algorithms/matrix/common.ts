import { Fraction, frac } from "../../utils/fraction";
import { Grid, MatrixInput, MATRIX_OPERATIONS, RowOp } from "../../types/matrix";

/** The editor and the solvers both cap the size: cofactor expansion is O(n!) and every step is printed. */
export const MAX_DIM = 6;
/** Eigenvalues are computed only for small matrices (the characteristic polynomial has degree n). */
export const MAX_EIGEN_DIM = 4;
/** Entries must be exact decimals of moderate size (the exact layer parses the printed decimal). */
export const MAX_ABS_ENTRY = 1e6;

export type FMatrix = Fraction[][];
export type FVector = Fraction[];

/* ------------------------------------------------------------------ validation */

export function validateMatrix(input: MatrixInput): string[] {
  const errors: string[] = [];
  if (!MATRIX_OPERATIONS.includes(input.operation)) {
    errors.push("Choose an operation.");
    return errors;
  }
  const M = input.matrix;
  const m = M.length;
  if (m < 1 || M[0].length < 1) {
    errors.push("The matrix needs at least one row and one column.");
    return errors;
  }
  const n = M[0].length;
  if (m > MAX_DIM || n > MAX_DIM) errors.push(`The matrix can be at most ${MAX_DIM} × ${MAX_DIM}.`);
  if (M.some((row) => row.length !== n)) {
    errors.push("Every row must have the same number of columns.");
    return errors;
  }

  const check = (v: number[], what: string) => {
    let bad = false;
    let tooBig = false;
    let tooFine = false;
    for (const x of v) {
      if (!Number.isFinite(x)) bad = true;
      else if (Math.abs(x) > MAX_ABS_ENTRY) tooBig = true;
      else if (String(x).includes("e")) tooFine = true;
    }
    if (bad) errors.push(`Every ${what} must be a number (no blank cells).`);
    if (tooBig) errors.push(`${what[0].toUpperCase()}${what.slice(1)}s must be between −${MAX_ABS_ENTRY.toLocaleString("en-US")} and ${MAX_ABS_ENTRY.toLocaleString("en-US")}.`);
    if (tooFine) errors.push(`${what[0].toUpperCase()}${what.slice(1)}s must be ordinary decimals (no scientific notation).`);
    return bad || tooBig || tooFine;
  };
  let broken = false;
  for (const row of M) broken = check(row, "matrix entry") || broken;

  if (input.operation === "gaussian") {
    if (!input.rhs) errors.push("Solving Ax = b needs a right-hand side b.");
    else if (input.rhs.length !== m) errors.push(`The right-hand side b must have ${m} entries (one per row).`);
    else broken = check(input.rhs, "right-hand side entry") || broken;
  }

  const square = m === n;
  if (!broken && !square) {
    if (input.operation === "determinant") errors.push("The determinant needs a square matrix.");
    if (input.operation === "inverse") errors.push("The inverse needs a square matrix.");
    if (input.operation === "eigen") errors.push("Eigenvalues need a square matrix.");
  }
  if (input.operation === "eigen" && square && n > MAX_EIGEN_DIM) {
    errors.push(`Eigenvalues are supported up to ${MAX_EIGEN_DIM} × ${MAX_EIGEN_DIM} (the characteristic polynomial has degree n).`);
  }
  return errors;
}

/* ------------------------------------------------------------------ conversion and display */

export const toFMatrix = (M: number[][]): FMatrix => M.map((row) => row.map((x) => frac(x)));
export const toFVector = (v: number[]): FVector => v.map((x) => frac(x));

export const cloneF = (M: FMatrix): FMatrix => M.map((row) => [...row]);

export function identity(n: number): FMatrix {
  return Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? Fraction.ONE : Fraction.ZERO)));
}

/** Exact text: "3", "-1/3", displayed with a real minus sign. Never rounded. */
export function exact(f: Fraction): string {
  const s = f.den === 1n ? f.num.toString() : `${f.num}/${f.den}`;
  return s.replace("-", "−");
}

export const gridOf = (M: FMatrix): Grid => M.map((row) => row.map(exact));
export const vecOf = (v: FVector): string[] => v.map(exact);

/** "x1, x2, …" labels for n unknowns. */
export const varLabels = (n: number): string[] => Array.from({ length: n }, (_, j) => `x${j + 1}`);

/** A signed coefficient term for algebra text: coeffTerm(−1, "x2") = "−x2", coeffTerm(3/2, "t1") = "3/2·t1". */
export function coeffTerm(c: Fraction, name: string): string {
  if (c.equals(1)) return name;
  if (c.equals(-1)) return `−${name}`;
  return `${exact(c)}·${name}`;
}

/** Joins terms with proper signs: ["x1", "−2x2", "3x3"] → "x1 − 2x2 + 3x3". Empty → "0". */
export function joinTerms(terms: string[]): string {
  const out: string[] = [];
  terms.forEach((t, i) => {
    if (i === 0) out.push(t);
    else if (t.startsWith("−")) out.push(`− ${t.slice(1)}`);
    else out.push(`+ ${t}`);
  });
  return out.length === 0 ? "0" : out.join(" ");
}

/* ------------------------------------------------------------------ row operations */

/**
 * A working tableau: a left block and an optional right block that are transformed in lockstep. Every mutation goes through
 * swapRows / scaleRow / eliminate, each of which returns the RowOp describing exactly what it did — so an algorithm
 * cannot change the matrix without producing a step for it.
 */
export class Tableau {
  left: FMatrix;
  right: FMatrix | null;

  constructor(left: FMatrix, right: FMatrix | null = null) {
    this.left = cloneF(left);
    this.right = right ? cloneF(right) : null;
  }

  get rows(): number {
    return this.left.length;
  }
  get cols(): number {
    return this.left[0].length;
  }

  swapRows(i: number, j: number): RowOp {
    [this.left[i], this.left[j]] = [this.left[j], this.left[i]];
    if (this.right) [this.right[i], this.right[j]] = [this.right[j], this.right[i]];
    return { kind: "swap", i, j };
  }

  /** Row i ← factor · row i (factor must be non-zero). */
  scaleRow(i: number, factor: Fraction): RowOp {
    if (factor.isZero()) throw new Error("Cannot scale a row by zero.");
    this.left[i] = this.left[i].map((x) => x.mul(factor));
    if (this.right) this.right[i] = this.right[i].map((x) => x.mul(factor));
    return { kind: "scale", i, factor: exact(factor) };
  }

  /** Row target ← row target − multiplier · row source. */
  eliminate(target: number, source: number, multiplier: Fraction): RowOp {
    this.left[target] = this.left[target].map((x, k) => x.sub(multiplier.mul(this.left[source][k])));
    if (this.right) this.right[target] = this.right[target].map((x, k) => x.sub(multiplier.mul(this.right![source][k])));
    return { kind: "eliminate", target, source, multiplier: exact(multiplier) };
  }
}

/** The operation in textbook notation, rows numbered from 1: "R2 ← R2 − 2·R1", "R1 ↔ R3", "R2 ← 1/2·R2". */
export function rowOpText(op: RowOp): string {
  switch (op.kind) {
    case "swap":
      return `R${op.i + 1} ↔ R${op.j + 1}`;
    case "scale":
      return `R${op.i + 1} ← ${op.factor === "1" ? "" : `${op.factor}·`}R${op.i + 1}`;
    case "eliminate": {
      const neg = op.multiplier.startsWith("−");
      const mag = neg ? op.multiplier.slice(1) : op.multiplier;
      const coeff = mag === "1" ? "" : `${mag}·`;
      return `R${op.target + 1} ← R${op.target + 1} ${neg ? "+" : "−"} ${coeff}R${op.source + 1}`;
    }
  }
}

/** All rows of the matrix except the given one (used by the cofactor expansion). */
export function minorMatrix(M: FMatrix, row: number, col: number): FMatrix {
  return M.filter((_, i) => i !== row).map((r) => r.filter((_, j) => j !== col));
}

export function matMul(A: FMatrix, B: FMatrix): FMatrix {
  const m = A.length;
  const k = B.length;
  const n = B[0].length;
  return Array.from({ length: m }, (_, i) =>
    Array.from({ length: n }, (_, j) => {
      let s = Fraction.ZERO;
      for (let t = 0; t < k; t++) s = s.add(A[i][t].mul(B[t][j]));
      return s;
    })
  );
}

export function matVec(A: FMatrix, x: FVector): FVector {
  return A.map((row) => row.reduce((s, a, j) => s.add(a.mul(x[j])), Fraction.ZERO));
}

export function isIdentity(M: FMatrix): boolean {
  return M.every((row, i) => row.every((x, j) => (i === j ? x.equals(1) : x.isZero())));
}

export function transpose(M: FMatrix): FMatrix {
  return M[0].map((_, j) => M.map((row) => row[j]));
}
