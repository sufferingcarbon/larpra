import { AlgorithmStep } from "../../types/lp";
import { MatrixState, TableauHighlight, TableauInfo, RowOp } from "../../types/matrix";
import { Fraction } from "../../utils/fraction";
import { Tableau, exact, gridOf, rowOpText, varLabels } from "./common";

/**
 * The reduction engine behind Ax = b, the inverse, and rank/nullspace.
 *
 * Forward phase (→ row echelon form): for each column, left to right, take the topmost non-zero entry at or below the
 * current row as the pivot (exact fractions make "partial pivoting for stability" unnecessary, so the rule is simply
 * "leftmost column, topmost non-zero"), swap it up if needed, then zero every entry below it.
 *
 * Backward phase (→ reduced row echelon form), when requested: scale each pivot to 1, then zero every entry above it.
 *
 * Every mutation is one Tableau call and therefore one emitted step — nothing is changed silently.
 */

export interface ReduceOptions {
  /** Also run the backward phase (Gauss–Jordan) to reach reduced row echelon form. */
  reduced: boolean;
  /** Label for the right block: "b" (solving), "I" (inverse), or null (none). */
  rightLabel: TableauInfo["rightLabel"];
  /** Only pivot within the first `pivotCols` columns (the coefficient block); columns beyond it are just carried along. */
  pivotCols?: number;
}

export interface ReduceResult {
  tableau: Tableau;
  pivotCols: number[];
  pivotRows: number[]; // pivotRows[k] is the row holding the k-th pivot (always k after swaps)
  /** Row swaps + scalings + eliminations actually performed. */
  operations: number;
}

type StepFactory = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">) => MatrixState;

/** Snapshots the tableau as the display structure the UI renders. */
export function snapshotTableau(t: Tableau, rightLabel: TableauInfo["rightLabel"], highlight: TableauHighlight, op: RowOp | null): TableauInfo {
  return {
    left: gridOf(t.left),
    right: t.right ? gridOf(t.right) : null,
    rightLabel: t.right ? rightLabel : null,
    colLabels: varLabels(t.cols),
    highlight,
    op,
    opText: op ? rowOpText(op) : null,
  };
}

/** Builds the shared step emitter for one tableau. */
function makeEmitter(t: Tableau, rightLabel: TableauInfo["rightLabel"], snap: StepFactory, steps: AlgorithmStep<MatrixState>[]) {
  return (title: string, explanation: string, phase: "forward" | "backward", stepKind: string, highlight: TableauHighlight, op: RowOp | null, why?: string) => {
    steps.push({
      title,
      explanation,
      operation: op ? rowOpText(op) : undefined,
      state: snap({ phase, stepKind, tableau: snapshotTableau(t, rightLabel, highlight, op) }),
      ...(why ? { why } : {}),
    });
  };
}

/**
 * Forward phase only: reduces `t` to row echelon form in place, one step per operation.
 * Returns the pivot columns/rows found.
 */
export function forwardPhase(
  t: Tableau,
  opts: Pick<ReduceOptions, "rightLabel" | "pivotCols">,
  snap: StepFactory,
  steps: AlgorithmStep<MatrixState>[]
): Omit<ReduceResult, "tableau"> {
  const m = t.rows;
  const coefCols = opts.pivotCols ?? t.cols;
  const pivotCols: number[] = [];
  const pivotRows: number[] = [];
  let operations = 0;
  const emit = makeEmitter(t, opts.rightLabel, snap, steps);

  let r = 0;
  for (let c = 0; c < coefCols && r < m; c++) {
    // leftmost column, topmost non-zero entry at or below row r
    let p = -1;
    for (let i = r; i < m; i++) {
      if (!t.left[i][c].isZero()) {
        p = i;
        break;
      }
    }
    if (p === -1) {
      emit(
        `Column ${c + 1} has no pivot`,
        `Every entry of column ${c + 1} at or below row ${r + 1} is zero, so there is no pivot in this column. x${c + 1} will be a free variable; move on to column ${c + 2}.`,
        "forward",
        "no-pivot",
        { pivotRow: null, pivotCol: c, changedRows: [], zeroedCells: [] },
        null,
        "A column without a pivot cannot be used to eliminate anything below it. Such columns correspond to free variables — unknowns that can take any value."
      );
      continue;
    }

    if (p !== r) {
      const op = t.swapRows(r, p);
      operations++;
      emit(
        `Swap R${r + 1} and R${p + 1}`,
        `The entry in row ${r + 1}, column ${c + 1} is zero, so row ${p + 1} (the first row below with a non-zero entry in this column) is swapped up to become the pivot row.`,
        "forward",
        "swap",
        { pivotRow: r, pivotCol: c, changedRows: [r, p], zeroedCells: [] },
        op,
        "Swapping two rows never changes the solution set. It is needed only to bring a non-zero number into the pivot position."
      );
    }

    const pv = t.left[r][c];
    pivotCols.push(c);
    pivotRows.push(r);

    for (let i = r + 1; i < m; i++) {
      if (t.left[i][c].isZero()) continue;
      const entry = t.left[i][c]; // read before the row changes
      const mult = entry.div(pv);
      const op = t.eliminate(i, r, mult);
      operations++;
      emit(
        rowOpText(op),
        `Pivot ${exact(pv)} at (${r + 1}, ${c + 1}). The multiplier is ${exact(entry)} ÷ ${exact(pv)} = ${exact(mult)}. Subtracting ${exact(mult)} × row ${r + 1} from row ${i + 1} makes the entry in column ${c + 1} exactly zero.`,
        "forward",
        "eliminate",
        { pivotRow: r, pivotCol: c, changedRows: [i], zeroedCells: [[i, c]] },
        op,
        "Adding a multiple of one row to another never changes the solution set. Choosing the multiplier as (entry ÷ pivot) is exactly what cancels the entry."
      );
    }
    r++;
  }
  return { pivotCols, pivotRows, operations };
}

/**
 * Backward phase only: given a tableau already in row echelon form with the given pivots, scales each pivot to 1 and clears
 * the entries above it (Gauss–Jordan / back-substitution), one step per operation. Returns the number of operations.
 */
export function backwardPhase(
  t: Tableau,
  pivotCols: number[],
  pivotRows: number[],
  opts: Pick<ReduceOptions, "rightLabel">,
  snap: StepFactory,
  steps: AlgorithmStep<MatrixState>[]
): number {
  let operations = 0;
  const emit = makeEmitter(t, opts.rightLabel, snap, steps);
  for (let k = pivotCols.length - 1; k >= 0; k--) {
    const row = pivotRows[k];
    const col = pivotCols[k];
    const pv = t.left[row][col];
    if (!pv.equals(1)) {
      const factor = Fraction.ONE.div(pv);
      const op = t.scaleRow(row, factor);
      operations++;
      emit(
        rowOpText(op),
        `Scale row ${row + 1} by 1 ÷ ${exact(pv)} = ${exact(factor)} so its pivot becomes exactly 1.`,
        "backward",
        "scale",
        { pivotRow: row, pivotCol: col, changedRows: [row], zeroedCells: [] },
        op,
        "Reduced row echelon form requires every pivot to equal 1 with zeros above and below it."
      );
    }
    for (let i = 0; i < row; i++) {
      if (t.left[i][col].isZero()) continue;
      const mult = t.left[i][col];
      const op = t.eliminate(i, row, mult);
      operations++;
      emit(
        rowOpText(op),
        `Subtract ${exact(mult)} × row ${row + 1} from row ${i + 1} to clear the entry above the pivot in column ${col + 1}.`,
        "backward",
        "eliminate-up",
        { pivotRow: row, pivotCol: col, changedRows: [i], zeroedCells: [[i, col]] },
        op
      );
    }
  }
  return operations;
}

/** Both phases in sequence (forward always; backward when `opts.reduced`). */
export function reduce(start: Tableau, opts: ReduceOptions, snap: StepFactory, steps: AlgorithmStep<MatrixState>[]): ReduceResult {
  const fwd = forwardPhase(start, opts, snap, steps);
  let operations = fwd.operations;
  if (opts.reduced) operations += backwardPhase(start, fwd.pivotCols, fwd.pivotRows, opts, snap, steps);
  return { tableau: start, pivotCols: fwd.pivotCols, pivotRows: fwd.pivotRows, operations };
}
