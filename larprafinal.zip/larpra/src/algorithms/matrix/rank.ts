import { AlgorithmStep } from "../../types/lp";
import { MatrixState, NullspaceInfo } from "../../types/matrix";
import { Fraction } from "../../utils/fraction";
import { FMatrix, FVector, Tableau, matVec, varLabels, vecOf } from "./common";
import { backwardPhase, forwardPhase, snapshotTableau } from "./gaussianElimination";
import { nullspaceFromRREF, parametricLines } from "./linearSystem";

type Snap = (over: Partial<MatrixState> & Pick<MatrixState, "phase" | "stepKind">) => MatrixState;

const NONE = { pivotRow: null, pivotCol: null, changedRows: [] as number[], zeroedCells: [] as [number, number][] };

export interface RankResult {
  rank: number;
  nullity: number;
  pivotCols: number[];
  freeCols: number[];
  /** Nullspace basis, one exact vector per free column. */
  basis: FVector[];
  /** A in reduced row echelon form. */
  rref: FMatrix;
}

/**
 * Rank and nullspace of A (m × n): row-reduce A to reduced row echelon form; the pivot columns give the rank, the non-pivot
 * columns are the free variables, and each free variable contributes one basis vector of the nullspace. rank + nullity = n.
 */
export function rankAndNullspace(A: FMatrix, snap: Snap, steps: AlgorithmStep<MatrixState>[]): RankResult {
  const n = A[0].length;
  const labels = varLabels(n);
  const t = new Tableau(A);

  steps.push({
    title: "Row-reduce A",
    explanation: `The rank is the number of pivots in a row echelon form of A, and the nullspace is the set of solutions of Ax = 0. Both come from the same row reduction, so reduce the ${A.length} × ${n} matrix A.`,
    state: snap({ phase: "setup", stepKind: "setup", tableau: snapshotTableau(t, null, NONE, null) }),
    why: "Row operations do not change the row space or the solutions of Ax = 0, so the rank and nullspace of the reduced matrix are those of A.",
  });

  const fwd = forwardPhase(t, { rightLabel: null }, snap, steps);
  const { pivotCols } = fwd;
  const rank = pivotCols.length;
  const freeCols = Array.from({ length: n }, (_, c) => c).filter((c) => !pivotCols.includes(c));

  steps.push({
    title: `Row echelon form — rank ${rank}`,
    explanation: `There ${rank === 1 ? "is 1 pivot" : `are ${rank} pivots`}, in column${rank === 1 ? "" : "s"} ${pivotCols.map((c) => c + 1).join(", ") || "—"}. So rank(A) = ${rank}.${
      freeCols.length > 0 ? ` The remaining column${freeCols.length === 1 ? "" : "s"} (${freeCols.map((c) => c + 1).join(", ")}) ${freeCols.length === 1 ? "has" : "have"} no pivot: ${freeCols.map((c) => labels[c]).join(", ")} ${freeCols.length === 1 ? "is a free variable" : "are free variables"}.` : " Every column has a pivot, so there are no free variables."
    }`,
    state: snap({
      phase: "rank",
      stepKind: "rank",
      tableau: snapshotTableau(t, null, NONE, null),
      pivots: { pivotCols, freeCols, rank, nullity: n - rank },
    }),
    why: "rank(A) is the number of pivots — equivalently the dimension of the column space and of the row space.",
  });

  if (rank > 0) {
    steps.push({
      title: "Reduce to reduced row echelon form",
      explanation: "Scale each pivot row so the pivot is 1 and clear the entries above every pivot. The free variables can then be read straight off the rows.",
      state: snap({ phase: "backward", stepKind: "backward-intro", tableau: snapshotTableau(t, null, NONE, null) }),
    });
    backwardPhase(t, pivotCols, fwd.pivotRows, { rightLabel: null }, snap, steps);
  }

  const { basis } = nullspaceFromRREF(t.left, pivotCols, n);

  steps.push({
    title: "Identify pivot and free columns",
    explanation: `Pivot columns: ${pivotCols.map((c) => labels[c]).join(", ") || "none"}. Free columns: ${freeCols.map((c) => labels[c]).join(", ") || "none"}. rank + nullity = ${rank} + ${freeCols.length} = ${n} = number of columns.`,
    state: snap({
      phase: "rank",
      stepKind: "pivot-summary",
      tableau: snapshotTableau(t, null, NONE, null),
      pivots: { pivotCols, freeCols, rank, nullity: freeCols.length },
    }),
    why: "The rank–nullity theorem: for an m × n matrix, rank(A) + nullity(A) = n. Each column is either a pivot column or a free column.",
  });

  const nullspace: NullspaceInfo = {
    freeCols,
    basis: basis.map(vecOf),
    parametric: freeCols.length === 0 ? [] : parametricLines(new Array(n).fill(Fraction.ZERO), basis, freeCols, n),
    colLabels: labels,
  };

  if (freeCols.length === 0) {
    steps.push({
      title: "Nullspace is {0}",
      explanation: "There are no free variables, so the only solution of Ax = 0 is x = 0. The nullspace contains only the zero vector and its dimension (the nullity) is 0.",
      state: snap({
        phase: "nullspace",
        stepKind: "nullspace",
        tableau: snapshotTableau(t, null, NONE, null),
        pivots: { pivotCols, freeCols, rank, nullity: 0 },
        nullspace,
      }),
    });
  } else {
    steps.push({
      title: `Nullspace basis (${freeCols.length} vector${freeCols.length === 1 ? "" : "s"})`,
      explanation: `For each free variable, set it to 1 and the other free variables to 0, then solve for the pivot variables from the reduced rows. That gives one basis vector per free variable: ${basis.map((b, k) => `v${k + 1} = (${vecOf(b).join(", ")})`).join("; ")}. Every solution of Ax = 0 is a combination ${basis.map((_, k) => `t${k + 1}·v${k + 1}`).join(" + ")}.`,
      state: snap({
        phase: "nullspace",
        stepKind: "nullspace",
        tableau: snapshotTableau(t, null, NONE, null),
        pivots: { pivotCols, freeCols, rank, nullity: freeCols.length },
        nullspace,
      }),
      why: "The basis vectors are linearly independent (each has a 1 in its own free coordinate and 0 in the other free coordinates) and span the solution set, so together they form a basis of the nullspace.",
    });

    const check = basis.every((v) => matVec(A, v).every((x) => x.isZero()));
    steps.push({
      title: check ? "Verify: A·v = 0 for every basis vector" : "Verify: some A·v ≠ 0",
      explanation: check
        ? `Multiplying A by each basis vector, exactly, gives the zero vector: ${basis.map((b, k) => `A·v${k + 1} = (${vecOf(matVec(A, b)).join(", ")})`).join("; ")}.`
        : "A basis vector did not satisfy Ax = 0. This should never happen; please report the input.",
      state: snap({
        phase: "nullspace",
        stepKind: "nullspace-verify",
        tableau: snapshotTableau(t, null, NONE, null),
        pivots: { pivotCols, freeCols, rank, nullity: freeCols.length },
        nullspace,
      }),
    });
  }

  return { rank, nullity: freeCols.length, pivotCols, freeCols, basis, rref: t.left };
}
