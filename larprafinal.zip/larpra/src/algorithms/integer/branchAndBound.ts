import { AlgorithmStep } from "../../types/lp";
import {
  BnBBranch,
  BnBCounters,
  BnBIncumbent,
  BnBNode,
  BnBStepState,
  DEFAULT_IP_OPTIONS,
  IPOptions,
  IPProblem,
  IPResult,
  IPStatus,
} from "../../types/integer";
import { Fraction } from "../../utils/fraction";
import { solveLPExact } from "../lp/simplex";
import {
  boundsText,
  effectiveTypes,
  exact,
  floorFrac,
  hasIntegralObjective,
  isIntegral,
  nodeLPProblem,
  quickEqualityInfeasibility,
  rootBounds,
} from "./common";
import { validateIP } from "./standardize";

interface Internal {
  /** Parent's LP objective as a maximization "score" (min problems are negated). null: root / feasibility nodes. */
  parentScore: Fraction | null;
}

interface Incumbent {
  score: Fraction;
  value: Fraction;
  values: Fraction[];
  nodeId: number;
}

/**
 * Exact Branch & Bound for integer, binary and mixed-integer linear programs.
 *
 * Every subproblem is the original LP plus bound rows (x ≤ ⌊v⌋ or x ≥ ⌊v⌋+1); it is solved with the same exact
 * two-phase simplex the LP module uses (`solveLPExact`), and "is this an integer?" is asked of exact Fractions —
 * never of floats. The search is deterministic, so the same problem always yields the same tree and steps.
 *
 * One step is recorded per visited node. The steps carry only counters; the tree itself lives in `result.tree`
 * (each node knows the step it was created and resolved at, so the UI can redraw the tree as of any step), and a
 * node's simplex tableaus are regenerated on demand with `nodeProblem` + `solveSimplex`.
 *
 * If the root LP is unbounded the integer problem is unbounded if it has any integer-feasible point (true for
 * rational data) and infeasible otherwise, so the search switches to a feasibility check (objective 0) to decide.
 */
export function solveIP(problem: IPProblem, partial: Partial<IPOptions> = {}): IPResult {
  const options: IPOptions = { ...DEFAULT_IP_OPTIONS, ...partial };
  options.nodeLimit = Math.max(1, Math.floor(options.nodeLimit));
  const errors = validateIP(problem);
  if (errors.length > 0) throw new Error(errors.join(" "));

  const names = problem.variables;
  const types = effectiveTypes(problem);
  const intIdx = names.map((_, j) => j).filter((j) => types[j] !== "continuous");
  const sign = problem.sense === "max" ? 1 : -1;
  const boundWord = sign === 1 ? "≤" : "≥";
  const score = (f: Fraction) => (sign === 1 ? f : f.neg());
  const fromScore = (s: Fraction) => (sign === 1 ? s : s.neg());
  const integralObjective = hasIntegralObjective(problem);
  const tighten = options.tightenIntegerObjective && integralObjective;
  const eff = (s: Fraction) => (tighten ? new Fraction(floorFrac(s)) : s);

  const nodes: BnBNode[] = [];
  const internal: Internal[] = [];
  const steps: AlgorithmStep<BnBStepState>[] = [];
  const counters: BnBCounters = { lpSolved: 0, branched: 0, integerSolutions: 0, prunedInfeasible: 0, prunedBound: 0, prunedInherited: 0, open: 0 };
  const open: number[] = [];
  const notes: string[] = [];
  let incumbent = null as Incumbent | null;
  let visited = 0;
  let mode: "optimize" | "feasibility" = "optimize";

  const fmt = (f: Fraction) => f.toDisplay();
  const solText = (vals: Fraction[]) => names.map((nm, j) => `${nm} = ${fmt(vals[j])}`).join(", ");
  const branchText = (b: BnBBranch) => `${b.variable} ${b.direction === "<=" ? "≤" : "≥"} ${b.bound}`;

  const newNode = (
    parentId: number | null,
    branch: BnBBranch | null,
    lb: number[],
    ub: (number | null)[],
    purpose: "optimize" | "feasibility",
    parentScore: Fraction | null,
    createdAtStep: number
  ): BnBNode => {
    const node: BnBNode = {
      id: nodes.length,
      parentId,
      depth: parentId === null ? 0 : nodes[parentId].depth + 1,
      purpose,
      branch,
      lb,
      ub,
      status: "open",
      parentBound: parentScore ? exact(fromScore(parentScore)) : null,
      lpStatus: null,
      lpValue: null,
      lpSolution: null,
      branchVariable: null,
      children: [],
      order: null,
      createdAtStep,
      resolvedAtStep: null,
    };
    nodes.push(node);
    internal.push({ parentScore });
    if (parentId !== null) nodes[parentId].children.push(node.id);
    return node;
  };

  const bestOpenScore = (): Fraction | null => {
    if (mode === "feasibility") return null;
    let best: Fraction | null = null;
    for (const id of open) {
      const ps = internal[id].parentScore;
      if (ps !== null && (best === null || ps.gt(best))) best = ps;
    }
    return best;
  };

  const snapshot = (kind: BnBStepState["kind"], nodeId: number | null): BnBStepState => {
    counters.open = open.length;
    const inc: BnBIncumbent | null = incumbent
      ? { value: exact(incumbent.value), solution: incumbent.values.map(exact), nodeId: incumbent.nodeId }
      : null;
    const bb = bestOpenScore();
    return { kind, nodeId, counters: { ...counters }, incumbent: mode === "optimize" ? inc : null, bestBound: bb ? exact(fromScore(bb)) : null };
  };

  const selectNext = (): number => {
    if (mode === "feasibility" || options.nodeSelection === "depth-first") return open.pop()!;
    let bestIdx = 0;
    for (let i = 1; i < open.length; i++) {
      const a = internal[open[i]].parentScore;
      const b = internal[open[bestIdx]].parentScore;
      const better = b === null ? false : a === null ? true : a.gt(b) || (a.equals(b) && open[i] < open[bestIdx]);
      if (better) bestIdx = i;
    }
    return open.splice(bestIdx, 1)[0];
  };

  const chooseBranchVariable = (values: Fraction[]): number => {
    const fractional = intIdx.filter((j) => !isIntegral(values[j]));
    if (options.branching === "lowest-index") return fractional[0];
    // most fractional: fractional part closest to 1/2 (ties → lowest index)
    let best = fractional[0];
    let bestDist: Fraction | null = null;
    for (const j of fractional) {
      const fp = values[j].sub(new Fraction(floorFrac(values[j])));
      const d = fp.sub(new Fraction(1n, 2n));
      const dist = d.isNegative() ? d.neg() : d;
      if (bestDist === null || dist.lt(bestDist)) {
        bestDist = dist;
        best = j;
      }
    }
    return best;
  };

  const modeLabel = (nd: BnBNode) => (nd.purpose === "feasibility" ? "feasibility check" : "LP relaxation");

  // ---------------------------------------------------------------- set-up step
  const typeSummary = (["integer", "binary", "continuous"] as const)
    .map((t) => {
      const vs = names.filter((_, j) => types[j] === t);
      return vs.length ? `${vs.join(", ")} ${t}` : null;
    })
    .filter(Boolean)
    .join("; ");
  if (options.tightenIntegerObjective && !integralObjective) {
    notes.push("Integer-objective tightening was requested but does not apply here (some objective coefficient is fractional or sits on a continuous variable), so it was ignored.");
  }
  if (types.includes("continuous")) notes.push("Continuous variables are never branched on — only integer and binary variables are forced to whole numbers.");
  steps.push({
    title: "Set-up: bound with the LP relaxation, then branch",
    explanation:
      `Branch & Bound first drops the integrality requirement to get the LP relaxation — an optimistic bound (Z ${boundWord} its value for every integer solution). ` +
      `If the LP optimum has a fractional integer variable, the problem is split into two subproblems that cut that value off; ` +
      `integer-feasible LP optima become the incumbent; a subproblem is pruned when it is infeasible or its bound cannot beat the incumbent. ` +
      `Variables: ${typeSummary}. Node selection: ${options.nodeSelection === "depth-first" ? "depth-first (down branch first)" : "best bound first"}; ` +
      `branching variable: ${options.branching === "lowest-index" ? "lowest-index fractional" : "most fractional"}` +
      `${tighten ? "; bounds are tightened because Z can only take integer values" : ""}.`,
    why: "The LP relaxation contains every integer-feasible point, so its optimum can only be as good as or better than the true integer optimum. That is what makes it a valid bound for pruning.",
    state: snapshot("start", null),
  });

  const rb = rootBounds(problem);
  newNode(null, null, rb.lb, rb.ub, "optimize", null, 0);
  open.push(0);

  // ---------------------------------------------------------------- one node
  type Outcome = "done" | "unbounded";
  const processNode = (id: number): Outcome => {
    const nd = nodes[id];
    const it = internal[id];
    const stepIndex = steps.length;
    nd.order = ++visited;
    nd.resolvedAtStep = stepIndex;
    const P = `P${id}`;
    const where = nd.branch ? ` (${branchText(nd.branch)})` : id === 0 ? " (the root: original constraints, integrality dropped)" : "";
    const path = boundsText(problem, nd.lb, nd.ub);

    // 1. Skip without solving when the parent's bound already cannot beat the incumbent.
    if (nd.purpose === "optimize" && incumbent && it.parentScore && !eff(it.parentScore).gt(incumbent.score)) {
      nd.status = "pruned-inherited";
      nd.lpStatus = "skipped";
      counters.prunedInherited++;
      const pb = eff(it.parentScore);
      steps.push({
        title: `${P} — pruned without solving`,
        explanation:
          `${P}${where} can do no better than its parent's bound, Z ${boundWord} ${fmt(fromScore(pb))}` +
          `${tighten ? " (rounded because Z can only take integer values)" : ""}, ` +
          `and the incumbent is already Z = ${fmt(incumbent.value)}. Nothing in this subproblem can beat the incumbent, so it is skipped without solving its LP.`,
        why: "A subproblem only adds constraints to its parent, so its LP optimum is never better than the parent's. If the parent's bound already fails to beat the incumbent, the child's cannot either.",
        state: snapshot("node", id),
      });
      return "done";
    }

    // 2. Solve the node's LP with the exact simplex engine.
    const lp = solveLPExact(nodeLPProblem(problem, nd.lb, nd.ub, nd.purpose));
    counters.lpSolved++;
    nd.lpStatus = lp.status;
    const ctx = `${P}${where}${nd.depth > 1 && path ? `, all bounds: ${path}` : ""}`;

    if (lp.status === "infeasible") {
      nd.status = "infeasible";
      counters.prunedInfeasible++;
      steps.push({
        title: `${P} — infeasible`,
        explanation: `${ctx}: the ${modeLabel(nd)} has no feasible point, so no integer point satisfies these bounds either. This branch is dead — pruned.`,
        why: "Adding bounds only shrinks the feasible region. If even the LP relaxation is empty, the integer problem below it is empty too.",
        state: snapshot("node", id),
      });
      return "done";
    }
    if (lp.status === "unbounded") {
      nd.status = "unbounded";
      steps.push({
        title: `${P} — LP relaxation is unbounded`,
        explanation:
          `${ctx}: the LP relaxation can improve forever. The integer problem is then unbounded if it has at least one integer-feasible point, and infeasible if it has none. ` +
          `To decide, the search now replaces the objective with 0 and looks for any integer-feasible point.`,
        why: "For data that are rational numbers (all larpra inputs), an integer program with an unbounded LP relaxation is either infeasible or unbounded — nothing in between. Feasibility is therefore the only question left.",
        state: snapshot("node", id),
      });
      return "unbounded";
    }

    const values = lp.values!;
    const obj = lp.objective!;
    nd.lpValue = exact(obj);
    nd.lpSolution = values.map(exact);
    const s = score(obj);
    const zText = nd.purpose === "feasibility" ? "" : `Z = ${fmt(obj)}, `;
    const head = `${ctx}: ${modeLabel(nd)} solved — ${zText}${solText(values)}.`;

    // 3. Bound test.
    if (nd.purpose === "optimize" && incumbent && !eff(s).gt(incumbent.score)) {
      nd.status = "pruned-bound";
      counters.prunedBound++;
      steps.push({
        title: `${P} — pruned by bound`,
        explanation:
          `${head} Its bound Z ${boundWord} ${fmt(fromScore(eff(s)))}${tighten && !eff(s).equals(s) ? " (rounded because Z can only take integer values)" : ""} ` +
          `is no better than the incumbent Z = ${fmt(incumbent.value)}, so no integer solution inside it can beat the incumbent — pruned.`,
        why: "Every integer point in this subproblem is feasible for its LP, so none can score better than the LP optimum. If that optimum does not beat the incumbent, the whole subtree can be discarded safely.",
        state: snapshot("node", id),
      });
      return "done";
    }

    // 4. Integer feasible?
    const fractional = intIdx.filter((j) => !isIntegral(values[j]));
    if (fractional.length === 0) {
      nd.status = "integer";
      counters.integerSolutions++;
      const previous = incumbent;
      incumbent = { score: s, value: obj, values, nodeId: id };
      if (nd.purpose === "feasibility") {
        steps.push({
          title: `${P} — integer-feasible point found`,
          explanation: `${head} Every integer variable is a whole number, so this is a feasible point of the original problem. Since the LP relaxation was unbounded, the integer problem is unbounded (it improves forever along the same direction).`,
          why: "Rational-data theorem: if an integer program has a feasible point and its LP relaxation is unbounded, the integer program itself is unbounded.",
          state: snapshot("node", id),
        });
      } else {
        steps.push({
          title: `${P} — new incumbent, Z = ${fmt(obj)}`,
          explanation:
            `${head} Every integer variable is a whole number, so this is a feasible integer solution` +
            `${previous ? `, better than the previous incumbent Z = ${fmt(previous.value)}` : " — the first one found"}. ` +
            `It becomes the incumbent; any subproblem whose bound cannot beat Z = ${fmt(obj)} can now be pruned.`,
          why: "An integer-feasible LP optimum is optimal for its whole subproblem (the LP was already the best it could be), so there is nothing below it to explore.",
          state: snapshot("node", id),
        });
      }
      return "done";
    }

    // 5. Branch.
    const j = chooseBranchVariable(values);
    const v = values[j];
    const fl = floorFrac(v);
    const down = Number(fl);
    const up = Number(fl) + 1;
    nd.status = "branched";
    nd.branchVariable = names[j];
    counters.branched++;
    const downUb = nd.ub.slice();
    downUb[j] = down;
    const upLb = nd.lb.slice();
    upLb[j] = up;
    const pScore = nd.purpose === "optimize" ? s : null;
    const a = newNode(id, { variable: names[j], direction: "<=", bound: down, fractionalValue: exact(v) }, nd.lb.slice(), downUb, nd.purpose, pScore, stepIndex);
    const b = newNode(id, { variable: names[j], direction: ">=", bound: up, fractionalValue: exact(v) }, upLb, nd.ub.slice(), nd.purpose, pScore, stepIndex);
    open.push(b.id, a.id); // depth-first pops the last element → the "down" child first
    steps.push({
      title: `${P} — branch on ${names[j]} = ${fmt(v)}`,
      explanation:
        `${head} ${names[j]} must be an integer but is ${fmt(v)}${fractional.length > 1 ? ` (${fractional.length} integer variables are fractional; ${options.branching === "lowest-index" ? "the lowest-indexed" : "the most fractional"} was chosen)` : ""}. ` +
        `Split into P${a.id}: ${names[j]} ≤ ${down} and P${b.id}: ${names[j]} ≥ ${up}. ` +
        `No integer lies strictly between ${down} and ${up}, so no integer solution is lost.`,
      why: `Both children exclude the fractional value ${fmt(v)} while keeping every integer point, so the LP optimum of each child is strictly different and the search makes progress.`,
      state: snapshot("node", id),
    });
    return "done";
  };

  // ---------------------------------------------------------------- main loop
  let stoppedByLimit = false;
  let witnessFound = false;
  let provenByDivisibility = false;
  while (open.length > 0) {
    if (visited >= options.nodeLimit) {
      stoppedByLimit = true;
      break;
    }
    const id = selectNext();
    const outcome = processNode(id);
    if (outcome === "unbounded") {
      mode = "feasibility";
      open.length = 0;
      const violation = quickEqualityInfeasibility(problem);
      if (violation) {
        provenByDivisibility = true;
        steps.push({
          title: "Infeasible — an integer divisibility argument",
          explanation:
            `The LP relaxation is unbounded, so the search would normally switch to hunting for any integer-feasible point. ` +
            `But ${violation[0].toLowerCase()}${violation.slice(1)} No amount of further branching can find a point that row rules out, ` +
            `so the integer problem is infeasible without visiting any more subproblems.`,
          why: "Every node this search creates only adds bound rows (x ≤ k or x ≥ k) on top of the original constraints, so if one original row already has no integer solution on its own, none of its descendants can have one either — no finite search is even needed.",
          state: snapshot("node", null),
        });
        continue; // open.length is 0, so the loop ends here with mode "feasibility" and witnessFound false
      }
      const root = nodes[0];
      const f = newNode(0, null, root.lb.slice(), root.ub.slice(), "feasibility", null, steps.length - 1);
      open.push(f.id);
      continue;
    }
    if (mode === "feasibility" && nodes[id].status === "integer") {
      witnessFound = true;
      break;
    }
  }

  // ---------------------------------------------------------------- outcome
  let status: IPStatus;
  if (mode === "feasibility") status = witnessFound ? "unbounded" : stoppedByLimit ? "node_limit" : "infeasible";
  else status = stoppedByLimit ? "node_limit" : incumbent ? "optimal" : "infeasible";

  const inc = incumbent;
  const result: IPResult = {
    status,
    steps,
    tree: nodes,
    options,
    varTypes: types,
    rootRelaxation: {
      status: nodes[0].lpStatus === "optimal" || nodes[0].lpStatus === "infeasible" || nodes[0].lpStatus === "unbounded" ? nodes[0].lpStatus : "infeasible",
      ...(nodes[0].lpValue !== null ? { value: nodes[0].lpValue, solution: nodes[0].lpSolution! } : {}),
    },
    notes,
  };

  const tally = `${visited} subproblem${visited === 1 ? "" : "s"} visited, ${counters.lpSolved} LP${counters.lpSolved === 1 ? "" : "s"} solved, ${counters.prunedInfeasible} infeasible, ${counters.prunedBound + counters.prunedInherited} pruned by bound, ${counters.integerSolutions} integer solution${counters.integerSolutions === 1 ? "" : "s"} found`;

  if (status === "optimal" && inc) {
    result.optimalValue = inc.value.toNumber();
    result.optimalValueExact = exact(inc.value);
    result.optimalSolution = Object.fromEntries(names.map((nm, j) => [nm, inc.values[j].toNumber()]));
    result.optimalSolutionExact = Object.fromEntries(names.map((nm, j) => [nm, exact(inc.values[j])]));
    result.incumbentNodeId = inc.nodeId;
    const rootValue = nodes[0].lpValue;
    steps.push({
      title: `Optimal: Z* = ${fmt(inc.value)}`,
      explanation:
        `No open subproblems remain (${tally}). Every branch ended in an integer solution, an infeasible LP, or a bound that could not beat Z = ${fmt(inc.value)}, ` +
        `so no integer solution is better than the incumbent: ${solText(inc.values)}. ` +
        (rootValue !== null && rootValue !== exact(inc.value) ? `(The LP relaxation alone promised Z ${boundWord} ${fmt(Fractionize(rootValue))}.)` : "The LP relaxation bound is met exactly."),
      state: snapshot("finish", inc.nodeId),
    });
  } else if (status === "infeasible") {
    const rootFeasible = nodes[0].lpStatus === "optimal";
    steps.push({
      title: "Infeasible",
      explanation: provenByDivisibility
        ? "Ruled out above by an integer divisibility argument on one of the original constraints — see the previous step."
        : mode === "feasibility"
        ? `The LP relaxation is unbounded, but the feasibility search (${tally}) exhausted every branch without finding an integer-feasible point, so the integer problem has no solution.`
        : rootFeasible
          ? `The LP relaxation is feasible, but every branch (${tally}) ended without an integer-feasible point: no integer solution satisfies all the constraints.`
          : `Even the LP relaxation has no feasible point, so no integer solution exists.`,
      state: snapshot("finish", null),
    });
  } else if (status === "unbounded") {
    const w = incumbent as Incumbent;
    result.feasiblePoint = Object.fromEntries(names.map((nm, j) => [nm, exact(w.values[j])]));
    steps.push({
      title: "Unbounded",
      explanation: `The LP relaxation is unbounded and the feasibility search found the integer-feasible point ${solText(w.values)} (${tally}), so the integer problem is unbounded: its objective can be improved without limit.`,
      state: snapshot("finish", w.nodeId),
    });
  } else {
    // node_limit
    const bb = bestOpenScore();
    if (mode === "optimize" && bb) result.bestBound = exact(fromScore(bb));
    if (mode === "optimize" && incumbent) {
      const w = incumbent as Incumbent;
      result.optimalValue = w.value.toNumber();
      result.optimalValueExact = exact(w.value);
      result.optimalSolution = Object.fromEntries(names.map((nm, j) => [nm, w.values[j].toNumber()]));
      result.optimalSolutionExact = Object.fromEntries(names.map((nm, j) => [nm, exact(w.values[j])]));
      result.incumbentNodeId = w.nodeId;
    }
    const inconclusive =
      mode === "feasibility"
        ? "The LP relaxation is unbounded and the feasibility search stopped before finding an integer point or proving there is none — the outcome (unbounded or infeasible) is undetermined."
        : incumbent
          ? `The best integer solution found so far is Z = ${fmt((incumbent as Incumbent).value)}${bb ? `; no solution better than Z ${boundWord} ${fmt(fromScore(bb))} can exist` : ""}. It is NOT proven optimal.`
          : "No integer-feasible solution has been found yet, and the search has not proven that none exists.";
    steps.push({
      title: `Stopped at the node limit (${options.nodeLimit})`,
      explanation: `The search was cut off after ${visited} subproblems with ${open.length} still open (${tally}). ${inconclusive} Raise the node limit to continue.`,
      state: snapshot("finish", null),
    });
    notes.push(inconclusive);
  }
  return result;
}

/** Parse an exact "a/b" or "a" string back into a Fraction (for display in the closing step). */
function Fractionize(s: string): Fraction {
  const [n, d] = s.split("/");
  return new Fraction(BigInt(n), d ? BigInt(d) : 1n);
}
