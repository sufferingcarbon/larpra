import { Fraction } from "../../utils/fraction";
import { BnBNode, IPProblem, VarType } from "../../types/integer";
import { LPConstraint, LPProblem } from "../../types/lp";

export const MAX_ABS = 1e12;

export function effectiveTypes(p: IPProblem): VarType[] {
  return p.variables.map((_, i) => p.varTypes?.[i] ?? "integer");
}

/** ⌊f⌋ as a BigInt (correct for negatives too — BigInt division truncates toward zero). */
export function floorFrac(f: Fraction): bigint {
  let q = f.num / f.den;
  if (f.num % f.den !== 0n && f.num < 0n) q -= 1n;
  return q;
}

export const isIntegral = (f: Fraction) => f.den === 1n;

/** Exact text: "3", "-7/4". Used for every machine-readable value; Fraction.toDisplay is for screens. */
export const exact = (f: Fraction) => (f.den === 1n ? f.num.toString() : `${f.num}/${f.den}`);

export function rootBounds(p: IPProblem): { lb: number[]; ub: (number | null)[] } {
  const types = effectiveTypes(p);
  return { lb: p.variables.map(() => 0), ub: types.map((t) => (t === "binary" ? 1 : null)) };
}

function unit(n: number, j: number): number[] {
  return Array.from({ length: n }, (_, k) => (k === j ? 1 : 0));
}

/** The bound rows a node adds on top of the original constraints: x ≥ lb where lb > 0, x ≤ ub where ub is set. */
export function boundConstraints(names: string[], lb: number[], ub: (number | null)[]): LPConstraint[] {
  const rows: LPConstraint[] = [];
  names.forEach((name, j) => {
    if (lb[j] > 0) rows.push({ coeffs: unit(names.length, j), relation: ">=", rhs: lb[j], label: `${name} ≥ ${lb[j]}` });
    const u = ub[j];
    if (u !== null) rows.push({ coeffs: unit(names.length, j), relation: "<=", rhs: u, label: `${name} ≤ ${u}` });
  });
  return rows;
}

/** The LP relaxation solved at a node: original constraints + the node's bounds (objective 0 for a feasibility check). */
export function nodeLPProblem(problem: IPProblem, lb: number[], ub: (number | null)[], purpose: "optimize" | "feasibility"): LPProblem {
  return {
    sense: problem.sense,
    variables: problem.variables,
    objective: purpose === "feasibility" ? problem.variables.map(() => 0) : problem.objective,
    constraints: [...problem.constraints, ...boundConstraints(problem.variables, lb, ub)],
  };
}

/** Same thing, from a recorded tree node — what the UI calls to replay a node's simplex tableaus. */
export function nodeProblem(problem: IPProblem, node: BnBNode): LPProblem {
  return nodeLPProblem(problem, node.lb, node.ub, node.purpose);
}

/** "x1 ≤ 3, x2 ≥ 1" — the bounds a node has beyond the root's. Empty string at the root. */
export function boundsText(problem: IPProblem, lb: number[], ub: (number | null)[]): string {
  const root = rootBounds(problem);
  const parts: string[] = [];
  problem.variables.forEach((name, j) => {
    if (lb[j] > root.lb[j]) parts.push(`${name} ≥ ${lb[j]}`);
    if (ub[j] !== null && ub[j] !== root.ub[j]) parts.push(`${name} ≤ ${ub[j]}`);
  });
  return parts.join(", ");
}

/** True when Z can only take integer values: every variable with a non-zero coefficient is integer-typed with an integer coefficient. */
export function hasIntegralObjective(problem: IPProblem): boolean {
  const types = effectiveTypes(problem);
  return problem.objective.every((c, j) => c === 0 || (Number.isInteger(c) && types[j] !== "continuous"));
}

function gcd(a: number, b: number): number {
  while (b) [a, b] = [b, a % b];
  return a;
}

/**
 * A necessary condition for integer feasibility that plain Branch & Bound cannot always discover in finite
 * time on its own: if an equality row's every variable is integer-typed with an integer coefficient, the
 * left-hand side can only ever take multiples of gcd(coefficients). When that gcd does not divide the
 * right-hand side, no assignment of integers to those variables — under any other constraints — can satisfy
 * the row, so the whole problem is infeasible. (Example: 2x1 − 2x2 = 1 has an unbounded LP relaxation along
 * x1 = x2 + 0.5, but the line contains no integer point at all — gcd(2,2)=2 does not divide 1 — so a search
 * that only ever tightens bounds and re-solves LPs would branch forever without ever seeing an infeasible
 * LP. This check catches that case up front instead of running the search to a node limit.)
 * Returns a human-readable explanation of the violated row, or null if no row rules the problem out this way.
 */
export function quickEqualityInfeasibility(problem: IPProblem): string | null {
  const types = effectiveTypes(problem);
  for (const c of problem.constraints) {
    if (c.relation !== "=") continue;
    const idx = c.coeffs.map((_, j) => j).filter((j) => c.coeffs[j] !== 0);
    if (idx.length === 0) continue;
    if (idx.some((j) => types[j] === "continuous")) continue; // a continuous variable can hit any real value
    if (!Number.isInteger(c.rhs) || idx.some((j) => !Number.isInteger(c.coeffs[j]))) continue; // only a clean test applies
    const g = idx.reduce((acc, j) => gcd(acc, Math.abs(c.coeffs[j])), 0);
    if (g > 0 && c.rhs % g !== 0) {
      const label = c.label ?? "An equality constraint";
      const lhs = idx.map((j) => `${c.coeffs[j]}·${problem.variables[j]}`).join(" + ");
      return (
        `${label} (${lhs} = ${c.rhs}) has all-integer coefficients with greatest common divisor ${g}, ` +
        `which does not divide ${c.rhs}. The left-hand side can only ever equal a multiple of ${g} for integer ` +
        `${idx.map((j) => problem.variables[j]).join(", ")}, so this row alone rules out every integer point.`
      );
    }
  }
  return null;
}
