import { IPProblem, VAR_TYPES } from "../../types/integer";
import { MAX_ABS } from "./common";

/** Everything wrong with the problem, phrased for the person typing it in. Empty array = valid. */
export function validateIP(problem: IPProblem): string[] {
  const errors: string[] = [];
  const n = problem.variables.length;
  if (n === 0) return ["Add at least one variable."];
  const bad = (x: number) => !Number.isFinite(x);
  const huge = (x: number) => Math.abs(x) > MAX_ABS;

  if (problem.objective.length !== n) errors.push("The objective needs one coefficient per variable.");
  else if (problem.objective.some(bad)) errors.push("Objective coefficients must be numbers.");
  else if (problem.objective.some(huge)) errors.push("Objective coefficients must be between −1e12 and 1e12.");

  if (problem.varTypes) {
    if (problem.varTypes.length !== n) errors.push("Each variable needs a type (integer, binary or continuous).");
    else if (problem.varTypes.some((t) => !VAR_TYPES.includes(t))) errors.push("Variable types must be integer, binary or continuous.");
  }

  problem.constraints.forEach((c, i) => {
    const k = i + 1;
    if (c.coeffs.length !== n) errors.push(`Constraint ${k} needs ${n} coefficients.`);
    else if (c.coeffs.some(bad)) errors.push(`Constraint ${k} has a missing coefficient.`);
    else if (c.coeffs.every((v) => v === 0)) errors.push(`Constraint ${k} has all-zero coefficients.`);
    else if (c.coeffs.some(huge)) errors.push(`Constraint ${k} has a coefficient beyond ±1e12.`);
    if (bad(c.rhs)) errors.push(`Constraint ${k} is missing a right-hand-side value.`);
    else if (huge(c.rhs)) errors.push(`Constraint ${k} has a right-hand side beyond ±1e12.`);
  });
  return errors;
}
