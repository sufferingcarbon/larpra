import { IPProblem } from "../../types/integer";
import data from "./examples.data.json";

export interface IPExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: IPProblem;
}

/**
 * The built-in examples live in examples.data.json so the Python ground-truth generator
 * (tools/ip_ground_truth.py) reads exactly the same problems the app offers.
 */
export const ipExamples: IPExample[] = data as unknown as IPExample[];
