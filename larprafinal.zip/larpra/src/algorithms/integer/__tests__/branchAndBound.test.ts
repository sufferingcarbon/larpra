import { describe, expect, it } from "vitest";
import { solveIP } from "../branchAndBound";
import { validateIP } from "../standardize";
import { nodeProblem, boundsText } from "../common";
import { solveSimplex } from "../../lp/simplex";
import { IPProblem } from "../../../types/integer";

const P = (over: Partial<IPProblem> & Pick<IPProblem, "variables" | "objective" | "constraints" | "sense">): IPProblem => over;

describe("hand-calculated textbook examples", () => {
  it("Taha's classic 2-variable IP: optimum (3,2), Z=23, tree matches the textbook trace", () => {
    // Taha, "Operations Research", the worked branch-and-bound example: max 5x1+4x2 s.t. x1+x2<=5, 10x1+6x2<=45.
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [5, 4],
      varTypes: ["integer", "integer"],
      constraints: [
        { coeffs: [1, 1], relation: "<=", rhs: 5 },
        { coeffs: [10, 6], relation: "<=", rhs: 45 },
      ],
    });
    const r = solveIP(p);
    expect(r.status).toBe("optimal");
    expect(r.optimalValueExact).toBe("23");
    expect(r.optimalSolutionExact).toEqual({ x1: "3", x2: "2" });
    expect(r.rootRelaxation.value).toBe("95/4");
    // Textbook tree: root branches on x1 (=15/4); the x1<=3 branch is integer immediately (incumbent);
    // the x1>=4 branch branches again on x2 (=5/6) into an infeasible node and a pruned node.
    expect(r.tree).toHaveLength(5);
    expect(r.tree[0].branchVariable).toBe("x1");
    const directChildren = r.tree[0].children.map((id) => r.tree[id]);
    const leftChild = directChildren.find((n) => n.branch?.direction === "<=")!;
    const rightChild = directChildren.find((n) => n.branch?.direction === ">=")!;
    expect(leftChild.status).toBe("integer");
    expect(leftChild.lpValue).toBe("23");
    expect(rightChild.branchVariable).toBe("x2");
    expect(rightChild.children.map((id) => r.tree[id].status).sort()).toEqual(["infeasible", "pruned-bound"]);
  });

  it("0-1 knapsack: LP relaxation takes a fraction of an item, integer optimum differs", () => {
    // max 8x1+11x2+6x3+4x4 s.t. 5x1+7x2+4x3+3x4<=14, binary. Well-known: LP picks x2 fully + fraction of x1/x3;
    // integer optimum is x2=x3=x4=1 (value 21), which beats taking x1 instead of x4.
    const p = P({
      sense: "max",
      variables: ["x1", "x2", "x3", "x4"],
      objective: [8, 11, 6, 4],
      varTypes: ["binary", "binary", "binary", "binary"],
      constraints: [{ coeffs: [5, 7, 4, 3], relation: "<=", rhs: 14 }],
    });
    const lpRelax = solveSimplex(p);
    expect(lpRelax.status === "optimal" || lpRelax.status === "alternate_optima").toBe(true);
    // fractional at the LP relaxation (not already integral) — otherwise this wouldn't exercise branching
    const fractional = p.variables.some((v) => {
      const val = lpRelax.optimalSolution![v];
      return Math.abs(val - Math.round(val)) > 1e-9;
    });
    expect(fractional).toBe(true);
    const r = solveIP(p);
    expect(r.status).toBe("optimal");
    expect(r.optimalValueExact).toBe("21");
    expect(r.optimalSolutionExact).toEqual({ x1: "0", x2: "1", x3: "1", x4: "1" });
    expect(r.optimalValueExact).not.toBe(lpRelax.optimalValue?.toString());
  });
});

describe("bounded, unbounded, and infeasible classification", () => {
  it("bounded: reports optimal with exact rational objective when the answer is fractional-looking but exact", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [3, 2],
      varTypes: ["integer", "integer"],
      constraints: [
        { coeffs: [3, 3], relation: "<=", rhs: 10 },
        { coeffs: [1, 0], relation: "<=", rhs: 5 },
      ],
    });
    const r = solveIP(p);
    expect(r.status).toBe("optimal");
    expect(Number.isFinite(r.optimalValue)).toBe(true);
  });

  it("unbounded LP relaxation + an integer-feasible ray ⇒ integer program is unbounded", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, 2],
      varTypes: ["integer", "integer"],
      constraints: [{ coeffs: [1, -1], relation: "<=", rhs: 3 }],
    });
    const r = solveIP(p);
    expect(r.status).toBe("unbounded");
    expect(r.feasiblePoint).toBeDefined();
    // The witness must actually satisfy the constraint exactly.
    const asNumber = (s: string) => {
      const [n, d] = s.split("/");
      return d ? Number(n) / Number(d) : Number(n);
    };
    const x1 = asNumber(r.feasiblePoint!.x1 as string);
    const x2 = asNumber(r.feasiblePoint!.x2 as string);
    expect(x1 - x2).toBeLessThanOrEqual(3 + 1e-9);
  });

  it("unbounded LP relaxation but NO integer point anywhere ⇒ infeasible, decided instantly by a divisibility argument", () => {
    // The line 2x1 - 2x2 = 1 is unbounded, but every point on it is a half-integer offset from every
    // other — gcd(2,2)=2 never divides 1, so no integer point exists at all. Without the divisibility
    // check, plain Branch & Bound could branch on this forever (every bounded sub-segment is still
    // fractional at both endpoints), so this also confirms the search terminates immediately.
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, 0],
      varTypes: ["integer", "integer"],
      constraints: [{ coeffs: [2, -2], relation: "=", rhs: 1 }],
    });
    const r = solveIP(p, { nodeLimit: 500 });
    expect(r.status).toBe("infeasible");
    expect(r.tree).toHaveLength(1); // only the root LP was solved; no feasibility-search nodes were created
  });

  it("infeasible: LP relaxation itself has no feasible point", () => {
    const p = P({
      sense: "max",
      variables: ["x1"],
      objective: [1],
      varTypes: ["integer"],
      constraints: [
        { coeffs: [1], relation: "<=", rhs: 2 },
        { coeffs: [1], relation: ">=", rhs: 5 },
      ],
    });
    const r = solveIP(p);
    expect(r.status).toBe("infeasible");
    expect(r.rootRelaxation.status).toBe("infeasible");
  });

  it("infeasible: LP relaxation feasible, but no integer point (classic 3x+3y in (4,5) gap)", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, 1],
      varTypes: ["integer", "integer"],
      constraints: [
        { coeffs: [3, 3], relation: ">=", rhs: 4 },
        { coeffs: [3, 3], relation: "<=", rhs: 5 },
      ],
    });
    const r = solveIP(p);
    expect(r.status).toBe("infeasible");
    expect(r.rootRelaxation.status).toBe("optimal");
  });

  it("node limit: stops early and reports node_limit rather than a false answer", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8"],
      objective: [22, 24, 27, 29, 32, 35, 38, 41],
      varTypes: Array(8).fill("binary"),
      constraints: [{ coeffs: [12, 14, 17, 19, 22, 25, 28, 31], relation: "<=", rhs: 80 }],
    });
    const r = solveIP(p, { nodeLimit: 2 });
    expect(r.status).toBe("node_limit");
    expect(r.tree.length).toBeGreaterThanOrEqual(2);
  });
});

describe("mixed-integer and continuous variables", () => {
  it("never branches on a continuous variable even when it is fractional at the optimum", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2", "x3"],
      objective: [6, 5, 4],
      varTypes: ["integer", "integer", "continuous"],
      constraints: [
        { coeffs: [2, 3, 1], relation: "<=", rhs: 13 },
        { coeffs: [0, 0, 1], relation: "<=", rhs: 2.5 },
      ],
    });
    const r = solveIP(p);
    expect(r.status).toBe("optimal");
    expect(Number.isInteger(r.optimalSolution!.x1)).toBe(true);
    expect(Number.isInteger(r.optimalSolution!.x2)).toBe(true);
    // x3 is allowed to be fractional (2.5, its own bound)
    for (const node of r.tree) expect(node.branchVariable).not.toBe("x3");
  });

  it("binary variables get an implicit x<=1 bound with no explicit constraint needed", () => {
    const p = P({
      sense: "max",
      variables: ["x1"],
      objective: [1],
      varTypes: ["binary"],
      constraints: [{ coeffs: [1], relation: "<=", rhs: 100 }],
    });
    const r = solveIP(p);
    expect(r.status).toBe("optimal");
    expect(r.optimalValueExact).toBe("1");
  });
});

describe("determinism and strategy invariance", () => {
  const p: IPProblem = {
    sense: "max",
    variables: ["x1", "x2", "x3"],
    objective: [16, 22, 12],
    varTypes: ["binary", "binary", "binary"],
    constraints: [{ coeffs: [5, 7, 4], relation: "<=", rhs: 10 }],
  };

  it("same problem, same options ⇒ byte-identical tree every run", () => {
    const r1 = solveIP(p);
    const r2 = solveIP(p);
    expect(JSON.stringify(r1.tree)).toBe(JSON.stringify(r2.tree));
    expect(r1.steps.length).toBe(r2.steps.length);
  });

  it("depth-first vs best-bound agree on the optimum but may visit a different number of nodes", () => {
    const df = solveIP(p, { nodeSelection: "depth-first" });
    const bb = solveIP(p, { nodeSelection: "best-bound" });
    expect(df.optimalValueExact).toBe(bb.optimalValueExact);
  });

  it("lowest-index vs most-fractional branching agree on the optimum", () => {
    const a = solveIP(p, { branching: "lowest-index" });
    const b = solveIP(p, { branching: "most-fractional" });
    expect(a.optimalValueExact).toBe(b.optimalValueExact);
  });
});

describe("tree and step invariants", () => {
  const p: IPProblem = {
    sense: "min",
    variables: ["x1", "x2", "x3"],
    objective: [1, 1, 1],
    varTypes: ["integer", "integer", "integer"],
    constraints: [{ coeffs: [3, 5, 7], relation: "=", rhs: 29 }],
  };
  const r = solveIP(p);

  it("every non-root node's bound is inherited exactly from its parent's LP value", () => {
    for (const node of r.tree) {
      if (node.parentId === null) continue;
      const parent = r.tree[node.parentId];
      if (parent.lpValue !== null) expect(node.parentBound).toBe(parent.lpValue);
    }
  });

  it("children partition the parent's fractional variable with no integer gap", () => {
    for (const node of r.tree) {
      if (node.status !== "branched") continue;
      const [a, b] = node.children.map((id) => r.tree[id]);
      const down = [a, b].find((n) => n.branch!.direction === "<=")!;
      const up = [a, b].find((n) => n.branch!.direction === ">=")!;
      expect(up.branch!.bound).toBe(down.branch!.bound + 1);
    }
  });

  it("nodeProblem() reproduces exactly the bounds recorded on the node (round-trips through the LP engine)", () => {
    for (const node of r.tree) {
      if (node.lpStatus !== "optimal") continue;
      const lp = solveSimplex(nodeProblem(p, node));
      expect(lp.optimalValue).toBeCloseTo(Number(node.lpValue!.includes("/")
        ? Number(node.lpValue!.split("/")[0]) / Number(node.lpValue!.split("/")[1])
        : node.lpValue), 6);
    }
  });

  it("boundsText renders empty at the root and non-empty once bounds diverge from the root's", () => {
    expect(boundsText(p, r.tree[0].lb, r.tree[0].ub)).toBe("");
    const branched = r.tree.find((n) => n.parentId !== null)!;
    expect(boundsText(p, branched.lb, branched.ub).length).toBeGreaterThan(0);
  });

  it("counters in the final step add up to the number of nodes visited", () => {
    const last = r.steps[r.steps.length - 1];
    const c = last.state.counters;
    const total = c.branched + c.integerSolutions + c.prunedInfeasible + c.prunedBound + c.prunedInherited;
    // "unbounded" root nodes count separately and don't occur here.
    expect(total).toBe(r.tree.length);
  });
});

describe("divisibility short-circuit", () => {
  it("does not fire on a satisfiable equality row", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, 1],
      varTypes: ["integer", "integer"],
      constraints: [{ coeffs: [2, 4], relation: "=", rhs: 10 }], // gcd(2,4)=2 divides 10 — fine
    });
    const r = solveIP(p, { nodeLimit: 500 });
    expect(r.status).not.toBe("node_limit");
  });

  it("does not fire across two equality rows even though neither alone need be unsatisfiable", () => {
    // Each row individually passes the gcd test; only combined are they infeasible. The short-circuit
    // must not claim a false infeasibility here — it only ever proves infeasibility, never assumes it.
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, 1],
      varTypes: ["integer", "integer"],
      constraints: [
        { coeffs: [1, 1], relation: "=", rhs: 3 },
        { coeffs: [1, -1], relation: "=", rhs: 0.5 }, // forces x1 = x2 + 0.25, unsatisfiable jointly
      ],
    });
    const r = solveIP(p, { nodeLimit: 2000 });
    // This problem's LP relaxation is bounded (a single point), so it resolves through the ordinary
    // path regardless — the point here is just that no row alone triggers a false positive.
    expect(["optimal", "infeasible"]).toContain(r.status);
  });

  it("ignores a continuous variable in the row (the check only ever applies to all-integer rows)", () => {
    const p = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, 1],
      varTypes: ["integer", "continuous"],
      constraints: [
        { coeffs: [2, 2], relation: "=", rhs: 1 }, // would fail the gcd test if x2 were integer — it isn't
        { coeffs: [1, 0], relation: "<=", rhs: 5 },
      ],
    });
    const r = solveIP(p, { nodeLimit: 500 });
    expect(r.status).not.toBe("node_limit");
  });
});

describe("validation", () => {
  it("rejects mismatched coefficient counts and non-finite values with a readable message", () => {
    const bad = P({
      sense: "max",
      variables: ["x1", "x2"],
      objective: [1, NaN],
      varTypes: ["integer", "integer"],
      constraints: [{ coeffs: [1], relation: "<=", rhs: 5 }],
    });
    const errors = validateIP(bad);
    expect(errors.length).toBeGreaterThan(0);
    expect(() => solveIP(bad)).toThrow();
  });

  it("accepts a well-formed problem with no errors", () => {
    const good = P({
      sense: "max",
      variables: ["x1"],
      objective: [1],
      varTypes: ["integer"],
      constraints: [{ coeffs: [1], relation: "<=", rhs: 5 }],
    });
    expect(validateIP(good)).toEqual([]);
  });
});
