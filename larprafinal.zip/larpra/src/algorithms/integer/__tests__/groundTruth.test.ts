import { describe, expect, it } from "vitest";
import { solveIP } from "../branchAndBound";
import { GT_CASES } from "./fixtures/groundTruth";
import { NODE_SELECTIONS, BRANCHING_RULES, NodeSelection, BranchingRule } from "../../../types/integer";

/**
 * Cross-validation against tools/ip_ground_truth.py's independent oracle: scipy.optimize.milp + linprog,
 * itself cross-checked there by exhaustive enumeration. 256 cases across the built-in examples and nine
 * random families (knapsacks, set covers, mixed-integer, equalities, mixed-sign rows, unbounded,
 * contradictory rows, decimal coefficients). Every case is run under all four (node selection × branching)
 * combinations — the optimal value must not depend on search strategy, only the path taken to find it.
 */
const STRATEGIES: { nodeSelection: NodeSelection; branching: BranchingRule }[] = NODE_SELECTIONS.flatMap((ns) =>
  BRANCHING_RULES.map((b) => ({ nodeSelection: ns, branching: b }))
);

describe(`ground truth (${GT_CASES.length} cases × ${STRATEGIES.length} strategies)`, () => {
  for (const c of GT_CASES) {
    for (const strat of STRATEGIES) {
      it(`${c.label} [${c.family}] — ${strat.nodeSelection}/${strat.branching}`, () => {
        const r = solveIP(c.problem, { ...strat, nodeLimit: 20000 });
        expect(r.status).toBe(c.expected.status);
        if (c.expected.status === "optimal") {
          expect(r.optimalValue).toBeCloseTo(c.expected.objective!, 6);
          if (c.expected.exactObjective) expect(r.optimalValueExact).toBe(c.expected.exactObjective);
          // The reported solution must itself be feasible and match the claimed objective exactly.
          const vars = c.problem.variables;
          let obj = 0;
          vars.forEach((v, j) => (obj += c.problem.objective[j] * r.optimalSolution![v]));
          expect(obj).toBeCloseTo(r.optimalValue!, 6);
        }
      });
    }
  }
});
