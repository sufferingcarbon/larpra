import { CPMMode, CPMProblemInput } from "../../types/cpm";

export interface CPMExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  mode: CPMMode;
  description: string;
  problem: CPMProblemInput;
  /**
   * Headline results, worked out by hand. Every example (and the complete ES/EF/LS/LF/slack
   * tables) is additionally checked against tools/cpm_ground_truth.py, which uses networkx,
   * exact fractions, full path enumeration and an LP — see __tests__/fixtures/groundTruth.ts.
   */
  expected: {
    projectDuration: number;
    criticalPaths: string[][];
    /** PERT only: project variance along the (largest-variance) critical path. */
    projectVariance?: number;
  };
}

const act = (name: string, duration: number, predecessors: string[] = []) => ({ name, duration, predecessors });
const pert = (name: string, optimistic: number, mostLikely: number, pessimistic: number, predecessors: string[] = []) => ({
  name,
  optimistic,
  mostLikely,
  pessimistic,
  predecessors,
});

export const cpmExamples: CPMExample[] = [
  {
    name: "Simple chain (A → B → C)",
    difficulty: "beginner",
    mode: "cpm",
    description:
      "Three tasks in strict sequence, so nothing can overlap and nothing has slack. A runs 0–3, B runs 3–8, C runs 8–10: the project takes 3 + 5 + 2 = 10 and every activity is critical.",
    problem: { activities: [act("A", 3), act("B", 5, ["A"]), act("C", 2, ["B"])] },
    expected: { projectDuration: 10, criticalPaths: [["A", "B", "C"]] },
  },
  {
    name: "Diamond dependency (A → {B, C} → D)",
    difficulty: "intermediate",
    mode: "cpm",
    description:
      "After A, tasks B and C run in parallel and D needs both. Path A-B-D is 2 + 4 + 3 = 9 but A-C-D is 2 + 6 + 3 = 11, so the project takes 11, C is critical, and B has 2 units of slack (ES 2, LS 4).",
    problem: {
      activities: [act("A", 2), act("B", 4, ["A"]), act("C", 6, ["A"]), act("D", 3, ["B", "C"])],
    },
    expected: { projectDuration: 11, criticalPaths: [["A", "C", "D"]] },
  },
  {
    name: "Two equally long critical paths",
    difficulty: "difficult",
    mode: "cpm",
    description:
      "After A the work splits into two parallel chains, B→D (4 + 6) and C→E (5 + 5), both exactly 10 long, that rejoin at G. Both are critical: A-B-D-G-H and A-C-E-G-H each total 20. A short side task F has 12 units of slack.",
    problem: {
      activities: [
        act("A", 3),
        act("B", 4, ["A"]),
        act("C", 5, ["A"]),
        act("D", 6, ["B"]),
        act("E", 5, ["C"]),
        act("F", 2, ["A"]),
        act("G", 4, ["D", "E"]),
        act("H", 3, ["F", "G"]),
      ],
    },
    expected: {
      projectDuration: 20,
      criticalPaths: [
        ["A", "B", "D", "G", "H"],
        ["A", "C", "E", "G", "H"],
      ],
    },
  },
  {
    name: "14-activity construction project",
    difficulty: "difficult",
    mode: "cpm",
    description:
      "A construction schedule with fourteen activities: A excavate (2), B foundation (4), C rough wall (10), D roof (6), E exterior plumbing (4), F interior plumbing (5), G exterior siding (7), H exterior painting (9), I electrical (7), J wallboard (8), K flooring (4), L interior painting (5), M exterior fixtures (2), N interior fixtures (6). The project takes 44 weeks along A-B-C-E-F-J-L-N; K has 1 week of slack, and the roof/siding/painting branch finishes at 40.",
    problem: {
      activities: [
        act("A", 2),
        act("B", 4, ["A"]),
        act("C", 10, ["B"]),
        act("D", 6, ["C"]),
        act("E", 4, ["C"]),
        act("F", 5, ["E"]),
        act("G", 7, ["D"]),
        act("H", 9, ["E", "G"]),
        act("I", 7, ["C"]),
        act("J", 8, ["F", "I"]),
        act("K", 4, ["J"]),
        act("L", 5, ["J"]),
        act("M", 2, ["H"]),
        act("N", 6, ["K", "L"]),
      ],
    },
    expected: { projectDuration: 44, criticalPaths: [["A", "B", "C", "E", "F", "J", "L", "N"]] },
  },
  {
    name: "PERT: simple diamond",
    difficulty: "intermediate",
    mode: "pert",
    description:
      "A→{B, C}→D with three-point estimates. Expected durations: A = (2 + 4·3 + 10)/6 = 4, B = 6, C = 4, D = 3. Path A-B-D is critical at 13 with variance 16/9 + 1 + 1/9 = 26/9 ≈ 2.8889 (σ ≈ 1.6997); C has 2 units of slack.",
    problem: {
      activities: [
        pert("A", 2, 3, 10),
        pert("B", 3, 6, 9, ["A"]),
        pert("C", 1, 4, 7, ["A"]),
        pert("D", 2, 3, 4, ["B", "C"]),
      ],
    },
    expected: { projectDuration: 13, criticalPaths: [["A", "B", "D"]], projectVariance: 26 / 9 },
  },
  {
    name: "PERT: software release with two critical paths",
    difficulty: "difficult",
    mode: "pert",
    description:
      "Design (B) fans out to a backend (C) and a frontend (D) that both take an expected 6, so two critical paths tie at 24. Their variances differ — 50/9 ≈ 5.56 via C, 82/9 ≈ 9.11 via D (the frontend's estimate is far more uncertain) — and the larger, 9.11 (σ ≈ 3.02), is used. Docs (G) has an expected duration of 14/6 ≈ 2.3333 and about 10.67 units of slack.",
    problem: {
      activities: [
        pert("A", 2, 4, 6),
        pert("B", 3, 5, 13, ["A"]),
        pert("C", 4, 6, 8, ["B"]),
        pert("D", 2, 5, 14, ["B"]),
        pert("E", 1, 2, 3, ["C", "D"]),
        pert("F", 3, 4, 11, ["E"]),
        pert("G", 1, 2, 5, ["B"]),
        pert("H", 1, 1, 1, ["F", "G"]),
      ],
    },
    expected: {
      projectDuration: 24,
      criticalPaths: [
        ["A", "B", "C", "E", "F", "H"],
        ["A", "B", "D", "E", "F", "H"],
      ],
      projectVariance: 82 / 9,
    },
  },
];
