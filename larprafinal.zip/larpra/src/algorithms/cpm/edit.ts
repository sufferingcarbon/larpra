import { CPMActivityInput, CPMMode, CPMProblemInput } from "../../types/cpm";
import { expectedDuration } from "./common";

/**
 * Pure editing helpers for the activity table. They live outside the React component so the
 * fiddly parts (renaming an activity must update every reference to it; switching modes must
 * carry the user's numbers across) can be unit-tested.
 */

const isNum = (x: unknown): x is number => typeof x === "number" && Number.isFinite(x);

/** "A, B , ,C" → ["A", "B", "C"] */
export function parsePredecessors(raw: string): string[] {
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

/** "A" … "Z", then "A1" … "Z1", "A2" … — the first name not already taken. */
export function nextActivityName(existing: string[]): string {
  const taken = new Set(existing);
  for (let n = 0; ; n++) {
    const name = String.fromCharCode(65 + (n % 26)) + (n >= 26 ? String(Math.floor(n / 26)) : "");
    if (!taken.has(name)) return name;
  }
}

/** Rename activity `index`, and repoint every predecessor reference to it. */
export function renameActivity(problem: CPMProblemInput, index: number, name: string): CPMProblemInput {
  const old = problem.activities[index].name;
  return {
    activities: problem.activities.map((a, i) => ({
      ...a,
      name: i === index ? name : a.name,
      predecessors: a.predecessors.map((p) => (p === old ? name : p)),
    })),
  };
}

/** Remove activity `index` and drop it from every predecessor list. */
export function removeActivity(problem: CPMProblemInput, index: number): CPMProblemInput {
  const gone = problem.activities[index].name;
  return {
    activities: problem.activities
      .filter((_, i) => i !== index)
      .map((a) => ({ ...a, predecessors: a.predecessors.filter((p) => p !== gone) })),
  };
}

/** Append a fresh activity with sensible defaults for the mode. */
export function addActivity(problem: CPMProblemInput, mode: CPMMode): CPMProblemInput {
  const name = nextActivityName(problem.activities.map((a) => a.name));
  const fresh: CPMActivityInput =
    mode === "pert"
      ? { name, optimistic: 1, mostLikely: 2, pessimistic: 3, predecessors: [] }
      : { name, duration: 1, predecessors: [] };
  return { activities: [...problem.activities, fresh] };
}

/**
 * Carry the user's numbers across a mode switch, dropping the fields the new mode doesn't use.
 * CPM → PERT: a single duration d becomes the degenerate estimate (d, d, d).
 * PERT → CPM: three estimates collapse to their expected duration (rounded to 4 decimals).
 * Values the user hadn't filled in stay blank.
 */
export function convertMode(problem: CPMProblemInput, to: CPMMode): CPMProblemInput {
  return {
    activities: problem.activities.map((a): CPMActivityInput => {
      if (to === "pert") {
        const d = isNum(a.duration) ? a.duration : undefined;
        return {
          name: a.name,
          predecessors: a.predecessors,
          optimistic: a.optimistic ?? d,
          mostLikely: a.mostLikely ?? d,
          pessimistic: a.pessimistic ?? d,
        };
      }
      const { optimistic: o, mostLikely: m, pessimistic: p } = a;
      const full = isNum(o) && isNum(m) && isNum(p);
      return {
        name: a.name,
        predecessors: a.predecessors,
        duration: isNum(a.duration) ? a.duration : full ? Math.round(expectedDuration(o, m, p) * 1e4) / 1e4 : undefined,
      };
    }),
  };
}
