import { describe, it, expect } from "vitest";
import { addActivity, convertMode, nextActivityName, parsePredecessors, removeActivity, renameActivity } from "../edit";
import { validateCPM } from "../standardize";
import { solveCPM } from "../solve";
import { cpmExamples } from "../examples";
import { CPMProblemInput } from "../../../types/cpm";

const diamond: CPMProblemInput = cpmExamples[1].problem;

describe("CPM table editing helpers", () => {
  it("parsePredecessors trims, drops blanks, and keeps names containing spaces", () => {
    expect(parsePredecessors("A, B , ,C")).toEqual(["A", "B", "C"]);
    expect(parsePredecessors("")).toEqual([]);
    expect(parsePredecessors("Rough wall, Roof")).toEqual(["Rough wall", "Roof"]);
  });

  it("nextActivityName picks the first free letter, then rolls over to A1, B1 …", () => {
    expect(nextActivityName([])).toBe("A");
    expect(nextActivityName(["A", "B", "D"])).toBe("C");
    const all26 = Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i));
    expect(nextActivityName(all26)).toBe("A1");
    expect(nextActivityName([...all26, "A1"])).toBe("B1");
  });

  it("renaming an activity repoints every predecessor reference, so the problem stays valid and solves the same", () => {
    const renamed = renameActivity(diamond, 0, "Kickoff"); // A → Kickoff
    expect(renamed.activities[0].name).toBe("Kickoff");
    expect(renamed.activities[1].predecessors).toEqual(["Kickoff"]);
    expect(renamed.activities[2].predecessors).toEqual(["Kickoff"]);
    expect(renamed.activities[3].predecessors).toEqual(["B", "C"]); // untouched
    expect(validateCPM(renamed, "cpm")).toEqual([]);
    expect(solveCPM(renamed, "cpm").projectDuration).toBe(11);
  });

  it("renaming does not mutate the original problem", () => {
    const before = JSON.stringify(diamond);
    renameActivity(diamond, 0, "X");
    removeActivity(diamond, 1);
    addActivity(diamond, "cpm");
    expect(JSON.stringify(diamond)).toBe(before);
  });

  it("removing an activity drops it from every predecessor list (no dangling references)", () => {
    const removed = removeActivity(diamond, 1); // remove B
    expect(removed.activities.map((a) => a.name)).toEqual(["A", "C", "D"]);
    expect(removed.activities[2].predecessors).toEqual(["C"]);
    expect(validateCPM(removed, "cpm")).toEqual([]);
    expect(solveCPM(removed, "cpm").projectDuration).toBe(11);
  });

  it("addActivity appends a valid default for each mode", () => {
    const cpm = addActivity(diamond, "cpm");
    expect(cpm.activities[4]).toEqual({ name: "E", duration: 1, predecessors: [] });
    expect(validateCPM(cpm, "cpm")).toEqual([]);

    const pertProblem = addActivity(cpmExamples[4].problem, "pert");
    expect(pertProblem.activities[4]).toEqual({ name: "E", optimistic: 1, mostLikely: 2, pessimistic: 3, predecessors: [] });
    expect(validateCPM(pertProblem, "pert")).toEqual([]);
  });
});

describe("Switching between CPM and PERT keeps the user's numbers", () => {
  it("CPM → PERT: each duration d becomes (d, d, d) — the same schedule with zero variance", () => {
    const pert = convertMode(diamond, "pert");
    expect(pert.activities[2]).toEqual({ name: "C", optimistic: 6, mostLikely: 6, pessimistic: 6, predecessors: ["A"] });
    expect("duration" in pert.activities[2]).toBe(false);
    expect(validateCPM(pert, "pert")).toEqual([]);
    const r = solveCPM(pert, "pert");
    expect(r.projectDuration).toBe(11);
    expect(r.projectVariance).toBe(0);
    expect(r.criticalPaths).toEqual([["A", "C", "D"]]);
  });

  it("PERT → CPM: estimates collapse to the expected duration, and the CPM answer equals the PERT project duration", () => {
    const pertProblem = cpmExamples[5].problem;
    const cpm = convertMode(pertProblem, "cpm");
    expect(cpm.activities.find((a) => a.name === "G")!.duration).toBeCloseTo(2.3333, 4);
    expect(cpm.activities.every((a) => a.optimistic === undefined)).toBe(true);
    expect(validateCPM(cpm, "cpm")).toEqual([]);
    expect(solveCPM(cpm, "cpm").projectDuration).toBeCloseTo(24, 3);
  });

  it("round trip CPM → PERT → CPM restores the original durations", () => {
    const back = convertMode(convertMode(diamond, "pert"), "cpm");
    expect(back.activities.map((a) => a.duration)).toEqual(diamond.activities.map((a) => a.duration));
  });

  it("leaves blanks blank instead of inventing numbers", () => {
    const partial: CPMProblemInput = { activities: [{ name: "A", predecessors: [] }] };
    expect(convertMode(partial, "pert").activities[0].optimistic).toBeUndefined();
    expect(convertMode(partial, "cpm").activities[0].duration).toBeUndefined();
  });
});
