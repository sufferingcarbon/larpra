import { describe, it, expect } from "vitest";
import { solveCPM, MAX_CRITICAL_PATHS } from "../solve";
import { cpmExamples } from "../examples";
import { exampleGroundTruth, randomGroundTruth, GTCase } from "./fixtures/groundTruth";
import { CPMProblemInput } from "../../../types/cpm";

const pathKey = (p: string[]) => p.join(">");
const sortedPaths = (paths: string[][]) => paths.map(pathKey).sort();

const act = (name: string, duration: number, predecessors: string[] = []) => ({ name, duration, predecessors });

/** Compare one solver result to one ground-truth case; returns a list of mismatch messages (empty = all good). */
function mismatches(gt: GTCase): string[] {
  const problem: CPMProblemInput = { activities: gt.activities };
  const r = solveCPM(problem, gt.mode);
  const bad: string[] = [];
  if (r.status !== "optimal") return [`${gt.label}: solver returned ${r.status}: ${r.notes.join(" | ")}`];
  const near = (a: number, b: number) => Math.abs(a - b) < 1e-9;
  if (!near(r.projectDuration!, gt.projectDuration)) bad.push(`${gt.label}: duration ${r.projectDuration} vs ${gt.projectDuration}`);
  for (const [name, e] of Object.entries(gt.schedule)) {
    const s = r.schedule![name];
    for (const k of ["duration", "es", "ef", "ls", "lf", "slack"] as const) {
      if (!near(s[k], e[k])) bad.push(`${gt.label}: ${name}.${k} ${s[k]} vs ${e[k]}`);
    }
    if (s.critical !== (e.slack === 0)) bad.push(`${gt.label}: ${name} critical flag ${s.critical} but slack ${e.slack}`);
    if (gt.mode === "pert" && !near(s.variance!, e.variance!)) bad.push(`${gt.label}: ${name}.variance ${s.variance} vs ${e.variance}`);
  }
  if (pathKey(sortedPaths(r.criticalPaths!)) !== pathKey(sortedPaths(gt.criticalPaths))) {
    bad.push(`${gt.label}: critical paths ${sortedPaths(r.criticalPaths!)} vs ${sortedPaths(gt.criticalPaths)}`);
  }
  if (gt.mode === "pert") {
    if (!near(r.projectVariance!, gt.projectVariance!)) bad.push(`${gt.label}: project variance ${r.projectVariance} vs ${gt.projectVariance}`);
    if (!near(r.projectStdDev!, gt.projectStdDev!)) bad.push(`${gt.label}: project std dev ${r.projectStdDev} vs ${gt.projectStdDev}`);
  }
  return bad;
}

describe("CPM/PERT — built-in examples: hand-computed headline results", () => {
  cpmExamples.forEach((ex) => {
    it(`${ex.name}: duration and critical paths`, () => {
      const r = solveCPM(ex.problem, ex.mode);
      expect(r.status).toBe("optimal");
      expect(r.isPert).toBe(ex.mode === "pert");
      expect(r.projectDuration).toBeCloseTo(ex.expected.projectDuration, 9);
      expect(sortedPaths(r.criticalPaths!)).toEqual(sortedPaths(ex.expected.criticalPaths));
      if (ex.expected.projectVariance !== undefined) {
        expect(r.projectVariance).toBeCloseTo(ex.expected.projectVariance, 9);
        expect(r.projectStdDev).toBeCloseTo(Math.sqrt(ex.expected.projectVariance), 9);
      }
    });
  });

  it("diamond: hand-worked ES/EF/LS/LF/slack for every activity", () => {
    const r = solveCPM(cpmExamples[1].problem, "cpm");
    // [ES, EF, LS, LF, slack]
    const expected: Record<string, number[]> = {
      A: [0, 2, 0, 2, 0],
      B: [2, 6, 4, 8, 2],
      C: [2, 8, 2, 8, 0],
      D: [8, 11, 8, 11, 0],
    };
    for (const [name, [es, ef, ls, lf, slack]] of Object.entries(expected)) {
      const s = r.schedule![name];
      expect([s.es, s.ef, s.ls, s.lf, s.slack], name).toEqual([es, ef, ls, lf, slack]);
    }
  });

  it("construction project: K has one week of slack, F/J/L/N are critical, D-G-H-M branch ends at 40", () => {
    const r = solveCPM(cpmExamples[3].problem, "cpm");
    expect(r.schedule!.K.slack).toBe(1);
    expect(r.schedule!.M.ef).toBe(40);
    expect(r.schedule!.M.slack).toBe(4);
    for (const n of ["A", "B", "C", "E", "F", "J", "L", "N"]) expect(r.schedule![n].critical, n).toBe(true);
    for (const n of ["D", "G", "H", "I", "K", "M"]) expect(r.schedule![n].critical, n).toBe(false);
  });

  it("two-equal-paths example: F has 12 units of slack while both parallel chains are critical", () => {
    const r = solveCPM(cpmExamples[2].problem, "cpm");
    expect(r.schedule!.F.slack).toBe(12);
    for (const n of ["A", "B", "C", "D", "E", "G", "H"]) expect(r.schedule![n].slack, n).toBe(0);
  });

  it("PERT release example: expected durations and the fractional slack on G", () => {
    const r = solveCPM(cpmExamples[5].problem, "pert");
    expect(r.schedule!.G.duration).toBeCloseTo(14 / 6, 9);
    expect(r.schedule!.G.slack).toBeCloseTo(32 / 3, 9); // 10.6667
    expect(r.criticalPathVariances!.map((v) => Math.round(v * 9)).sort((a, b) => a - b)).toEqual([50, 82]);
    expect(r.notes.join(" ")).toMatch(/largest path variance/);
  });
});

describe("CPM/PERT — cross-validation against independent ground truth (networkx + exact fractions + LP)", () => {
  exampleGroundTruth.forEach((gt) => {
    it(`example "${gt.label}": every ES/EF/LS/LF/slack value, critical paths${gt.mode === "pert" ? ", variance" : ""}`, () => {
      // The examples shipped in the app must be the same problems the ground truth was computed for.
      const ex = cpmExamples.find((e) => e.name === gt.label);
      expect(ex, `no built-in example named "${gt.label}"`).toBeDefined();
      expect(ex!.problem.activities).toEqual(gt.activities);
      expect(mismatches(gt)).toEqual([]);
    });
  });

  it("150 random DAGs (activities listed in non-topological order): CPM cases match on every field", () => {
    const cases = randomGroundTruth.filter((c) => c.mode === "cpm");
    expect(cases.length).toBeGreaterThan(50);
    expect(cases.flatMap(mismatches)).toEqual([]);
  });

  it("150 random DAGs: PERT cases match on every field including variance", () => {
    const cases = randomGroundTruth.filter((c) => c.mode === "pert");
    expect(cases.length).toBeGreaterThan(30);
    expect(cases.flatMap(mismatches)).toEqual([]);
  });

  it("the random set genuinely exercises ties (several dozen cases have more than one critical path)", () => {
    const multi = randomGroundTruth.filter((c) => c.criticalPaths.length > 1).length;
    expect(multi).toBeGreaterThan(10);
  });
});

describe("CPM/PERT — structural invariants of every solve", () => {
  const allProblems = [
    ...cpmExamples.map((e) => ({ label: e.name, problem: e.problem, mode: e.mode })),
    ...randomGroundTruth.slice(0, 40).map((g) => ({ label: g.label, problem: { activities: g.activities }, mode: g.mode })),
  ];

  it("ES ≤ LS, EF ≤ LF, slack ≥ 0, and slack = LS − ES = LF − EF everywhere", () => {
    for (const { label, problem, mode } of allProblems) {
      const r = solveCPM(problem, mode);
      for (const [n, s] of Object.entries(r.schedule!)) {
        expect(s.es, `${label}/${n}`).toBeLessThanOrEqual(s.ls + 1e-9);
        expect(s.ef, `${label}/${n}`).toBeLessThanOrEqual(s.lf + 1e-9);
        expect(s.slack, `${label}/${n}`).toBeGreaterThanOrEqual(0);
        expect(s.slack, `${label}/${n}`).toBeCloseTo(s.lf - s.ef, 9);
      }
    }
  });

  it("every critical path's durations add up to exactly the project duration, and every critical activity is on one", () => {
    for (const { label, problem, mode } of allProblems) {
      const r = solveCPM(problem, mode);
      const onPath = new Set<string>();
      for (const p of r.criticalPaths!) {
        const sum = p.reduce((t, n) => t + r.schedule![n].duration, 0);
        expect(sum, `${label}: ${p.join("→")}`).toBeCloseTo(r.projectDuration!, 9);
        p.forEach((n) => onPath.add(n));
      }
      const critical = Object.entries(r.schedule!).filter(([, s]) => s.critical).map(([n]) => n);
      expect([...onPath].sort(), label).toEqual(critical.sort());
    }
  });

  it("is deterministic: solving twice gives byte-identical steps", () => {
    for (const { problem, mode } of allProblems.slice(0, 12)) {
      expect(JSON.stringify(solveCPM(problem, mode).steps)).toBe(JSON.stringify(solveCPM(problem, mode).steps));
    }
  });
});

describe("CPM/PERT — step emission (every step is a real snapshot)", () => {
  const diamond = () => solveCPM(cpmExamples[1].problem, "cpm");

  it("CPM step layout: setup, one forward step per activity, forward-complete, one backward step per activity, slack, paths, summary", () => {
    const r = diamond();
    const kinds = r.steps.map((s) => s.state.stepKind);
    expect(kinds).toEqual([
      "network",
      "forward", "forward", "forward", "forward",
      "forward-complete",
      "backward", "backward", "backward", "backward",
      "slack",
      "critical-path-found",
      "summary",
    ]);
    expect(r.steps.map((s) => s.state.phase)).toEqual([
      "setup",
      "forward", "forward", "forward", "forward", "forward",
      "backward", "backward", "backward", "backward",
      "slack",
      "critical-path", "critical-path",
    ]);
  });

  it("PERT adds one leading step converting estimates to expected durations and variances", () => {
    const r = solveCPM(cpmExamples[4].problem, "pert");
    expect(r.steps[0].state.stepKind).toBe("pert-estimates");
    expect(r.steps[0].state.phase).toBe("setup");
    expect(r.steps[0].explanation).toContain("(2 + 4×3 + 10) / 6 = 4");
    expect(r.steps[0].state.activities[0].estimates).toEqual({ optimistic: "2", mostLikely: "3", pessimistic: "10" });
    expect(r.steps[0].state.activities[0].variance).toBe("1.7778");
    expect(r.steps[1].state.stepKind).toBe("network");
  });

  it("the forward pass visits activities in topological order, one per step, and reveals values only once computed", () => {
    const r = diamond();
    const fwd = r.steps.filter((s) => s.state.stepKind === "forward");
    expect(fwd.map((s) => s.state.currentActivity)).toEqual(["A", "B", "C", "D"]);
    // after the 2nd forward step (B), only A and B have ES/EF — C and D are still blank; nothing backward exists yet
    const afterB = fwd[1].state.activities;
    expect(afterB.map((a) => a.es)).toEqual(["0", "2", null, null]);
    expect(afterB.every((a) => a.ls === null && a.lf === null && a.slack === null && a.isCritical === null)).toBe(true);
  });

  it("the backward pass runs in reverse topological order and starts from the project duration", () => {
    const r = diamond();
    const bwd = r.steps.filter((s) => s.state.stepKind === "backward");
    expect(bwd.map((s) => s.state.currentActivity)).toEqual(["D", "C", "B", "A"]);
    expect(bwd[0].explanation).toContain("project deadline: LF = 11");
    expect(bwd[0].state.projectDuration).toBe("11");
    expect(bwd[0].state.activities.map((a) => a.ls)).toEqual([null, null, null, "8"]);
  });

  it("explanations name the activity that sets each start/finish time", () => {
    const r = diamond();
    const forwardD = r.steps.find((s) => s.title.startsWith("Forward pass — D"))!;
    expect(forwardD.explanation).toContain("set by C");
    expect(forwardD.operation).toBe("ES(D) = max(6, 8) = 8;  EF(D) = 8 + 3 = 11");
    const backwardA = r.steps.find((s) => s.title.startsWith("Backward pass — A"))!;
    expect(backwardA.explanation).toContain("set by C");
    expect(backwardA.operation).toBe("LF(A) = min(4, 2) = 2;  LS(A) = 2 − 2 = 0");
  });

  it("reports ties explicitly (two predecessors finishing at the same time)", () => {
    const r = solveCPM(cpmExamples[2].problem, "cpm");
    const forwardG = r.steps.find((s) => s.title.startsWith("Forward pass — G"))!;
    expect(forwardG.explanation).toContain("a tie between D and E");
  });

  it("slack step marks exactly the critical activities", () => {
    const r = diamond();
    const s = r.steps.find((st) => st.state.stepKind === "slack")!;
    expect(s.state.criticalActivityNames).toEqual(["A", "C", "D"]);
    expect(s.state.activities.map((a) => [a.name, a.slack, a.isCritical])).toEqual([
      ["A", "0", true],
      ["B", "2", false],
      ["C", "0", true],
      ["D", "0", true],
    ]);
  });

  it("emits one 'critical-path-found' step per path, accumulating paths as they are discovered", () => {
    const r = solveCPM(cpmExamples[2].problem, "cpm");
    const found = r.steps.filter((s) => s.state.stepKind === "critical-path-found");
    expect(found.map((s) => s.state.currentPath!.join(""))).toEqual(["ABDGH", "ACEGH"]);
    expect(found[0].state.criticalPaths).toHaveLength(1);
    expect(found[1].state.criticalPaths).toHaveLength(2);
    const summary = r.steps[r.steps.length - 1];
    expect(summary.state.stepKind).toBe("summary");
    expect(summary.state.criticalPaths).toHaveLength(2);
    expect(summary.title).toContain("2 critical paths");
  });

  it("PERT summary carries project variance and σ; CPM summary carries none", () => {
    const p = solveCPM(cpmExamples[4].problem, "pert");
    const ps = p.steps[p.steps.length - 1].state;
    expect(ps.projectVariance).toBe("2.8889");
    expect(ps.projectStdDev).toBe("1.6997");
    const c = solveCPM(cpmExamples[0].problem, "cpm");
    const cs = c.steps[c.steps.length - 1].state;
    expect(cs.projectVariance).toBeNull();
    expect(cs.projectStdDev).toBeNull();
    expect(c.projectVariance).toBeUndefined();
  });

  it("the same steps that drive Next Step give the answer (final summary state agrees with the result)", () => {
    for (const ex of cpmExamples) {
      const r = solveCPM(ex.problem, ex.mode);
      const last = r.steps[r.steps.length - 1].state;
      expect(Number(last.projectDuration)).toBeCloseTo(r.projectDuration!, 4);
      expect(last.criticalPaths).toEqual(r.criticalPaths);
      for (const row of last.activities) expect(Number(row.es)).toBeCloseTo(r.schedule![row.name].es, 4);
    }
  });
});

describe("CPM/PERT — tricky networks", () => {
  it("does not chain two zero-slack activities across a hand-off that isn't tight", () => {
    // A(2)→V, A→W(4), X(4)→V(2). Every activity has zero slack, but A finishes at 2 while V can only
    // start at 4 (it waits for X) — so A→V is not a real critical path (2 + 2 ≠ 6). The paths are A→W and X→V.
    const r = solveCPM(
      { activities: [act("A", 2), act("X", 4), act("V", 2, ["A", "X"]), act("W", 4, ["A"])] },
      "cpm"
    );
    expect(r.projectDuration).toBe(6);
    expect(Object.values(r.schedule!).every((s) => s.critical)).toBe(true);
    expect(sortedPaths(r.criticalPaths!)).toEqual(["A>W", "X>V"]);
  });

  it("accepts activities listed before their predecessors", () => {
    const r = solveCPM({ activities: [act("C", 2, ["B"]), act("B", 5, ["A"]), act("A", 3)] }, "cpm");
    expect(r.status).toBe("optimal");
    expect(r.projectDuration).toBe(10);
    expect(r.criticalPaths).toEqual([["A", "B", "C"]]);
    // the topological order is A, B, C even though the user listed C first
    expect(r.steps[0].explanation).toContain("A → B → C");
  });

  it("handles a single activity", () => {
    const r = solveCPM({ activities: [act("Solo", 7)] }, "cpm");
    expect(r.projectDuration).toBe(7);
    expect(r.criticalPaths).toEqual([["Solo"]]);
    expect(r.schedule!.Solo).toMatchObject({ es: 0, ef: 7, ls: 0, lf: 7, slack: 0 });
  });

  it("handles disconnected sub-projects: the shorter chain is non-critical and gets slack", () => {
    const r = solveCPM({ activities: [act("A", 3), act("B", 2, ["A"]), act("C", 1)] }, "cpm");
    expect(r.projectDuration).toBe(5);
    expect(r.criticalPaths).toEqual([["A", "B"]]);
    expect(r.schedule!.C).toMatchObject({ es: 0, ef: 1, ls: 4, lf: 5, slack: 4, critical: false });
  });

  it("handles zero-duration milestones", () => {
    const r = solveCPM({ activities: [act("Start", 0), act("Work", 4, ["Start"]), act("Done", 0, ["Work"])] }, "cpm");
    expect(r.projectDuration).toBe(4);
    expect(r.criticalPaths).toEqual([["Start", "Work", "Done"]]);
  });

  it("handles a project where every duration is zero (everything critical)", () => {
    const r = solveCPM({ activities: [act("A", 0), act("B", 0, ["A"])] }, "cpm");
    expect(r.projectDuration).toBe(0);
    expect(r.criticalPaths).toEqual([["A", "B"]]);
  });

  it("treats floating-point noise as a tie: 0.1 + 0.2 vs 0.3 gives two critical paths", () => {
    const r = solveCPM(
      { activities: [act("A", 0.1), act("B", 0.2, ["A"]), act("C", 0.3), act("D", 1, ["B", "C"])] },
      "cpm"
    );
    expect(r.schedule!.B.slack).toBe(0);
    expect(r.schedule!.C.slack).toBe(0);
    expect(sortedPaths(r.criticalPaths!)).toEqual(["A>B>D", "C>D"]);
  });

  it("respects a custom tolerance", () => {
    // B is 0.05 short of critical; with the default tolerance it has slack, with a loose one it counts as critical.
    const problem = { activities: [act("A", 1), act("B", 0.95), act("C", 1, ["A", "B"])] };
    expect(solveCPM(problem, "cpm").schedule!.B.critical).toBe(false);
    expect(solveCPM(problem, "cpm", { tolerance: 0.1 }).schedule!.B.critical).toBe(true);
  });

  it("caps the critical-path listing when the count explodes (8 stacked diamonds = 256 paths)", () => {
    const acts = [act("S0", 1)];
    for (let k = 1; k <= 8; k++) {
      acts.push(act(`X${k}`, 2, [`S${k - 1}`]), act(`Y${k}`, 2, [`S${k - 1}`]), act(`S${k}`, 1, [`X${k}`, `Y${k}`]));
    }
    const r = solveCPM({ activities: acts }, "cpm");
    expect(r.projectDuration).toBe(1 + 8 * 3);
    expect(r.criticalPaths).toHaveLength(MAX_CRITICAL_PATHS);
    expect(r.notes.join(" ")).toContain(`first ${MAX_CRITICAL_PATHS} critical paths`);
    expect(r.steps[r.steps.length - 1].title).toContain(`${MAX_CRITICAL_PATHS}+`);
  });

  it("does not cap when the count is exactly manageable (6 stacked diamonds = 64 paths)", () => {
    const acts = [act("S0", 1)];
    for (let k = 1; k <= 6; k++) {
      acts.push(act(`X${k}`, 2, [`S${k - 1}`]), act(`Y${k}`, 2, [`S${k - 1}`]), act(`S${k}`, 1, [`X${k}`, `Y${k}`]));
    }
    const r = solveCPM({ activities: acts }, "cpm");
    expect(r.criticalPaths).toHaveLength(64);
    expect(r.notes).toEqual([]);
  });
});

describe("CPM/PERT — PERT arithmetic", () => {
  it("computes te = (a + 4m + b)/6 and variance ((b − a)/6)² per activity", () => {
    const r = solveCPM({ activities: [{ name: "A", optimistic: 2, mostLikely: 3, pessimistic: 10, predecessors: [] }] }, "pert");
    expect(r.schedule!.A.duration).toBeCloseTo(4, 12);
    expect(r.schedule!.A.variance).toBeCloseTo(16 / 9, 12);
    expect(r.projectVariance).toBeCloseTo(16 / 9, 12);
    expect(r.projectStdDev).toBeCloseTo(4 / 3, 12);
  });

  it("a = m = b gives zero variance and zero standard deviation", () => {
    const r = solveCPM({ activities: [{ name: "A", optimistic: 5, mostLikely: 5, pessimistic: 5, predecessors: [] }] }, "pert");
    expect(r.schedule!.A.duration).toBe(5);
    expect(r.projectVariance).toBe(0);
    expect(r.projectStdDev).toBe(0);
  });

  it("critical is decided on EXPECTED durations, and only critical activities contribute variance", () => {
    const r = solveCPM(cpmExamples[4].problem, "pert");
    expect(r.schedule!.C.critical).toBe(false); // C is uncertain but has slack — its variance (1) is not counted
    expect(r.projectVariance).toBeCloseTo(16 / 9 + 1 + 1 / 9, 12);
  });

  it("carries a caveat about near-critical paths in the notes", () => {
    expect(solveCPM(cpmExamples[4].problem, "pert").notes.join(" ")).toMatch(/near-critical/);
  });
});
