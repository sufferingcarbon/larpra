import { describe, it, expect } from "vitest";
import { validateCPM, standardizeCPM, topologicalOrder, inferMode } from "../standardize";
import { solveCPM } from "../solve";
import { CPMActivityInput, CPMProblemInput } from "../../../types/cpm";

const act = (name: string, duration: number | undefined, predecessors: string[] = []): CPMActivityInput => ({ name, duration, predecessors });
const pert = (name: string, o: number, m: number, p: number, predecessors: string[] = []): CPMActivityInput => ({
  name,
  optimistic: o,
  mostLikely: m,
  pessimistic: p,
  predecessors,
});
const problem = (...activities: CPMActivityInput[]): CPMProblemInput => ({ activities });

describe("CPM validation", () => {
  it("accepts a well-formed CPM problem", () => {
    expect(validateCPM(problem(act("A", 3), act("B", 2, ["A"])), "cpm")).toEqual([]);
  });

  it("accepts a well-formed PERT problem", () => {
    expect(validateCPM(problem(pert("A", 1, 2, 3), pert("B", 2, 2, 4, ["A"])), "pert")).toEqual([]);
  });

  it("rejects an empty activity list", () => {
    expect(validateCPM(problem(), "cpm")).toEqual(["Add at least one activity."]);
  });

  it("rejects empty and duplicate names", () => {
    const errors = validateCPM(problem(act("A", 1), act("A", 2), act("  ", 3)), "cpm");
    expect(errors).toContain("Duplicate activity name: A.");
    expect(errors).toContain("Activity 3 has an empty name.");
  });

  it("rejects an unknown predecessor, naming it", () => {
    const errors = validateCPM(problem(act("A", 1, ["Z"])), "cpm");
    expect(errors).toEqual(["Activity A has an unknown predecessor: Z."]);
  });

  it("rejects an activity that lists itself as a predecessor", () => {
    expect(validateCPM(problem(act("A", 1, ["A"])), "cpm")).toEqual(["Activity A lists itself as a predecessor."]);
  });

  it("rejects a predecessor listed twice", () => {
    const errors = validateCPM(problem(act("A", 1), act("B", 1, ["A", "A"])), "cpm");
    expect(errors).toEqual(["Activity B lists predecessor A more than once."]);
  });

  it("rejects missing, negative and non-finite durations in CPM mode", () => {
    expect(validateCPM(problem(act("A", undefined)), "cpm")).toEqual(["Activity A needs a duration."]);
    expect(validateCPM(problem(act("A", -1)), "cpm")[0]).toContain("negative duration");
    expect(validateCPM(problem(act("A", Number.NaN)), "cpm")[0]).toContain("needs a duration");
    expect(validateCPM(problem(act("A", Infinity)), "cpm")[0]).toContain("needs a duration");
  });

  it("CPM mode: an activity that only has three-point estimates gets a pointer to PERT mode", () => {
    const errors = validateCPM(problem(pert("A", 1, 2, 3)), "cpm");
    expect(errors[0]).toContain("switch to PERT mode");
  });

  it("PERT mode: requires all three estimates, in order, non-negative", () => {
    expect(validateCPM(problem({ name: "A", optimistic: 1, mostLikely: 2, predecessors: [] }), "pert")[0]).toContain("all three estimates");
    expect(validateCPM(problem(pert("A", 3, 2, 5)), "pert")[0]).toContain("optimistic ≤ most likely ≤ pessimistic");
    expect(validateCPM(problem(pert("A", 1, 4, 3)), "pert")[0]).toContain("optimistic ≤ most likely ≤ pessimistic");
    expect(validateCPM(problem(pert("A", -1, 2, 3)), "pert")[0]).toContain("negative");
  });

  it("PERT mode: an activity with only a plain duration is rejected", () => {
    expect(validateCPM(problem(act("A", 4)), "pert")[0]).toContain("all three estimates");
  });

  it("detects a cycle and spells out the loop, starting from the earliest-listed member", () => {
    // edges: C→A, A→B, B→C  ⇒  the loop is A → B → C → A
    const errors = validateCPM(problem(act("A", 1, ["C"]), act("B", 1, ["A"]), act("C", 1, ["B"])), "cpm");
    expect(errors).toHaveLength(1);
    expect(errors[0]).toContain("A → B → C → A");
    expect(errors[0]).toContain("cycle");
  });

  it("finds a cycle buried inside an otherwise fine network (not just at the start)", () => {
    const errors = validateCPM(
      problem(act("S", 1), act("X", 1, ["S", "Z"]), act("Y", 1, ["X"]), act("Z", 1, ["Y"]), act("T", 1, ["Z"])),
      "cpm"
    );
    expect(errors).toHaveLength(1);
    expect(errors[0]).toContain("X → Y → Z → X");
  });

  it("does not pile a cycle message on top of other errors (references must be sound first)", () => {
    const errors = validateCPM(problem(act("A", 1, ["B", "Nope"]), act("B", 1, ["A"])), "cpm");
    expect(errors).toEqual(["Activity A has an unknown predecessor: Nope."]);
  });

  it("solveCPM refuses an invalid problem cleanly: status invalid, no steps, errors in notes", () => {
    const r = solveCPM(problem(act("A", 1, ["B"]), act("B", 1, ["A"])), "cpm");
    expect(r.status).toBe("invalid");
    expect(r.steps).toEqual([]);
    expect(r.notes[0]).toContain("cycle");
    expect(r.projectDuration).toBeUndefined();
  });
});

describe("Topological order and network construction", () => {
  it("orders predecessors first, even when the user lists them last", () => {
    const names = ["C", "B", "A"];
    const preds = new Map([["C", ["B"]], ["B", ["A"]], ["A", [] as string[]]]);
    expect(topologicalOrder(names, preds)).toEqual({ order: ["A", "B", "C"], cycle: null });
  });

  it("breaks ties by input order, so the order is deterministic", () => {
    const names = ["D", "B", "C", "A"];
    const preds = new Map([["D", ["A"]], ["B", ["A"]], ["C", ["A"]], ["A", [] as string[]]]);
    // A first (only source), then D, B, C in the order they were listed
    expect(topologicalOrder(names, preds).order).toEqual(["A", "D", "B", "C"]);
  });

  it("standardizeCPM exposes sources, sinks, successors and per-activity durations", () => {
    const { errors, network } = standardizeCPM(problem(act("A", 2), act("B", 3, ["A"]), act("C", 4, ["A"]), act("D", 1, ["B", "C"])), "cpm");
    expect(errors).toEqual([]);
    expect(network!.sources).toEqual(["A"]);
    expect(network!.sinks).toEqual(["D"]);
    expect(network!.succs.get("A")).toEqual(["B", "C"]);
    expect(network!.duration.get("C")).toBe(4);
    expect(network!.variance).toBeNull();
  });

  it("standardizeCPM in PERT mode converts estimates to expected durations and variances", () => {
    const { network } = standardizeCPM(problem(pert("A", 2, 3, 10)), "pert");
    expect(network!.duration.get("A")).toBeCloseTo(4, 12);
    expect(network!.variance!.get("A")).toBeCloseTo(16 / 9, 12);
  });

  it("standardizeCPM returns no network when validation fails", () => {
    const { errors, network } = standardizeCPM(problem(act("A", -3)), "cpm");
    expect(errors.length).toBeGreaterThan(0);
    expect(network).toBeNull();
  });
});

describe("Mode inference", () => {
  it("plain durations → cpm; full three-point estimates → pert; mixtures → cpm (and get a clear error)", () => {
    expect(inferMode(problem(act("A", 1)))).toBe("cpm");
    expect(inferMode(problem(pert("A", 1, 2, 3), pert("B", 1, 2, 3)))).toBe("pert");
    expect(inferMode(problem(pert("A", 1, 2, 3), act("B", 4)))).toBe("cpm");
    expect(inferMode(problem())).toBe("cpm");
  });

  it("solveCPM with no mode argument infers it", () => {
    expect(solveCPM(problem(pert("A", 2, 3, 10))).isPert).toBe(true);
    expect(solveCPM(problem(act("A", 5))).isPert).toBe(false);
  });
});
