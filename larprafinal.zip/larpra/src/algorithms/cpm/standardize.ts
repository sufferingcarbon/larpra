import { CPMActivityInput, CPMMode, CPMProblemInput } from "../../types/cpm";
import { expectedDuration, pertVariance } from "./common";

/** The validated precedence network, with everything the passes need pre-computed. */
export interface CPMNetwork {
  /** Activity names in the order the user listed them. */
  names: string[];
  preds: Map<string, string[]>;
  /** Successors, ordered by the successor's position in the input list. */
  succs: Map<string, string[]>;
  /** Deterministic topological order (Kahn's algorithm, ties broken by input order). */
  order: string[];
  sources: string[];
  sinks: string[];
  /** Duration used by the passes (the expected duration in PERT mode). */
  duration: Map<string, number>;
  /** Per-activity variance — PERT only. */
  variance: Map<string, number> | null;
  estimates: Map<string, { optimistic: number; mostLikely: number; pessimistic: number }> | null;
}

const isNum = (x: unknown): x is number => typeof x === "number" && Number.isFinite(x);

/** If every activity carries all three estimates (and none a plain duration), the problem is PERT; otherwise CPM. */
export function inferMode(input: CPMProblemInput): CPMMode {
  const acts = input.activities;
  const allThree = acts.length > 0 && acts.every((a) => isNum(a.optimistic) && isNum(a.mostLikely) && isNum(a.pessimistic));
  const anyPlain = acts.some((a) => a.duration !== undefined);
  return allThree && !anyPlain ? "pert" : "cpm";
}

/**
 * Kahn's algorithm. Among activities that are ready at the same moment, the one listed
 * earliest by the user goes first, so the same input always yields the same order.
 * If a cycle blocks completion, `cycle` names one explicit cycle (A → B → C → A).
 */
export function topologicalOrder(
  names: string[],
  preds: Map<string, string[]>
): { order: string[]; cycle: string[] | null } {
  const position = new Map(names.map((n, i) => [n, i]));
  const remainingPreds = new Map(names.map((n) => [n, new Set(preds.get(n) ?? [])]));
  const succs = new Map(names.map((n) => [n, [] as string[]]));
  names.forEach((n) => remainingPreds.get(n)!.forEach((p) => succs.get(p)?.push(n)));

  let ready = names.filter((n) => remainingPreds.get(n)!.size === 0);
  const order: string[] = [];
  while (ready.length > 0) {
    ready.sort((a, b) => position.get(a)! - position.get(b)!);
    const next = ready.shift()!;
    order.push(next);
    for (const s of succs.get(next)!) {
      const set = remainingPreds.get(s)!;
      set.delete(next);
      if (set.size === 0) ready.push(s);
    }
  }
  if (order.length === names.length) return { order, cycle: null };

  // Every activity left over has at least one predecessor that is also left over.
  // Walk predecessor links until a name repeats; that segment is a cycle.
  const stuck = new Set(names.filter((n) => !order.includes(n)));
  const walk: string[] = [];
  let cur = names.find((n) => stuck.has(n))!;
  while (!walk.includes(cur)) {
    walk.push(cur);
    cur = (preds.get(cur) ?? []).find((p) => stuck.has(p))!;
  }
  const cycle = walk.slice(walk.indexOf(cur)).reverse();
  // Rotate so the loop starts at whichever member the user listed first — it reads more naturally.
  const first = cycle.reduce((best, n, i) => (position.get(n)! < position.get(cycle[best])! ? i : best), 0);
  const rotated = [...cycle.slice(first), ...cycle.slice(0, first)];
  return { order, cycle: [...rotated, rotated[0]] };
}

/** Everything wrong with the activity list, phrased for the person typing it in. Empty array = valid. */
export function validateCPM(input: CPMProblemInput, mode: CPMMode = inferMode(input)): string[] {
  const errors: string[] = [];
  const acts = input.activities;
  if (acts.length === 0) return ["Add at least one activity."];

  // ---- names
  const seen = new Set<string>();
  let namesOk = true;
  acts.forEach((a, i) => {
    if (!a.name.trim()) {
      errors.push(`Activity ${i + 1} has an empty name.`);
      namesOk = false;
    } else if (seen.has(a.name)) {
      errors.push(`Duplicate activity name: ${a.name}.`);
      namesOk = false;
    }
    seen.add(a.name);
  });

  // ---- durations / estimates
  acts.forEach((a) => {
    const label = a.name.trim() ? a.name : "(unnamed)";
    if (mode === "cpm") {
      if (!isNum(a.duration)) {
        const hasEstimates = isNum(a.optimistic) || isNum(a.mostLikely) || isNum(a.pessimistic);
        errors.push(
          hasEstimates
            ? `Activity ${label} has no single duration — switch to PERT mode to use three-point estimates.`
            : `Activity ${label} needs a duration.`
        );
      } else if (a.duration < 0) {
        errors.push(`Activity ${label} has a negative duration (${a.duration}).`);
      }
    } else {
      const { optimistic: o, mostLikely: m, pessimistic: p } = a;
      if (!isNum(o) || !isNum(m) || !isNum(p)) {
        errors.push(`Activity ${label} needs all three estimates (optimistic, most likely, pessimistic).`);
      } else if (o < 0 || m < 0 || p < 0) {
        errors.push(`Activity ${label} has a negative time estimate.`);
      } else if (!(o <= m && m <= p)) {
        errors.push(`Activity ${label}: estimates must satisfy optimistic ≤ most likely ≤ pessimistic (got ${o}, ${m}, ${p}).`);
      }
    }
  });

  // ---- predecessor references
  let refsOk = true;
  acts.forEach((a) => {
    const label = a.name.trim() ? a.name : "(unnamed)";
    const listed = new Set<string>();
    a.predecessors.forEach((p) => {
      if (p === a.name) {
        errors.push(`Activity ${label} lists itself as a predecessor.`);
        refsOk = false;
      } else if (!seen.has(p)) {
        errors.push(`Activity ${label} has an unknown predecessor: ${p}.`);
        refsOk = false;
      } else if (listed.has(p)) {
        errors.push(`Activity ${label} lists predecessor ${p} more than once.`);
        refsOk = false;
      }
      listed.add(p);
    });
  });

  // ---- cycles (only meaningful once names and references are sound)
  if (namesOk && refsOk) {
    const preds = new Map(acts.map((a) => [a.name, a.predecessors]));
    const { cycle } = topologicalOrder(acts.map((a) => a.name), preds);
    if (cycle) {
      errors.push(
        `The precedence relations form a cycle: ${cycle.join(" → ")}. Each activity in the loop would have to finish before it can start, so no schedule exists.`
      );
    }
  }
  return errors;
}

/** Validate and build the network in one go. `network` is null exactly when `errors` is non-empty. */
export function standardizeCPM(
  input: CPMProblemInput,
  mode: CPMMode = inferMode(input)
): { errors: string[]; network: CPMNetwork | null } {
  const errors = validateCPM(input, mode);
  if (errors.length > 0) return { errors, network: null };

  const acts: CPMActivityInput[] = input.activities;
  const names = acts.map((a) => a.name);
  const preds = new Map(acts.map((a) => [a.name, a.predecessors.slice()]));
  const succs = new Map(names.map((n) => [n, [] as string[]]));
  acts.forEach((a) => a.predecessors.forEach((p) => succs.get(p)!.push(a.name)));

  const { order } = topologicalOrder(names, preds);

  const duration = new Map<string, number>();
  const variance = mode === "pert" ? new Map<string, number>() : null;
  const estimates = mode === "pert" ? new Map<string, { optimistic: number; mostLikely: number; pessimistic: number }>() : null;
  acts.forEach((a) => {
    if (mode === "pert") {
      const o = a.optimistic!, m = a.mostLikely!, p = a.pessimistic!;
      duration.set(a.name, expectedDuration(o, m, p));
      variance!.set(a.name, pertVariance(o, p));
      estimates!.set(a.name, { optimistic: o, mostLikely: m, pessimistic: p });
    } else {
      duration.set(a.name, a.duration!);
    }
  });

  return {
    errors: [],
    network: {
      names,
      preds,
      succs,
      order,
      sources: names.filter((n) => preds.get(n)!.length === 0),
      sinks: names.filter((n) => succs.get(n)!.length === 0),
      duration,
      variance,
      estimates,
    },
  };
}
