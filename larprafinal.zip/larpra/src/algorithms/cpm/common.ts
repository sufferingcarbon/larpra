/** Shared numeric helpers for the CPM/PERT module. Plain numbers, not Fractions (see README). */

/** Slack at or below this is treated as zero. */
export const DEFAULT_TOLERANCE = 1e-9;

/** PERT expected duration: a weighted mean that counts the most-likely estimate four times. */
export function expectedDuration(optimistic: number, mostLikely: number, pessimistic: number): number {
  return (optimistic + 4 * mostLikely + pessimistic) / 6;
}

/** PERT variance of one activity: the (pessimistic − optimistic) range is treated as six standard deviations. */
export function pertVariance(optimistic: number, pessimistic: number): number {
  const sd = (pessimistic - optimistic) / 6;
  return sd * sd;
}

/**
 * Display formatting: at most 4 decimals, no trailing zeros, never "-0".
 * Calculations always use full precision; only what is shown is rounded.
 */
export function fmt(x: number): string {
  if (!Number.isFinite(x)) return String(x);
  const r = Math.round(x * 1e4) / 1e4;
  return String(Object.is(r, -0) ? 0 : r);
}

export function nearlyEqual(a: number, b: number, tol: number): boolean {
  return Math.abs(a - b) <= tol;
}
