import { AlgorithmStep } from "../../types/lp";
import {
  CPMActivityRow,
  CPMMode,
  CPMOptions,
  CPMProblemInput,
  CPMResult,
  CPMScheduleEntry,
  CPMTableauState,
} from "../../types/cpm";
import { DEFAULT_TOLERANCE, fmt, nearlyEqual } from "./common";
import { CPMNetwork, inferMode, standardizeCPM } from "./standardize";

/** A network with many parallel equal chains can have exponentially many critical paths; stop listing after this many. */
export const MAX_CRITICAL_PATHS = 100;

/** The algorithm's working memory — every step is a literal snapshot of this. */
interface Working {
  es: Map<string, number>;
  ef: Map<string, number>;
  ls: Map<string, number>;
  lf: Map<string, number>;
  slack: Map<string, number>;
  critical: Map<string, boolean>;
}

const orNull = (m: Map<string, number>, k: string): string | null => (m.has(k) ? fmt(m.get(k)!) : null);

/** "A", "A and B", "A, B and C" */
function andList(items: string[]): string {
  if (items.length <= 1) return items.join("");
  return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}

function buildRows(net: CPMNetwork, w: Working): CPMActivityRow[] {
  return net.names.map((name) => {
    const est = net.estimates?.get(name);
    return {
      name,
      duration: fmt(net.duration.get(name)!),
      estimates: est
        ? { optimistic: fmt(est.optimistic), mostLikely: fmt(est.mostLikely), pessimistic: fmt(est.pessimistic) }
        : null,
      predecessors: net.preds.get(name)!.slice(),
      successors: net.succs.get(name)!.slice(),
      variance: net.variance ? fmt(net.variance.get(name)!) : null,
      es: orNull(w.es, name),
      ef: orNull(w.ef, name),
      ls: orNull(w.ls, name),
      lf: orNull(w.lf, name),
      slack: orNull(w.slack, name),
      isCritical: w.critical.has(name) ? w.critical.get(name)! : null,
    };
  });
}

interface SnapshotOpts {
  phase: CPMTableauState["phase"];
  stepKind: string;
  currentActivity?: string | null;
  projectDuration?: number | null;
  criticalActivityNames?: string[] | null;
  criticalPaths?: string[][] | null;
  currentPath?: string[] | null;
  projectVariance?: number | null;
  projectStdDev?: number | null;
}

function snapshot(net: CPMNetwork, w: Working, o: SnapshotOpts): CPMTableauState {
  return {
    phase: o.phase,
    stepKind: o.stepKind,
    isPert: net.variance !== null,
    activities: buildRows(net, w),
    topologicalOrder: net.order.slice(),
    currentActivity: o.currentActivity ?? null,
    projectDuration: o.projectDuration == null ? null : fmt(o.projectDuration),
    criticalActivityNames: o.criticalActivityNames ? o.criticalActivityNames.slice() : null,
    criticalPaths: o.criticalPaths ? o.criticalPaths.map((p) => p.slice()) : null,
    currentPath: o.currentPath ? o.currentPath.slice() : null,
    projectVariance: o.projectVariance == null ? null : fmt(o.projectVariance),
    projectStdDev: o.projectStdDev == null ? null : fmt(o.projectStdDev),
  };
}

/**
 * Critical Path Method / PERT.
 *
 *  1. (PERT only) turn each three-point estimate into an expected duration and a variance
 *  2. topologically order the precedence network
 *  3. forward pass  — one step per activity:  ES = max(EF of predecessors), EF = ES + d
 *  4. backward pass — one step per activity:  LF = min(LS of successors),   LS = LF − d
 *  5. slack = LS − ES; slack ≈ 0 ⇒ critical
 *  6. critical paths = every source→sink chain of critical activities whose hand-offs are tight
 *  7. (PERT only) project variance = sum of activity variances along the critical path
 *
 * The same steps that drive "Next Step" produce the final answer — nothing is computed off to the side.
 */
export function solveCPM(input: CPMProblemInput, mode: CPMMode = inferMode(input), options: CPMOptions = {}): CPMResult {
  const tol = options.tolerance ?? DEFAULT_TOLERANCE;
  const isPert = mode === "pert";
  const { errors, network } = standardizeCPM(input, mode);
  if (!network) return { status: "invalid", steps: [], isPert, notes: errors };
  const net = network;

  const w: Working = {
    es: new Map(),
    ef: new Map(),
    ls: new Map(),
    lf: new Map(),
    slack: new Map(),
    critical: new Map(),
  };
  const steps: AlgorithmStep<CPMTableauState>[] = [];
  const dur = (n: string) => net.duration.get(n)!;
  let D: number | null = null;

  /* ------------------------------ setup ------------------------------ */

  if (isPert) {
    const first = net.order[0];
    const e = net.estimates!.get(first)!;
    steps.push({
      title: "Turn three-point estimates into expected durations",
      explanation:
        `PERT gives every activity three time estimates — optimistic (a), most likely (m) and pessimistic (b) — and replaces them with one expected duration te = (a + 4m + b) / 6 and a variance ((b − a) / 6)². ` +
        `For example, ${first}: te = (${fmt(e.optimistic)} + 4×${fmt(e.mostLikely)} + ${fmt(e.pessimistic)}) / 6 = ${fmt(net.duration.get(first)!)}, ` +
        `variance = ((${fmt(e.pessimistic)} − ${fmt(e.optimistic)}) / 6)² = ${fmt(net.variance!.get(first)!)}. ` +
        `From here on, the ordinary CPM passes run on the expected durations.`,
      operation: "te = (a + 4m + b) / 6;  var = ((b − a) / 6)²",
      state: snapshot(net, w, { phase: "setup", stepKind: "pert-estimates" }),
      why:
        "The formula approximates a Beta distribution: the most likely time gets four times the weight of either extreme, and the optimistic-to-pessimistic range is treated as about six standard deviations wide. " +
        "Shown values are rounded to 4 decimals; calculations keep full precision.",
    });
  }

  steps.push({
    title: "Set up the precedence network",
    explanation:
      `${net.names.length} ${net.names.length === 1 ? "activity" : "activities"}. ` +
      `Start ${net.sources.length === 1 ? "activity" : "activities"} (no predecessors): ${net.sources.join(", ")}. ` +
      `End ${net.sinks.length === 1 ? "activity" : "activities"} (no successors): ${net.sinks.join(", ")}. ` +
      `Processing order (a topological order): ${net.order.join(" → ")}.`,
    operation: "topological sort",
    state: snapshot(net, w, { phase: "setup", stepKind: "network" }),
    why:
      "The forward pass must handle each activity only after all of its predecessors, and the backward pass only after all of its successors. " +
      "A topological order guarantees that — and it exists exactly when the precedence relations contain no cycle.",
  });

  /* --------------------------- forward pass --------------------------- */

  for (const v of net.order) {
    const preds = net.preds.get(v)!;
    const d = dur(v);
    let esV = 0;
    let explanation: string;
    let operation: string;

    if (preds.length === 0) {
      explanation = `${v} has no predecessors, so it can start at time 0: ES = 0. EF = ES + duration = 0 + ${fmt(d)} = ${fmt(d)}.`;
      operation = `ES(${v}) = 0;  EF(${v}) = 0 + ${fmt(d)} = ${fmt(d)}`;
    } else {
      const efs = preds.map((p) => w.ef.get(p)!);
      esV = Math.max(...efs);
      const drivers = preds.filter((p) => nearlyEqual(w.ef.get(p)!, esV, tol));
      const listing = preds.map((p) => `${p} (EF ${fmt(w.ef.get(p)!)})`).join(", ");
      const drivenBy =
        preds.length === 1
          ? ""
          : drivers.length === 1
          ? `, set by ${drivers[0]}`
          : `, a tie between ${andList(drivers)}`;
      explanation =
        `${v} can't start until ${preds.length === 1 ? "its predecessor is" : "all its predecessors are"} done: ${listing}. ` +
        `ES = ${preds.length === 1 ? "that finish time" : "the latest of those finish times"} = ${fmt(esV)}${drivenBy}. ` +
        `EF = ES + duration = ${fmt(esV)} + ${fmt(d)} = ${fmt(esV + d)}.`;
      operation = `ES(${v}) = max(${efs.map(fmt).join(", ")}) = ${fmt(esV)};  EF(${v}) = ${fmt(esV)} + ${fmt(d)} = ${fmt(esV + d)}`;
    }
    w.es.set(v, esV);
    w.ef.set(v, esV + d);

    steps.push({
      title: `Forward pass — ${v}: ES = ${fmt(esV)}, EF = ${fmt(esV + d)}`,
      explanation,
      operation,
      state: snapshot(net, w, { phase: "forward", stepKind: "forward", currentActivity: v }),
      why: "An activity can't begin until every predecessor has finished, so its earliest start is the LARGEST of their earliest finishes — the slowest predecessor sets the pace.",
    });
  }

  D = Math.max(...net.names.map((n) => w.ef.get(n)!));
  const finishers = net.names.filter((n) => nearlyEqual(w.ef.get(n)!, D!, tol));
  steps.push({
    title: `Forward pass complete — project duration = ${fmt(D)}`,
    explanation:
      `The project can't finish before its last activity does: max(EF) = ${fmt(D)}, reached by ${andList(finishers)}. ` +
      `That is the shortest possible project duration, and it becomes the deadline the backward pass works back from.`,
    operation: `project duration = max(EF) = ${fmt(D)}`,
    state: snapshot(net, w, { phase: "forward", stepKind: "forward-complete", projectDuration: D }),
    why: "Every activity has to finish, so the project length is the largest earliest-finish time. No amount of parallelism can beat the longest chain of dependent work.",
  });

  /* -------------------------- backward pass -------------------------- */

  for (const v of [...net.order].reverse()) {
    const succs = net.succs.get(v)!;
    const d = dur(v);
    let lfV: number;
    let explanation: string;
    let operation: string;

    if (succs.length === 0) {
      lfV = D;
      explanation = `${v} has no successors, so it only has to finish by the project deadline: LF = ${fmt(D)}. LS = LF − duration = ${fmt(D)} − ${fmt(d)} = ${fmt(D - d)}.`;
      operation = `LF(${v}) = ${fmt(D)};  LS(${v}) = ${fmt(D)} − ${fmt(d)} = ${fmt(D - d)}`;
    } else {
      const lss = succs.map((s) => w.ls.get(s)!);
      lfV = Math.min(...lss);
      const drivers = succs.filter((s) => nearlyEqual(w.ls.get(s)!, lfV, tol));
      const listing = succs.map((s) => `${s} (LS ${fmt(w.ls.get(s)!)})`).join(", ");
      const drivenBy =
        succs.length === 1
          ? ""
          : drivers.length === 1
          ? `, set by ${drivers[0]}`
          : `, a tie between ${andList(drivers)}`;
      explanation =
        `${v} must be finished in time for ${succs.length === 1 ? "its successor" : "every successor"} to start on schedule: ${listing}. ` +
        `LF = ${succs.length === 1 ? "that start time" : "the earliest of those start times"} = ${fmt(lfV)}${drivenBy}. ` +
        `LS = LF − duration = ${fmt(lfV)} − ${fmt(d)} = ${fmt(lfV - d)}.`;
      operation = `LF(${v}) = min(${lss.map(fmt).join(", ")}) = ${fmt(lfV)};  LS(${v}) = ${fmt(lfV)} − ${fmt(d)} = ${fmt(lfV - d)}`;
    }
    w.lf.set(v, lfV);
    w.ls.set(v, lfV - d);

    steps.push({
      title: `Backward pass — ${v}: LF = ${fmt(lfV)}, LS = ${fmt(lfV - d)}`,
      explanation,
      operation,
      state: snapshot(net, w, { phase: "backward", stepKind: "backward", currentActivity: v, projectDuration: D }),
      why: "An activity can finish no later than the moment its most demanding successor must start, so its latest finish is the SMALLEST of its successors' latest starts (or the project deadline if it has none).",
    });
  }

  /* ------------------------------ slack ------------------------------ */

  const criticalNames: string[] = [];
  for (const v of net.names) {
    let s = w.ls.get(v)! - w.es.get(v)!;
    if (Math.abs(s) <= tol) s = 0;
    w.slack.set(v, s);
    const isCrit = s <= tol;
    w.critical.set(v, isCrit);
    if (isCrit) criticalNames.push(v);
  }
  const slackers = net.names.filter((n) => !w.critical.get(n));
  steps.push({
    title: `Slack: ${criticalNames.length} critical ${criticalNames.length === 1 ? "activity" : "activities"}`,
    explanation:
      `Slack = LS − ES (which equals LF − EF): how long an activity can slip without delaying the project. ` +
      `Zero slack means critical — ${andList(criticalNames)}. ` +
      (slackers.length === 0
        ? "Every activity is critical."
        : `The rest have room to move: ${slackers.map((n) => `${n} (${fmt(w.slack.get(n)!)})`).join(", ")}.`),
    operation: "slack = LS − ES;  critical ⇔ slack ≤ tolerance",
    state: snapshot(net, w, {
      phase: "slack",
      stepKind: "slack",
      projectDuration: D,
      criticalActivityNames: criticalNames,
    }),
    why:
      "Zero slack means the earliest and latest schedules coincide, so any delay pushes the project's end date out by the same amount. " +
      "Slack on a non-critical activity is only a budget for that one path — activities on the same path share it, so using it up on one leaves less for the others.",
  });

  /* ------------------------- critical paths -------------------------- */

  const isCritical = (n: string) => w.critical.get(n) === true;
  const paths: string[][] = [];
  let truncated = false;

  const extend = (path: string[]) => {
    const u = path[path.length - 1];
    const succs = net.succs.get(u)!;
    if (succs.length === 0) {
      if (paths.length >= MAX_CRITICAL_PATHS) truncated = true;
      else paths.push(path.slice());
      return;
    }
    for (const s of succs) {
      // A hand-off only counts if it is tight: u's earliest finish is exactly s's earliest start.
      if (isCritical(s) && nearlyEqual(w.ef.get(u)!, w.es.get(s)!, tol)) {
        path.push(s);
        extend(path);
        path.pop();
        if (truncated) return;
      }
    }
  };
  for (const s of net.sources.filter(isCritical)) {
    extend([s]);
    if (truncated) break;
  }

  const pathVariance = (p: string[]) => (net.variance ? p.reduce((sum, n) => sum + net.variance!.get(n)!, 0) : 0);

  paths.forEach((path, k) => {
    const terms = path.map((n) => fmt(dur(n))).join(" + ");
    const total = path.reduce((sum, n) => sum + dur(n), 0);
    steps.push({
      title: `Critical path ${k + 1}: ${path.join(" → ")}`,
      explanation:
        `Start at ${path[0]} (no predecessors) and follow zero-slack activities, each starting exactly when the previous one finishes, until ${path[path.length - 1]} (no successors). ` +
        `Durations along the way: ${terms} = ${fmt(total)}, which equals the project duration ${fmt(D!)}.` +
        (net.variance
          ? ` Variance along this path: ${path.map((n) => fmt(net.variance!.get(n)!)).join(" + ")} = ${fmt(pathVariance(path))}.`
          : ""),
      operation: `path length = ${terms} = ${fmt(total)}`,
      state: snapshot(net, w, {
        phase: "critical-path",
        stepKind: "critical-path-found",
        projectDuration: D,
        criticalActivityNames: criticalNames,
        criticalPaths: paths.slice(0, k + 1),
        currentPath: path,
      }),
      why:
        "A critical path is a chain with no slack anywhere — delay any activity on it and the whole project slips. Each hand-off must be tight: two zero-slack activities do not form a path if the later one is actually waiting on a different predecessor.",
    });
  });

  /* ---------------------------- PERT summary ---------------------------- */

  const pathVars = paths.map(pathVariance);
  let projectVariance: number | undefined;
  let projectStdDev: number | undefined;
  if (net.variance) {
    projectVariance = Math.max(...pathVars);
    projectStdDev = Math.sqrt(projectVariance);
  }

  const multi = paths.length > 1;
  const pathListing = paths.map((p) => p.join(" → ")).join("; ");
  steps.push({
    title: `Result: project duration ${fmt(D)}, ${paths.length}${truncated ? "+" : ""} critical path${paths.length === 1 && !truncated ? "" : "s"}`,
    explanation:
      `The project takes ${fmt(D)} time units. ` +
      (multi ? `${paths.length}${truncated ? "+" : ""} critical paths tie: ${pathListing}. ` : `The critical path is ${pathListing}. `) +
      (truncated ? `(Listing stopped at ${MAX_CRITICAL_PATHS} paths; more exist.) ` : "") +
      (net.variance
        ? `Project variance = sum of activity variances along the critical path = ${fmt(projectVariance!)}, so the standard deviation is ${fmt(projectStdDev!)}.` +
          (multi ? ` The critical paths' variances are ${pathVars.map(fmt).join(", ")}; the largest is used, the cautious choice.` : "")
        : "Delaying any critical activity delays the project by the same amount; the others can slip by up to their slack."),
    operation: net.variance ? "σ² = Σ var(critical activities);  σ = √σ²" : undefined,
    state: snapshot(net, w, {
      phase: "critical-path",
      stepKind: "summary",
      projectDuration: D,
      criticalActivityNames: criticalNames,
      criticalPaths: paths,
      projectVariance,
      projectStdDev,
    }),
    why: net.variance
      ? "PERT treats the project length as roughly normal, with mean = project duration (the sum of expected durations on the critical path) and variance = the sum of the activities' variances, assuming the activities are independent."
      : undefined,
  });

  /* ------------------------------ result ------------------------------ */

  const schedule: Record<string, CPMScheduleEntry> = {};
  for (const n of net.names) {
    schedule[n] = {
      duration: dur(n),
      variance: net.variance ? net.variance.get(n)! : null,
      es: w.es.get(n)!,
      ef: w.ef.get(n)!,
      ls: w.ls.get(n)!,
      lf: w.lf.get(n)!,
      slack: w.slack.get(n)!,
      critical: w.critical.get(n)!,
    };
  }

  const notes: string[] = [];
  if (truncated) notes.push(`Only the first ${MAX_CRITICAL_PATHS} critical paths are listed; the network has more.`);
  if (net.variance) {
    notes.push(
      "PERT's project variance sums the variances along a single critical path and assumes independent activities. It ignores near-critical paths, so it can understate the real uncertainty when several paths are close in length."
    );
    notes.push("Values are shown rounded to 4 decimals; calculations use full precision.");
    if (multi) notes.push("Several critical paths tie; the project variance uses the largest path variance (the conservative choice).");
  }

  return {
    status: "optimal",
    steps,
    projectDuration: D,
    criticalPaths: paths,
    schedule,
    projectVariance,
    projectStdDev,
    criticalPathVariances: net.variance ? pathVars : undefined,
    isPert,
    notes,
  };
}
