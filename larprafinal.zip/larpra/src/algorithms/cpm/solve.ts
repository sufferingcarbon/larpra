export { solveCPM, MAX_CRITICAL_PATHS } from "./cpm";
