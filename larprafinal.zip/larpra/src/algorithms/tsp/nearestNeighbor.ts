import { AlgorithmStep } from "../../types/lp";
import { NNCandidate, NNResult, NNState, TSPProblemInput } from "../../types/tsp";
import { validateTSP } from "./standardize";

function snapshot(opts: {
  stepKind: string;
  phase: NNState["phase"];
  tour: string[];
  remaining: string[];
  currentCity: string | null;
  candidates?: NNCandidate[] | null;
  selected?: string | null;
  totalCost: number;
}): NNState {
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    tour: opts.tour.slice(),
    remaining: opts.remaining.slice(),
    currentCity: opts.currentCity,
    candidates: opts.candidates ?? null,
    selected: opts.selected ?? null,
    totalCost: String(opts.totalCost),
  };
}

export function solveNearestNeighbor(input: TSPProblemInput, startCity?: string): NNResult {
  const errors = validateTSP(input);
  const start = startCity ?? input.cities[0];
  if (!input.cities.includes(start) && errors.length === 0) errors.push(`Start city "${start}" is not in the problem.`);
  if (errors.length > 0) return { status: "invalid", steps: [], notes: errors };

  const index = new Map(input.cities.map((c, i) => [c, i]));
  const dist = (a: string, b: string) => input.distances[index.get(a)!][index.get(b)!];

  let tour = [start];
  let remaining = input.cities.filter((c) => c !== start);
  let totalCost = 0;

  const steps: AlgorithmStep<NNState>[] = [
    {
      title: `Start at ${start}`,
      explanation: `Nearest Neighbor always starts by picking a city arbitrarily and repeatedly hopping to whichever unvisited city is closest, so the tour begins at ${start}.`,
      state: snapshot({ stepKind: "start", phase: "start", tour, remaining, currentCity: start, totalCost }),
      why: "This is a greedy heuristic, not an exhaustive search — it never reconsiders a choice once made, which is what makes it fast but not guaranteed optimal.",
    },
  ];

  let current = start;
  while (remaining.length > 0) {
    const candidates: NNCandidate[] = remaining.map((c) => ({ city: c, distance: String(dist(current, c)) }));
    const reachable = candidates.filter((c) => Number.isFinite(Number(c.distance)));
    if (reachable.length === 0) {
      steps.push({
        title: "No reachable city remains",
        explanation: `Every remaining city (${remaining.join(", ")}) has no direct edge from ${current} — Nearest Neighbor cannot complete a tour from here.`,
        state: snapshot({ stepKind: "stuck", phase: "done", tour, remaining, currentCity: current, candidates, totalCost }),
      });
      return { status: "no-tour", steps, notes: [`Nearest Neighbor got stuck at ${current} with no edge to any remaining city.`] };
    }

    let best = reachable[0];
    for (const c of reachable) if (Number(c.distance) < Number(best.distance)) best = c;

    steps.push({
      title: `From ${current}, choose ${best.city} (distance ${best.distance})`,
      explanation: `Among the remaining unvisited cities (${remaining.join(", ")}), ${best.city} is closest to ${current} at distance ${best.distance}, so it's added next.`,
      operation: `select(${best.city})`,
      state: snapshot({ stepKind: "select", phase: "select", tour, remaining, currentCity: current, candidates, selected: best.city, totalCost }),
      why: "Nearest Neighbor's rule is simply \"go to whatever's closest right now\" — it never looks ahead to whether that choice strands a distant city for later.",
    });

    totalCost += Number(best.distance);
    tour = [...tour, best.city];
    remaining = remaining.filter((c) => c !== best.city);
    current = best.city;
  }

  const closingDistance = dist(current, start);
  totalCost += closingDistance;
  tour = [...tour, start];

  steps.push({
    title: `Return to ${start} (distance ${closingDistance}) — tour complete`,
    explanation: `Every city has been visited, so the tour closes by returning from ${current} to the start (${start}), adding ${closingDistance}. Total tour cost: ${totalCost}.`,
    state: snapshot({ stepKind: "close", phase: "done", tour, remaining: [], currentCity: current, selected: start, totalCost }),
  });

  return { status: "optimal", steps, tour, totalCost, notes: ["Nearest Neighbor is a heuristic — it finds a valid tour quickly but does not guarantee the shortest possible one."] };
}
