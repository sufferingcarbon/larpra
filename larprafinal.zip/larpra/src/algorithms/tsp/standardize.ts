import { TSPProblemInput } from "../../types/tsp";

export function validateTSP(input: TSPProblemInput): string[] {
  const errors: string[] = [];
  const n = input.cities.length;

  const seen = new Set<string>();
  input.cities.forEach((c) => {
    if (!c.trim()) errors.push("A city has an empty name.");
    if (seen.has(c)) errors.push(`Duplicate city name: ${c}.`);
    seen.add(c);
  });
  if (n < 3) errors.push("A tour needs at least 3 cities.");

  if (input.distances.length !== n) {
    errors.push(`The distance matrix has ${input.distances.length} rows but there are ${n} cities.`);
    return errors; // further row/col checks would be meaningless
  }
  input.distances.forEach((row, i) => {
    if (row.length !== n) {
      errors.push(`Row ${i + 1} of the distance matrix has ${row.length} entries; expected ${n}.`);
    }
  });
  if (errors.length > 0) return errors;

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      const d = input.distances[i][j];
      if (i === j) continue;
      if (Number.isNaN(d)) errors.push(`Distance from ${input.cities[i]} to ${input.cities[j]} is missing.`);
      else if (d < 0) errors.push(`Distance from ${input.cities[i]} to ${input.cities[j]} is negative — costs can't be negative.`);
    }
  }

  if (input.symmetric) {
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const a = input.distances[i][j];
        const b = input.distances[j][i];
        if (a !== b) {
          errors.push(
            `Matrix marked symmetric, but ${input.cities[i]}→${input.cities[j]} (${a}) ≠ ${input.cities[j]}→${input.cities[i]} (${b}).`
          );
        }
      }
    }
  }

  return errors;
}
