import { describe, it, expect } from "vitest";
import { solveTSPBranchAndBound } from "../branchAndBound";
import { tspExamples } from "../examples";
import { TSPProblemInput } from "../../../types/tsp";

describe.each(tspExamples)("solveTSPBranchAndBound — $name (brute-force verified)", (example) => {
  it(`finds the true optimum (${example.optimalCost})`, () => {
    const result = solveTSPBranchAndBound(example.problem);
    expect(result.status).toBe("optimal");
    expect(result.totalCost).toBeCloseTo(example.optimalCost, 1);
  });

  it("returns a tour that visits every city exactly once and returns to the start", () => {
    const result = solveTSPBranchAndBound(example.problem);
    const tour = result.tour!;
    expect(tour[0]).toBe(tour[tour.length - 1]);
    const interior = tour.slice(0, -1);
    expect(new Set(interior).size).toBe(example.problem.cities.length);
    example.problem.cities.forEach((c) => expect(interior).toContain(c));
  });

  it("recomputes the reported cost by summing the actual tour edges", () => {
    const result = solveTSPBranchAndBound(example.problem);
    const tour = result.tour!;
    const idx = new Map(example.problem.cities.map((c, i) => [c, i]));
    let sum = 0;
    for (let i = 0; i < tour.length - 1; i++) sum += example.problem.distances[idx.get(tour[i])!][idx.get(tour[i + 1])!];
    expect(sum).toBeCloseTo(result.totalCost!, 6);
  });

  it("proves optimality via an exhausted frontier (final step reports 0 remaining)", () => {
    const result = solveTSPBranchAndBound(example.problem);
    const last = result.steps[result.steps.length - 1];
    expect(last.state.stepKind).toBe("done");
    expect(last.state.frontierSize).toBe(0);
  });

  it("prunes at least one node on this instance (demonstrating the bound actually does work)", () => {
    const result = solveTSPBranchAndBound(example.problem);
    const last = result.steps[result.steps.length - 1];
    expect(last.state.nodesPruned).toBeGreaterThan(0);
  });
});

describe("solveTSPBranchAndBound — edge cases", () => {
  it("rejects fewer than 3 cities", () => {
    const problem: TSPProblemInput = { cities: ["A", "B"], symmetric: true, distances: [[0, 1], [1, 0]] };
    const result = solveTSPBranchAndBound(problem);
    expect(result.status).toBe("invalid");
  });

  it("rejects a mismatched matrix size", () => {
    const problem: TSPProblemInput = { cities: ["A", "B", "C"], symmetric: true, distances: [[0, 1], [1, 0]] };
    const result = solveTSPBranchAndBound(problem);
    expect(result.status).toBe("invalid");
  });

  it("reports infeasible when a required edge is missing (Infinity)", () => {
    const problem: TSPProblemInput = {
      cities: ["A", "B", "C"],
      symmetric: false,
      distances: [
        [0, 1, Infinity],
        [Infinity, 0, 1],
        [Infinity, Infinity, 0],
      ],
    };
    const result = solveTSPBranchAndBound(problem);
    expect(result.status).toBe("infeasible");
  });

  it("handles a case with tied distances deterministically (same result every run)", () => {
    const problem: TSPProblemInput = {
      cities: ["A", "B", "C", "D"],
      symmetric: true,
      distances: [
        [0, 1, 1, 1],
        [1, 0, 1, 1],
        [1, 1, 0, 1],
        [1, 1, 1, 0],
      ],
    };
    const r1 = solveTSPBranchAndBound(problem);
    const r2 = solveTSPBranchAndBound(problem);
    expect(r1.tour).toEqual(r2.tour);
    expect(r1.totalCost).toBe(4);
  });
});
