import { describe, it, expect } from "vitest";
import { solveNearestNeighbor } from "../nearestNeighbor";
import { tspExamples } from "../examples";
import { TSPProblemInput } from "../../../types/tsp";

describe.each(tspExamples)("solveNearestNeighbor — $name", (example) => {
  it("produces a valid tour visiting every city exactly once", () => {
    const result = solveNearestNeighbor(example.problem);
    expect(result.status).toBe("optimal");
    const tour = result.tour!;
    expect(tour[0]).toBe(tour[tour.length - 1]);
    const interior = tour.slice(0, -1);
    expect(new Set(interior).size).toBe(example.problem.cities.length);
  });

  it("never returns a cost cheaper than the true optimum (it's a heuristic, an upper bound)", () => {
    const result = solveNearestNeighbor(example.problem);
    expect(result.totalCost!).toBeGreaterThanOrEqual(example.optimalCost - 1e-6);
  });

  it("recomputes the reported cost by summing the actual tour edges", () => {
    const result = solveNearestNeighbor(example.problem);
    const tour = result.tour!;
    const idx = new Map(example.problem.cities.map((c, i) => [c, i]));
    let sum = 0;
    for (let i = 0; i < tour.length - 1; i++) sum += example.problem.distances[idx.get(tour[i])!][idx.get(tour[i + 1])!];
    expect(sum).toBeCloseTo(result.totalCost!, 6);
  });

  it("flags itself as a heuristic, not a guaranteed optimum", () => {
    const result = solveNearestNeighbor(example.problem);
    expect(result.notes.some((n) => /heuristic/i.test(n))).toBe(true);
  });
});

describe("solveNearestNeighbor — edge cases", () => {
  it("reports no-tour when stuck with no reachable remaining city", () => {
    const problem: TSPProblemInput = {
      cities: ["A", "B", "C"],
      symmetric: false,
      distances: [
        [0, 1, Infinity],
        [Infinity, 0, Infinity],
        [1, 1, 0],
      ],
    };
    const result = solveNearestNeighbor(problem, "A");
    expect(result.status).toBe("no-tour");
  });

  it("respects a custom start city", () => {
    const result = solveNearestNeighbor(tspExamples[1].problem, "C");
    expect(result.tour![0]).toBe("C");
  });
});
