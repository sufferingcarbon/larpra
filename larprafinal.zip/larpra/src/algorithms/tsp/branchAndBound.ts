import { AlgorithmStep } from "../../types/lp";
import { BnBResult, BnBState, TSPChildSummary, TSPProblemInput } from "../../types/tsp";
import { validateTSP } from "./standardize";

interface BnBNode {
  partial: string[];
  remaining: string[];
  cost: number;
  lowerBound: number;
  isComplete: boolean;
}

function snapshot(opts: {
  stepKind: string;
  phase: BnBState["phase"];
  currentNode?: BnBNode | null;
  children?: TSPChildSummary[];
  frontierSize: number;
  incumbent: { tour: string[]; cost: number } | null;
  nodesExplored: number;
  nodesPruned: number;
}): BnBState {
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    currentNode: opts.currentNode
      ? { partial: opts.currentNode.partial.slice(), cost: String(opts.currentNode.cost), lowerBound: String(opts.currentNode.lowerBound) }
      : null,
    children: opts.children ?? [],
    frontierSize: opts.frontierSize,
    incumbentTour: opts.incumbent?.tour.slice() ?? null,
    incumbentCost: opts.incumbent ? String(opts.incumbent.cost) : null,
    nodesExplored: opts.nodesExplored,
    nodesPruned: opts.nodesPruned,
  };
}

export function solveTSPBranchAndBound(input: TSPProblemInput): BnBResult {
  const errors = validateTSP(input);
  if (errors.length > 0) return { status: "invalid", steps: [], notes: errors };

  const n = input.cities.length;
  const index = new Map(input.cities.map((c, i) => [c, i]));
  const dist = (a: string, b: string) => input.distances[index.get(a)!][index.get(b)!];
  const start = input.cities[0];

  const minEdge = (u: string, targets: string[]): number => {
    let best = Infinity;
    for (const v of targets) best = Math.min(best, dist(u, v));
    return best;
  };

  const lowerBound = (partial: string[], remaining: string[], costSoFar: number): number => {
    const last = partial[partial.length - 1];
    if (remaining.length === 0) return costSoFar + dist(last, start);
    let bound = costSoFar + minEdge(last, remaining);
    for (const x of remaining) {
      const targets = [...remaining.filter((c) => c !== x), start];
      bound += minEdge(x, targets);
    }
    return bound;
  };

  const makeNode = (partial: string[], remaining: string[], costSoFar: number): BnBNode => {
    if (remaining.length === 0) {
      const closed = costSoFar + dist(partial[partial.length - 1], start);
      return { partial, remaining, cost: closed, lowerBound: closed, isComplete: true };
    }
    return { partial, remaining, cost: costSoFar, lowerBound: lowerBound(partial, remaining, costSoFar), isComplete: false };
  };

  const root = makeNode([start], input.cities.filter((c) => c !== start), 0);

  if (root.lowerBound === Infinity) {
    return { status: "infeasible", steps: [], notes: ["No feasible tour exists — some required edge is missing from the distance matrix."] };
  }

  const frontier: BnBNode[] = [root];
  let incumbent: { tour: string[]; cost: number } | null = null;
  let nodesExplored = 0;
  let nodesPruned = 0;

  const steps: AlgorithmStep<BnBState>[] = [
    {
      title: `Root node: start at ${start}`,
      explanation: `The search fixes ${start} as the starting city (any tour can be rotated to start there without changing its cost), leaving ${root.remaining.length} cities to order. The root's lower bound is ${root.lowerBound}: it assumes every city still gets its cheapest available outgoing edge, which is optimistic but never overstates the true cost.`,
      state: snapshot({ stepKind: "root", phase: "root", currentNode: root, frontierSize: 1, incumbent, nodesExplored, nodesPruned }),
      why: "A lower bound is admissible when it never exceeds the true cost of the best completion — that's exactly what summing each unrouted city's cheapest remaining edge gives, since the real tour can't do better than everyone's single cheapest option simultaneously.",
    },
  ];

  let guard = 0;
  const maxGuard = 20000;

  while (frontier.length > 0 && guard++ < maxGuard) {
    // Best-first: pop the node with the smallest lower bound (ties broken by cost, then partial path for determinism).
    let bestIdx = 0;
    for (let i = 1; i < frontier.length; i++) {
      const a = frontier[i];
      const b = frontier[bestIdx];
      if (a.lowerBound < b.lowerBound || (a.lowerBound === b.lowerBound && a.cost < b.cost) || (a.lowerBound === b.lowerBound && a.cost === b.cost && a.partial.join() < b.partial.join())) {
        bestIdx = i;
      }
    }
    const node = frontier.splice(bestIdx, 1)[0];
    nodesExplored++;

    if (incumbent && node.lowerBound >= incumbent.cost) {
      nodesPruned++;
      steps.push({
        title: `Prune node ${node.partial.join("→")}… (bound ${node.lowerBound} ≥ best known ${incumbent.cost})`,
        explanation: `This node's own lower bound (${node.lowerBound}) is already no better than the best complete tour found so far (${incumbent.cost}), so no completion of it could possibly improve on the incumbent — it's discarded without expanding.`,
        state: snapshot({ stepKind: "prune", phase: "expand", currentNode: node, frontierSize: frontier.length, incumbent, nodesExplored, nodesPruned }),
        why: "This is the entire point of branch and bound: a node never needs to be explored further once we can prove — via its bound — that it cannot beat what we already have.",
      });
      continue;
    }

    if (node.isComplete) {
      const improved = !incumbent || node.cost < incumbent.cost;
      if (improved) incumbent = { tour: [...node.partial, start], cost: node.cost };
      steps.push({
        title: improved
          ? `Complete tour found: ${[...node.partial, start].join("→")} (cost ${node.cost}) — new best`
          : `Complete tour found: ${[...node.partial, start].join("→")} (cost ${node.cost}) — not an improvement`,
        explanation: improved
          ? `Every city is now visited and the tour closes back to ${start} for a total cost of ${node.cost}, which beats the previous best (${incumbent && incumbent.cost !== node.cost ? "none yet" : "—"}). This becomes the new incumbent.`
          : `This completes a valid tour at cost ${node.cost}, but the current incumbent (${incumbent!.cost}) is still better, so it's kept as-is.`,
        state: snapshot({ stepKind: improved ? "incumbent-update" : "complete-no-improve", phase: "expand", currentNode: node, frontierSize: frontier.length, incumbent, nodesExplored, nodesPruned }),
        why: "A complete tour is a real, feasible solution — not just a bound — so it's always safe to compare it directly against the incumbent.",
      });
      continue;
    }

    // Expand: branch on every remaining city as the next step from this node.
    const children: TSPChildSummary[] = [];
    const last = node.partial[node.partial.length - 1];
    const candidates = node.remaining.slice().sort((a, b) => dist(last, a) - dist(last, b));
    for (const c of candidates) {
      const child = makeNode([...node.partial, c], node.remaining.filter((x) => x !== c), node.cost + dist(last, c));
      const wouldPrune = incumbent !== null && child.lowerBound >= incumbent.cost;
      children.push({
        partial: child.partial,
        cost: String(child.cost),
        lowerBound: String(child.lowerBound),
        isComplete: child.isComplete,
        pruned: wouldPrune,
        pruneReason: wouldPrune ? `bound ${child.lowerBound} ≥ best known ${incumbent!.cost}` : null,
      });
      if (wouldPrune) nodesPruned++;
      else frontier.push(child);
    }

    steps.push({
      title: `Expand ${node.partial.join("→")}… into ${children.length} branch${children.length === 1 ? "" : "es"}`,
      explanation: `From ${last}, the search branches on each remaining city (${node.remaining.join(", ")}), computing a new lower bound for each. ${
        children.some((c) => c.pruned)
          ? `${children.filter((c) => c.pruned).length} of them can already be pruned against the current incumbent (${incumbent!.cost}).`
          : "None can be pruned yet."
      }`,
      operation: `expand(${node.partial.join("-")})`,
      state: snapshot({ stepKind: "expand", phase: "expand", currentNode: node, children, frontierSize: frontier.length, incumbent, nodesExplored, nodesPruned }),
      why: "Branching enumerates every legal next city; each child's lower bound is checked immediately against the best solution found so far so obviously-worse branches never even enter the frontier.",
    });
  }

  if (!incumbent) {
    return { status: "infeasible", steps, notes: ["No feasible tour was found."] };
  }

  steps.push({
    title: `Optimal tour: ${incumbent.tour.join("→")} (cost ${incumbent.cost})`,
    explanation: `The frontier is exhausted — every remaining possibility has been either explored to completion or proven, via its bound, that it cannot beat ${incumbent.cost}. That makes this tour provably optimal, not just the best one tried. Explored ${nodesExplored} nodes, pruned ${nodesPruned}.`,
    state: snapshot({ stepKind: "done", phase: "done", currentNode: null, frontierSize: 0, incumbent, nodesExplored, nodesPruned }),
  });

  return { status: "optimal", steps, tour: incumbent.tour, totalCost: incumbent.cost, notes: [] };
}
