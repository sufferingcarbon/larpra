import { TSPProblemInput } from "../../types/tsp";

export interface TSPExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: TSPProblemInput;
  optimalCost: number;
}

export const tspExamples: TSPExample[] = [
  {
    name: "5 cities on a plane (Euclidean)",
    difficulty: "beginner",
    description:
      "Four cities at the corners of a square with one in the middle; distances are straight-line (Euclidean). Brute-force enumeration confirms the optimal tour is the square's perimeter (A→B→C→D→A) with E slotted in, cost 8.82.",
    problem: {
      cities: ["A", "B", "C", "D", "E"],
      symmetric: true,
      coordinates: { A: { x: 0, y: 0 }, B: { x: 2, y: 0 }, C: { x: 2, y: 2 }, D: { x: 0, y: 2 }, E: { x: 1, y: 1 } },
      distances: [
        [0, 2, 2.83, 2, 1.41],
        [2, 0, 2, 2.83, 1.41],
        [2.83, 2, 0, 2, 1.41],
        [2, 2.83, 2, 0, 1.41],
        [1.41, 1.41, 1.41, 1.41, 0],
      ],
    },
    optimalCost: 8.82,
  },
  {
    name: "6-city symmetric network",
    difficulty: "intermediate",
    description:
      "A denser 6-city symmetric cost matrix with no obvious geometric shortcut. Brute-force enumeration over all 60 distinct tours confirms the optimum: A→B→D→C→F→E→A, cost 40.",
    problem: {
      cities: ["A", "B", "C", "D", "E", "F"],
      symmetric: true,
      distances: [
        [0, 12, 10, 19, 8, 15],
        [12, 0, 3, 7, 6, 20],
        [10, 3, 0, 2, 20, 4],
        [19, 7, 2, 0, 4, 16],
        [8, 6, 20, 4, 0, 7],
        [15, 20, 4, 16, 7, 0],
      ],
    },
    optimalCost: 40,
  },
  {
    name: "5-city asymmetric network",
    difficulty: "difficult",
    description:
      "Cost depends on direction of travel (e.g. A→B costs 4 but B→A costs 6) — a realistic case for one-way streets or wind-affected routes. Brute-force enumeration confirms the optimum: A→B→D→C→E→A, cost 21.",
    problem: {
      cities: ["A", "B", "C", "D", "E"],
      symmetric: false,
      distances: [
        [0, 4, 9, 7, 3],
        [6, 0, 5, 2, 8],
        [8, 7, 0, 6, 4],
        [5, 3, 9, 0, 6],
        [2, 8, 5, 7, 0],
      ],
    },
    optimalCost: 21,
  },
];
