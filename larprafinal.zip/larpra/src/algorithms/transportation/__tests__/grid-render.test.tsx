import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { solveTransportation } from "../solve";
import { transportationExamples } from "../examples";
import { InitialMethod } from "../../../types/transportation";
import { TransportationGrid } from "../../../components/transportation/TransportationGrid";

const methods: InitialMethod[] = ["northwest-corner", "least-cost", "vogel"];

describe("TransportationGrid renders every real step without throwing", () => {
  transportationExamples.forEach((ex) => {
    methods.forEach((method) => {
      it(`${ex.name} / ${method}`, () => {
        const result = solveTransportation(ex.problem, method);
        expect(result.steps.length).toBeGreaterThan(0);
        result.steps.forEach((step, i) => {
          let html: string;
          try {
            html = renderToStaticMarkup(<TransportationGrid state={step.state} />);
          } catch (e) {
            throw new Error(`Step ${i} ("${step.title}") failed to render: ${(e as Error).message}`);
          }
          expect(html.length).toBeGreaterThan(0);
          ex.problem.sourceNames.forEach((name) => expect(html).toContain(name));
        });
      });
    });
  });
});
