import { describe, it, expect } from "vitest";
import { balance, validateProblem } from "../standardize";
import { TransportationProblemInput } from "../../../types/transportation";

describe("balance", () => {
  it("leaves an already-balanced problem untouched", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1", "S2"],
      destNames: ["D1", "D2"],
      costs: [
        [1, 2],
        [3, 4],
      ],
      supply: [5, 5],
      demand: [5, 5],
    };
    const result = balance(problem);
    expect(result.dummy).toBeNull();
    expect(result.sourceNames).toEqual(["S1", "S2"]);
    expect(result.destNames).toEqual(["D1", "D2"]);
  });

  it("adds a dummy destination when supply exceeds demand", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1"],
      destNames: ["D1"],
      costs: [[5]],
      supply: [10],
      demand: [6],
    };
    const result = balance(problem);
    expect(result.dummy).not.toBeNull();
    expect(result.dummy!.type).toBe("destination");
    expect(result.dummy!.amount.toNumber()).toBe(4);
    expect(result.destNames).toEqual(["D1", "Dummy destination"]);
    expect(result.costs[0][1].toNumber()).toBe(0);
    expect(result.totalSupply.equals(result.totalDemand)).toBe(true);
  });

  it("adds a dummy source when demand exceeds supply", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1"],
      destNames: ["D1"],
      costs: [[5]],
      supply: [6],
      demand: [10],
    };
    const result = balance(problem);
    expect(result.dummy).not.toBeNull();
    expect(result.dummy!.type).toBe("source");
    expect(result.dummy!.amount.toNumber()).toBe(4);
    expect(result.sourceNames).toEqual(["S1", "Dummy source"]);
    expect(result.costs[1][0].toNumber()).toBe(0);
    expect(result.totalSupply.equals(result.totalDemand)).toBe(true);
  });
});

describe("validateProblem", () => {
  it("accepts a well-formed problem", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1"],
      destNames: ["D1"],
      costs: [[5]],
      supply: [10],
      demand: [10],
    };
    expect(validateProblem(problem)).toEqual([]);
  });

  it("flags a cost-matrix / dimension mismatch", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1", "S2"],
      destNames: ["D1"],
      costs: [[5]],
      supply: [10, 5],
      demand: [10],
    };
    expect(validateProblem(problem).length).toBeGreaterThan(0);
  });

  it("flags negative supply", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1"],
      destNames: ["D1"],
      costs: [[5]],
      supply: [-1],
      demand: [10],
    };
    expect(validateProblem(problem).length).toBeGreaterThan(0);
  });
});
