import { describe, it, expect } from "vitest";
import { solveTransportation } from "../solve";
import { InitialMethod, TransportationProblemInput } from "../../../types/transportation";

const methods: InitialMethod[] = ["northwest-corner", "least-cost", "vogel"];

describe("solveTransportation — balanced case", () => {
  // Ground truth: 743, independently verified with scipy.optimize.linprog.
  const problem: TransportationProblemInput = {
    sourceNames: ["Plant 1", "Plant 2", "Plant 3"],
    destNames: ["W1", "W2", "W3", "W4"],
    costs: [
      [19, 30, 50, 10],
      [70, 30, 40, 60],
      [40, 8, 70, 20],
    ],
    supply: [7, 9, 18],
    demand: [5, 8, 7, 14],
  };

  methods.forEach((method) => {
    it(`reaches the true optimum (743) starting from ${method}`, () => {
      const result = solveTransportation(problem, method);
      expect(["optimal", "degenerate_optimal"]).toContain(result.status);
      expect(result.totalCost).toBeCloseTo(743);
      expect(result.steps.length).toBeGreaterThan(3);
      // Every allocation shipped respects that source's/destination's original totals.
      const shippedPerSource: Record<string, number> = {};
      const shippedPerDest: Record<string, number> = {};
      for (const [src, dests] of Object.entries(result.allocation ?? {})) {
        for (const [dest, amt] of Object.entries(dests)) {
          shippedPerSource[src] = (shippedPerSource[src] ?? 0) + amt;
          shippedPerDest[dest] = (shippedPerDest[dest] ?? 0) + amt;
        }
      }
      problem.sourceNames.forEach((name, i) => {
        expect(shippedPerSource[name] ?? 0).toBeCloseTo(problem.supply[i]);
      });
      problem.destNames.forEach((name, j) => {
        expect(shippedPerDest[name] ?? 0).toBeCloseTo(problem.demand[j]);
      });
    });
  });
});

describe("solveTransportation — unbalanced case (needs a dummy)", () => {
  // Ground truth: 144, independently verified with scipy.optimize.linprog.
  const problem: TransportationProblemInput = {
    sourceNames: ["F1", "F2", "F3"],
    destNames: ["W1", "W2", "W3"],
    costs: [
      [4, 6, 8],
      [6, 8, 6],
      [3, 5, 4],
    ],
    supply: [6, 8, 20],
    demand: [7, 5, 20],
  };

  methods.forEach((method) => {
    it(`balances via a dummy and reaches 144 starting from ${method}`, () => {
      const result = solveTransportation(problem, method);
      expect(["optimal", "degenerate_optimal"]).toContain(result.status);
      expect(result.totalCost).toBeCloseTo(144);
      const balanceStep = result.steps.find((s) => s.state.stepKind === "balance-check");
      expect(balanceStep).toBeDefined();
      expect((balanceStep!.state as any).dummyNote).not.toBeNull();
    });
  });
});

describe("solveTransportation — degenerate case", () => {
  // Ground truth: 100, independently verified with scipy.optimize.linprog.
  const problem: TransportationProblemInput = {
    sourceNames: ["S1", "S2", "S3"],
    destNames: ["D1", "D2", "D3"],
    costs: [
      [2, 3, 1],
      [5, 4, 8],
      [5, 6, 8],
    ],
    supply: [10, 10, 10],
    demand: [10, 10, 10],
  };

  it("North-West Corner hits simultaneous zeroing and needs ε", () => {
    const result = solveTransportation(problem, "northwest-corner");
    expect(result.status).toBe("degenerate_optimal");
    expect(result.totalCost).toBeCloseTo(100);
    const degStep = result.steps.find((s) => s.state.stepKind === "degeneracy-fix");
    expect(degStep).toBeDefined();
  });

  methods.forEach((method) => {
    it(`reaches the true optimum (100) starting from ${method}`, () => {
      const result = solveTransportation(problem, method);
      expect(result.totalCost).toBeCloseTo(100);
    });
  });
});

describe("solveTransportation — invalid input", () => {
  it("reports validation errors instead of throwing", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1", "S2"],
      destNames: ["D1"],
      costs: [[5]],
      supply: [10, 5],
      demand: [10],
    };
    const result = solveTransportation(problem, "vogel");
    expect(result.status).toBe("invalid");
    expect(result.notes.length).toBeGreaterThan(0);
    expect(result.steps).toEqual([]);
  });
});

describe("VAM shows every penalty iteration", () => {
  it("emits a vam-penalty step before each vam-alloc step", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["Plant 1", "Plant 2", "Plant 3"],
      destNames: ["W1", "W2", "W3", "W4"],
      costs: [
        [19, 30, 50, 10],
        [70, 30, 40, 60],
        [40, 8, 70, 20],
      ],
      supply: [7, 9, 18],
      demand: [5, 8, 7, 14],
    };
    const result = solveTransportation(problem, "vogel");
    const penaltySteps = result.steps.filter((s) => s.state.stepKind === "vam-penalty");
    expect(penaltySteps.length).toBeGreaterThan(0);
    penaltySteps.forEach((s) => {
      const state = s.state as any;
      expect(state.rowPenalties).not.toBeNull();
      expect(state.colPenalties).not.toBeNull();
    });
  });
});

describe("MODI reaches a step with isOptimal true", () => {
  it("terminates with an explicit optimal step", () => {
    const problem: TransportationProblemInput = {
      sourceNames: ["S1", "S2"],
      destNames: ["D1", "D2"],
      costs: [
        [8, 6],
        [4, 9],
      ],
      supply: [10, 10],
      demand: [10, 10],
    };
    const result = solveTransportation(problem, "northwest-corner");
    const optimalStep = result.steps.find((s) => (s.state as any).isOptimal);
    expect(optimalStep).toBeDefined();
  });
});
