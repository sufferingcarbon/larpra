import { AlgorithmStep } from "../../types/lp";
import { TransportationProblemInput, TransportationTableauState } from "../../types/transportation";
import { Fraction } from "../../utils/fraction";
import { balance } from "./standardize";
import { ConstructionTableau } from "./tableau";
import { balanceStep } from "./common";
import { finalizeConstruction, InitialSolutionResult } from "./northwestCorner";

/**
 * Least Cost Method: repeatedly finds the single cheapest cell among rows
 * and columns not yet exhausted, and allocates as much as that row's
 * remaining supply or column's remaining demand allows (whichever is
 * smaller). Ties on cost are broken by lowest row index, then lowest column
 * index, for a deterministic, reproducible sequence of steps.
 */
export function solveLeastCost(problem: TransportationProblemInput): InitialSolutionResult {
  const balanced = balance(problem);
  const tab = new ConstructionTableau(balanced, "least-cost");
  const steps: AlgorithmStep<TransportationTableauState>[] = [balanceStep(tab, balanced)];

  while (tab.crossedRows.some((c) => !c) && tab.crossedCols.some((c) => !c)) {
    let bestI = -1;
    let bestJ = -1;
    let bestCost: Fraction | null = null;
    for (let i = 0; i < tab.m; i++) {
      if (tab.crossedRows[i]) continue;
      for (let j = 0; j < tab.n; j++) {
        if (tab.crossedCols[j]) continue;
        const cost = tab.costs[i][j];
        if (bestCost === null || cost.lt(bestCost)) {
          bestCost = cost;
          bestI = i;
          bestJ = j;
        }
      }
    }
    if (bestI === -1) break; // defensive: no active cells left

    const i = bestI;
    const j = bestJ;
    const supplyLeft = tab.remainingSupply[i];
    const demandLeft = tab.remainingDemand[j];
    const amount = supplyLeft.lte(demandLeft) ? supplyLeft : demandLeft;
    tab.allocate(i, j, amount);

    const supplyExhausted = tab.remainingSupply[i].isZero();
    const demandExhausted = tab.remainingDemand[j].isZero();

    steps.push({
      title: `Cheapest cell (${tab.sourceNames[i]}, ${tab.destNames[j]}) at cost ${tab.costs[i][j].toDisplay()}`,
      explanation:
        `Among all cells whose row and column are still active, (${tab.sourceNames[i]}, ${tab.destNames[j]}) has the lowest cost, ${tab.costs[i][j].toDisplay()}. ` +
        `Allocate the smaller of ${tab.sourceNames[i]}'s remaining supply (${supplyLeft.toDisplay()}) and ${tab.destNames[j]}'s remaining demand (${demandLeft.toDisplay()}): ${amount.toDisplay()}.` +
        (supplyExhausted && demandExhausted
          ? " Both the row and column are exhausted at once — this signals a degenerate solution."
          : supplyExhausted
          ? ` ${tab.sourceNames[i]}'s supply is now used up, so its row is crossed out.`
          : ` ${tab.destNames[j]}'s demand is now fully met, so its column is crossed out.`),
      operation: `allocate(${i}, ${j}, ${amount.toDisplay()})`,
      state: tab.snapshot({ stepKind: "allocate", selectedCell: { row: i, col: j } }),
      why: "Least Cost greedily takes the globally cheapest available route at each step, which usually starts closer to optimal than NW Corner — though, like any greedy method, it can still be improved by MODI.",
    });

    if (supplyExhausted) tab.crossedRows[i] = true;
    if (demandExhausted) tab.crossedCols[j] = true;
  }

  finalizeConstruction(tab, steps);
  return { steps, tableau: tab };
}
