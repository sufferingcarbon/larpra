import { AlgorithmStep } from "../../types/lp";
import { Cell, LoopStep, TransportationTableauState } from "../../types/transportation";
import { Fraction } from "../../utils/fraction";
import { ConstructionTableau } from "./tableau";

/** Computes u_i, v_j from the current basic cells: u_i + v_j = c_ij for every basic cell, anchored at u_0 = 0. */
function computeUV(tab: ConstructionTableau): { u: (Fraction | null)[]; v: (Fraction | null)[] } {
  const u: (Fraction | null)[] = new Array(tab.m).fill(null);
  const v: (Fraction | null)[] = new Array(tab.n).fill(null);
  u[0] = Fraction.ZERO;
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < tab.m; i++) {
      for (let j = 0; j < tab.n; j++) {
        if (!tab.isBasic[i][j]) continue;
        if (u[i] !== null && v[j] === null) {
          v[j] = tab.costs[i][j].sub(u[i]!);
          changed = true;
        } else if (v[j] !== null && u[i] === null) {
          u[i] = tab.costs[i][j].sub(v[j]!);
          changed = true;
        }
      }
    }
  }
  return { u, v };
}

/**
 * Finds the unique closed loop created by treating the entering cell as
 * basic, using a BFS over the basic-cell spanning tree (sources and
 * destinations as nodes, basic cells as edges) from the entering cell's
 * source to its destination. Returns the loop as an alternating +/- cell
 * sequence starting and ending conceptually at the entering cell (which is
 * listed first, marked '+').
 */
function findLoop(tab: ConstructionTableau, r0: number, c0: number): LoopStep[] {
  const destBase = tab.m;
  const totalNodes = tab.m + tab.n;
  const adjacency: { node: number; cell: Cell }[][] = Array.from({ length: totalNodes }, () => []);
  for (let i = 0; i < tab.m; i++) {
    for (let j = 0; j < tab.n; j++) {
      if (!tab.isBasic[i][j]) continue;
      adjacency[i].push({ node: destBase + j, cell: { row: i, col: j } });
      adjacency[destBase + j].push({ node: i, cell: { row: i, col: j } });
    }
  }

  const target = destBase + c0;
  const visited = new Array(totalNodes).fill(false);
  const prevNode = new Array(totalNodes).fill(-1);
  const prevCell: (Cell | null)[] = new Array(totalNodes).fill(null);
  const queue: number[] = [r0];
  visited[r0] = true;
  while (queue.length > 0) {
    const cur = queue.shift()!;
    if (cur === target) break;
    for (const edge of adjacency[cur]) {
      if (!visited[edge.node]) {
        visited[edge.node] = true;
        prevNode[edge.node] = cur;
        prevCell[edge.node] = edge.cell;
        queue.push(edge.node);
      }
    }
  }

  if (!visited[target]) {
    throw new Error(
      "No closed loop found for the entering cell — the basic cells no longer form a spanning tree (this indicates a bug in degeneracy handling)."
    );
  }

  const reversedPath: Cell[] = [];
  let node = target;
  while (node !== r0) {
    reversedPath.push(prevCell[node]!);
    node = prevNode[node];
  }
  const path = reversedPath.reverse();

  const loop: LoopStep[] = [{ row: r0, col: c0, sign: "+" }];
  path.forEach((cell, idx) => {
    loop.push({ row: cell.row, col: cell.col, sign: idx % 2 === 0 ? "-" : "+" });
  });
  return loop;
}

/**
 * Runs MODI to optimality on an already-built initial BFS, mutating `tab`
 * in place with each pivot. Returns the MODI-phase steps only — the caller
 * concatenates them after the initial-solution steps.
 */
export function runModi(
  tab: ConstructionTableau,
  maxIterations = 500
): AlgorithmStep<TransportationTableauState>[] {
  const steps: AlgorithmStep<TransportationTableauState>[] = [];

  for (let iter = 0; iter < maxIterations; iter++) {
    const { u, v } = computeUV(tab);

    steps.push({
      title: "Compute u, v (dual values)",
      explanation:
        `Anchoring u(${tab.sourceNames[0]}) = 0, every basic cell gives an equation uᵢ + vⱼ = cᵢⱼ. ` +
        `Working outward through the basic cells (which form a spanning tree) fills in every remaining uᵢ and vⱼ.`,
      state: tab.snapshot({ stepKind: "modi-uv", phase: "modi", u, v }),
      why: "u and v are not unique on their own (one degree of freedom exists, which is why u₀ is fixed at 0 arbitrarily) — but every opportunity cost cᵢⱼ − (uᵢ + vⱼ) computed from them comes out the same regardless of which anchor is chosen.",
    });

    const opportunity: (Fraction | null)[][] = Array.from({ length: tab.m }, () => new Array(tab.n).fill(null));
    let enteringRow = -1;
    let enteringCol = -1;
    let mostNegative: Fraction | null = null;
    for (let i = 0; i < tab.m; i++) {
      for (let j = 0; j < tab.n; j++) {
        if (tab.isBasic[i][j]) continue;
        const delta = tab.costs[i][j].sub(u[i]!.add(v[j]!));
        opportunity[i][j] = delta;
        if (delta.isNegative() && (mostNegative === null || delta.lt(mostNegative))) {
          mostNegative = delta;
          enteringRow = i;
          enteringCol = j;
        }
      }
    }

    if (enteringRow === -1) {
      steps.push({
        title: "Optimal — no negative opportunity cost remains",
        explanation:
          `Every non-basic cell's opportunity cost Δᵢⱼ = cᵢⱼ − (uᵢ + vⱼ) is ≥ 0, so no reallocation can lower the total cost any further. ` +
          `The minimum transportation cost is ${tab.currentCost().toDisplay()}.`,
        state: tab.snapshot({ stepKind: "modi-optimal", phase: "modi", u, v, opportunityCosts: opportunity, isOptimal: true }),
        why: "Δᵢⱼ is exactly how much the total cost would change per unit shipped through cell (i,j) if it entered the basis. If every Δᵢⱼ ≥ 0, entering any of them can only raise (or, at best, not lower) the total cost — the textbook optimality condition for MODI.",
      });
      return steps;
    }

    steps.push({
      title: `Entering cell: (${tab.sourceNames[enteringRow]}, ${tab.destNames[enteringCol]})`,
      explanation: `Cell (${tab.sourceNames[enteringRow]}, ${tab.destNames[enteringCol]}) has the most negative opportunity cost, Δ = ${mostNegative!.toDisplay()}, so routing units through it will reduce the total cost.`,
      state: tab.snapshot({
        stepKind: "modi-entering",
        phase: "modi",
        u,
        v,
        opportunityCosts: opportunity,
        enteringCell: { row: enteringRow, col: enteringCol },
      }),
      why: "Among all non-basic cells with a negative Δᵢⱼ, the most negative one gives the steepest cost reduction per unit — the same greedy rule simplex uses to pick the entering variable.",
    });

    const loop = findLoop(tab, enteringRow, enteringCol);

    steps.push({
      title: "Trace the closed loop",
      explanation:
        `Starting a closed loop at the entering cell and moving alternately along rows and columns through basic cells only, ` +
        `${loop.length} cells are involved: ${loop
          .map((c) => `(${tab.sourceNames[c.row]}, ${tab.destNames[c.col]})${c.sign}`)
          .join(" → ")}. ` +
        `"+" cells will gain allocation, "−" cells will give it up.`,
      state: tab.snapshot({ stepKind: "modi-loop", phase: "modi", u, v, opportunityCosts: opportunity, enteringCell: { row: enteringRow, col: enteringCol }, loopPath: loop }),
      why: "Because the basic cells form a spanning tree, adding the entering cell creates exactly one cycle. Moving units around that cycle is the only way to keep every row and column total unchanged while bringing the entering cell into the solution.",
    });

    const minusCells = loop.filter((c) => c.sign === "-");
    let leaving = minusCells[0];
    let theta = tab.allocations[leaving.row][leaving.col]!;
    for (const c of minusCells) {
      const val = tab.allocations[c.row][c.col]!;
      if (val.lt(theta)) {
        theta = val;
        leaving = c;
      }
    }

    steps.push({
      title: `θ = ${theta.toDisplay()}`,
      explanation:
        `θ is the smallest allocation among the "−" cells in the loop, since that's as far as the loop can shift before a basic variable would go negative. ` +
        `Here that's (${tab.sourceNames[leaving.row]}, ${tab.destNames[leaving.col]}) with ${theta.toDisplay()}${tab.isEpsilon[leaving.row][leaving.col] ? " (an ε cell — this is a degenerate pivot)" : ""}, so θ = ${theta.toDisplay()}.`,
      state: tab.snapshot({
        stepKind: "modi-theta",
        phase: "modi",
        u,
        v,
        opportunityCosts: opportunity,
        enteringCell: { row: enteringRow, col: enteringCol },
        loopPath: loop,
        theta,
        leavingCell: { row: leaving.row, col: leaving.col },
      }),
      why: "Every '+' cell in the loop increases by θ and every '−' cell decreases by θ, which keeps all row and column totals exactly balanced. θ has to be the smallest '−' cell, or that cell's allocation would be driven negative — infeasible.",
    });

    for (const c of loop) {
      const current = tab.allocations[c.row][c.col] ?? Fraction.ZERO;
      const updated = c.sign === "+" ? current.add(theta) : current.sub(theta);
      tab.allocations[c.row][c.col] = updated;
      tab.isBasic[c.row][c.col] = true;
      tab.isEpsilon[c.row][c.col] = false;
    }
    tab.allocations[leaving.row][leaving.col] = null;
    tab.isBasic[leaving.row][leaving.col] = false;
    tab.isEpsilon[leaving.row][leaving.col] = false;

    steps.push({
      title: `Pivot: (${tab.sourceNames[enteringRow]}, ${tab.destNames[enteringCol]}) enters, (${tab.sourceNames[leaving.row]}, ${tab.destNames[leaving.col]}) leaves`,
      explanation: `Every "+" cell in the loop gains ${theta.toDisplay()}, every "−" cell loses it. The new total cost is ${tab.currentCost().toDisplay()}.`,
      operation: `pivot(enter=(${enteringRow},${enteringCol}), leave=(${leaving.row},${leaving.col}), theta=${theta.toDisplay()})`,
      state: tab.snapshot({ stepKind: "modi-pivot", phase: "modi", enteringCell: { row: enteringRow, col: enteringCol }, leavingCell: { row: leaving.row, col: leaving.col } }),
    });
  }

  throw new Error("MODI did not converge within the iteration limit — check for cycling.");
}
