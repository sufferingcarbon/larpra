import { Fraction } from "../../utils/fraction";
import { Cell, InitialMethod, TransportationTableauState } from "../../types/transportation";
import { BalanceResult } from "./standardize";

/**
 * ε is treated as the textbook limit ε → 0: an ε-basic cell holds the exact
 * value 0 for every arithmetic purpose (cost contribution, u/v equations,
 * theta/min-ratio comparisons). `isEpsilon` is purely a bookkeeping flag so
 * the UI can display "ε" instead of "0" and explain why the cell is basic
 * despite carrying no real allocation. This is exact (no floating epsilon
 * ever leaks into an arithmetic comparison) and matches the standard
 * "ε is infinitesimally small, i.e. 0 in the limit" convention.
 */

/** Mutable working state shared by NW Corner, Least Cost and VAM while they build an initial BFS. */
export class ConstructionTableau {
  sourceNames: string[];
  destNames: string[];
  costs: Fraction[][];
  originalSupply: Fraction[];
  originalDemand: Fraction[];
  remainingSupply: Fraction[];
  remainingDemand: Fraction[];
  allocations: (Fraction | null)[][];
  isBasic: boolean[][];
  isEpsilon: boolean[][];
  crossedRows: boolean[];
  crossedCols: boolean[];
  method: InitialMethod;

  constructor(balanced: BalanceResult, method: InitialMethod) {
    this.sourceNames = balanced.sourceNames;
    this.destNames = balanced.destNames;
    this.costs = balanced.costs;
    this.originalSupply = balanced.supply;
    this.originalDemand = balanced.demand;
    this.remainingSupply = balanced.supply.slice();
    this.remainingDemand = balanced.demand.slice();
    const m = this.m,
      n = this.n;
    this.allocations = Array.from({ length: m }, () => new Array<Fraction | null>(n).fill(null));
    this.isBasic = Array.from({ length: m }, () => new Array<boolean>(n).fill(false));
    this.isEpsilon = Array.from({ length: m }, () => new Array<boolean>(n).fill(false));
    this.crossedRows = new Array(m).fill(false);
    this.crossedCols = new Array(n).fill(false);
    this.method = method;
  }

  get m() {
    return this.sourceNames.length;
  }
  get n() {
    return this.destNames.length;
  }

  /** Allocates a real (non-epsilon) amount, drawing down remaining supply/demand. */
  allocate(i: number, j: number, amount: Fraction) {
    this.allocations[i][j] = amount;
    this.isBasic[i][j] = true;
    this.isEpsilon[i][j] = false;
    this.remainingSupply[i] = this.remainingSupply[i].sub(amount);
    this.remainingDemand[j] = this.remainingDemand[j].sub(amount);
  }

  /** Marks a cell basic via ε (value 0 in the limit), purely to satisfy the m+n-1 count. Does not touch supply/demand. */
  markEpsilonBasic(i: number, j: number) {
    this.allocations[i][j] = Fraction.ZERO;
    this.isBasic[i][j] = true;
    this.isEpsilon[i][j] = true;
  }

  basicCellCount(): number {
    let c = 0;
    for (let i = 0; i < this.m; i++) for (let j = 0; j < this.n; j++) if (this.isBasic[i][j]) c++;
    return c;
  }

  requiredBasicCells(): number {
    return this.m + this.n - 1;
  }

  currentCost(): Fraction {
    let sum = Fraction.ZERO;
    for (let i = 0; i < this.m; i++)
      for (let j = 0; j < this.n; j++) {
        if (this.isBasic[i][j] && !this.isEpsilon[i][j]) {
          sum = sum.add(this.allocations[i][j]!.mul(this.costs[i][j]));
        }
      }
    return sum;
  }

  displayAllocations(): (string | null)[][] {
    return this.allocations.map((row, i) =>
      row.map((v, j) => (v === null ? null : this.isEpsilon[i][j] ? "ε" : v.toDisplay()))
    );
  }

  snapshot(opts: {
    stepKind: string;
    phase?: "balance" | "construction" | "modi";
    selectedCell?: Cell | null;
    rowPenalties?: (Fraction | null)[] | null;
    colPenalties?: (Fraction | null)[] | null;
    highlightPenaltyRow?: number | null;
    highlightPenaltyCol?: number | null;
    dummyNote?: string | null;
    degenerateNote?: string | null;
    u?: (Fraction | null)[] | null;
    v?: (Fraction | null)[] | null;
    opportunityCosts?: (Fraction | null)[][] | null;
    enteringCell?: Cell | null;
    loopPath?: import("../../types/transportation").LoopStep[] | null;
    theta?: Fraction | null;
    leavingCell?: Cell | null;
    isOptimal?: boolean;
  }): TransportationTableauState {
    return {
      phase: opts.phase ?? "construction",
      stepKind: opts.stepKind,
      sourceNames: this.sourceNames,
      destNames: this.destNames,
      costs: this.costs.map((row) => row.map((c) => c.toDisplay())),
      originalSupply: this.originalSupply.map((s) => s.toDisplay()),
      originalDemand: this.originalDemand.map((d) => d.toDisplay()),
      remainingSupply: this.remainingSupply.map((s) => s.toDisplay()),
      remainingDemand: this.remainingDemand.map((d) => d.toDisplay()),
      allocations: this.displayAllocations(),
      isBasic: this.isBasic.map((r) => r.slice()),
      isEpsilon: this.isEpsilon.map((r) => r.slice()),
      crossedRows: this.crossedRows.slice(),
      crossedCols: this.crossedCols.slice(),
      selectedCell: opts.selectedCell ?? null,
      rowPenalties: opts.rowPenalties ? opts.rowPenalties.map((p) => (p ? p.toDisplay() : null)) : null,
      colPenalties: opts.colPenalties ? opts.colPenalties.map((p) => (p ? p.toDisplay() : null)) : null,
      highlightPenaltyRow: opts.highlightPenaltyRow ?? null,
      highlightPenaltyCol: opts.highlightPenaltyCol ?? null,
      currentCost: this.currentCost().toDisplay(),
      basicCellCount: this.basicCellCount(),
      requiredBasicCells: this.requiredBasicCells(),
      dummyNote: opts.dummyNote ?? null,
      degenerateNote: opts.degenerateNote ?? null,
      u: opts.u ? opts.u.map((x) => (x ? x.toDisplay() : null)) : null,
      v: opts.v ? opts.v.map((x) => (x ? x.toDisplay() : null)) : null,
      opportunityCosts: opts.opportunityCosts
        ? opts.opportunityCosts.map((row) => row.map((x) => (x ? x.toDisplay() : null)))
        : null,
      enteringCell: opts.enteringCell ?? null,
      loopPath: opts.loopPath ?? null,
      theta: opts.theta ? opts.theta.toDisplay() : null,
      leavingCell: opts.leavingCell ?? null,
      isOptimal: opts.isOptimal ?? false,
    };
  }
}

/**
 * If the finished initial BFS has fewer than m+n-1 basic cells (degenerate),
 * top it up with infinitesimal ε-allocations on independent cells (ones that
 * don't close a loop with the existing basic cells) until the count is
 * exactly m+n-1, which MODI needs to compute a full set of u/v duals.
 * Uses union-find over the m+n source/destination nodes: an existing basic
 * cell (i,j) is an edge between source-node i and destination-node m+j.
 */
export function fixDegeneracy(tab: ConstructionTableau): Cell[] {
  const m = tab.m,
    n = tab.n;
  const total = m + n;
  const parent = Array.from({ length: total }, (_, i) => i);
  function find(x: number): number {
    while (parent[x] !== x) {
      parent[x] = parent[parent[x]];
      x = parent[x];
    }
    return x;
  }
  function union(a: number, b: number) {
    const ra = find(a),
      rb = find(b);
    if (ra !== rb) parent[ra] = rb;
  }

  for (let i = 0; i < m; i++)
    for (let j = 0; j < n; j++) {
      if (tab.isBasic[i][j]) union(i, m + j);
    }

  const needed = tab.requiredBasicCells() - tab.basicCellCount();
  const added: Cell[] = [];
  if (needed <= 0) return added;

  // Scan by lowest cost first among candidates that don't close a loop — a reasonable,
  // deterministic tie-break that keeps the added epsilon cells cheap to carry forward.
  const candidates: { i: number; j: number; cost: Fraction }[] = [];
  for (let i = 0; i < m; i++)
    for (let j = 0; j < n; j++) {
      if (!tab.isBasic[i][j]) candidates.push({ i, j, cost: tab.costs[i][j] });
    }
  candidates.sort((a, b) => a.cost.compare(b.cost));

  let remaining = needed;
  for (const c of candidates) {
    if (remaining <= 0) break;
    if (find(c.i) !== find(c.j + m)) {
      tab.markEpsilonBasic(c.i, c.j);
      union(c.i, c.j + m);
      added.push({ row: c.i, col: c.j });
      remaining--;
    }
  }
  return added;
}
