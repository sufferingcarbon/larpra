import { TransportationProblemInput } from "../../types/transportation";

export interface TransportationExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: TransportationProblemInput;
}

export const transportationExamples: TransportationExample[] = [
  {
    name: "Classic 3×4 (balanced)",
    difficulty: "intermediate",
    description:
      "A textbook balanced problem (three plants, four warehouses) — a good first run for comparing how NW Corner, Least Cost and VAM start from different initial solutions but MODI always drives them to the same optimum.",
    problem: {
      sourceNames: ["Plant 1", "Plant 2", "Plant 3"],
      destNames: ["W1", "W2", "W3", "W4"],
      costs: [
        [19, 30, 50, 10],
        [70, 30, 40, 60],
        [40, 8, 70, 20],
      ],
      supply: [7, 9, 18],
      demand: [5, 8, 7, 14],
    },
  },
  {
    name: "Factories to warehouses (unbalanced — needs a dummy)",
    difficulty: "beginner",
    description:
      "Total supply (34) exceeds total demand (32) by 2, so a dummy destination is auto-added with zero cost to absorb the surplus before NW Corner / Least Cost / VAM can run.",
    problem: {
      sourceNames: ["F1", "F2", "F3"],
      destNames: ["W1", "W2", "W3"],
      costs: [
        [4, 6, 8],
        [6, 8, 6],
        [3, 5, 4],
      ],
      supply: [6, 8, 20],
      demand: [7, 5, 20],
    },
  },
  {
    name: "Equal splits (degenerate)",
    difficulty: "difficult",
    description:
      "Every source's supply exactly matches the corresponding destination's demand, so North-West Corner immediately exhausts a row and a column at the same time — a classic degenerate case that needs ε to reach m+n−1 basic cells before MODI can run.",
    problem: {
      sourceNames: ["S1", "S2", "S3"],
      destNames: ["D1", "D2", "D3"],
      costs: [
        [2, 3, 1],
        [5, 4, 8],
        [5, 6, 8],
      ],
      supply: [10, 10, 10],
      demand: [10, 10, 10],
    },
  },
];
