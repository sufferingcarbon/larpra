import { AlgorithmStep } from "../../types/lp";
import { TransportationProblemInput, TransportationTableauState } from "../../types/transportation";
import { balance } from "./standardize";
import { ConstructionTableau, fixDegeneracy } from "./tableau";
import { balanceStep } from "./common";

export interface InitialSolutionResult {
  steps: AlgorithmStep<TransportationTableauState>[];
  tableau: ConstructionTableau;
}

/**
 * North-West Corner Method: ignores cost entirely and simply allocates from
 * the top-left cell outward, always exhausting whichever of the current
 * row's remaining supply or the current column's remaining demand is
 * smaller, then moving to the next row and/or column.
 */
export function solveNorthwestCorner(problem: TransportationProblemInput): InitialSolutionResult {
  const balanced = balance(problem);
  const tab = new ConstructionTableau(balanced, "northwest-corner");
  const steps: AlgorithmStep<TransportationTableauState>[] = [balanceStep(tab, balanced)];

  let i = 0;
  let j = 0;
  while (i < tab.m && j < tab.n) {
    const supplyLeft = tab.remainingSupply[i];
    const demandLeft = tab.remainingDemand[j];
    const amount = supplyLeft.lte(demandLeft) ? supplyLeft : demandLeft;
    tab.allocate(i, j, amount);

    const supplyExhausted = tab.remainingSupply[i].isZero();
    const demandExhausted = tab.remainingDemand[j].isZero();

    steps.push({
      title: `Allocate ${amount.toDisplay()} to (${tab.sourceNames[i]}, ${tab.destNames[j]})`,
      explanation:
        `At the current north-west corner, ${tab.sourceNames[i]} has ${supplyLeft.toDisplay()} supply left and ` +
        `${tab.destNames[j]} needs ${demandLeft.toDisplay()} — allocate the smaller of the two, ${amount.toDisplay()}.` +
        (supplyExhausted && demandExhausted
          ? ` Both the row and column are now exhausted simultaneously — a hallmark of a degenerate solution.`
          : supplyExhausted
          ? ` ${tab.sourceNames[i]}'s supply is now used up, so move down to the next source.`
          : ` ${tab.destNames[j]}'s demand is now fully met, so move right to the next destination.`),
      operation: `allocate(${i}, ${j}, ${amount.toDisplay()})`,
      state: tab.snapshot({ stepKind: "allocate", selectedCell: { row: i, col: j } }),
      why: "The NW Corner rule never looks at cost — it only ever asks whether the current row's supply or the current column's demand runs out first, which guarantees a feasible (but not generally cheap) starting solution in exactly m+n-1 steps at most.",
    });

    if (supplyExhausted) tab.crossedRows[i] = true;
    if (demandExhausted) tab.crossedCols[j] = true;

    if (supplyExhausted && demandExhausted) {
      // Degenerate: crossing out both at once would skip a needed basic cell. Standard fix is to
      // advance only one index for real and let fixDegeneracy() below top up the basic count with ε.
      i++;
      j++;
    } else if (supplyExhausted) {
      i++;
    } else {
      j++;
    }
  }

  finalizeConstruction(tab, steps);
  return { steps, tableau: tab };
}

/** Shared by all three construction methods: checks/repairs degeneracy and emits the closing summary step. */
export function finalizeConstruction(tab: ConstructionTableau, steps: AlgorithmStep<TransportationTableauState>[]) {
  const before = tab.basicCellCount();
  const required = tab.requiredBasicCells();
  if (before < required) {
    const added = fixDegeneracy(tab);
    steps.push({
      title: "Degeneracy check — ε added",
      explanation:
        `A feasible solution needs m + n − 1 = ${required} basic cells, but this initial solution only has ${before}. ` +
        `An infinitesimal ε was allocated to ${added.length === 1 ? "cell" : "cells"} ` +
        `${added.map((c) => `(${tab.sourceNames[c.row]}, ${tab.destNames[c.col]})`).join(", ")} — chosen because ` +
        `${added.length === 1 ? "it" : "each"} doesn't close a loop with the existing basic cells — bringing the count up to ${tab.basicCellCount()}. ` +
        `ε is treated as zero in the total cost and will vanish from the final answer, but it lets MODI compute a full set of dual values.`,
      state: tab.snapshot({
        stepKind: "degeneracy-fix",
        degenerateNote: `${before} basic cells found; ${required} required.`,
      }),
      why: "MODI's u/v system has exactly m+n-1 independent equations only when there are exactly m+n-1 basic cells forming a spanning tree over the sources and destinations. Fewer than that leaves the system under-determined; ε cells (which cost nothing) fill the gap without changing the solution's real cost.",
    });
  }

  steps.push({
    title: "Initial basic feasible solution complete",
    explanation: `Every supply and demand is now exhausted. The initial solution has a total cost of ${tab.currentCost().toDisplay()}, using ${tab.basicCellCount()} basic cells (m + n − 1 = ${tab.requiredBasicCells()}). Optimization via MODI can now check whether this is already the cheapest routing.`,
    state: tab.snapshot({ stepKind: "initial-complete" }),
  });
}
