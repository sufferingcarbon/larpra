import {
  InitialMethod,
  TransportationProblemInput,
  TransportationResult,
} from "../../types/transportation";
import { validateProblem } from "./standardize";
import { solveNorthwestCorner } from "./northwestCorner";
import { solveLeastCost } from "./leastCost";
import { solveVogel } from "./vogel";
import { runModi } from "./modi";

export function solveTransportation(
  problem: TransportationProblemInput,
  method: InitialMethod
): TransportationResult {
  const errors = validateProblem(problem);
  if (errors.length > 0) {
    return {
      status: "invalid",
      steps: [],
      notes: errors,
      sourceNames: problem.sourceNames,
      destNames: problem.destNames,
    };
  }

  const initial =
    method === "northwest-corner"
      ? solveNorthwestCorner(problem)
      : method === "least-cost"
      ? solveLeastCost(problem)
      : solveVogel(problem);

  const modiSteps = runModi(initial.tableau);
  const steps = [...initial.steps, ...modiSteps];
  const tab = initial.tableau;

  const origM = problem.sourceNames.length;
  const origN = problem.destNames.length;

  const allocation: Record<string, Record<string, number>> = {};
  let degenerate = false;
  for (let i = 0; i < tab.m; i++) {
    for (let j = 0; j < tab.n; j++) {
      if (tab.isEpsilon[i][j]) degenerate = true;
      if (!tab.isBasic[i][j]) continue;
      if (i >= origM || j >= origN) continue; // dummy route: not a real shipment
      const amt = tab.allocations[i][j];
      if (!amt || amt.isZero()) continue;
      const srcName = tab.sourceNames[i];
      const destName = tab.destNames[j];
      allocation[srcName] = allocation[srcName] ?? {};
      allocation[srcName][destName] = amt.toNumber();
    }
  }

  const notes: string[] = [];
  if (degenerate) {
    notes.push(
      "This solution is degenerate: fewer than m+n−1 real basic cells were found, so ε was used to complete the basis for MODI."
    );
  }

  return {
    status: degenerate ? "degenerate_optimal" : "optimal",
    steps,
    totalCost: tab.currentCost().toNumber(),
    allocation,
    notes,
    sourceNames: problem.sourceNames,
    destNames: problem.destNames,
  };
}
