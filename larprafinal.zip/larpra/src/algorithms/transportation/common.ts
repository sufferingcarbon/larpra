import { AlgorithmStep } from "../../types/lp";
import { TransportationTableauState } from "../../types/transportation";
import { BalanceResult } from "./standardize";
import { ConstructionTableau } from "./tableau";

/** Emits the balance-check step shared by every initial-solution method. */
export function balanceStep(
  tab: ConstructionTableau,
  balanced: BalanceResult
): AlgorithmStep<TransportationTableauState> {
  if (!balanced.dummy) {
    return {
      title: "Balance check",
      explanation: `Total supply (${balanced.totalSupply.toDisplay()}) equals total demand (${balanced.totalDemand.toDisplay()}), so the problem is already balanced — no dummy row or column is needed.`,
      state: tab.snapshot({ stepKind: "balance-check" }),
    };
  }

  const { type, name, amount } = balanced.dummy;
  const rawSupply = type === "source" ? balanced.totalSupply.sub(amount) : balanced.totalSupply;
  const rawDemand = type === "destination" ? balanced.totalDemand.sub(amount) : balanced.totalDemand;
  const explanation =
    type === "destination"
      ? `Total supply (${rawSupply.toDisplay()}) exceeds total demand (${rawDemand.toDisplay()}) by ${amount.toDisplay()}, so a dummy destination "${name}" is added with demand ${amount.toDisplay()} and zero cost from every source. Any units routed there in the final solution represent unused supply.`
      : `Total demand (${rawDemand.toDisplay()}) exceeds total supply (${rawSupply.toDisplay()}) by ${amount.toDisplay()}, so a dummy source "${name}" is added with supply ${amount.toDisplay()} and zero cost to every destination. Any units routed from it in the final solution represent unmet demand.`;

  return {
    title: `Balance check — dummy ${type} added`,
    explanation,
    state: tab.snapshot({
      stepKind: "balance-check",
      dummyNote: `${name}: ${type === "source" ? "supply" : "demand"} ${amount.toDisplay()}, zero shipping cost.`,
    }),
    why: "NW Corner, Least Cost, VAM and MODI all assume total supply equals total demand. A zero-cost dummy row/column is the standard fix: it silently absorbs whatever surplus can't be shipped or demand that can't be met, without affecting the true minimum cost.",
  };
}
