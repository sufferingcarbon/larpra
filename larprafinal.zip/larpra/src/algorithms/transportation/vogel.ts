import { AlgorithmStep } from "../../types/lp";
import { TransportationProblemInput, TransportationTableauState } from "../../types/transportation";
import { Fraction } from "../../utils/fraction";
import { balance } from "./standardize";
import { ConstructionTableau } from "./tableau";
import { balanceStep } from "./common";
import { finalizeConstruction, InitialSolutionResult } from "./northwestCorner";

/** Smallest and second-smallest of a non-empty list of costs. */
function twoSmallest(costs: Fraction[]): [Fraction, Fraction | null] {
  const sorted = costs.slice().sort((a, b) => a.compare(b));
  return [sorted[0], sorted.length > 1 ? sorted[1] : null];
}

/**
 * Vogel's Approximation Method. At every iteration, computes a row penalty
 * and a column penalty for every still-active row/column (the difference
 * between the two cheapest costs available to it), picks the row or column
 * with the single largest penalty, allocates to the cheapest cell within
 * it, and crosses out whatever supply or demand that allocation exhausts.
 * Every iteration is emitted as its own penalty step followed by its own
 * allocation step — nothing here is summarized after the fact.
 */
export function solveVogel(problem: TransportationProblemInput): InitialSolutionResult {
  const balanced = balance(problem);
  const tab = new ConstructionTableau(balanced, "vogel");
  const steps: AlgorithmStep<TransportationTableauState>[] = [balanceStep(tab, balanced)];

  let iteration = 0;
  while (true) {
    const activeRows = range(tab.m).filter((i) => !tab.crossedRows[i]);
    const activeCols = range(tab.n).filter((j) => !tab.crossedCols[j]);
    if (activeRows.length === 0 || activeCols.length === 0) break;

    if (activeRows.length === 1 || activeCols.length === 1) {
      // No penalty is computable once only one row or one column remains active — every
      // remaining active cell is a forced allocation, so fill them directly (same rule NW
      // Corner uses), rather than manufacturing a meaningless "penalty" for a single option.
      for (const i of activeRows) {
        for (const j of activeCols) {
          if (tab.crossedRows[i] || tab.crossedCols[j]) continue;
          const supplyLeft = tab.remainingSupply[i];
          const demandLeft = tab.remainingDemand[j];
          if (supplyLeft.isZero() && demandLeft.isZero() && tab.isBasic[i][j]) continue;
          const amount = supplyLeft.lte(demandLeft) ? supplyLeft : demandLeft;
          tab.allocate(i, j, amount);
          const supplyExhausted = tab.remainingSupply[i].isZero();
          const demandExhausted = tab.remainingDemand[j].isZero();
          steps.push({
            title: `Forced allocation at (${tab.sourceNames[i]}, ${tab.destNames[j]})`,
            explanation:
              `Only one active ${activeRows.length === 1 ? "row" : "column"} remains, so no penalty comparison is meaningful — ` +
              `every remaining cell is allocated directly. Allocate ${amount.toDisplay()} to (${tab.sourceNames[i]}, ${tab.destNames[j]}).`,
            operation: `allocate(${i}, ${j}, ${amount.toDisplay()})`,
            state: tab.snapshot({ stepKind: "vam-alloc", selectedCell: { row: i, col: j } }),
          });
          if (supplyExhausted) tab.crossedRows[i] = true;
          if (demandExhausted) tab.crossedCols[j] = true;
        }
      }
      break;
    }

    iteration++;
    const rowPenalties: (Fraction | null)[] = range(tab.m).map((i) => {
      if (!activeRows.includes(i)) return null;
      const costs = activeCols.map((j) => tab.costs[i][j]);
      const [min, second] = twoSmallest(costs);
      return second === null ? min : second.sub(min);
    });
    const colPenalties: (Fraction | null)[] = range(tab.n).map((j) => {
      if (!activeCols.includes(j)) return null;
      const costs = activeRows.map((i) => tab.costs[i][j]);
      const [min, second] = twoSmallest(costs);
      return second === null ? min : second.sub(min);
    });

    steps.push({
      title: `Iteration ${iteration}: compute row/column penalties`,
      explanation:
        "For every active row and column, the penalty is the difference between its two cheapest " +
        "available costs (the cost of not using the cheapest option). The row or column with the " +
        "largest penalty is the one where picking the wrong cell would be most costly, so it's handled next.",
      state: tab.snapshot({ stepKind: "vam-penalty", rowPenalties, colPenalties }),
      why: "A large penalty means the second-best option in that row/column is much worse than the best — so if that row/column isn't served by its cheapest cell now, the eventual cost of serving it another way will be high. Prioritizing the largest penalty tends to avoid expensive last-resort allocations later.",
    });

    let bestPenalty: Fraction | null = null;
    let selIsRow = true;
    let selIdx = -1;
    for (const i of activeRows) {
      const p = rowPenalties[i]!;
      if (bestPenalty === null || p.gt(bestPenalty)) {
        bestPenalty = p;
        selIsRow = true;
        selIdx = i;
      }
    }
    for (const j of activeCols) {
      const p = colPenalties[j]!;
      if (bestPenalty === null || p.gt(bestPenalty)) {
        bestPenalty = p;
        selIsRow = false;
        selIdx = j;
      }
    }

    let row: number, col: number;
    if (selIsRow) {
      row = selIdx;
      col = activeCols.reduce((best, j) => (tab.costs[row][j].lt(tab.costs[row][best]) ? j : best), activeCols[0]);
    } else {
      col = selIdx;
      row = activeRows.reduce((best, i) => (tab.costs[i][col].lt(tab.costs[best][col]) ? i : best), activeRows[0]);
    }

    const supplyLeft = tab.remainingSupply[row];
    const demandLeft = tab.remainingDemand[col];
    const amount = supplyLeft.lte(demandLeft) ? supplyLeft : demandLeft;
    tab.allocate(row, col, amount);

    const supplyExhausted = tab.remainingSupply[row].isZero();
    const demandExhausted = tab.remainingDemand[col].isZero();

    steps.push({
      title: `Iteration ${iteration}: allocate at (${tab.sourceNames[row]}, ${tab.destNames[col]})`,
      explanation:
        `The largest penalty, ${bestPenalty!.toDisplay()}, belongs to ${selIsRow ? "row" : "column"} "${
          selIsRow ? tab.sourceNames[selIdx] : tab.destNames[selIdx]
        }". Within it, the cheapest cell is (${tab.sourceNames[row]}, ${tab.destNames[col]}) at cost ${tab.costs[row][col].toDisplay()}. ` +
        `Allocate the smaller of remaining supply (${supplyLeft.toDisplay()}) and remaining demand (${demandLeft.toDisplay()}): ${amount.toDisplay()}.` +
        (supplyExhausted && demandExhausted
          ? " Both the row and column are exhausted at once — a degenerate solution."
          : supplyExhausted
          ? ` ${tab.sourceNames[row]}'s supply is now used up, so its row is crossed out.`
          : ` ${tab.destNames[col]}'s demand is now fully met, so its column is crossed out.`),
      operation: `allocate(${row}, ${col}, ${amount.toDisplay()})`,
      state: tab.snapshot({
        stepKind: "vam-alloc",
        selectedCell: { row, col },
        rowPenalties,
        colPenalties,
        highlightPenaltyRow: selIsRow ? selIdx : null,
        highlightPenaltyCol: selIsRow ? null : selIdx,
      }),
    });

    if (supplyExhausted) tab.crossedRows[row] = true;
    if (demandExhausted) tab.crossedCols[col] = true;
  }

  finalizeConstruction(tab, steps);
  return { steps, tableau: tab };
}

function range(n: number): number[] {
  return Array.from({ length: n }, (_, i) => i);
}
