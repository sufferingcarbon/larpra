import { Fraction, frac } from "../../utils/fraction";
import { TransportationProblemInput } from "../../types/transportation";

export function validateProblem(problem: TransportationProblemInput): string[] {
  const errors: string[] = [];
  const m = problem.sourceNames.length;
  const n = problem.destNames.length;

  if (m === 0) errors.push("Add at least one source.");
  if (n === 0) errors.push("Add at least one destination.");
  if (problem.costs.length !== m) {
    errors.push(`Cost matrix has ${problem.costs.length} rows, expected ${m}.`);
  } else {
    problem.costs.forEach((row, i) => {
      if (row.length !== n) errors.push(`Cost row ${i + 1} has ${row.length} entries, expected ${n}.`);
      row.forEach((c, j) => {
        if (Number.isNaN(c)) errors.push(`Cost at source ${i + 1}, destination ${j + 1} is missing.`);
        if (c < 0) errors.push(`Cost at source ${i + 1}, destination ${j + 1} is negative.`);
      });
    });
  }
  if (problem.supply.length !== m) errors.push(`Supply has ${problem.supply.length} entries, expected ${m}.`);
  problem.supply.forEach((s, i) => {
    if (Number.isNaN(s)) errors.push(`Supply for source ${i + 1} is missing.`);
    else if (s < 0) errors.push(`Supply for source ${i + 1} is negative.`);
  });
  if (problem.demand.length !== n) errors.push(`Demand has ${problem.demand.length} entries, expected ${n}.`);
  problem.demand.forEach((d, j) => {
    if (Number.isNaN(d)) errors.push(`Demand for destination ${j + 1} is missing.`);
    else if (d < 0) errors.push(`Demand for destination ${j + 1} is negative.`);
  });

  if (errors.length === 0 && problem.supply.every((s) => s === 0) && problem.demand.every((d) => d === 0)) {
    errors.push("Total supply and demand are both zero — nothing to transport.");
  }

  return errors;
}

export interface BalanceResult {
  sourceNames: string[];
  destNames: string[];
  costs: Fraction[][];
  supply: Fraction[];
  demand: Fraction[];
  totalSupply: Fraction;
  totalDemand: Fraction;
  /** Non-null when a dummy row/column was added to balance the problem. */
  dummy: { type: "source" | "destination"; name: string; amount: Fraction } | null;
}

/**
 * Detects a supply/demand imbalance and, if present, auto-adds a zero-cost
 * dummy source or destination absorbing the difference — the standard
 * textbook fix that lets NW Corner / Least Cost / VAM / MODI all proceed as
 * if the problem were balanced.
 */
export function balance(problem: TransportationProblemInput): BalanceResult {
  const sourceNames = problem.sourceNames.slice();
  const destNames = problem.destNames.slice();
  const costs = problem.costs.map((row) => row.map(frac));
  const supply = problem.supply.map(frac);
  const demand = problem.demand.map(frac);

  const totalSupply = supply.reduce((a, b) => a.add(b), Fraction.ZERO);
  const totalDemand = demand.reduce((a, b) => a.add(b), Fraction.ZERO);

  if (totalSupply.equals(totalDemand)) {
    return { sourceNames, destNames, costs, supply, demand, totalSupply, totalDemand, dummy: null };
  }

  if (totalSupply.gt(totalDemand)) {
    const diff = totalSupply.sub(totalDemand);
    const name = "Dummy destination";
    destNames.push(name);
    demand.push(diff);
    costs.forEach((row) => row.push(Fraction.ZERO));
    return {
      sourceNames,
      destNames,
      costs,
      supply,
      demand,
      totalSupply,
      totalDemand: totalDemand.add(diff),
      dummy: { type: "destination", name, amount: diff },
    };
  }

  const diff = totalDemand.sub(totalSupply);
  const name = "Dummy source";
  sourceNames.push(name);
  supply.push(diff);
  costs.push(destNames.map(() => Fraction.ZERO));
  return {
    sourceNames,
    destNames,
    costs,
    supply,
    demand,
    totalSupply: totalSupply.add(diff),
    totalDemand,
    dummy: { type: "source", name, amount: diff },
  };
}
