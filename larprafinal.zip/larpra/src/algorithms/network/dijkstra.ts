import { AlgorithmStep } from "../../types/lp";
import { ShortestPathInput, ShortestPathNodeRow, ShortestPathResult, ShortestPathState } from "../../types/network";
import { Fraction } from "../../utils/fraction";
import { validateGraph, buildAdjacency } from "./graph";

function snapshot(opts: {
  stepKind: string;
  phase: ShortestPathState["phase"];
  dist: Map<string, Fraction | null>;
  pred: Map<string, string | null>;
  visited: Set<string>;
  order: string[];
  currentNode?: string | null;
  edgeConsidered?: { from: string; to: string; weight: string } | null;
  improved?: boolean | null;
}): ShortestPathState {
  const nodes: ShortestPathNodeRow[] = opts.order.map((n) => ({
    node: n,
    distance: opts.dist.get(n)?.toDisplay() ?? null,
    predecessor: opts.pred.get(n) ?? null,
    visited: opts.visited.has(n),
  }));
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    nodes,
    currentNode: opts.currentNode ?? null,
    edgeConsidered: opts.edgeConsidered ?? null,
    improved: opts.improved ?? null,
  };
}

export function solveDijkstra(input: ShortestPathInput): ShortestPathResult {
  const { graph, source } = input;
  const errors = validateGraph(graph);
  if (!graph.nodes.includes(source) && errors.length === 0) {
    errors.push(`Source node "${source}" is not in the graph.`);
  }
  if (errors.length > 0) {
    return { status: "invalid", steps: [], notes: errors };
  }

  const negativeEdge = graph.edges.find((e) => e.weight < 0);
  if (negativeEdge) {
    return {
      status: "negative-edge",
      steps: [],
      notes: [
        `Dijkstra's algorithm requires non-negative edge weights, but the edge ${negativeEdge.from}→${negativeEdge.to} has weight ${negativeEdge.weight}. ` +
          `Once a node is finalized, Dijkstra never revisits it — a later negative edge could still find a shorter route, silently producing a wrong answer. Use Bellman-Ford for graphs with negative edges.`,
      ],
    };
  }

  const order = graph.nodes.slice();
  const adj = buildAdjacency(graph);
  const dist = new Map<string, Fraction | null>(order.map((n) => [n, n === source ? Fraction.ZERO : null]));
  const pred = new Map<string, string | null>(order.map((n) => [n, null]));
  const visited = new Set<string>();

  const steps: AlgorithmStep<ShortestPathState>[] = [
    {
      title: "Initialize",
      explanation: `Set the source (${source}) to distance 0 and every other node to infinity (unreached). No node is visited yet.`,
      state: snapshot({ stepKind: "init", phase: "init", dist, pred, visited, order }),
      why: "Dijkstra grows a set of finalized shortest distances one node at a time, always finalizing whichever unvisited node currently has the smallest tentative distance. Starting the source at 0 and everything else at infinity is the only distance assignment consistent with not having explored any edge yet.",
    },
  ];

  for (let iter = 0; iter < order.length; iter++) {
    // Select the unvisited node with the smallest tentative distance (ties broken by input order for determinism).
    let best: string | null = null;
    for (const n of order) {
      if (visited.has(n)) continue;
      const d = dist.get(n);
      if (d === null || d === undefined) continue;
      const bd = best !== null ? dist.get(best) : null;
      if (best === null || (bd !== null && bd !== undefined && d.lt(bd))) best = n;
    }

    if (best === null) {
      const unreached = order.filter((n) => !visited.has(n) && dist.get(n) === null);
      steps.push({
        title: "No reachable nodes remain",
        explanation:
          `Every remaining unvisited node (${unreached.join(", ")}) still has distance infinity — there is no path to ${unreached.length === 1 ? "it" : "them"} from ${source}. The algorithm stops here.`,
        state: snapshot({ stepKind: "unreachable", phase: "done", dist, pred, visited, order }),
      });
      break;
    }

    steps.push({
      title: `Select ${best} (distance ${dist.get(best)!.toDisplay()})`,
      explanation: `Among all unvisited nodes, ${best} currently has the smallest tentative distance (${dist.get(best)!.toDisplay()}), so its distance is now final and it is marked visited.`,
      state: snapshot({ stepKind: "select", phase: "select", dist, pred, visited, order, currentNode: best }),
      why: "Because every edge weight is non-negative, no future relaxation through a still-unvisited (necessarily farther-or-equal) node could ever produce a shorter route to the closest remaining node — so it's safe to finalize it now.",
    });
    visited.add(best);

    for (const e of adj.get(best) ?? []) {
      if (visited.has(e.to)) continue;
      const candidate = dist.get(best)!.add(e.weight);
      const current = dist.get(e.to);
      const improved = current === null || current === undefined || candidate.lt(current);
      if (improved) {
        dist.set(e.to, candidate);
        pred.set(e.to, best);
      }
      steps.push({
        title: improved
          ? `Relax ${best}→${e.to}: distance improves to ${candidate.toDisplay()}`
          : `Relax ${best}→${e.to}: no improvement`,
        explanation: improved
          ? `Distance to ${best} (${dist.get(best)!.toDisplay()}) plus the edge weight (${e.weight.toDisplay()}) gives ${candidate.toDisplay()}, which is shorter than ${e.to}'s previous distance (${current === null || current === undefined ? "infinity" : current.toDisplay()}) — update it, with ${best} as its new predecessor.`
          : `Distance to ${best} (${dist.get(best)!.toDisplay()}) plus the edge weight (${e.weight.toDisplay()}) gives ${candidate.toDisplay()}, which is not shorter than ${e.to}'s current distance (${current!.toDisplay()}) — leave it unchanged.`,
        operation: `relax(${best}→${e.to})`,
        state: snapshot({
          stepKind: improved ? "relax-improve" : "relax-no-improve",
          phase: "relax",
          dist,
          pred,
          visited,
          order,
          currentNode: best,
          edgeConsidered: { from: best, to: e.to, weight: e.weight.toDisplay() },
          improved,
        }),
        why: "Relaxation just tests the triangle inequality: if going through the node just finalized is shorter than the best route found so far, take it.",
      });
    }
  }

  const distances: Record<string, number | null> = {};
  const predecessors: Record<string, string | null> = {};
  order.forEach((n) => {
    const d = dist.get(n) ?? null;
    distances[n] = d === null ? null : d.toNumber();
    predecessors[n] = pred.get(n) ?? null;
  });

  steps.push({
    title: "Shortest paths finalized",
    explanation:
      `Every reachable node now holds its shortest distance from ${source}: ` +
      order.map((n) => `${n}=${distances[n] === null ? "∞" : distances[n]}`).join(", ") +
      ".",
    state: snapshot({ stepKind: "done", phase: "done", dist, pred, visited, order }),
  });

  const unreachable = order.filter((n) => distances[n] === null && n !== source);
  const notes = unreachable.length > 0 ? [`Unreachable from ${source}: ${unreachable.join(", ")}.`] : [];

  return { status: "optimal", steps, distances, predecessors, notes };
}
