import { GraphInput, MaxFlowInput, MSTInput, ShortestPathInput } from "../../types/network";

export interface ShortestPathExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: ShortestPathInput;
}

export interface MSTExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  graph: GraphInput;
  defaultStartNode: string;
}

export interface MaxFlowExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: MaxFlowInput;
}

export const shortestPathExamples: ShortestPathExample[] = [
  {
    name: "6-node directed network",
    difficulty: "intermediate",
    description:
      "A small directed graph with two routes to most nodes — cross-validated against networkx's Dijkstra. Distances from A: B=3, C=2, D=8, E=10, F=13 (shortest route to B and D actually goes through C, not the direct A→B edge).",
    problem: {
      graph: {
        directed: true,
        nodes: ["A", "B", "C", "D", "E", "F"],
        edges: [
          { from: "A", to: "B", weight: 4 },
          { from: "A", to: "C", weight: 2 },
          { from: "C", to: "B", weight: 1 },
          { from: "B", to: "D", weight: 5 },
          { from: "C", to: "D", weight: 8 },
          { from: "C", to: "E", weight: 10 },
          { from: "D", to: "E", weight: 2 },
          { from: "D", to: "F", weight: 6 },
          { from: "E", to: "F", weight: 3 },
        ],
      },
      source: "A",
    },
  },
  {
    name: "Graph with an unreachable node",
    difficulty: "beginner",
    description:
      "A 6-node graph where Z has no incoming edge from S at all, so Dijkstra correctly reports it as unreachable instead of guessing. Distances from S: A=2, B=5, C=5, D=9.",
    problem: {
      graph: {
        directed: true,
        nodes: ["S", "A", "B", "C", "D", "Z"],
        edges: [
          { from: "S", to: "A", weight: 2 },
          { from: "S", to: "B", weight: 5 },
          { from: "A", to: "C", weight: 3 },
          { from: "B", to: "C", weight: 1 },
          { from: "C", to: "D", weight: 4 },
        ],
      },
      source: "S",
    },
  },
  {
    name: "Negative edge (should fail gracefully)",
    difficulty: "difficult",
    description:
      "Dijkstra is only correct for non-negative weights — this graph has one negative edge on purpose, so the solver should reject it with a clear explanation rather than silently returning a wrong distance.",
    problem: {
      graph: {
        directed: true,
        nodes: ["A", "B", "C"],
        edges: [
          { from: "A", to: "B", weight: 4 },
          { from: "A", to: "C", weight: 6 },
          { from: "B", to: "C", weight: -3 },
        ],
      },
      source: "A",
    },
  },
];

export const mstExamples: MSTExample[] = [
  {
    name: "6-node undirected network",
    difficulty: "intermediate",
    description:
      "A textbook spanning-tree problem — cross-validated against networkx. Minimum total weight: 11 (edges A–C, B–C, B–D, D–E, E–F). Works identically whether solved with Kruskal or Prim.",
    graph: {
      directed: false,
      nodes: ["A", "B", "C", "D", "E", "F"],
      edges: [
        { from: "A", to: "B", weight: 4 },
        { from: "A", to: "C", weight: 3 },
        { from: "B", to: "C", weight: 1 },
        { from: "B", to: "D", weight: 2 },
        { from: "C", to: "D", weight: 3 },
        { from: "C", to: "E", weight: 5 },
        { from: "D", to: "E", weight: 2 },
        { from: "D", to: "F", weight: 6 },
        { from: "E", to: "F", weight: 3 },
      ],
    },
    defaultStartNode: "A",
  },
  {
    name: "Triangle plus a tail (tied weights, guaranteed cycle rejection)",
    difficulty: "difficult",
    description:
      "A–B–C form a weight-1 triangle (so one of those three edges must be rejected as a cycle no matter the tie-break), with a tail C–D of weight 2. networkx confirms minimum weight 4.",
    graph: {
      directed: false,
      nodes: ["A", "B", "C", "D"],
      edges: [
        { from: "A", to: "B", weight: 1 },
        { from: "B", to: "C", weight: 1 },
        { from: "A", to: "C", weight: 1 },
        { from: "C", to: "D", weight: 2 },
      ],
    },
    defaultStartNode: "A",
  },
];

export const maxFlowExamples: MaxFlowExample[] = [
  {
    name: "Classic 6-node flow network",
    difficulty: "difficult",
    description:
      "A well-known textbook max-flow network (CLRS-style) with several possible augmenting routes and one internal back-edge (C→B) that gets used to reroute flow. Cross-validated against networkx: max flow = 23.",
    problem: {
      graph: {
        directed: true,
        nodes: ["S", "A", "B", "C", "D", "T"],
        edges: [
          { from: "S", to: "A", weight: 16 },
          { from: "S", to: "B", weight: 13 },
          { from: "A", to: "C", weight: 12 },
          { from: "B", to: "A", weight: 4 },
          { from: "B", to: "D", weight: 14 },
          { from: "C", to: "B", weight: 9 },
          { from: "C", to: "T", weight: 20 },
          { from: "D", to: "C", weight: 7 },
          { from: "D", to: "T", weight: 4 },
        ],
      },
      source: "S",
      sink: "T",
    },
  },
  {
    name: "Small bottleneck network",
    difficulty: "beginner",
    description:
      "A simple 6-node network good for watching the bottleneck concept directly — the S→B and D→T edges are the tightest links. Cross-validated against networkx: max flow = 5.",
    problem: {
      graph: {
        directed: true,
        nodes: ["S", "A", "B", "C", "D", "T"],
        edges: [
          { from: "S", to: "A", weight: 3 },
          { from: "S", to: "B", weight: 2 },
          { from: "A", to: "C", weight: 2 },
          { from: "A", to: "D", weight: 3 },
          { from: "B", to: "D", weight: 2 },
          { from: "C", to: "T", weight: 2 },
          { from: "D", to: "T", weight: 4 },
        ],
      },
      source: "S",
      sink: "T",
    },
  },
];
