export { solveDijkstra } from "./dijkstra";
export { solveMST } from "./mst";
export { solveMaxFlow } from "./maxflow";
