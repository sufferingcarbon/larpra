import { AlgorithmStep } from "../../types/lp";
import { MaxFlowEdgeRow, MaxFlowInput, MaxFlowResult, MaxFlowState } from "../../types/network";
import { Fraction, frac } from "../../utils/fraction";
import { validateGraph } from "./graph";

interface TraceEntry {
  node: string;
  edgeIndex: number;
  direction: "forward" | "backward";
}

function snapshot(opts: {
  stepKind: string;
  phase: MaxFlowState["phase"];
  edges: { from: string; to: string; capacity: Fraction; flow: Fraction }[];
  augmentingPath?: string[] | null;
  bottleneck?: Fraction | null;
  totalFlow: Fraction;
}): MaxFlowState {
  const rows: MaxFlowEdgeRow[] = opts.edges.map((e) => ({
    from: e.from,
    to: e.to,
    capacity: e.capacity.toDisplay(),
    flow: e.flow.toDisplay(),
    residual: e.capacity.sub(e.flow).toDisplay(),
  }));
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    edges: rows,
    augmentingPath: opts.augmentingPath ?? null,
    bottleneck: opts.bottleneck ? opts.bottleneck.toDisplay() : null,
    totalFlow: opts.totalFlow.toDisplay(),
  };
}

export function solveMaxFlow(input: MaxFlowInput): MaxFlowResult {
  const { graph, source, sink } = input;
  const errors = validateGraph(graph, { requirePositiveWeights: true });
  if (!graph.directed) {
    errors.push("Maximum flow requires a directed graph of capacities — check \"directed\" for this graph.");
  }
  if (!graph.nodes.includes(source)) errors.push(`Source node "${source}" is not in the graph.`);
  if (!graph.nodes.includes(sink)) errors.push(`Sink node "${sink}" is not in the graph.`);
  if (source === sink && graph.nodes.includes(source)) errors.push("Source and sink must be different nodes.");
  if (errors.length > 0) {
    return { status: "invalid", steps: [], notes: errors };
  }

  const capacity = graph.edges.map((e) => frac(e.weight));
  const flow = graph.edges.map(() => Fraction.ZERO);
  let totalFlow = Fraction.ZERO;

  const edgeSnap = () => graph.edges.map((e, i) => ({ from: e.from, to: e.to, capacity: capacity[i], flow: flow[i] }));

  const steps: AlgorithmStep<MaxFlowState>[] = [
    {
      title: "Initialize residual graph",
      explanation: `Every edge starts with zero flow, so its residual (spare) capacity equals its full capacity. Looking for the first augmenting path from ${source} to ${sink}.`,
      state: snapshot({ stepKind: "init", phase: "search", edges: edgeSnap(), totalFlow }),
      why: "Ford-Fulkerson repeatedly finds a path from source to sink with spare capacity along every edge (the residual graph) and pushes as much flow as the tightest edge on that path allows, until no such path remains.",
    },
  ];

  // Edmonds-Karp: BFS for the shortest augmenting path each round, using both
  // forward edges (residual = capacity - flow) and backward edges (residual = flow, to allow undoing).
  const findAugmentingPath = (): TraceEntry[] | null => {
    const visited = new Set<string>([source]);
    const trace = new Map<string, TraceEntry>();
    const queue = [source];
    while (queue.length > 0) {
      const cur = queue.shift()!;
      if (cur === sink) break;
      for (let i = 0; i < graph.edges.length; i++) {
        const e = graph.edges[i];
        if (e.from === cur && !visited.has(e.to) && flow[i].lt(capacity[i])) {
          visited.add(e.to);
          trace.set(e.to, { node: cur, edgeIndex: i, direction: "forward" });
          queue.push(e.to);
        } else if (e.to === cur && !visited.has(e.from) && flow[i].gt(Fraction.ZERO)) {
          visited.add(e.from);
          trace.set(e.from, { node: cur, edgeIndex: i, direction: "backward" });
          queue.push(e.from);
        }
      }
    }
    if (!visited.has(sink)) return null;

    // Walk backward from sink to source using `trace`.
    const path: TraceEntry[] = [];
    let cur = sink;
    while (cur !== source) {
      const t = trace.get(cur)!;
      path.push(t);
      cur = t.node;
    }
    return path.reverse();
  };

  let guard = 0;
  while (guard++ < 1000) {
    const path = findAugmentingPath();
    if (!path) {
      steps.push({
        title: "No augmenting path remains",
        explanation: `No path with spare capacity exists from ${source} to ${sink} in the current residual graph — the flow is maximal.`,
        state: snapshot({ stepKind: "no-path", phase: "done", edges: edgeSnap(), totalFlow }),
      });
      break;
    }

    let bottleneck: Fraction | null = null;
    for (const step of path) {
      const avail = step.direction === "forward" ? capacity[step.edgeIndex].sub(flow[step.edgeIndex]) : flow[step.edgeIndex];
      if (bottleneck === null || avail.lt(bottleneck)) bottleneck = avail;
    }
    const b = bottleneck!;

    const pathNodes: string[] = [source];
    let cursor = source;
    for (const step of path) {
      const e = graph.edges[step.edgeIndex];
      cursor = step.direction === "forward" ? e.to : e.from;
      pathNodes.push(cursor);
    }

    for (const step of path) {
      if (step.direction === "forward") flow[step.edgeIndex] = flow[step.edgeIndex].add(b);
      else flow[step.edgeIndex] = flow[step.edgeIndex].sub(b);
    }
    totalFlow = totalFlow.add(b);

    const pathDesc = pathNodes.join(" → ");
    steps.push({
      title: `Augment along ${pathDesc} by ${b.toDisplay()}`,
      explanation: `A path with spare capacity was found: ${pathDesc}. The smallest spare capacity along it is ${b.toDisplay()} (the bottleneck), so every edge on the path carries ${b.toDisplay()} more flow. Total flow is now ${totalFlow.toDisplay()}.`,
      operation: `augment(${pathDesc})`,
      state: snapshot({
        stepKind: "augment",
        phase: "augment",
        edges: edgeSnap(),
        augmentingPath: pathNodes,
        bottleneck: b,
        totalFlow,
      }),
      why: "Breadth-first search always finds the shortest (fewest-edges) augmenting path available (Edmonds-Karp's refinement of Ford-Fulkerson), which guarantees the algorithm terminates in a polynomial number of augmentations regardless of how large the capacities are.",
    });
  }

  // Min cut: nodes reachable from source in the final residual graph.
  const reachable = new Set<string>([source]);
  {
    const queue = [source];
    while (queue.length > 0) {
      const cur = queue.shift()!;
      for (let i = 0; i < graph.edges.length; i++) {
        const e = graph.edges[i];
        if (e.from === cur && !reachable.has(e.to) && flow[i].lt(capacity[i])) {
          reachable.add(e.to);
          queue.push(e.to);
        } else if (e.to === cur && !reachable.has(e.from) && flow[i].gt(Fraction.ZERO)) {
          reachable.add(e.from);
          queue.push(e.from);
        }
      }
    }
  }
  const cutEdges = graph.edges.filter((e) => reachable.has(e.from) && !reachable.has(e.to));
  const sSide = graph.nodes.filter((n) => reachable.has(n));
  const tSide = graph.nodes.filter((n) => !reachable.has(n));

  if (tSide.length > 0) {
    steps.push({
      title: "Identify the minimum cut",
      explanation:
        `The nodes still reachable from ${source} in the final residual graph are {${sSide.join(", ")}}; everything else is {${tSide.join(", ")}}. ` +
        `By the max-flow/min-cut theorem, the edges crossing from the first group to the second (${cutEdges.map((e) => `${e.from}→${e.to}`).join(", ")}) are saturated and their combined capacity (${cutEdges.reduce((s, e) => s.add(e.weight), Fraction.ZERO).toDisplay()}) equals the maximum flow — confirming ${totalFlow.toDisplay()} is optimal.`,
      state: snapshot({ stepKind: "min-cut", phase: "done", edges: edgeSnap(), totalFlow }),
      why: "Max-flow/min-cut theorem: the maximum amount of flow from source to sink always equals the minimum total capacity of any set of edges whose removal disconnects the source from the sink.",
    });
  }

  return { status: "optimal", steps, maxFlow: totalFlow.toNumber(), notes: [] };
}
