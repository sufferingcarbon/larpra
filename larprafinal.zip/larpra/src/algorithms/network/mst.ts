import { AlgorithmStep } from "../../types/lp";
import { MSTEdgeRow, MSTInput, MSTResult, MSTState } from "../../types/network";
import { Fraction, frac } from "../../utils/fraction";
import { validateGraph, isConnectedUndirected } from "./graph";

class UnionFind {
  parent: number[];
  constructor(n: number) {
    this.parent = Array.from({ length: n }, (_, i) => i);
  }
  find(x: number): number {
    while (this.parent[x] !== x) {
      this.parent[x] = this.parent[this.parent[x]];
      x = this.parent[x];
    }
    return x;
  }
  union(a: number, b: number): boolean {
    const ra = this.find(a);
    const rb = this.find(b);
    if (ra === rb) return false;
    this.parent[ra] = rb;
    return true;
  }
}

function snapshot(opts: {
  stepKind: string;
  phase: MSTState["phase"];
  method: MSTState["method"];
  edges: MSTEdgeRow[];
  treeNodes: string[];
  totalWeight: Fraction;
  currentEdge?: { from: string; to: string; weight: string } | null;
  componentOf?: Record<string, number> | null;
}): MSTState {
  return {
    phase: opts.phase,
    stepKind: opts.stepKind,
    method: opts.method,
    edges: opts.edges,
    treeNodes: opts.treeNodes.slice(),
    totalWeight: opts.totalWeight.toDisplay(),
    currentEdge: opts.currentEdge ?? null,
    componentOf: opts.componentOf ?? null,
  };
}

export function solveMST(input: MSTInput): MSTResult {
  const { graph, method } = input;
  const errors = validateGraph(graph);
  if (graph.directed) {
    errors.push("Minimum Spanning Tree is defined for undirected graphs — uncheck \"directed\" for this graph.");
  }
  if (method === "prim" && input.startNode && !graph.nodes.includes(input.startNode)) {
    errors.push(`Start node "${input.startNode}" is not in the graph.`);
  }
  if (errors.length > 0) {
    return { status: "invalid", steps: [], notes: errors };
  }
  if (!isConnectedUndirected(graph)) {
    return {
      status: "disconnected",
      steps: [],
      notes: ["This graph is disconnected — no spanning tree exists that reaches every node."],
    };
  }

  return method === "kruskal" ? runKruskal(graph, input) : runPrim(graph, input);
}

function runKruskal(graph: MSTInput["graph"], input: MSTInput): MSTResult {
  const nodeIndex = new Map(graph.nodes.map((n, i) => [n, i]));
  const uf = new UnionFind(graph.nodes.length);

  const sortedIdx = graph.edges
    .map((_, i) => i)
    .sort((a, b) => graph.edges[a].weight - graph.edges[b].weight || a - b);

  const rows: MSTEdgeRow[] = sortedIdx.map((i) => ({
    from: graph.edges[i].from,
    to: graph.edges[i].to,
    weight: frac(graph.edges[i].weight).toDisplay(),
    status: "unconsidered",
  }));

  const componentOf = () => {
    const m: Record<string, number> = {};
    graph.nodes.forEach((n) => (m[n] = uf.find(nodeIndex.get(n)!)));
    return m;
  };

  let total = Fraction.ZERO;
  const treeNodes = new Set<string>();
  const treeEdges: { from: string; to: string; weight: number }[] = [];

  const steps: AlgorithmStep<MSTState>[] = [
    {
      title: "Sort edges by weight",
      explanation: `Kruskal's algorithm considers every edge exactly once, from lightest to heaviest: ${rows
        .map((r) => `${r.from}–${r.to} (${r.weight})`)
        .join(", ")}.`,
      state: snapshot({ stepKind: "sort", phase: "sort", method: "kruskal", edges: rows, treeNodes: [], totalWeight: total, componentOf: componentOf() }),
      why: "Always trying the globally cheapest remaining edge next, and only skipping it if it would close a cycle, is exactly what makes Kruskal's a correct greedy algorithm — proved by the cut property of spanning trees.",
    },
  ];

  for (let k = 0; k < sortedIdx.length; k++) {
    const i = sortedIdx[k];
    const e = graph.edges[i];
    const a = nodeIndex.get(e.from)!;
    const b = nodeIndex.get(e.to)!;
    const wouldCycle = uf.find(a) === uf.find(b);

    if (!wouldCycle) {
      uf.union(a, b);
      total = total.add(e.weight);
      treeNodes.add(e.from);
      treeNodes.add(e.to);
      treeEdges.push({ from: e.from, to: e.to, weight: e.weight });
      rows[k] = { ...rows[k], status: "accepted" };
    } else {
      rows[k] = { ...rows[k], status: "rejected-cycle" };
    }

    steps.push({
      title: wouldCycle
        ? `Reject ${e.from}–${e.to}: would close a cycle`
        : `Accept ${e.from}–${e.to} (weight ${frac(e.weight).toDisplay()})`,
      explanation: wouldCycle
        ? `${e.from} and ${e.to} are already connected through previously accepted edges, so adding ${e.from}–${e.to} would create a cycle — a spanning tree can never contain one, so this edge is skipped.`
        : `${e.from} and ${e.to} are in different components so far, so accepting this edge connects them without creating a cycle. Running total: ${total.toDisplay()}.`,
      operation: wouldCycle ? undefined : `union(${e.from}, ${e.to})`,
      state: snapshot({
        stepKind: wouldCycle ? "reject-cycle" : "accept",
        phase: "consider",
        method: "kruskal",
        edges: rows.slice(),
        treeNodes: Array.from(treeNodes),
        totalWeight: total,
        currentEdge: { from: e.from, to: e.to, weight: frac(e.weight).toDisplay() },
        componentOf: componentOf(),
      }),
      why: "Union-find tracks which component each node belongs to in near-constant time per operation, so testing \"would this edge close a cycle?\" is just checking whether its two endpoints already share a component.",
    });

    if (treeEdges.length === graph.nodes.length - 1) break;
  }

  steps.push({
    title: "Minimum spanning tree found",
    explanation: `All ${graph.nodes.length} nodes are now connected using ${treeEdges.length} edges, with total weight ${total.toDisplay()}.`,
    state: snapshot({ stepKind: "done", phase: "done", method: "kruskal", edges: rows, treeNodes: Array.from(treeNodes), totalWeight: total, componentOf: componentOf() }),
  });

  return { status: "optimal", steps, totalWeight: total.toNumber(), treeEdges, notes: [] };
}

function runPrim(graph: MSTInput["graph"], input: MSTInput): MSTResult {
  const start = input.startNode ?? graph.nodes[0];
  const allRows: MSTEdgeRow[] = graph.edges.map((e) => ({
    from: e.from,
    to: e.to,
    weight: frac(e.weight).toDisplay(),
    status: "unconsidered",
  }));

  const treeNodes = new Set<string>([start]);
  const acceptedKeys = new Set<string>();
  let total = Fraction.ZERO;
  const treeEdges: { from: string; to: string; weight: number }[] = [];

  const edgeKey = (i: number) => `${graph.edges[i].from}|${graph.edges[i].to}`;

  const withStatus = (): MSTEdgeRow[] =>
    allRows.map((r, i) => ({ ...r, status: acceptedKeys.has(edgeKey(i)) ? "accepted" : "unconsidered" }));

  const steps: AlgorithmStep<MSTState>[] = [
    {
      title: `Start the tree at ${start}`,
      explanation: `Prim's algorithm grows a single tree one node at a time, starting from ${start}. At each step, the cheapest edge connecting the current tree to any outside node is added.`,
      state: snapshot({ stepKind: "start", phase: "consider", method: "prim", edges: withStatus(), treeNodes: Array.from(treeNodes), totalWeight: total }),
      why: "Unlike Kruskal, which works on the whole edge list at once, Prim's grows outward from a single connected blob — so at every point the current \"tree\" is guaranteed connected, and the only question is which crossing edge to add next.",
    },
  ];

  while (treeNodes.size < graph.nodes.length) {
    // Find the cheapest edge with exactly one endpoint in the tree.
    let bestIdx = -1;
    let bestWeight: Fraction | null = null;
    for (let i = 0; i < graph.edges.length; i++) {
      const e = graph.edges[i];
      const fromIn = treeNodes.has(e.from);
      const toIn = treeNodes.has(e.to);
      if (fromIn === toIn) continue; // both in or both out — not a crossing edge
      const w = frac(e.weight);
      if (bestWeight === null || w.lt(bestWeight)) {
        bestWeight = w;
        bestIdx = i;
      }
    }

    if (bestIdx === -1) {
      // Shouldn't happen since connectivity was checked, but guard anyway.
      break;
    }

    const e = graph.edges[bestIdx];
    const newNode = treeNodes.has(e.from) ? e.to : e.from;
    acceptedKeys.add(edgeKey(bestIdx));
    treeNodes.add(newNode);
    total = total.add(e.weight);
    treeEdges.push({ from: e.from, to: e.to, weight: e.weight });

    steps.push({
      title: `Add ${e.from}–${e.to} (weight ${frac(e.weight).toDisplay()}) — brings in ${newNode}`,
      explanation: `Among every edge with exactly one endpoint already in the tree, ${e.from}–${e.to} is cheapest (${frac(e.weight).toDisplay()}), so it's added, bringing ${newNode} into the tree. Running total: ${total.toDisplay()}.`,
      operation: `add(${e.from}-${e.to})`,
      state: snapshot({
        stepKind: "accept",
        phase: "consider",
        method: "prim",
        edges: withStatus(),
        treeNodes: Array.from(treeNodes),
        totalWeight: total,
        currentEdge: { from: e.from, to: e.to, weight: frac(e.weight).toDisplay() },
      }),
      why: "The cut property: for any split of the nodes into two groups, the cheapest edge crossing that split must belong to some minimum spanning tree. The current tree and \"everything else\" is exactly such a split, so the cheapest crossing edge is always safe to add.",
    });
  }

  steps.push({
    title: "Minimum spanning tree found",
    explanation: `All ${graph.nodes.length} nodes are now connected using ${treeEdges.length} edges, with total weight ${total.toDisplay()}.`,
    state: snapshot({ stepKind: "done", phase: "done", method: "prim", edges: withStatus(), treeNodes: Array.from(treeNodes), totalWeight: total }),
  });

  return { status: "optimal", steps, totalWeight: total.toNumber(), treeEdges, notes: [] };
}
