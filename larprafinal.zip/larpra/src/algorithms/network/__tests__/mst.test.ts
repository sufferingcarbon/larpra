import { describe, it, expect } from "vitest";
import { solveMST } from "../mst";
import { mstExamples } from "../examples";
import { MSTInput } from "../../../types/network";

describe("solveMST — 6-node network (networkx-verified: total weight 11)", () => {
  const graph = mstExamples[0].graph;

  it("Kruskal reaches the true minimum weight of 11", () => {
    const result = solveMST({ graph, method: "kruskal" });
    expect(result.status).toBe("optimal");
    expect(result.totalWeight).toBe(11);
    expect(result.treeEdges?.length).toBe(5); // n - 1 = 6 - 1
  });

  it("Prim reaches the same minimum weight of 11 from any start node", () => {
    const resultA = solveMST({ graph, method: "prim", startNode: "A" });
    const resultD = solveMST({ graph, method: "prim", startNode: "D" });
    expect(resultA.totalWeight).toBe(11);
    expect(resultD.totalWeight).toBe(11);
  });

  it("Kruskal emits an accept/reject step for every edge it examines, in sorted order", () => {
    const result = solveMST({ graph, method: "kruskal" });
    const consider = result.steps.filter((s) => s.state.phase === "consider");
    expect(consider.length).toBeGreaterThan(0);
    const weights = consider.map((s) => Number(s.state.currentEdge?.weight));
    for (let i = 1; i < weights.length; i++) expect(weights[i]).toBeGreaterThanOrEqual(weights[i - 1]);
  });

  it("Kruskal rejects at least one edge that would close a cycle on this graph", () => {
    const result = solveMST({ graph, method: "kruskal" });
    const rejected = result.steps.filter((s) => s.state.stepKind === "reject-cycle");
    expect(rejected.length).toBeGreaterThan(0);
  });

  it("Prim emits exactly n-1 acceptance steps", () => {
    const result = solveMST({ graph, method: "prim", startNode: "A" });
    const accepted = result.steps.filter((s) => s.state.stepKind === "accept");
    expect(accepted.length).toBe(5);
  });
});

describe("solveMST — triangle plus a tail (networkx-verified: total weight 4)", () => {
  const graph = mstExamples[1].graph;

  it("both methods reach the true minimum weight of 4 despite the tied triangle", () => {
    expect(solveMST({ graph, method: "kruskal" }).totalWeight).toBe(4);
    expect(solveMST({ graph, method: "prim", startNode: "A" }).totalWeight).toBe(4);
  });

  it("produces a valid spanning tree (n-1 edges, all nodes covered)", () => {
    const result = solveMST({ graph, method: "kruskal" });
    expect(result.treeEdges?.length).toBe(3);
    const covered = new Set(result.treeEdges?.flatMap((e) => [e.from, e.to]));
    expect(covered.size).toBe(4);
  });

  it("Kruskal rejects exactly one triangle edge as a cycle", () => {
    const result = solveMST({ graph, method: "kruskal" });
    const rejected = result.steps.filter((s) => s.state.stepKind === "reject-cycle");
    expect(rejected.length).toBe(1);
  });
});

describe("solveMST — disconnected graph", () => {
  it("reports disconnected instead of a partial/fake tree", () => {
    const graph: MSTInput["graph"] = {
      directed: false,
      nodes: ["A", "B", "C", "D"],
      edges: [
        { from: "A", to: "B", weight: 1 },
        { from: "C", to: "D", weight: 1 },
      ],
    };
    const result = solveMST({ graph, method: "kruskal" });
    expect(result.status).toBe("disconnected");
    expect(result.steps).toEqual([]);
  });
});

describe("solveMST — invalid input", () => {
  it("rejects a directed graph (MST is only defined for undirected graphs)", () => {
    const graph: MSTInput["graph"] = {
      directed: true,
      nodes: ["A", "B"],
      edges: [{ from: "A", to: "B", weight: 1 }],
    };
    const result = solveMST({ graph, method: "kruskal" });
    expect(result.status).toBe("invalid");
  });
});
