import { describe, it, expect } from "vitest";
import { solveMaxFlow } from "../maxflow";
import { maxFlowExamples } from "../examples";
import { MaxFlowInput } from "../../../types/network";

describe("solveMaxFlow — classic 6-node network (networkx-verified: max flow 23)", () => {
  const problem = maxFlowExamples[0].problem;

  it("reaches the true maximum flow of 23", () => {
    const result = solveMaxFlow(problem);
    expect(result.status).toBe("optimal");
    expect(result.maxFlow).toBe(23);
  });

  it("needs more than one augmenting path to saturate the network", () => {
    const result = solveMaxFlow(problem);
    const augments = result.steps.filter((s) => s.state.stepKind === "augment");
    expect(augments.length).toBeGreaterThan(1);
  });

  it("identifies a min cut whose capacity equals the max flow", () => {
    const result = solveMaxFlow(problem);
    const cutStep = result.steps.find((s) => s.state.stepKind === "min-cut");
    expect(cutStep).toBeDefined();
    expect(cutStep!.explanation).toContain("23");
  });

  it("never lets any edge's flow exceed its capacity", () => {
    const result = solveMaxFlow(problem);
    const finalEdges = result.steps[result.steps.length - 1].state.edges;
    finalEdges.forEach((e) => {
      expect(Number(e.flow)).toBeLessThanOrEqual(Number(e.capacity) + 1e-9);
      expect(Number(e.flow)).toBeGreaterThanOrEqual(-1e-9);
    });
  });
});

describe("solveMaxFlow — small bottleneck network (networkx-verified: max flow 5)", () => {
  const problem = maxFlowExamples[1].problem;

  it("reaches the true maximum flow of 5", () => {
    const result = solveMaxFlow(problem);
    expect(result.status).toBe("optimal");
    expect(result.maxFlow).toBe(5);
  });

  it("conserves flow at every intermediate node", () => {
    const result = solveMaxFlow(problem);
    const finalEdges = result.steps[result.steps.length - 1].state.edges;
    const nodes = problem.graph.nodes.filter((n) => n !== problem.source && n !== problem.sink);
    nodes.forEach((n) => {
      const inflow = finalEdges.filter((e) => e.to === n).reduce((s, e) => s + Number(e.flow), 0);
      const outflow = finalEdges.filter((e) => e.from === n).reduce((s, e) => s + Number(e.flow), 0);
      expect(inflow).toBeCloseTo(outflow, 9);
    });
  });
});

describe("solveMaxFlow — invalid input", () => {
  it("rejects an undirected graph", () => {
    const problem: MaxFlowInput = {
      graph: { directed: false, nodes: ["S", "T"], edges: [{ from: "S", to: "T", weight: 5 }] },
      source: "S",
      sink: "T",
    };
    const result = solveMaxFlow(problem);
    expect(result.status).toBe("invalid");
  });

  it("rejects source === sink", () => {
    const problem: MaxFlowInput = {
      graph: { directed: true, nodes: ["S"], edges: [] },
      source: "S",
      sink: "S",
    };
    const result = solveMaxFlow(problem);
    expect(result.status).toBe("invalid");
  });
});
