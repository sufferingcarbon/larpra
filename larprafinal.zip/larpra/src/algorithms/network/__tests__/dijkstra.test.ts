import { describe, it, expect } from "vitest";
import { solveDijkstra } from "../dijkstra";
import { shortestPathExamples } from "../examples";
import { ShortestPathInput } from "../../../types/network";

describe("solveDijkstra — 6-node directed network (networkx-verified)", () => {
  const problem = shortestPathExamples[0].problem;

  it("matches networkx's shortest distances from A", () => {
    const result = solveDijkstra(problem);
    expect(result.status).toBe("optimal");
    expect(result.distances).toEqual({ A: 0, B: 3, C: 2, D: 8, E: 10, F: 13 });
  });

  it("reconstructs the correct predecessor for the indirect A→C→B route", () => {
    const result = solveDijkstra(problem);
    // The direct A→B edge weighs 4, but A→C→B weighs 2+1=3 — the shorter route must win.
    expect(result.predecessors?.B).toBe("C");
  });

  it("emits an init step, a select step per node, and a relax step per outgoing edge", () => {
    const result = solveDijkstra(problem);
    const kinds = result.steps.map((s) => s.state.stepKind);
    expect(kinds).toContain("init");
    expect(kinds.filter((k) => k === "select").length).toBe(6);
    expect(kinds.filter((k) => k === "relax-improve" || k === "relax-no-improve").length).toBeGreaterThan(0);
    expect(kinds).toContain("done");
  });
});

describe("solveDijkstra — unreachable node", () => {
  const problem = shortestPathExamples[1].problem;

  it("matches networkx distances and correctly reports Z as unreachable", () => {
    const result = solveDijkstra(problem);
    expect(result.status).toBe("optimal");
    expect(result.distances).toEqual({ S: 0, A: 2, B: 5, C: 5, D: 9, Z: null });
    expect(result.notes.some((n) => n.includes("Z"))).toBe(true);
  });
});

describe("solveDijkstra — negative edge", () => {
  const problem = shortestPathExamples[2].problem;

  it("rejects the problem instead of returning a silently wrong answer", () => {
    const result = solveDijkstra(problem);
    expect(result.status).toBe("negative-edge");
    expect(result.steps).toEqual([]);
    expect(result.notes[0]).toMatch(/non-negative/i);
  });
});

describe("solveDijkstra — invalid input", () => {
  it("reports a validation error instead of throwing on an unknown source", () => {
    const problem: ShortestPathInput = {
      graph: { directed: true, nodes: ["A", "B"], edges: [{ from: "A", to: "B", weight: 1 }] },
      source: "Z",
    };
    const result = solveDijkstra(problem);
    expect(result.status).toBe("invalid");
    expect(result.notes.length).toBeGreaterThan(0);
  });

  it("reports a validation error for an edge referencing an unknown node", () => {
    const problem: ShortestPathInput = {
      graph: { directed: true, nodes: ["A", "B"], edges: [{ from: "A", to: "C", weight: 1 }] },
      source: "A",
    };
    const result = solveDijkstra(problem);
    expect(result.status).toBe("invalid");
  });
});

describe("solveDijkstra — single node graph", () => {
  it("handles a graph with only the source, no edges", () => {
    const problem: ShortestPathInput = {
      graph: { directed: true, nodes: ["A"], edges: [] },
      source: "A",
    };
    const result = solveDijkstra(problem);
    expect(result.status).toBe("optimal");
    expect(result.distances).toEqual({ A: 0 });
  });
});
