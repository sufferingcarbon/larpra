import { Fraction, frac } from "../../utils/fraction";
import { GraphInput } from "../../types/network";

export function validateGraph(graph: GraphInput, opts: { requirePositiveWeights?: boolean } = {}): string[] {
  const errors: string[] = [];
  const seen = new Set<string>();
  graph.nodes.forEach((n) => {
    if (!n.trim()) errors.push("A node has an empty name.");
    if (seen.has(n)) errors.push(`Duplicate node name: ${n}.`);
    seen.add(n);
  });
  if (graph.nodes.length === 0) errors.push("Add at least one node.");

  const nodeSet = new Set(graph.nodes);
  graph.edges.forEach((e, i) => {
    if (!nodeSet.has(e.from)) errors.push(`Edge ${i + 1}: unknown node "${e.from}".`);
    if (!nodeSet.has(e.to)) errors.push(`Edge ${i + 1}: unknown node "${e.to}".`);
    if (Number.isNaN(e.weight)) errors.push(`Edge ${i + 1} (${e.from}→${e.to}): weight is missing.`);
    if (opts.requirePositiveWeights && e.weight <= 0) {
      errors.push(`Edge ${i + 1} (${e.from}→${e.to}): weight/capacity must be positive.`);
    }
  });

  return errors;
}

export interface AdjEdge {
  to: string;
  weight: Fraction;
  /** Index into the original edges array — lets callers trace a relaxed/accepted edge back to its input row. */
  edgeIndex: number;
}

/** Builds an adjacency list. For an undirected graph, every edge is added in both directions. */
export function buildAdjacency(graph: GraphInput): Map<string, AdjEdge[]> {
  const adj = new Map<string, AdjEdge[]>();
  graph.nodes.forEach((n) => adj.set(n, []));
  graph.edges.forEach((e, i) => {
    adj.get(e.from)?.push({ to: e.to, weight: frac(e.weight), edgeIndex: i });
    if (!graph.directed) {
      adj.get(e.to)?.push({ to: e.from, weight: frac(e.weight), edgeIndex: i });
    }
  });
  return adj;
}

/** Breadth-first reachability from `start`, following directed edges as given (or both ways if undirected). */
export function reachableFrom(graph: GraphInput, start: string): Set<string> {
  const adj = buildAdjacency(graph);
  const seen = new Set<string>([start]);
  const queue = [start];
  while (queue.length > 0) {
    const cur = queue.shift()!;
    for (const e of adj.get(cur) ?? []) {
      if (!seen.has(e.to)) {
        seen.add(e.to);
        queue.push(e.to);
      }
    }
  }
  return seen;
}

/** Whether the whole graph is connected, treating every edge as undirected (used by MST, which is defined on undirected graphs). */
export function isConnectedUndirected(graph: GraphInput): boolean {
  if (graph.nodes.length === 0) return true;
  const undirected: GraphInput = { ...graph, directed: false };
  return reachableFrom(undirected, graph.nodes[0]).size === graph.nodes.length;
}
