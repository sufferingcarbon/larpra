import { LPProblem, AlgorithmStep, LPResult } from "../../types/lp";

const EPS = 1e-7;

export interface Point {
  x: number;
  y: number;
}

export interface ConstraintLine {
  a: number;
  b: number;
  c: number; // line is a*x + b*y = c
  label: string;
  relation: "<=" | ">=" | "=";
}

export interface GraphicalState {
  lines: ConstraintLine[];
  vertices: (Point & { objective: number })[];
  optimalIndex: number | null;
  bounds: { maxX: number; maxY: number };
}

function isFeasible(p: Point, problem: LPProblem): boolean {
  if (p.x < -EPS || p.y < -EPS) return false;
  for (const c of problem.constraints) {
    const lhs = c.coeffs[0] * p.x + c.coeffs[1] * p.y;
    if (c.relation === "<=" && lhs > c.rhs + EPS) return false;
    if (c.relation === ">=" && lhs < c.rhs - EPS) return false;
    if (c.relation === "=" && Math.abs(lhs - c.rhs) > EPS) return false;
  }
  return true;
}

function intersect(l1: ConstraintLine, l2: ConstraintLine): Point | null {
  const det = l1.a * l2.b - l2.a * l1.b;
  if (Math.abs(det) < EPS) return null; // parallel or identical
  const x = (l1.c * l2.b - l2.c * l1.b) / det;
  const y = (l1.a * l2.c - l2.a * l1.c) / det;
  return { x, y };
}

function dedupe(points: Point[]): Point[] {
  const out: Point[] = [];
  for (const p of points) {
    if (!out.some((q) => Math.abs(q.x - p.x) < 1e-6 && Math.abs(q.y - p.y) < 1e-6)) {
      out.push({ x: Math.max(0, p.x), y: Math.max(0, p.y) });
    }
  }
  return out;
}

/** Recession-cone check: is there a direction d>=0 (d!=0) along which every constraint stays
 * satisfied forever, and which strictly improves the objective? If so the region is unbounded. */
function findUnboundedDirection(problem: LPProblem): Point | null {
  const asLE = problem.constraints.map((c) => {
    if (c.relation === "<=") return { a: c.coeffs[0], b: c.coeffs[1], eq: false };
    if (c.relation === ">=") return { a: -c.coeffs[0], b: -c.coeffs[1], eq: false };
    return { a: c.coeffs[0], b: c.coeffs[1], eq: true };
  });

  const candidates: Point[] = [
    { x: 1, y: 0 },
    { x: 0, y: 1 },
    { x: 1, y: 1 },
  ];
  problem.constraints.forEach((c) => {
    const [a, b] = c.coeffs;
    candidates.push({ x: b, y: -a }, { x: -b, y: a });
  });

  const [c1, c2] = problem.objective;
  let best: Point | null = null;
  let bestProfit = EPS;

  for (const raw of candidates) {
    if (raw.x < -EPS || raw.y < -EPS) continue;
    if (Math.abs(raw.x) < EPS && Math.abs(raw.y) < EPS) continue;
    const d = { x: Math.max(raw.x, 0), y: Math.max(raw.y, 0) };
    const valid = asLE.every(({ a, b, eq }) => {
      const val = a * d.x + b * d.y;
      return eq ? Math.abs(val) < 1e-6 : val <= 1e-6;
    });
    if (!valid) continue;
    const raw_profit = c1 * d.x + c2 * d.y;
    const profit = problem.sense === "max" ? raw_profit : -raw_profit;
    if (profit > bestProfit) {
      bestProfit = profit;
      best = d;
    }
  }
  return best;
}

export function solveGraphical(problem: LPProblem): LPResult<GraphicalState> {
  if (problem.variables.length !== 2) {
    throw new Error("The graphical method only applies to two-variable problems.");
  }
  const steps: AlgorithmStep<GraphicalState>[] = [];
  const notes: string[] = [];

  const lines: ConstraintLine[] = problem.constraints.map((c, i) => ({
    a: c.coeffs[0],
    b: c.coeffs[1],
    c: c.rhs,
    label: c.label ?? `Constraint ${i + 1}`,
    relation: c.relation,
  }));
  const axisLines: ConstraintLine[] = [
    { a: 1, b: 0, c: 0, label: `${problem.variables[0]} = 0`, relation: ">=" },
    { a: 0, b: 1, c: 0, label: `${problem.variables[1]} = 0`, relation: ">=" },
  ];
  const allLines = [...lines, ...axisLines];

  steps.push({
    title: "Plot constraint boundaries",
    explanation: `Each constraint becomes a boundary line on the ${problem.variables[0]}–${problem.variables[1]} plane. Together with the non-negativity axes, these ${allLines.length} lines bound the feasible region.`,
    state: { lines: allLines, vertices: [], optimalIndex: null, bounds: { maxX: 10, maxY: 10 } },
  });

  const unboundedDir = findUnboundedDirection(problem);

  const rawPoints: Point[] = [];
  for (let i = 0; i < allLines.length; i++) {
    for (let j = i + 1; j < allLines.length; j++) {
      const p = intersect(allLines[i], allLines[j]);
      if (p && isFeasible(p, problem)) rawPoints.push(p);
    }
  }
  const vertexPoints = dedupe(rawPoints);

  if (vertexPoints.length === 0 && !unboundedDir) {
    steps.push({
      title: "Infeasible",
      explanation:
        "No point satisfies every constraint (together with x, y ≥ 0) simultaneously — the constraint boundaries never enclose a common region.",
      state: { lines: allLines, vertices: [], optimalIndex: null, bounds: { maxX: 10, maxY: 10 } },
    });
    return { status: "infeasible", steps, notes };
  }

  // Order around the centroid so the polygon renders correctly.
  const cx = vertexPoints.reduce((s, p) => s + p.x, 0) / (vertexPoints.length || 1);
  const cy = vertexPoints.reduce((s, p) => s + p.y, 0) / (vertexPoints.length || 1);
  const ordered = [...vertexPoints].sort(
    (p, q) => Math.atan2(p.y - cy, p.x - cx) - Math.atan2(q.y - cy, q.x - cx)
  );

  const vertices = ordered.map((p) => ({
    x: Number(p.x.toFixed(6)),
    y: Number(p.y.toFixed(6)),
    objective: Number((problem.objective[0] * p.x + problem.objective[1] * p.y).toFixed(6)),
  }));

  const maxX = Math.max(10, ...vertices.map((v) => v.x * 1.4));
  const maxY = Math.max(10, ...vertices.map((v) => v.y * 1.4));

  steps.push({
    title: "Identify the feasible region",
    explanation: `${vertices.length} corner point(s) satisfy every constraint at once: ${vertices
      .map((v) => `(${v.x}, ${v.y})`)
      .join(", ") || "none"}. By the fundamental theorem of linear programming, an optimal solution — if one exists — occurs at one of these corner points.`,
    state: { lines: allLines, vertices, optimalIndex: null, bounds: { maxX, maxY } },
  });

  if (unboundedDir) {
    steps.push({
      title: "Unbounded",
      explanation: `Moving from a feasible point in direction (${unboundedDir.x.toFixed(2)}, ${unboundedDir.y.toFixed(2)}) stays feasible forever and keeps improving the objective. There is no finite optimum.`,
      state: { lines: allLines, vertices, optimalIndex: null, bounds: { maxX, maxY } },
    });
    return { status: "unbounded", steps, notes };
  }

  let optimalIndex = 0;
  for (let i = 1; i < vertices.length; i++) {
    const better =
      problem.sense === "max"
        ? vertices[i].objective > vertices[optimalIndex].objective
        : vertices[i].objective < vertices[optimalIndex].objective;
    if (better) optimalIndex = i;
  }
  const bestVal = vertices[optimalIndex]?.objective;
  const tiedCount = vertices.filter((v) => Math.abs(v.objective - bestVal) < 1e-6).length;
  if (tiedCount > 1) {
    notes.push(
      "More than one corner point achieves the optimal objective value: any point on the edge joining them is also optimal (alternate optima)."
    );
  }

  steps.push({
    title: "Evaluate the objective at every corner",
    explanation: `Substituting each corner point into Z = ${problem.objective[0]}${problem.variables[0]} + ${problem.objective[1]}${problem.variables[1]} gives the objective column above. The ${problem.sense === "max" ? "largest" : "smallest"} value is Z = ${bestVal} at (${vertices[optimalIndex].x}, ${vertices[optimalIndex].y}).`,
    state: { lines: allLines, vertices, optimalIndex, bounds: { maxX, maxY } },
  });

  const solution: Record<string, number> = {
    [problem.variables[0]]: vertices[optimalIndex].x,
    [problem.variables[1]]: vertices[optimalIndex].y,
  };

  return {
    status: tiedCount > 1 ? "alternate_optima" : "optimal",
    steps,
    optimalValue: bestVal,
    optimalSolution: solution,
    notes,
  };
}
