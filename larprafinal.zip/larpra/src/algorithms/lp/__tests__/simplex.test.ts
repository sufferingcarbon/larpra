import { describe, it, expect } from "vitest";
import { solveSimplex } from "../simplex";
import { LPProblem } from "../../../types/lp";

describe("solveSimplex", () => {
  it("solves a classic all-<= maximization problem", () => {
    // max 3x1 + 5x2 s.t. x1<=4, 2x2<=12, 3x1+2x2<=18 -> x1=2, x2=6, Z=36
    const problem: LPProblem = {
      sense: "max",
      objective: [3, 5],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 0], relation: "<=", rhs: 4 },
        { coeffs: [0, 2], relation: "<=", rhs: 12 },
        { coeffs: [3, 2], relation: "<=", rhs: 18 },
      ],
    };
    const result = solveSimplex(problem);
    expect(result.status).toBe("optimal");
    expect(result.optimalValue).toBeCloseTo(36);
    expect(result.optimalSolution!["x1"]).toBeCloseTo(2);
    expect(result.optimalSolution!["x2"]).toBeCloseTo(6);
    expect(result.steps.length).toBeGreaterThan(1);
  });

  it("solves a >= / two-phase minimization problem", () => {
    // min 2x1 + 3x2 s.t. x1+x2>=10, 2x1+x2>=12.
    // Feasible vertices are (0,12) Z=36, (2,8) Z=28, (10,0) Z=20 -> true optimum is (10,0), Z=20.
    const problem: LPProblem = {
      sense: "min",
      objective: [2, 3],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 1], relation: ">=", rhs: 10 },
        { coeffs: [2, 1], relation: ">=", rhs: 12 },
      ],
    };
    const result = solveSimplex(problem);
    expect(result.status).toBe("optimal");
    expect(result.optimalValue).toBeCloseTo(20);
    expect(result.optimalSolution!["x1"]).toBeCloseTo(10);
    expect(result.optimalSolution!["x2"]).toBeCloseTo(0);
  });

  it("handles an equality constraint via Phase I", () => {
    // max x1 + x2 s.t. x1+x2=4, x1<=3 -> (3,1) or check bound; Z=4 everywhere on the segment
    const problem: LPProblem = {
      sense: "max",
      objective: [1, 1],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 1], relation: "=", rhs: 4 },
        { coeffs: [1, 0], relation: "<=", rhs: 3 },
      ],
    };
    const result = solveSimplex(problem);
    expect(["optimal", "alternate_optima"]).toContain(result.status);
    expect(result.optimalValue).toBeCloseTo(4);
  });

  it("detects infeasibility", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [2, 3],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 1], relation: "<=", rhs: 4 },
        { coeffs: [1, 1], relation: ">=", rhs: 10 },
      ],
    };
    const result = solveSimplex(problem);
    expect(result.status).toBe("infeasible");
  });

  it("detects unboundedness", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [1, 1],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, -1], relation: "<=", rhs: 1 },
        { coeffs: [-1, 1], relation: "<=", rhs: 2 },
      ],
    };
    const result = solveSimplex(problem);
    expect(result.status).toBe("unbounded");
  });

  it("flags alternate optima when a non-basic column ties at zero", () => {
    // max 2x1 + 4x2 s.t. x1+2x2<=10, x1<=6 -- objective is parallel to the x1+2x2<=10 edge.
    const problem: LPProblem = {
      sense: "max",
      objective: [2, 4],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 2], relation: "<=", rhs: 10 },
        { coeffs: [1, 0], relation: "<=", rhs: 6 },
      ],
    };
    const result = solveSimplex(problem);
    expect(result.optimalValue).toBeCloseTo(20);
    expect(result.status).toBe("alternate_optima");
  });

  it("rejects mismatched coefficient counts", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [1, 1],
      variables: ["x1", "x2"],
      constraints: [{ coeffs: [1], relation: "<=", rhs: 4 }],
    };
    expect(() => solveSimplex(problem)).toThrow();
  });
});
