import { describe, it, expect } from "vitest";
import { solveGraphical } from "../graphical";
import { LPProblem } from "../../../types/lp";

describe("solveGraphical", () => {
  it("matches the simplex optimum on the classic furniture problem", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [3, 5],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 0], relation: "<=", rhs: 4 },
        { coeffs: [0, 2], relation: "<=", rhs: 12 },
        { coeffs: [3, 2], relation: "<=", rhs: 18 },
      ],
    };
    const result = solveGraphical(problem);
    expect(result.status).toBe("optimal");
    expect(result.optimalValue).toBeCloseTo(36);
    expect(result.optimalSolution!["x1"]).toBeCloseTo(2);
    expect(result.optimalSolution!["x2"]).toBeCloseTo(6);
  });

  it("detects unboundedness", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [1, 1],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, -1], relation: "<=", rhs: 1 },
        { coeffs: [-1, 1], relation: "<=", rhs: 2 },
      ],
    };
    const result = solveGraphical(problem);
    expect(result.status).toBe("unbounded");
  });

  it("detects infeasibility", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [2, 3],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 1], relation: "<=", rhs: 4 },
        { coeffs: [1, 1], relation: ">=", rhs: 10 },
      ],
    };
    const result = solveGraphical(problem);
    expect(result.status).toBe("infeasible");
  });

  it("rejects problems that are not 2-variable", () => {
    const problem: LPProblem = {
      sense: "max",
      objective: [1, 1, 1],
      variables: ["x1", "x2", "x3"],
      constraints: [{ coeffs: [1, 1, 1], relation: "<=", rhs: 4 }],
    };
    expect(() => solveGraphical(problem)).toThrow();
  });
});
