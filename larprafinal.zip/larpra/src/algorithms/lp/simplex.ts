import { LPProblem, AlgorithmStep, LPResult, SolutionStatus } from "../../types/lp";
import { Fraction, frac } from "../../utils/fraction";
import { standardize, StandardForm } from "./standardize";

export interface SimplexTableauState {
  phase: 1 | 2;
  columns: string[];
  basisVars: string[];
  rows: string[][];
  rhs: string[];
  cj: string[];
  zj: string[];
  cjMinusZj: string[];
  ratios: (string | null)[];
  enteringVar: string | null;
  enteringCol: number | null;
  leavingVar: string | null;
  leavingRow: number | null;
  pivotElement: string | null;
  objectiveValue: string;
  isOptimal: boolean;
  tie: boolean;
}

const TOL_NOTE = "Exact rational arithmetic is used throughout, so this optimality test is exact — no floating-point tolerance is involved.";

class Tableau {
  columns: string[];
  kinds: ("decision" | "slack" | "surplus" | "artificial")[];
  rows: Fraction[][]; // rows[i][j]
  rhs: Fraction[];
  basis: number[]; // column index that is basic in row i
  cost: Fraction[]; // current-phase objective coefficients over columns

  constructor(
    columns: string[],
    kinds: Tableau["kinds"],
    rows: Fraction[][],
    rhs: Fraction[],
    basis: number[],
    cost: Fraction[]
  ) {
    this.columns = columns;
    this.kinds = kinds;
    this.rows = rows;
    this.rhs = rhs;
    this.basis = basis;
    this.cost = cost;
  }

  get numRows() {
    return this.rows.length;
  }
  get numCols() {
    return this.columns.length;
  }

  cB(): Fraction[] {
    return this.basis.map((colIdx) => this.cost[colIdx]);
  }

  zj(): Fraction[] {
    const cb = this.cB();
    const z: Fraction[] = [];
    for (let j = 0; j < this.numCols; j++) {
      let sum = Fraction.ZERO;
      for (let i = 0; i < this.numRows; i++) {
        sum = sum.add(cb[i].mul(this.rows[i][j]));
      }
      z.push(sum);
    }
    return z;
  }

  objectiveValue(): Fraction {
    const cb = this.cB();
    let sum = Fraction.ZERO;
    for (let i = 0; i < this.numRows; i++) sum = sum.add(cb[i].mul(this.rhs[i]));
    return sum;
  }

  cjMinusZj(): Fraction[] {
    const z = this.zj();
    return this.cost.map((c, j) => c.sub(z[j]));
  }

  pivot(row: number, col: number) {
    const pivotVal = this.rows[row][col];
    this.rows[row] = this.rows[row].map((v) => v.div(pivotVal));
    this.rhs[row] = this.rhs[row].div(pivotVal);
    for (let i = 0; i < this.numRows; i++) {
      if (i === row) continue;
      const factor = this.rows[i][col];
      if (factor.isZero()) continue;
      this.rows[i] = this.rows[i].map((v, j) => v.sub(factor.mul(this.rows[row][j])));
      this.rhs[i] = this.rhs[i].sub(factor.mul(this.rhs[row]));
    }
    this.basis[row] = col;
  }

  snapshot(
    phase: 1 | 2,
    opts: {
      enteringCol?: number | null;
      leavingRow?: number | null;
      ratios?: (Fraction | null)[];
      tie?: boolean;
      isOptimal?: boolean;
    } = {}
  ): SimplexTableauState {
    const z = this.zj();
    const cz = this.cjMinusZj();
    const enteringCol = opts.enteringCol ?? null;
    const leavingRow = opts.leavingRow ?? null;
    return {
      phase,
      columns: this.columns.slice(),
      basisVars: this.basis.map((c) => this.columns[c]),
      rows: this.rows.map((r) => r.map((v) => v.toDisplay())),
      rhs: this.rhs.map((v) => v.toDisplay()),
      cj: this.cost.map((v) => v.toDisplay()),
      zj: z.map((v) => v.toDisplay()),
      cjMinusZj: cz.map((v) => v.toDisplay()),
      ratios: (opts.ratios ?? []).map((r) => (r ? r.toDisplay() : null)),
      enteringVar: enteringCol !== null ? this.columns[enteringCol] : null,
      enteringCol,
      leavingVar: leavingRow !== null ? this.columns[this.basis[leavingRow]] : null,
      leavingRow,
      pivotElement:
        enteringCol !== null && leavingRow !== null ? this.rows[leavingRow][enteringCol].toDisplay() : null,
      objectiveValue: this.objectiveValue().toDisplay(),
      isOptimal: opts.isOptimal ?? false,
      tie: opts.tie ?? false,
    };
  }
}

function buildInitialTableau(sf: StandardForm, phase: 1 | 2, phase2Objective?: Fraction[]): Tableau {
  const columns = sf.columns.map((c) => c.name);
  const kinds = sf.columns.map((c) => c.kind);
  const rows = sf.rows.map((r) => r.coeffs.slice());
  const rhs = sf.rows.map((r) => r.rhs);
  const basis = sf.rows.map((r) => r.basisColumnIndex);

  let cost: Fraction[];
  if (phase === 1) {
    cost = sf.columns.map((c) => (c.kind === "artificial" ? Fraction.ONE.neg() : Fraction.ZERO));
  } else {
    cost = (phase2Objective ?? sf.maxObjective).slice();
    // Artificials must never re-enter phase 2; costing them at -infinity (approximated by a very
    // unfavourable value) is unnecessary because we physically remove their columns before phase 2.
  }
  return new Tableau(columns, kinds, rows, rhs, basis, cost);
}

export type PivotRule = "dantzig" | "bland";

/** Thrown when the pivot loop hits its iteration cap — the signature of cycling. */
export class SimplexIterationLimit extends Error {
  constructor() {
    super("Simplex did not converge within the iteration limit — check the problem for cycling.");
    this.name = "SimplexIterationLimit";
  }
}

/**
 * The exact (Fraction) outcome of an LP, with no display rounding. Integer programming needs this:
 * whether a value is an integer is a yes/no question that must never be answered from a float.
 */
export interface ExactLPResult {
  status: "optimal" | "infeasible" | "unbounded";
  /** Optimal objective in the problem's own sense (a "min" problem is NOT negated). */
  objective?: Fraction;
  /** Optimal values of the decision variables, in `problem.variables` order. */
  values?: Fraction[];
}

/**
 * Runs simplex to optimality on an already-built tableau, pushing one step per pivot (plus the starting
 * tableau) when `steps` is given. Passing null skips all step building — the fast path Branch & Bound uses.
 *
 * rule "dantzig": entering = most positive Cj − Zj (ties: lowest index), leaving = smallest ratio (ties: lowest row).
 * rule "bland":   entering = lowest-indexed column with Cj − Zj > 0, leaving = smallest ratio (ties: lowest-indexed
 *                 basic variable). Slower per problem but provably never cycles; used only as a fallback.
 */
function runSimplex(
  tab: Tableau,
  phase: 1 | 2,
  steps: AlgorithmStep<SimplexTableauState>[] | null,
  rule: PivotRule = "dantzig",
  maxIterations = rule === "bland" ? 5000 : 200
): { unbounded: boolean } {
  steps?.push({
    title: phase === 1 ? "Phase I — initial tableau" : "Initial tableau",
    explanation:
      phase === 1
        ? "Phase I minimizes the sum of the artificial variables (shown here as maximizing their negative sum) to find a starting basic feasible solution for the real problem."
        : "This is the starting basic feasible solution: every slack/surplus (or the Phase I basis) is basic, every decision variable is 0.",
    state: tab.snapshot(phase),
  });

  for (let iter = 0; iter < maxIterations; iter++) {
    const cz = tab.cjMinusZj();
    let enteringCol = -1;
    let best = Fraction.ZERO;
    let tieCount = 0;
    if (rule === "bland") {
      for (let j = 0; j < tab.numCols; j++) {
        if (cz[j].isPositive()) {
          enteringCol = j;
          best = cz[j];
          break;
        }
      }
    } else {
      for (let j = 0; j < tab.numCols; j++) {
        if (cz[j].gt(best)) {
          best = cz[j];
          enteringCol = j;
          tieCount = 1;
        } else if (enteringCol !== -1 && cz[j].equals(best) && !cz[j].isZero()) {
          tieCount++;
        }
      }
    }

    if (enteringCol === -1) {
      steps?.push({
        title: phase === 1 ? "Phase I — optimal" : "Optimal tableau reached",
        explanation:
          "Every Cj − Zj value is ≤ 0, so no non-basic variable can improve the objective any further. " +
          TOL_NOTE,
        state: tab.snapshot(phase, { isOptimal: true }),
        why: "The optimality rule for maximization: stop as soon as no column has a positive Cj − Zj, because entering any such column would only decrease (or, at best, not increase) the objective.",
      });
      return { unbounded: false };
    }

    // Ratio test.
    const ratios: (Fraction | null)[] = [];
    let leavingRow = -1;
    let minRatio: Fraction | null = null;
    for (let i = 0; i < tab.numRows; i++) {
      const a = tab.rows[i][enteringCol];
      if (a.isPositive()) {
        const ratio = tab.rhs[i].div(a);
        ratios.push(ratio);
        if (minRatio === null || ratio.lt(minRatio)) {
          minRatio = ratio;
          leavingRow = i;
        } else if (rule === "bland" && ratio.equals(minRatio) && tab.basis[i] < tab.basis[leavingRow]) {
          leavingRow = i;
        }
      } else {
        ratios.push(null);
      }
    }

    if (leavingRow === -1) {
      steps?.push({
        title: "Unbounded",
        explanation: `Every coefficient in the ${tab.columns[enteringCol]} column is ≤ 0, so ${tab.columns[enteringCol]} can increase without limit and the objective grows without bound.`,
        state: tab.snapshot(phase, { enteringCol, ratios }),
        why: "The ratio test needs at least one positive coefficient in the entering column to compute a limiting ratio bᵢ/aᵢⱼ. With none available, there is no bound on how far the entering variable can increase.",
      });
      return { unbounded: true };
    }

    const leavingVarName = tab.columns[tab.basis[leavingRow]];
    const enteringVarName = tab.columns[enteringCol];
    if (steps) {
      const tiedRows = ratios.filter((r) => r !== null && minRatio !== null && r.equals(minRatio)).length;
      const pivotElement = tab.rows[leavingRow][enteringCol];
      const enteringWhy =
        rule === "bland"
          ? `${enteringVarName} is the lowest-indexed column with a positive Cj − Zj (${best.toDisplay()}) — Bland's anti-cycling rule.`
          : `${enteringVarName} has the largest Cj − Zj (${best.toDisplay()}), so it enters the basis.`;
      steps.push({
        title: `Pivot: ${enteringVarName} enters, ${leavingVarName} leaves`,
        explanation:
          `${enteringWhy} ` +
          `The minimum ratio test (RHS ÷ pivot column, positive entries only) selects row "${leavingVarName}" ` +
          `with ratio ${minRatio!.toDisplay()}, so ${leavingVarName} leaves the basis. ` +
          `Pivoting on element ${pivotElement.toDisplay()}.` +
          (tiedRows > 1
            ? rule === "bland"
              ? " Note: the ratio test was tied — Bland's rule picked the tied row whose basic variable has the lowest index."
              : " Note: this ratio test was tied between multiple rows — the lowest-indexed row was chosen, which can signal a degenerate solution."
            : ""),
        operation: `pivot(row=${leavingRow}, col=${enteringCol})`,
        state: tab.snapshot(phase, { enteringCol, leavingRow, ratios, tie: tieCount > 1 }),
        why:
          `Entering-variable rule: choose the column with the most positive Cj − Zj, since it improves the objective fastest per unit increase. ` +
          `Leaving-variable rule: among rows with a positive coefficient in that column, choose the smallest ratio bᵢ/aᵢⱼ — any larger step would drive some other basic variable negative.`,
      });
    }

    tab.pivot(leavingRow, enteringCol);

    steps?.push({
      title: `Tableau after pivot ${iter + 1}`,
      explanation: `${enteringVarName} is now basic in the row where ${leavingVarName} used to be. All other rows were updated so every basic column remains a unit column.`,
      state: tab.snapshot(phase),
    });
  }

  throw new SimplexIterationLimit();
}

function solveCore(
  problem: LPProblem,
  record: boolean,
  rule: PivotRule
): { lp: LPResult<SimplexTableauState>; exact: ExactLPResult } {
  const notes: string[] = [];
  const steps: AlgorithmStep<SimplexTableauState>[] | null = record ? [] : null;
  const finish = (lp: Omit<LPResult<SimplexTableauState>, "steps">, exact: ExactLPResult) => ({
    lp: { ...lp, steps: steps ?? [] } as LPResult<SimplexTableauState>,
    exact,
  });
  const sf = standardize(problem);

  let workingTableau: Tableau;

  if (sf.hasArtificials) {
    const phase1Tableau = buildInitialTableau(sf, 1);
    const { unbounded } = runSimplex(phase1Tableau, 1, steps, rule);
    if (unbounded) {
      // Cannot happen in a correctly formed Phase I (bounded above by 0), but guard anyway.
      return finish({ status: "infeasible", notes: ["Phase I reported unbounded, which indicates a modeling error."] }, { status: "infeasible" });
    }
    const phase1Obj = phase1Tableau.objectiveValue();
    if (!phase1Obj.isZero()) {
      steps?.push({
        title: "Infeasible",
        explanation: `Phase I cannot reduce the artificial variables to zero (minimum sum of artificials = ${phase1Obj.neg().toDisplay()}). No point satisfies every constraint simultaneously, so the problem is infeasible.`,
        state: phase1Tableau.snapshot(1, { isOptimal: true }),
      });
      return finish({ status: "infeasible", notes }, { status: "infeasible" });
    }

    // Try to pivot out any artificial variables still sitting in the basis at level 0 (degenerate).
    // If a row has no non-artificial column with a non-zero coefficient, it is truly redundant
    // (a multiple of other constraints) and gets dropped rather than forced to stay artificial.
    const redundantRows: number[] = [];
    sf.artificialColumnIndices.forEach((artCol) => {
      const row = phase1Tableau.basis.indexOf(artCol);
      if (row === -1) return;
      let pivoted = false;
      for (let j = 0; j < phase1Tableau.numCols; j++) {
        if (sf.columns[j].kind === "artificial") continue;
        if (!phase1Tableau.rows[row][j].isZero()) {
          phase1Tableau.pivot(row, j);
          notes.push(
            `An artificial variable remained in the basis at zero after Phase I (a degenerate row); it was pivoted out using ${sf.columns[j].name} before Phase II.`
          );
          pivoted = true;
          break;
        }
      }
      if (!pivoted) {
        redundantRows.push(row);
        notes.push(
          `Constraint "${sf.rows[row].sourceLabel}" is redundant given the other constraints and was dropped before Phase II.`
        );
      }
    });

    // Build Phase II tableau from Phase I's final rows: drop artificial columns entirely, and
    // drop any redundant rows identified above.
    const keepCols = sf.columns
      .map((_, idx) => idx)
      .filter((idx) => sf.columns[idx].kind !== "artificial");
    const keepRows = phase1Tableau.rows.map((_, i) => i).filter((i) => !redundantRows.includes(i));
    const remap = new Map<number, number>();
    keepCols.forEach((oldIdx, newIdx) => remap.set(oldIdx, newIdx));

    const newColumns = keepCols.map((idx) => sf.columns[idx].name);
    const newKinds = keepCols.map((idx) => sf.columns[idx].kind);
    const newRows = keepRows.map((i) => keepCols.map((idx) => phase1Tableau.rows[i][idx]));
    const newRhs = keepRows.map((i) => phase1Tableau.rhs[i]);
    const newBasis = keepRows.map((i) => remap.get(phase1Tableau.basis[i])!);
    const phase2Cost = keepCols.map((idx) => sf.maxObjective[idx]);

    workingTableau = new Tableau(newColumns, newKinds, newRows, newRhs, newBasis, phase2Cost);

    steps?.push({
      title: "Entering Phase II",
      explanation:
        "All artificial variables reached zero, so a basic feasible solution to the real problem has been found. Their columns are dropped and the original objective row replaces the Phase I objective.",
      state: workingTableau.snapshot(2),
    });
  } else {
    workingTableau = buildInitialTableau(sf, 2);
  }

  const { unbounded } = runSimplex(workingTableau, 2, steps, rule);
  if (unbounded) {
    return finish({ status: "unbounded", notes }, { status: "unbounded" });
  }

  const finalCz = workingTableau.cjMinusZj();
  const nonBasicZero = workingTableau.columns.some(
    (_, j) => !workingTableau.basis.includes(j) && finalCz[j].isZero()
  );

  const solution: Record<string, number> = {};
  const exactValues: Fraction[] = problem.variables.map(() => Fraction.ZERO);
  problem.variables.forEach((v) => (solution[v] = 0));
  workingTableau.basis.forEach((colIdx, rowIdx) => {
    const name = workingTableau.columns[colIdx];
    const varIdx = problem.variables.indexOf(name);
    if (varIdx !== -1) {
      solution[name] = workingTableau.rhs[rowIdx].toNumber();
      exactValues[varIdx] = workingTableau.rhs[rowIdx];
    }
  });

  const rawObjective = workingTableau.objectiveValue();
  const reportedObjective = sf.negatedForMin ? rawObjective.neg() : rawObjective;
  const exact: ExactLPResult = { status: "optimal", objective: reportedObjective, values: exactValues };

  // The fast path (no steps) is what Branch & Bound calls thousands of times — skip the reporting extras.
  if (!record) return finish({ status: "optimal", notes }, exact);

  if (nonBasicZero) {
    notes.push(
      "A non-basic variable has Cj − Zj = 0 at the optimal tableau: alternate optimal solutions exist along the edge connecting this vertex to another one with the same objective value."
    );
  }

  const finalZj = workingTableau.zj();
  const shadowPrices: Record<string, string | null> = {};
  problem.constraints.forEach((c, i) => {
    const label = c.label ?? `Constraint ${i + 1}`;
    if (c.relation === "<=") {
      const colIdx = workingTableau.columns.indexOf(`s${i + 1}`);
      if (colIdx === -1) {
        shadowPrices[label] = null; // dropped as a redundant row
      } else {
        const shadow = sf.negatedForMin ? finalZj[colIdx].neg() : finalZj[colIdx];
        shadowPrices[label] = shadow.toDisplay();
      }
    } else {
      shadowPrices[label] = null;
    }
  });

  const reducedCosts: Record<string, string> = {};
  problem.variables.forEach((v) => {
    const colIdx = workingTableau.columns.indexOf(v);
    reducedCosts[v] = colIdx === -1 ? "0" : finalCz[colIdx].toDisplay();
  });

  return finish(
    {
      status: nonBasicZero ? "alternate_optima" : "optimal",
      optimalValue: reportedObjective.toNumber(),
      optimalSolution: solution,
      notes,
      sensitivity: { shadowPrices, reducedCosts },
    },
    exact
  );
}

const CYCLING_NOTE =
  "The default pivot rule (largest Cj − Zj) cycled without converging, so this problem was re-solved from scratch with Bland's rule, which cannot cycle.";

function solveWithFallback(problem: LPProblem, record: boolean) {
  try {
    return solveCore(problem, record, "dantzig");
  } catch (e) {
    if (!(e instanceof SimplexIterationLimit)) throw e;
    const r = solveCore(problem, record, "bland");
    r.lp.notes.unshift(CYCLING_NOTE);
    return r;
  }
}

/** Full step-by-step two-phase simplex (what the LP page shows). */
export function solveSimplex(problem: LPProblem): LPResult<SimplexTableauState> {
  return solveWithFallback(problem, true).lp;
}

/**
 * Same engine, no step recording, exact Fraction output. Deterministic: it takes exactly the pivots
 * `solveSimplex` shows, so a step-by-step replay of any node always agrees with the value used to decide it.
 */
export function solveLPExact(problem: LPProblem): ExactLPResult {
  return solveWithFallback(problem, false).exact;
}
