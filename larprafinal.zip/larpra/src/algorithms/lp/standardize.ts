import { LPProblem, ConstraintRelation } from "../../types/lp";
import { Fraction, frac } from "../../utils/fraction";

export interface StandardColumn {
  name: string;
  kind: "decision" | "slack" | "surplus" | "artificial";
}

export interface StandardRow {
  /** Coefficients for every column in `columns`, row-index aligned with the original constraint. */
  coeffs: Fraction[];
  rhs: Fraction;
  basisColumnIndex: number;
  originalRelation: ConstraintRelation;
  sourceLabel: string;
}

export interface StandardForm {
  columns: StandardColumn[];
  rows: StandardRow[];
  hasArtificials: boolean;
  artificialColumnIndices: number[];
  /** Objective coefficients over `columns`, always expressed as a MAXIMIZATION objective. */
  maxObjective: Fraction[];
  /** True when the caller's problem was "min" and we negated it to solve as "max". */
  negatedForMin: boolean;
}

export function standardize(problem: LPProblem): StandardForm {
  const n = problem.variables.length;
  if (problem.objective.length !== n) {
    throw new Error("Objective coefficient count must match the number of variables.");
  }

  const columns: StandardColumn[] = problem.variables.map((v) => ({
    name: v,
    kind: "decision",
  }));

  // Normalize sign of RHS first so every row we build has rhs >= 0.
  type Normalized = { coeffs: Fraction[]; relation: ConstraintRelation; rhs: Fraction; label: string };
  const normalized: Normalized[] = problem.constraints.map((c, i) => {
    if (c.coeffs.length !== n) {
      throw new Error(`Constraint ${i + 1} has ${c.coeffs.length} coefficients, expected ${n}.`);
    }
    let coeffs = c.coeffs.map(frac);
    let rhs = frac(c.rhs);
    let relation = c.relation;
    if (rhs.isNegative()) {
      coeffs = coeffs.map((x) => x.neg());
      rhs = rhs.neg();
      if (relation === "<=") relation = ">=";
      else if (relation === ">=") relation = "<=";
    }
    return { coeffs, relation, rhs, label: c.label ?? `Constraint ${i + 1}` };
  });

  // Decide, per row, what logical/artificial columns are needed, and register the columns first
  // so every row array can be sized uniformly.
  const logicalColIndex: (number | null)[] = [];
  const artificialColIndex: (number | null)[] = [];

  normalized.forEach((row, i) => {
    if (row.relation === "<=") {
      columns.push({ name: `s${i + 1}`, kind: "slack" });
      logicalColIndex.push(columns.length - 1);
      artificialColIndex.push(null);
    } else if (row.relation === ">=") {
      columns.push({ name: `s${i + 1}`, kind: "surplus" });
      logicalColIndex.push(columns.length - 1);
      columns.push({ name: `a${i + 1}`, kind: "artificial" });
      artificialColIndex.push(columns.length - 1);
    } else {
      logicalColIndex.push(null);
      columns.push({ name: `a${i + 1}`, kind: "artificial" });
      artificialColIndex.push(columns.length - 1);
    }
  });

  const totalCols = columns.length;
  const rows: StandardRow[] = normalized.map((row, i) => {
    const coeffs = new Array(totalCols).fill(null).map(() => Fraction.ZERO);
    for (let j = 0; j < n; j++) coeffs[j] = row.coeffs[j];
    const logIdx = logicalColIndex[i];
    if (logIdx !== null) coeffs[logIdx] = row.relation === "<=" ? Fraction.ONE : Fraction.ONE.neg();
    const artIdx = artificialColIndex[i];
    if (artIdx !== null) coeffs[artIdx] = Fraction.ONE;
    const basisColumnIndex = artIdx !== null ? artIdx : (logIdx as number);
    return {
      coeffs,
      rhs: row.rhs,
      basisColumnIndex,
      originalRelation: row.relation,
      sourceLabel: row.label,
    };
  });

  const artificialColumnIndices = artificialColIndex.filter((x): x is number => x !== null);

  const negatedForMin = problem.sense === "min";
  const objective = problem.objective.map(frac);
  const maxObjective = new Array(totalCols).fill(null).map(() => Fraction.ZERO);
  for (let j = 0; j < n; j++) {
    maxObjective[j] = negatedForMin ? objective[j].neg() : objective[j];
  }

  return {
    columns,
    rows,
    hasArtificials: artificialColumnIndices.length > 0,
    artificialColumnIndices,
    maxObjective,
    negatedForMin,
  };
}
