import { LPProblem } from "../../types/lp";

export interface LPExample {
  name: string;
  difficulty: "beginner" | "intermediate" | "difficult";
  description: string;
  problem: LPProblem;
}

export const lpExamples: LPExample[] = [
  {
    name: "Furniture factory (classic <=)",
    difficulty: "beginner",
    description: "Maximize profit from two products under labor and material limits — every constraint is ≤, so no artificial variables are needed.",
    problem: {
      sense: "max",
      objective: [3, 5],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 0], relation: "<=", rhs: 4, label: "x1 ≤ 4" },
        { coeffs: [0, 2], relation: "<=", rhs: 12, label: "2x2 ≤ 12" },
        { coeffs: [3, 2], relation: "<=", rhs: 18, label: "3x1 + 2x2 ≤ 18" },
      ],
    },
  },
  {
    name: "Diet problem (>= constraints)",
    difficulty: "intermediate",
    description: "Minimize cost while meeting minimum nutrient requirements — needs surplus + artificial variables and the two-phase method.",
    problem: {
      sense: "min",
      objective: [2, 3],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 1], relation: ">=", rhs: 10, label: "x1 + x2 ≥ 10" },
        { coeffs: [2, 1], relation: ">=", rhs: 12, label: "2x1 + x2 ≥ 12" },
      ],
    },
  },
  {
    name: "Mixed constraints with equality",
    difficulty: "difficult",
    description: "A production-mix problem combining ≤, ≥ and = constraints, exercising the full two-phase artificial-variable machinery.",
    problem: {
      sense: "max",
      objective: [5, 4],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [6, 4], relation: "<=", rhs: 24, label: "6x1 + 4x2 ≤ 24" },
        { coeffs: [1, 2], relation: "<=", rhs: 6, label: "x1 + 2x2 ≤ 6" },
        { coeffs: [1, 0], relation: ">=", rhs: 1, label: "x1 ≥ 1" },
        { coeffs: [1, 1], relation: "=", rhs: 4, label: "x1 + x2 = 4" },
      ],
    },
  },
  {
    name: "Unbounded example",
    difficulty: "intermediate",
    description: "A textbook unbounded LP — the feasible region extends forever in a direction that keeps improving the objective.",
    problem: {
      sense: "max",
      objective: [1, 1],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, -1], relation: "<=", rhs: 1, label: "x1 − x2 ≤ 1" },
        { coeffs: [-1, 1], relation: "<=", rhs: 2, label: "−x1 + x2 ≤ 2" },
      ],
    },
  },
  {
    name: "Infeasible example",
    difficulty: "intermediate",
    description: "Two constraints that directly contradict each other — no point can satisfy both.",
    problem: {
      sense: "max",
      objective: [2, 3],
      variables: ["x1", "x2"],
      constraints: [
        { coeffs: [1, 1], relation: "<=", rhs: 4, label: "x1 + x2 ≤ 4" },
        { coeffs: [1, 1], relation: ">=", rhs: 10, label: "x1 + x2 ≥ 10" },
      ],
    },
  },
];
