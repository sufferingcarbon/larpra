/**
 * Types for the Queuing Models module: M/M/1 (single server) and M/M/c
 * (multi-server) queues with Poisson arrivals and exponential service times.
 *
 * Unlike the tableau/search modules (simplex, Hungarian, branch & bound),
 * a queuing model has no iterative search to trace — every quantity is a
 * closed-form function of λ, μ (and c). So "steps" here are the sequence of
 * formulas actually evaluated, in the order a textbook derivation would use
 * them (stability check → P0 → Erlang C/Lq → Little's-Law chain →
 * distribution), each one a literal snapshot of the running metrics object
 * with only the fields computed so far filled in. Same philosophy as every
 * other module: the UI never invents a number the solver didn't compute.
 */

export type QueuingModelType = "mm1" | "mmc";

export interface MM1Input {
  lambda: number; // mean arrival rate (customers per unit time)
  mu: number; // mean service rate per server (customers per unit time)
  /** How many states (n = 0..maxN) to show in the steady-state distribution. */
  maxN: number;
}

export interface MMcInput {
  lambda: number;
  mu: number;
  /** Number of parallel, identical servers (c). */
  servers: number;
  maxN: number;
}

export type QueuingProblem = { model: "mm1"; params: MM1Input } | { model: "mmc"; params: MMcInput };

/** Every metric that can appear on the running panel, as display strings. Null = not computed yet (or n/a for this model). */
export interface QueuingMetricsPartial {
  /** Offered load a = λ/μ, in erlangs. Shown for both models; it's the quantity ρ is built from. */
  offeredLoad: string | null;
  /** Utilization: ρ = λ/μ for M/M/1, ρ = a/c for M/M/c. Requires ρ < 1 for a steady state to exist. */
  rho: string | null;
  /** P(system empty). */
  p0: string | null;
  /** M/M/c only: Erlang C, the probability an arriving customer finds every server busy and must wait. */
  probWait: string | null;
  /** M/M/c only, informational: Erlang B, the blocking probability in the companion loss system (no waiting room, c servers, arrivals blocked and lost when all are busy). */
  erlangB: string | null;
  Lq: string | null; // expected number waiting in queue
  L: string | null; // expected number in the system (queue + in service)
  Wq: string | null; // expected time waiting in queue
  W: string | null; // expected time in the system
}

export interface QueuingDistributionRow {
  n: number;
  pn: string; // P(N = n)
  cumulative: string; // P(N <= n)
}

export type QueuingPhase = "setup" | "stability" | "core" | "littles-law" | "distribution" | "done";

/**
 * One genuine computational snapshot. `metrics` accumulates left-to-right through the
 * derivation — earlier steps leave later fields null — so the UI's running panel fills in
 * exactly the way the underlying math was actually evaluated.
 */
export interface QueuingState {
  phase: QueuingPhase;
  stepKind: string;
  model: QueuingModelType;
  lambda: string;
  mu: string;
  servers: number | null; // null for mm1
  metrics: QueuingMetricsPartial;
  /** Filled in once the distribution step runs; null before that. */
  distribution: QueuingDistributionRow[] | null;
  /** Which metric this step just computed, so the view can highlight it. */
  justComputed: string | null;
}

export type QueuingStatus = "optimal" | "invalid" | "unstable";

export interface QueuingResult {
  status: QueuingStatus;
  steps: import("./lp").AlgorithmStep<QueuingState>[];
  metrics?: QueuingMetricsPartial;
  distribution?: QueuingDistributionRow[];
  notes: string[];
}
