import type { AlgorithmStep } from "./lp";

/**
 * Types for the Matrix / Linear Equations module.
 *
 * Every entry of every matrix is an exact fraction, and every row operation is one step. As in every other
 * module, the solver produces the steps and the UI only renders them: each MatrixState below is a literal
 * snapshot of what the algorithm knew at that moment.
 *
 * Eigenvalues are the one place exactness has limits (most eigenvalues are irrational or complex), so those
 * are reported with an explicit `exact` flag — larpra never presents a decimal approximation as exact.
 */

export type MatrixOperation = "gaussian" | "determinant" | "inverse" | "rank" | "eigen";

export const MATRIX_OPERATIONS: readonly MatrixOperation[] = ["gaussian", "determinant", "inverse", "rank", "eigen"];

export interface MatrixInput {
  operation: MatrixOperation;
  /** The coefficient matrix A, rows × cols, as typed (decimals allowed; converted to exact fractions). */
  matrix: number[][];
  /** Right-hand side b for `gaussian` (one entry per row). Ignored by every other operation. */
  rhs?: number[];
}

/** One row operation, in textbook notation. */
export type RowOp =
  | { kind: "swap"; i: number; j: number }
  | { kind: "scale"; i: number; factor: string }
  | { kind: "eliminate"; target: number; source: number; multiplier: string };

export type MatrixPhase =
  | "setup"
  | "forward"
  | "backward"
  | "solution"
  | "cofactor"
  | "determinant"
  | "inverse"
  | "rank"
  | "nullspace"
  | "polynomial"
  | "eigenvalues"
  | "eigenvectors"
  | "summary";

/** A rectangular grid of exact values, as display strings (never rounded). */
export type Grid = string[][];

/** What the tableau view highlights at this step. */
export interface TableauHighlight {
  pivotRow: number | null;
  pivotCol: number | null;
  /** Rows touched by the operation just applied. */
  changedRows: number[];
  /** Cells that were just made zero by an elimination. */
  zeroedCells: [number, number][];
}

/** The current tableau: left block (A, or the working copy of A) and right block (b, or I / A⁻¹). */
export interface TableauInfo {
  left: Grid;
  /** The augmented right-hand block; null when there is none (rank, plain elimination without b). */
  right: Grid | null;
  rightLabel: "b" | "I" | "A⁻¹" | null;
  /** Column labels for the left block, e.g. ["x1", "x2", "x3"]. */
  colLabels: string[];
  highlight: TableauHighlight;
  /** The row operation applied to reach this tableau (null on the starting tableau). */
  op: RowOp | null;
  /** The operation in plain text, e.g. "R2 ← R2 − 2·R1". */
  opText: string | null;
}

/** One node of the cofactor-expansion tree. */
export interface CofactorNode {
  /** The submatrix whose determinant this node computes (display strings). */
  matrix: Grid;
  /** Its determinant, exact. */
  value: string;
  /** How it was computed: closed form for 1×1 / 2×2 / 3×3 at the top, else expansion along row 1. */
  method: "1x1" | "2x2" | "3x3-closed-form" | "expansion";
  /** The formula with numbers substituted, e.g. "a·d − b·c = 2·5 − 3·1". */
  formula: string;
  /** For `expansion` nodes: one child per non-zero first-row entry, in column order. */
  terms: CofactorTerm[];
}

export interface CofactorTerm {
  col: number; // 0-based column j in row 1
  entry: string; // a₁ⱼ
  sign: "+" | "−"; // (−1)^(1+j)
  minor: CofactorNode; // the (1,j) minor's determinant
  /** a₁ⱼ · Cⱼ, exact. */
  contribution: string;
}

export interface DeterminantInfo {
  root: CofactorNode;
  /** Which term of the top-level expansion this step is about (null = the whole tree / final value). */
  focusTerm: number | null;
  value: string | null;
  invertible: boolean | null;
}

export interface PivotSummary {
  pivotCols: number[];
  freeCols: number[];
  rank: number;
  nullity: number;
}

export interface NullspaceInfo {
  freeCols: number[];
  /** One basis vector per free column, each a length-n list of exact strings. */
  basis: string[][];
  /** The parametric solution to Ax = 0, one line per variable, e.g. "x1 = −2·t1 + 1·t2". */
  parametric: string[];
  colLabels: string[];
}

export type SolutionKind = "unique" | "none" | "many";

export interface SolutionInfo {
  kind: SolutionKind;
  /** Unique solution, exact (length n); null otherwise. */
  x: string[] | null;
  /** For `many`: a particular solution (free variables = 0) and the nullspace basis. */
  particular: string[] | null;
  basis: string[][] | null;
  parametric: string[] | null;
  /** For `none`: the row that reads 0 = c with c ≠ 0, as text. */
  contradiction: string | null;
  colLabels: string[];
}

export interface InverseInfo {
  original: Grid;
  inverse: Grid | null;
  /** A · A⁻¹, computed exactly (should be the identity). */
  product: Grid | null;
  verified: boolean | null;
}

/** A polynomial in λ with exact rational coefficients, highest degree first: [1, −5, 6] = λ² − 5λ + 6. */
export interface PolynomialInfo {
  /** Coefficients as exact strings, highest degree first. */
  coefficients: string[];
  /** The polynomial in plain text, e.g. "λ² − 5λ + 6". */
  text: string;
  degree: number;
}

export type EigenvalueKind = "rational" | "quadratic-real" | "quadratic-complex" | "numeric-real" | "numeric-complex";

export interface EigenvalueEntry {
  /** Display of the eigenvalue: exact ("3", "1/2", "1 + √2") when `exact`, else a decimal (labeled approximate). */
  text: string;
  kind: EigenvalueKind;
  exact: boolean;
  /** Algebraic multiplicity. */
  multiplicity: number;
  /** Real and imaginary parts as JS numbers, for display/verification only. */
  re: number;
  im: number;
}

export interface EigenvectorEntry {
  /** Index into `eigenvalues`. */
  eigenvalueIndex: number;
  exact: boolean;
  /** A basis for the eigenspace (one vector per free variable); each entry a display string. */
  basis: string[][];
  /** Geometric multiplicity (dimension of the eigenspace) when exact; null when only approximate. */
  geometricMultiplicity: number | null;
}

export interface EigenInfo {
  polynomial: PolynomialInfo | null;
  /** How the roots were found, one line each, in order (rational roots, deflation, quadratic formula, numeric). */
  rootMethod: string[];
  eigenvalues: EigenvalueEntry[];
  eigenvectors: EigenvectorEntry[];
  /** Index of the eigenvalue currently being worked on (null outside the per-eigenvalue steps). */
  focus: number | null;
  /** The matrix A − λI for the focused eigenvalue when it is exact; null otherwise. */
  shifted: Grid | null;
}

export interface MatrixState {
  phase: MatrixPhase;
  stepKind: string;
  operation: MatrixOperation;
  /** The matrix as entered (display strings) — always shown for context. */
  a: Grid;
  b: string[] | null;
  tableau: TableauInfo | null;
  pivots: PivotSummary | null;
  solution: SolutionInfo | null;
  determinant: DeterminantInfo | null;
  inverse: InverseInfo | null;
  nullspace: NullspaceInfo | null;
  eigen: EigenInfo | null;
}

export type MatrixStatus = "solved" | "invalid";

/** The final answers, whichever operation was chosen (only the relevant one is set). */
export interface MatrixAnswer {
  solution?: SolutionInfo;
  determinant?: string;
  inverse?: { inverse: Grid | null; singular: boolean };
  rank?: { rank: number; nullity: number; pivotCols: number[]; freeCols: number[]; nullspaceBasis: string[][] };
  eigen?: { polynomial: string; eigenvalues: EigenvalueEntry[]; eigenvectors: EigenvectorEntry[] };
}

export interface MatrixResult {
  status: MatrixStatus;
  operation: MatrixOperation;
  steps: AlgorithmStep<MatrixState>[];
  answer: MatrixAnswer;
  notes: string[];
}
