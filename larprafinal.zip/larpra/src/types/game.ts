import type { AlgorithmStep, LPProblem } from "./lp";

/**
 * Types for the Game Theory module: finite two-player games in normal (strategic) form.
 *
 * The row player (Player 1) picks a row, the column player (Player 2) picks a column, and the chosen
 * cell (i, j) pays payoffA[i][j] to the row player and payoffB[i][j] to the column player. Each player
 * maximizes their own payoff. A zero-sum game is the special case payoffB = −payoffA.
 *
 * As in every other module, the solver produces the steps and the UI only renders them: each
 * GameState below is a literal snapshot of what the algorithm knew at that moment.
 */

export interface GameInput {
  rowNames: string[]; // Player 1's pure strategies
  colNames: string[]; // Player 2's pure strategies
  /** Player 1 (row player) payoff for every (row, column) cell. */
  payoffA: number[][];
  /** Player 2 (column player) payoff for every cell. When zeroSum is true this must equal −payoffA. */
  payoffB: number[][];
  zeroSum: boolean;
}

export type GamePhase = "setup" | "best-response" | "pure" | "dominance" | "zero-sum" | "supports" | "summary";

/** One Nash equilibrium (a pair of mixed strategies), with every number exact. */
export interface Equilibrium {
  kind: "pure" | "mixed";
  /** Player 1's probabilities, exact ("1/3", "0", "1"), one per row. */
  p: string[];
  /** Player 2's probabilities, exact, one per column. */
  q: string[];
  /** The same probabilities as JS numbers, for drawing bars only. */
  pNum: number[];
  qNum: number[];
  /** Expected payoffs at the equilibrium (exact display). */
  payoffA: string;
  payoffB: string;
  /** Indices of the rows / columns played with positive probability. */
  supportRows: number[];
  supportCols: number[];
}

export type SupportOutcome =
  | "equilibrium"
  | "no-solution-q" // the indifference equations for Player 2's mix have no solution
  | "non-unique-q" // ...or infinitely many (a degenerate situation)
  | "nonpositive-q" // solved, but some probability is ≤ 0
  | "no-solution-p"
  | "non-unique-p"
  | "nonpositive-p"
  | "row-deviation" // a row outside the support would pay strictly more
  | "col-deviation";

/** One (row support, column support) pair tried by support enumeration. */
export interface SupportAttempt {
  rows: number[];
  cols: number[];
  outcome: SupportOutcome;
  /** One line saying what happened, with the numbers involved. */
  detail: string;
  /** The indifference equations that were solved (empty when the attempt stopped before any were written). */
  equations: string[];
}

export interface SupportEnumInfo {
  /** Current support size k being enumerated (null for the overview step). */
  size: number | null;
  /** Number of support pairs of size k (and in total over all sizes). */
  pairsThisSize: number;
  pairsTotal: number;
  attempts: SupportAttempt[];
  /** Attempts of this size broken down by outcome. */
  tally: Partial<Record<SupportOutcome, number>>;
}

export interface DegeneracyInfo {
  degenerate: boolean;
  /** When degenerate: one concrete witness, e.g. "Player 1's strategy with support {Up} has 2 best responses…". */
  witness: string | null;
}

export interface DominanceElimination {
  player: 1 | 2;
  index: number;
  /** The remaining strategy (same player) that strictly dominates it. */
  by: number;
}

export interface DominanceInfo {
  /** Whole-game dominance summary (only set on the first dominance step). */
  dominantRow: { index: number; kind: "strict" | "weak" } | null;
  dominantCol: { index: number; kind: "strict" | "weak" } | null;
  /** Elimination round number (1-based) — null on the dominant-strategy summary step. */
  round: number | null;
  eliminations: DominanceElimination[];
}

export interface ZeroSumInfo {
  rowMins: string[]; // for each row: its worst-case payoff
  colMaxs: string[]; // for each column: the row player's best payoff against it
  maximin: string;
  minimax: string;
  maximinRows: number[];
  minimaxCols: number[];
  /** Cells that are both a row minimum and a column maximum (pure saddle points). */
  saddleCells: [number, number][];
  /** The constant added to every payoff so the LPs' coefficients are positive (null before that step). */
  shift: string | null;
  /** The two LPs, ready for the simplex viewer to replay (null before those steps). */
  rowLP: LPProblem | null;
  colLP: LPProblem | null;
  /** Σy (row LP optimum) and Σz (column LP optimum) — equal by LP duality. */
  rowLPObjective: string | null;
  colLPObjective: string | null;
  value: string | null;
  p: string[] | null;
  q: string[] | null;
}

export interface GameState {
  phase: GamePhase;
  stepKind: string;
  rowNames: string[];
  colNames: string[];
  a: string[][]; // Player 1's payoffs, display strings
  b: string[][]; // Player 2's payoffs
  zeroSum: boolean;
  /** rowBR[i][j]: row i is a best response of Player 1 to column j. null until that step. */
  rowBR: boolean[][] | null;
  /** colBR[i][j]: column j is a best response of Player 2 to row i. */
  colBR: boolean[][] | null;
  /** Cells drawn as equilibria (pure equilibria in the pure step, saddle cells in the zero-sum step). */
  highlightCells: [number, number][];
  /** Cumulative dominance eliminations so far. */
  eliminatedRows: number[];
  eliminatedCols: number[];
  dominance: DominanceInfo | null;
  zeroSumInfo: ZeroSumInfo | null;
  degeneracy: DegeneracyInfo | null;
  supports: SupportEnumInfo | null;
  /** Every equilibrium found up to this step. */
  equilibria: Equilibrium[];
}

export type GameStatus = "solved" | "invalid";

export interface GameResult {
  status: GameStatus;
  steps: AlgorithmStep<GameState>[];
  equilibria: Equilibrium[];
  degeneracy?: DegeneracyInfo;
  /** Zero-sum games only: the value of the game (Player 1's equilibrium payoff). */
  value?: string;
  notes: string[];
}
