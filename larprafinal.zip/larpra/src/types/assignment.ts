/**
 * Types for the Assignment Problem module (Hungarian Algorithm).
 *
 * Same philosophy as types/transportation.ts: one flexible tableau-state
 * interface carries every field any phase of the algorithm (padding, row/col
 * reduction, zero-covering, augmenting-path matching) might need. Fields
 * that don't apply to a given step are left null. The UI never invents a
 * step — every AlgorithmStep here is a literal snapshot of the algorithm's
 * working state.
 */

export interface AssignmentProblemInput {
  workerNames: string[];
  taskNames: string[];
  /** costs[i][j] = cost of assigning worker i to task j. */
  costs: number[][];
}

/** A single cell reference into the cost matrix. */
export interface Cell {
  row: number;
  col: number;
}

export type AssignmentPhase = "balance" | "reduction" | "matching";

/**
 * One genuine computational snapshot of the Hungarian tableau. `phase` and
 * `stepKind` say which kind of step this is so the UI can render the right
 * emphasis (square-padding note, a reduction table, a covering diagram, or
 * an augmenting-path search).
 */
export interface AssignmentTableauState {
  phase: AssignmentPhase;
  stepKind: string;

  workerNames: string[];
  taskNames: string[];

  /** Fixed for the whole run: display strings of the (possibly dummy-padded) original cost matrix. */
  originalCosts: string[][];
  /** Current working matrix, mutated by row/col reduction and by each covering adjustment. */
  costs: string[][];

  /** Amount subtracted from each row during row reduction. Null before/after that single step. */
  rowReductions: (string | null)[] | null;
  /** Amount subtracted from each column during column reduction. Null before/after that single step. */
  colReductions: (string | null)[] | null;

  /** Rows/columns covered by the current minimum line cover (König's theorem marking). */
  coveredRows: boolean[] | null;
  coveredCols: boolean[] | null;
  /** Number of covered lines this step (== current matching size). */
  lineCount: number | null;

  /** matching[i] = j if worker i is currently matched to task j via a zero cell, else null. */
  matching: (number | null)[];
  /** Which row the current augmenting-path attempt is starting from. */
  currentRow: number | null;
  /** Columns visited so far during the current augmenting-path search. */
  visitedCols: boolean[] | null;
  /** The augmenting path used by the current step (alternating worker/task cells), if one was found. */
  augmentingPath: Cell[] | null;

  /** The smallest uncovered value found during an adjustment step. */
  uncoveredMin: string | null;

  /** Total cost (in original, unreduced terms) of whichever pairs are matched as of this step. */
  currentCost: string;
  isOptimal: boolean;

  dummyNote: string | null;
}

export type AssignmentStatus = "optimal" | "invalid";

export interface AssignmentResult {
  status: AssignmentStatus;
  steps: import("./lp").AlgorithmStep<AssignmentTableauState>[];
  totalCost?: number;
  /** assignment[workerName] = taskName, omitting any pairing that involves a dummy row/column. */
  assignment?: Record<string, string>;
  notes: string[];
  workerNames: string[];
  taskNames: string[];
}
