/**
 * Types for the Network & Routing module: Shortest Path (Dijkstra),
 * Minimum Spanning Tree (Kruskal / Prim), and Maximum Flow
 * (Ford-Fulkerson via Edmonds-Karp BFS augmenting paths).
 *
 * Same philosophy as types/assignment.ts and types/transportation.ts: a
 * flexible per-step state carries every field that phase of the algorithm
 * might need, fields that don't apply are null, and the UI never invents a
 * step — every AlgorithmStep here is a literal snapshot of real working
 * state.
 */

export interface NetworkEdgeInput {
  from: string;
  to: string;
  /** Distance (shortest path), weight (MST), or capacity (max flow) — meaning depends on which algorithm consumes it. */
  weight: number;
}

export interface GraphInput {
  nodes: string[];
  edges: NetworkEdgeInput[];
  directed: boolean;
}

/* ---------------------------- Shortest Path (Dijkstra) ---------------------------- */

export interface ShortestPathInput {
  graph: GraphInput;
  source: string;
}

export interface ShortestPathNodeRow {
  node: string;
  distance: string | null; // null = infinity (not yet reached)
  predecessor: string | null;
  visited: boolean;
}

export type ShortestPathPhase = "init" | "select" | "relax" | "done";

export interface ShortestPathState {
  phase: ShortestPathPhase;
  stepKind: string;
  nodes: ShortestPathNodeRow[];
  /** Node whose outgoing edges are being relaxed this step. */
  currentNode: string | null;
  /** The specific edge being relaxed this step, if this is a relax step. */
  edgeConsidered: { from: string; to: string; weight: string } | null;
  /** Whether relaxing edgeConsidered actually improved a distance. */
  improved: boolean | null;
}

export type ShortestPathStatus = "optimal" | "invalid" | "negative-edge" | "unreachable";

export interface ShortestPathResult {
  status: ShortestPathStatus;
  steps: import("./lp").AlgorithmStep<ShortestPathState>[];
  distances?: Record<string, number | null>;
  predecessors?: Record<string, string | null>;
  notes: string[];
}

/* ---------------------------- Minimum Spanning Tree ---------------------------- */

export type MSTMethod = "kruskal" | "prim";

export interface MSTInput {
  graph: GraphInput;
  method: MSTMethod;
  /** Required for Prim (which node to grow the tree from); ignored for Kruskal. */
  startNode?: string;
}

export type MSTEdgeStatus = "unconsidered" | "accepted" | "rejected-cycle" | "candidate";

export interface MSTEdgeRow {
  from: string;
  to: string;
  weight: string;
  status: MSTEdgeStatus;
}

export type MSTPhase = "sort" | "consider" | "done";

export interface MSTState {
  phase: MSTPhase;
  stepKind: string;
  method: MSTMethod;
  edges: MSTEdgeRow[];
  /** Nodes currently connected to the growing tree (Prim) or already spanned (Kruskal, informational). */
  treeNodes: string[];
  totalWeight: string;
  currentEdge: { from: string; to: string; weight: string } | null;
  /** Kruskal only: which union-find component each node currently belongs to, for explaining cycle rejection. */
  componentOf: Record<string, number> | null;
}

export type MSTStatus = "optimal" | "invalid" | "disconnected";

export interface MSTResult {
  status: MSTStatus;
  steps: import("./lp").AlgorithmStep<MSTState>[];
  totalWeight?: number;
  treeEdges?: { from: string; to: string; weight: number }[];
  notes: string[];
}

/* ---------------------------- Maximum Flow ---------------------------- */

export interface MaxFlowInput {
  graph: GraphInput; // edges' weight = capacity; always treated as directed
  source: string;
  sink: string;
}

export interface MaxFlowEdgeRow {
  from: string;
  to: string;
  capacity: string;
  flow: string;
  residual: string;
}

export type MaxFlowPhase = "search" | "augment" | "done";

export interface MaxFlowState {
  phase: MaxFlowPhase;
  stepKind: string;
  edges: MaxFlowEdgeRow[];
  /** The augmenting path found this step, as a sequence of node names, or null if this step is a "no path found" step. */
  augmentingPath: string[] | null;
  bottleneck: string | null;
  totalFlow: string;
}

export type MaxFlowStatus = "optimal" | "invalid";

export interface MaxFlowResult {
  status: MaxFlowStatus;
  steps: import("./lp").AlgorithmStep<MaxFlowState>[];
  maxFlow?: number;
  notes: string[];
}
