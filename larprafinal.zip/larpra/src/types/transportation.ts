/**
 * Types for the Transportation Problem module.
 *
 * Follows the same philosophy as types/lp.ts: one flexible tableau-state
 * interface carries every field any step of any method (NW Corner, Least
 * Cost, VAM, MODI) might need. Fields that don't apply to a given step are
 * left null. The UI never invents a step — every AlgorithmStep here is a
 * literal snapshot of the algorithm's working state.
 */

export type InitialMethod = "northwest-corner" | "least-cost" | "vogel";

export interface TransportationProblemInput {
  sourceNames: string[];
  destNames: string[];
  /** costs[i][j] = cost of shipping one unit from source i to destination j. */
  costs: number[][];
  supply: number[];
  demand: number[];
}

/** A single cell reference into the cost/allocation grid. */
export interface Cell {
  row: number;
  col: number;
}

export interface LoopStep extends Cell {
  sign: "+" | "-";
}

/**
 * One genuine computational snapshot of the transportation tableau.
 * Used for balancing, NW Corner / Least Cost / VAM construction steps,
 * and MODI optimization steps alike — `phase` and `stepKind` say which
 * kind of step this is so the UI can render the right emphasis.
 */
export interface TransportationTableauState {
  phase: "balance" | "construction" | "modi";
  stepKind: string;

  sourceNames: string[];
  destNames: string[];
  /** Fixed for the whole run — display strings of the (possibly dummy-augmented) cost matrix. */
  costs: string[][];

  /** Original supply/demand as given (pre-balance), for reference display. Null before balancing runs. */
  originalSupply: string[] | null;
  originalDemand: string[] | null;

  /** Supply/demand still unallocated as of this step. */
  remainingSupply: string[];
  remainingDemand: string[];

  /** allocations[i][j] is the display string of the amount allocated, or null if the cell is non-basic. */
  allocations: (string | null)[][];
  /** Whether cell [i][j] is currently a basic cell (including epsilon-basic degenerate cells). */
  isBasic: boolean[][];
  /** Whether cell [i][j] is basic only via an infinitesimal epsilon inserted to break degeneracy. */
  isEpsilon: boolean[][];

  crossedRows: boolean[];
  crossedCols: boolean[];

  /** The cell this step is about (just allocated, just entering, etc). */
  selectedCell: Cell | null;

  /** VAM only: current penalty per row/column, or null where not computed/applicable this step. */
  rowPenalties: (string | null)[] | null;
  colPenalties: (string | null)[] | null;
  /** Which row/column penalty (if any) drove this step's selection. */
  highlightPenaltyRow: number | null;
  highlightPenaltyCol: number | null;

  /** Running cost of allocations made so far (construction) or of the current tableau (modi). */
  currentCost: string;

  basicCellCount: number;
  /** m + n - 1, the number of basic cells a non-degenerate BFS must have. */
  requiredBasicCells: number;

  dummyNote: string | null;
  degenerateNote: string | null;

  /** MODI only. */
  u: (string | null)[] | null;
  v: (string | null)[] | null;
  /** opportunityCosts[i][j] = cij - (ui+vj), only meaningful for non-basic cells. */
  opportunityCosts: (string | null)[][] | null;
  enteringCell: Cell | null;
  loopPath: LoopStep[] | null;
  theta: string | null;
  leavingCell: Cell | null;
  isOptimal: boolean;
}

export type TransportationStatus = "optimal" | "degenerate_optimal" | "invalid";

export interface TransportationResult {
  status: TransportationStatus;
  steps: import("./lp").AlgorithmStep<TransportationTableauState>[];
  totalCost?: number;
  /** allocation[sourceName][destName] = units shipped, omitting zero and dummy routes. */
  allocation?: Record<string, Record<string, number>>;
  notes: string[];
  sourceNames: string[];
  destNames: string[];
}
