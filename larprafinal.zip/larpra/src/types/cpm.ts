/**
 * Types for the CPM/PERT module (Critical Path Method / Program Evaluation
 * and Review Technique).
 *
 * Same philosophy as types/assignment.ts and types/transportation.ts: one
 * flexible activity-state array carries every field any phase of the
 * algorithm (forward pass, backward pass, slack, critical-path extraction)
 * might need. Fields that don't apply to a given step are left null. The
 * UI never invents a step — every AlgorithmStep here is a literal snapshot
 * of the algorithm's working state.
 */

export interface CPMActivityInput {
  name: string;
  /** Plain single-point duration (CPM mode). Omit when using 3-point PERT estimates instead. */
  duration?: number;
  /** Optimistic time (PERT mode). All three estimates must be given together. */
  optimistic?: number;
  mostLikely?: number;
  pessimistic?: number;
  /** Names of activities that must finish before this one can start. */
  predecessors: string[];
}

export interface CPMProblemInput {
  activities: CPMActivityInput[];
}

/**
 * "cpm"  — every activity has one deterministic `duration`.
 * "pert" — every activity has optimistic / mostLikely / pessimistic estimates; the
 *          expected duration (a + 4m + b) / 6 feeds the very same forward/backward pass.
 */
export type CPMMode = "cpm" | "pert";

export interface CPMOptions {
  /** Slack at or below this counts as zero (guards against floating-point noise). Default 1e-9. */
  tolerance?: number;
}

export type CPMPhase = "setup" | "forward" | "backward" | "slack" | "critical-path";

/** One activity's row in the network table, as of a given step. */
export interface CPMActivityRow {
  name: string;
  /** Duration used by the pass. In PERT mode this is the expected duration (a + 4m + b) / 6. */
  duration: string;
  /** The raw three-point estimates (PERT only). Null in plain-CPM mode. */
  estimates: { optimistic: string; mostLikely: string; pessimistic: string } | null;
  predecessors: string[];
  successors: string[];
  /** Expected-duration variance (PERT only), display string. Null in plain-CPM mode. */
  variance: string | null;
  es: string | null;
  ef: string | null;
  ls: string | null;
  lf: string | null;
  slack: string | null;
  isCritical: boolean | null;
}

/**
 * One genuine computational snapshot of the CPM/PERT network. `phase` and
 * `stepKind` say which kind of step this is so the UI can render the right
 * emphasis (topological-order note, a forward/backward pass row, a slack
 * table, or a discovered critical path).
 */
export interface CPMTableauState {
  phase: CPMPhase;
  stepKind: string;

  isPert: boolean;
  activities: CPMActivityRow[];
  topologicalOrder: string[] | null;

  /** Which activity this step's computation is for. Null for summary/setup steps. */
  currentActivity: string | null;

  projectDuration: string | null;
  /** Every activity name that has zero total slack, once slack has been computed. */
  criticalActivityNames: string[] | null;
  /** Every distinct source→sink chain of critical activities found so far. */
  criticalPaths: string[][] | null;
  /** The single path this step just discovered, if this step is a "critical-path-found" step. */
  currentPath: string[] | null;

  /**
   * Sum of activity variances along the critical path — PERT only. When several critical
   * paths tie, the LARGEST path variance is used (the conservative choice).
   */
  projectVariance: string | null;
  projectStdDev: string | null;
}

export type CPMStatus = "optimal" | "invalid";

/** Numeric (unrounded) schedule for one activity — the machine-readable twin of a CPMActivityRow. */
export interface CPMScheduleEntry {
  duration: number;
  variance: number | null;
  es: number;
  ef: number;
  ls: number;
  lf: number;
  slack: number;
  critical: boolean;
}

export interface CPMResult {
  status: CPMStatus;
  steps: import("./lp").AlgorithmStep<CPMTableauState>[];
  projectDuration?: number;
  /** Every source→sink chain of zero-slack activities whose hand-offs are all tight. */
  criticalPaths?: string[][];
  /** Numeric schedule keyed by activity name (unrounded — display strings live in the steps). */
  schedule?: Record<string, CPMScheduleEntry>;
  projectVariance?: number;
  projectStdDev?: number;
  /** Sum of variances along each critical path, aligned with `criticalPaths` (PERT only). */
  criticalPathVariances?: number[];
  isPert: boolean;
  notes: string[];
}
