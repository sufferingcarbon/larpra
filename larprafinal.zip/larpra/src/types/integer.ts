import { AlgorithmStep, LPProblem } from "./lp";

/** "binary" is an integer variable with the extra bound x ≤ 1; "continuous" is never branched on. */
export type VarType = "integer" | "binary" | "continuous";
export const VAR_TYPES: readonly VarType[] = ["integer", "binary", "continuous"];

export interface IPProblem extends LPProblem {
  /** One entry per variable. Absent (or a short array) means "general integer" for the missing entries. */
  varTypes?: VarType[];
}

export type NodeSelection = "depth-first" | "best-bound";
export type BranchingRule = "lowest-index" | "most-fractional";
export const NODE_SELECTIONS: readonly NodeSelection[] = ["depth-first", "best-bound"];
export const BRANCHING_RULES: readonly BranchingRule[] = ["lowest-index", "most-fractional"];

export interface IPOptions {
  /** Which open subproblem to solve next. */
  nodeSelection: NodeSelection;
  /** Which fractional variable to split on. */
  branching: BranchingRule;
  /**
   * When every variable with a non-zero objective coefficient is an integer variable with an integer
   * coefficient, Z can only take integer values, so a bound of 23.75 is really 23. Off by default so the
   * tree matches a textbook trace.
   */
  tightenIntegerObjective: boolean;
  /** Stop after this many subproblems have been visited. */
  nodeLimit: number;
}

export const DEFAULT_IP_OPTIONS: IPOptions = {
  nodeSelection: "depth-first",
  branching: "lowest-index",
  tightenIntegerObjective: false,
  nodeLimit: 1000,
};

export type IPStatus = "optimal" | "infeasible" | "unbounded" | "node_limit";

export type NodeStatus =
  | "open" // created, not visited yet (only ever seen at a stopped search)
  | "branched" // LP optimum has a fractional integer variable → split into two children
  | "integer" // LP optimum is integer-feasible → new incumbent (or, in a feasibility check, a witness point)
  | "infeasible" // LP has no feasible point
  | "pruned-bound" // LP solved, but its bound cannot beat the incumbent
  | "pruned-inherited" // skipped without solving: the parent's bound already cannot beat the incumbent
  | "unbounded"; // root LP unbounded

export interface BnBBranch {
  variable: string;
  direction: "<=" | ">=";
  bound: number;
  /** The fractional LP value of `variable` in the parent that this branch cuts off (exact). */
  fractionalValue: string;
}

export interface BnBNode {
  id: number;
  parentId: number | null;
  depth: number;
  /** "feasibility" nodes belong to the check run when the root relaxation is unbounded (objective replaced by 0). */
  purpose: "optimize" | "feasibility";
  branch: BnBBranch | null;
  /** Bounds in force at this node, one entry per variable (ub null = no upper bound). */
  lb: number[];
  ub: (number | null)[];
  status: NodeStatus;
  /** Parent's LP objective (the optimistic bound this node inherits); null for the root. */
  parentBound: string | null;
  lpStatus: "optimal" | "infeasible" | "unbounded" | "skipped" | null;
  lpValue: string | null;
  /** Exact LP optimum, in `problem.variables` order. */
  lpSolution: string[] | null;
  branchVariable: string | null;
  children: number[];
  /** 1-based order in which the node was visited; null while still open. */
  order: number | null;
  createdAtStep: number;
  resolvedAtStep: number | null;
}

export interface BnBCounters {
  lpSolved: number;
  branched: number;
  integerSolutions: number;
  prunedInfeasible: number;
  prunedBound: number;
  prunedInherited: number;
  open: number;
}

export interface BnBIncumbent {
  value: string;
  solution: string[];
  nodeId: number;
}

export interface BnBStepState {
  kind: "start" | "node" | "finish";
  nodeId: number | null;
  counters: BnBCounters;
  incumbent: BnBIncumbent | null;
  /** Best objective any still-open subproblem could reach (original sense); null when none is open. */
  bestBound: string | null;
}

export interface IPResult {
  status: IPStatus;
  steps: AlgorithmStep<BnBStepState>[];
  tree: BnBNode[];
  options: IPOptions;
  varTypes: VarType[];
  rootRelaxation: { status: "optimal" | "infeasible" | "unbounded"; value?: string; solution?: string[] };
  optimalValue?: number;
  optimalValueExact?: string;
  optimalSolution?: Record<string, number>;
  optimalSolutionExact?: Record<string, string>;
  incumbentNodeId?: number;
  /** status "unbounded": an integer-feasible point that proves the problem is not infeasible. */
  feasiblePoint?: Record<string, string>;
  /** status "node_limit": best objective still possible (original sense), and the gap to the incumbent if there is one. */
  bestBound?: string;
  notes: string[];
}
