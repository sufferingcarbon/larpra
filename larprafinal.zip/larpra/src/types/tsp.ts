/**
 * Types for the Traveling Salesman Problem module: Nearest Neighbor
 * (heuristic) and exact Branch and Bound.
 *
 * Same philosophy as the rest of the lab: every AlgorithmStep's state is a
 * literal, real snapshot of the algorithm's working state — no steps are
 * invented after the fact to make a nicer story.
 */

export interface TSPProblemInput {
  cities: string[];
  /** distances[i][j] = cost of traveling directly from cities[i] to cities[j]. Use Infinity for "no direct edge". */
  distances: number[][];
  symmetric: boolean;
  /** Optional plotting coordinates; falls back to a circular layout when omitted. */
  coordinates?: Record<string, { x: number; y: number }>;
}

/* ---------------------------- Nearest Neighbor ---------------------------- */

export type NNPhase = "start" | "select" | "done";

export interface NNCandidate {
  city: string;
  distance: string;
}

export interface NNState {
  phase: NNPhase;
  stepKind: string;
  tour: string[];
  remaining: string[];
  currentCity: string | null;
  /** Every remaining city considered this step, with its distance from currentCity — the one actually chosen is `selected`. */
  candidates: NNCandidate[] | null;
  selected: string | null;
  totalCost: string;
}

export type NNStatus = "optimal" | "invalid" | "no-tour";

export interface NNResult {
  status: NNStatus;
  steps: import("./lp").AlgorithmStep<NNState>[];
  tour?: string[];
  totalCost?: number;
  notes: string[];
}

/* ---------------------------- Exact Branch & Bound ---------------------------- */

export interface TSPChildSummary {
  partial: string[];
  cost: string;
  lowerBound: string;
  isComplete: boolean;
  pruned: boolean;
  pruneReason: string | null;
}

export type BnBPhase = "root" | "expand" | "done";

export interface BnBState {
  phase: BnBPhase;
  stepKind: string;
  currentNode: { partial: string[]; cost: string; lowerBound: string } | null;
  children: TSPChildSummary[];
  frontierSize: number;
  incumbentTour: string[] | null;
  incumbentCost: string | null;
  nodesExplored: number;
  nodesPruned: number;
}

export type BnBStatus = "optimal" | "invalid" | "infeasible";

export interface BnBResult {
  status: BnBStatus;
  steps: import("./lp").AlgorithmStep<BnBState>[];
  tour?: string[];
  totalCost?: number;
  notes: string[];
}
