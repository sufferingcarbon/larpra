export type ConstraintRelation = "<=" | ">=" | "=";
export type Sense = "max" | "min";

export interface LPConstraint {
  /** Coefficients on x1, x2, ... in the same order as LPProblem.variables. */
  coeffs: number[];
  relation: ConstraintRelation;
  rhs: number;
  label?: string;
}

export interface LPProblem {
  sense: Sense;
  /** Objective coefficients, one per decision variable. */
  objective: number[];
  variables: string[]; // e.g. ["x1", "x2"]
  constraints: LPConstraint[];
}

/**
 * A single genuine computational state produced by an algorithm.
 * The UI never invents explanatory text after the fact — every field here
 * is derived directly from the state the algorithm actually reached.
 */
export interface AlgorithmStep<TState = unknown> {
  title: string;
  explanation: string;
  state: TState;
  operation?: string;
  /** Optional deeper "why" explanation shown behind a Why? button. */
  why?: string;
}

export type SolutionStatus =
  | "optimal"
  | "infeasible"
  | "unbounded"
  | "alternate_optima"
  | "degenerate";

export interface SensitivityInfo {
  /** Shadow price per constraint label. null means "not computed for this constraint type yet". */
  shadowPrices: Record<string, string | null>;
  /** |Cj − Zj| for each variable at the optimal tableau (0 for basic variables). */
  reducedCosts: Record<string, string>;
}

export interface LPResult<TState = unknown> {
  status: SolutionStatus;
  steps: AlgorithmStep<TState>[];
  optimalValue?: number;
  optimalSolution?: Record<string, number>;
  notes: string[];
  sensitivity?: SensitivityInfo;
}
