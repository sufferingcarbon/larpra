import { useState } from "react";
import { Sidebar, ModuleId, modules } from "./components/Sidebar";
import { Dashboard } from "./components/Dashboard";
import { LinearProgramming } from "./pages/LinearProgramming";
import { Transportation } from "./pages/Transportation";
import { Assignment } from "./pages/Assignment";
import { Network } from "./pages/Network";
import { TSP } from "./pages/TSP";
import { CPM } from "./pages/CPM";
import { IntegerProgramming } from "./pages/IntegerProgramming";
import { Queuing } from "./pages/Queuing";
import { Game } from "./pages/Game";
import { Matrix } from "./pages/Matrix";
import { Help } from "./pages/Help";
import { ComingSoon } from "./pages/ComingSoon";

export default function App() {
  const [active, setActive] = useState<ModuleId>("dashboard");

  const renderPage = () => {
    switch (active) {
      case "dashboard":
        return <Dashboard onSelect={setActive} />;
      case "lp":
        return <LinearProgramming />;
      case "transportation":
        return <Transportation />;
      case "assignment":
        return <Assignment />;
      case "network":
        return <Network />;
      case "tsp":
        return <TSP />;
      case "cpm":
        return <CPM />;
      case "integer":
        return <IntegerProgramming />;
      case "queuing":
        return <Queuing />;
      case "game":
        return <Game />;
      case "matrix":
        return <Matrix />;
      case "help":
        return <Help />;
      default: {
        const def = modules.find((m) => m.id === active);
        return <ComingSoon moduleName={def?.label ?? "This module"} />;
      }
    }
  };

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      <Sidebar active={active} onSelect={setActive} />
      <main className="flex-1 overflow-y-auto">{renderPage()}</main>
    </div>
  );
}
