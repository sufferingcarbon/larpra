import { NNState, TSPProblemInput } from "../../types/tsp";
import { TSPMap } from "./TSPMap";

export function NNView({ problem, state }: { problem: TSPProblemInput; state: NNState }) {
  const nodeTones: Record<string, "default" | "start" | "current" | "visited"> = {};
  problem.cities.forEach((c) => {
    if (c === problem.cities[0]) nodeTones[c] = "start";
    if (state.tour.includes(c)) nodeTones[c] = "visited";
    if (state.currentCity === c) nodeTones[c] = "current";
  });

  return (
    <div className="space-y-3">
      <TSPMap cities={problem.cities} coordinates={problem.coordinates} path={state.tour} nodeTones={nodeTones} />
      <div className="flex flex-wrap items-center gap-3 text-xs">
        <span className="font-mono text-graphite">Tour so far: {state.tour.join(" → ")}</span>
        <span className="rounded-full bg-forest/10 px-2.5 py-1 font-medium text-forestDark">Cost so far: {state.totalCost}</span>
      </div>
      {state.candidates && (
        <div className="overflow-x-auto">
          <table className="ledger-table min-w-full">
            <thead>
              <tr>
                <th className="text-left">Candidate</th>
                <th>Distance from {state.currentCity}</th>
              </tr>
            </thead>
            <tbody>
              {state.candidates.map((c) => (
                <tr key={c.city} className={state.selected === c.city ? "bg-forest/10" : ""}>
                  <th className="text-left font-sans font-normal text-graphite">
                    {c.city} {state.selected === c.city && <span className="font-medium text-forestDark">(chosen)</span>}
                  </th>
                  <td className="text-center font-mono">{Number.isFinite(Number(c.distance)) ? c.distance : "∞"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
