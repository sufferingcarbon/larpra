import { useMemo } from "react";

export type TSPNodeTone = "default" | "start" | "current" | "visited";

interface Props {
  cities: string[];
  coordinates?: Record<string, { x: number; y: number }>;
  /** The primary path to draw as a solid highlighted line, in visiting order. */
  path?: string[] | null;
  /** A secondary path (e.g. the best-known/incumbent tour) drawn dashed and muted. */
  secondaryPath?: string[] | null;
  nodeTones?: Record<string, TSPNodeTone>;
}

const W = 480;
const H = 340;
const PAD = 40;

const TONE_COLORS: Record<TSPNodeTone, string> = {
  default: "#161B22",
  start: "#2F6B4F",
  current: "#B08A2E",
  visited: "#2F6B4F",
};

export function TSPMap({ cities, coordinates, path, secondaryPath, nodeTones }: Props) {
  const positions = useMemo(() => {
    const map = new Map<string, { x: number; y: number }>();
    if (coordinates && cities.every((c) => coordinates[c])) {
      const xs = cities.map((c) => coordinates[c].x);
      const ys = cities.map((c) => coordinates[c].y);
      const minX = Math.min(...xs);
      const maxX = Math.max(...xs);
      const minY = Math.min(...ys);
      const maxY = Math.max(...ys);
      const spanX = maxX - minX || 1;
      const spanY = maxY - minY || 1;
      cities.forEach((c) => {
        const nx = (coordinates[c].x - minX) / spanX;
        const ny = (coordinates[c].y - minY) / spanY;
        map.set(c, { x: PAD + nx * (W - 2 * PAD), y: H - PAD - ny * (H - 2 * PAD) });
      });
    } else {
      const n = Math.max(cities.length, 1);
      const cx = W / 2;
      const cy = H / 2 + 4;
      const r = Math.min(W, H) / 2 - PAD;
      cities.forEach((c, i) => {
        const angle = (2 * Math.PI * i) / n - Math.PI / 2;
        map.set(c, { x: cx + r * Math.cos(angle), y: cy + r * Math.sin(angle) });
      });
    }
    return map;
  }, [cities, coordinates]);

  const pathPoints = (p: string[] | null | undefined) =>
    (p ?? []).map((c) => positions.get(c)).filter((pt): pt is { x: number; y: number } => !!pt);

  const toLinePoints = (pts: { x: number; y: number }[]) => pts.map((p) => `${p.x},${p.y}`).join(" ");

  return (
    <div className="rounded border border-rule bg-white p-3">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full">
        {secondaryPath && secondaryPath.length > 1 && (
          <polyline
            points={toLinePoints(pathPoints(secondaryPath))}
            fill="none"
            stroke="#B08A2E"
            strokeWidth={1.5}
            strokeDasharray="5 4"
            opacity={0.7}
          />
        )}
        {path && path.length > 1 && (
          <polyline points={toLinePoints(pathPoints(path))} fill="none" stroke="#2F6B4F" strokeWidth={2.5} />
        )}
        {cities.map((c) => {
          const p = positions.get(c);
          if (!p) return null;
          const tone = nodeTones?.[c] ?? "default";
          return (
            <g key={c}>
              <circle cx={p.x} cy={p.y} r={14} fill={TONE_COLORS[tone]} stroke="white" strokeWidth={2} />
              <text x={p.x} y={p.y + 4} fontSize={11} textAnchor="middle" fontFamily="IBM Plex Mono" fill="white">
                {c}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
