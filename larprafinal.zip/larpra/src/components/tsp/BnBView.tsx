import { BnBState, TSPProblemInput } from "../../types/tsp";
import { TSPMap } from "./TSPMap";

export function BnBView({ problem, state }: { problem: TSPProblemInput; state: BnBState }) {
  const nodeTones: Record<string, "default" | "start" | "current" | "visited"> = {};
  problem.cities.forEach((c) => {
    if (c === problem.cities[0]) nodeTones[c] = "start";
  });
  state.currentNode?.partial.forEach((c) => {
    nodeTones[c] = "visited";
  });
  if (state.currentNode) {
    const last = state.currentNode.partial[state.currentNode.partial.length - 1];
    nodeTones[last] = "current";
  }

  return (
    <div className="space-y-3">
      <TSPMap
        cities={problem.cities}
        coordinates={problem.coordinates}
        path={state.currentNode?.partial ?? null}
        secondaryPath={state.incumbentTour}
        nodeTones={nodeTones}
      />
      <div className="flex flex-wrap items-center gap-3 text-xs">
        {state.currentNode && (
          <span className="font-mono text-graphite">
            Node: {state.currentNode.partial.join("→")}… (cost {state.currentNode.cost}, bound {state.currentNode.lowerBound})
          </span>
        )}
        <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">Frontier: {state.frontierSize}</span>
        <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">Explored: {state.nodesExplored}</span>
        <span className="rounded-full bg-sienna/10 px-2.5 py-1 font-medium text-sienna">Pruned: {state.nodesPruned}</span>
        {state.incumbentCost !== null && (
          <span className="rounded-full bg-forest/10 px-2.5 py-1 font-medium text-forestDark">Best known: {state.incumbentCost}</span>
        )}
      </div>
      {state.children.length > 0 && (
        <div className="overflow-x-auto">
          <table className="ledger-table min-w-full">
            <thead>
              <tr>
                <th className="text-left">Branch</th>
                <th>Cost</th>
                <th>Lower bound</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {state.children.map((c, i) => (
                <tr key={i}>
                  <th className="text-left font-sans font-normal text-graphite">{c.partial.join("→")}{!c.isComplete ? "…" : ""}</th>
                  <td className="text-center font-mono">{c.cost}</td>
                  <td className="text-center font-mono">{c.lowerBound}</td>
                  <td className="text-center">
                    {c.pruned && <span className="font-medium text-sienna">pruned</span>}
                    {!c.pruned && c.isComplete && <span className="font-medium text-forestDark">complete tour</span>}
                    {!c.pruned && !c.isComplete && <span className="text-graphite/60">added to frontier</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
