import { TSPProblemInput } from "../../types/tsp";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  problem: TSPProblemInput;
  onChange: (problem: TSPProblemInput) => void;
  errors: string[];
}

export function ProblemInput({ problem, onChange, errors }: Props) {
  const n = problem.cities.length;

  const addCity = () => {
    let idx = n + 1;
    let name = `City${idx}`;
    while (problem.cities.includes(name)) {
      idx += 1;
      name = `City${idx}`;
    }
    const distances = problem.distances.map((row) => [...row, 1]);
    distances.push(new Array(n + 1).fill(1));
    distances[n][n] = 0;
    onChange({ ...problem, cities: [...problem.cities, name], distances });
  };

  const removeCity = (i: number) => {
    const cities = problem.cities.filter((_, idx) => idx !== i);
    const distances = problem.distances.filter((_, r) => r !== i).map((row) => row.filter((_, c) => c !== i));
    onChange({ ...problem, cities, distances });
  };

  const renameCity = (i: number, name: string) => {
    onChange({ ...problem, cities: problem.cities.map((c, idx) => (idx === i ? name : c)) });
  };

  const setDistance = (i: number, j: number, value: number) => {
    const distances = problem.distances.map((row) => row.slice());
    distances[i][j] = value;
    if (problem.symmetric) distances[j][i] = value;
    onChange({ ...problem, distances });
  };

  const setSymmetric = (symmetric: boolean) => {
    let distances = problem.distances;
    if (symmetric) {
      // Mirror the upper triangle onto the lower triangle so the matrix becomes valid immediately.
      distances = problem.distances.map((row) => row.slice());
      for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) distances[j][i] = distances[i][j];
    }
    onChange({ ...problem, symmetric, distances });
  };

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <label className="flex items-center gap-2 text-sm text-graphite">
        <input type="checkbox" checked={problem.symmetric} onChange={(e) => setSymmetric(e.target.checked)} />
        Symmetric (distance A→B always equals B→A)
      </label>

      <div>
        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-graphite">Cities</h4>
        <div className="flex flex-wrap gap-2">
          {problem.cities.map((c, i) => (
            <div key={i} className="flex items-center gap-1 rounded border border-rule bg-white px-1.5 py-1">
              <input
                className="focus-ring w-16 rounded border-0 bg-transparent px-1 text-center font-mono text-sm"
                value={c}
                onChange={(e) => renameCity(i, e.target.value)}
              />
              <button className="focus-ring text-graphite hover:text-sienna" onClick={() => removeCity(i)} aria-label="Remove city">
                <Trash2 size={12} />
              </button>
            </div>
          ))}
          <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addCity}>
            <Plus size={14} /> Add city
          </button>
        </div>
      </div>

      <div>
        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-graphite">Distance matrix</h4>
        <div className="overflow-x-auto">
          <table className="ledger-table min-w-full">
            <thead>
              <tr>
                <th></th>
                {problem.cities.map((c) => (
                  <th key={c} className="font-mono">
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {problem.cities.map((rowCity, i) => (
                <tr key={rowCity}>
                  <th className="text-left font-mono">{rowCity}</th>
                  {problem.cities.map((_, j) => (
                    <td key={j} className="text-center">
                      {i === j ? (
                        <span className="text-graphite/40">—</span>
                      ) : (
                        <input
                          type="number"
                          className="focus-ring w-16 rounded border border-rule px-1 py-1 text-right"
                          value={Number.isFinite(problem.distances[i]?.[j]) ? problem.distances[i][j] : ""}
                          placeholder="∞"
                          onChange={(e) => setDistance(i, j, e.target.value === "" ? Infinity : Number(e.target.value))}
                        />
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-1 text-xs text-graphite/70">Leave a cell blank for "no direct route" (∞).</p>
      </div>
    </div>
  );
}
