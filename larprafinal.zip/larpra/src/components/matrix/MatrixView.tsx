import { CofactorNode, Grid, MatrixState } from "../../types/matrix";

/**
 * Renders whichever part of a MatrixState is populated for the current step. Every module (linalg, determinant,
 * inverse, rank, eigenvalues) fills in only the fields relevant to it, so this component is a set of independent
 * panels gated on those fields — never a single monolithic switch on `operation`, since a gaussian solve's steps
 * also pass through `tableau` and `solution` in sequence while an eigen solve moves through `eigen` alone.
 */
export function MatrixView({ state }: { state: MatrixState }) {
  return (
    <div className="space-y-4" data-testid="matrix-view">
      {state.tableau && <TableauGrid state={state} />}
      {state.pivots && !state.tableau?.op && <PivotSummary state={state} />}
      {state.solution && <SolutionPanel state={state} />}
      {state.determinant && <DeterminantPanel state={state} />}
      {state.inverse && <InversePanel state={state} />}
      {state.nullspace && <NullspacePanel state={state} />}
      {state.eigen && <EigenPanel state={state} />}
    </div>
  );
}

/* ---------------- shared grid rendering ---------------- */

function GridTable({
  grid,
  colLabels,
  rightGrid,
  rightLabel,
  highlightRow,
  highlightCol,
  changedRows,
  zeroedCells,
}: {
  grid: Grid;
  colLabels?: string[];
  rightGrid?: Grid | null;
  rightLabel?: string | null;
  highlightRow?: number | null;
  highlightCol?: number | null;
  changedRows?: number[];
  zeroedCells?: [number, number][];
}) {
  const isZeroed = (i: number, j: number) => (zeroedCells ?? []).some(([ri, rj]) => ri === i && rj === j);
  const isChanged = (i: number) => (changedRows ?? []).includes(i);
  return (
    <div className="overflow-x-auto">
      <table className="ledger-table font-mono">
        {colLabels && (
          <thead>
            <tr>
              <th></th>
              {colLabels.map((c, j) => (
                <th key={j} className={j === highlightCol ? "text-forestDark" : ""}>
                  {c}
                </th>
              ))}
              {rightGrid && <th className="border-l-2 border-rule text-forestDark">{rightLabel}</th>}
            </tr>
          </thead>
        )}
        <tbody>
          {grid.map((row, i) => (
            <tr key={i} className={i === highlightRow ? "bg-forest/10" : isChanged(i) ? "bg-gold/10" : ""}>
              <th className="text-left text-graphite">R{i + 1}</th>
              {row.map((val, j) => (
                <td key={j} className={`text-right ${i === highlightRow && j === highlightCol ? "font-bold text-forestDark ring-2 ring-forest" : isZeroed(i, j) ? "font-semibold text-sienna" : ""}`}>
                  {val}
                </td>
              ))}
              {rightGrid && (
                <>
                  {rightGrid[i].map((val, j) => (
                    <td key={`r${j}`} className={`border-l-2 border-rule text-right ${isZeroed(i, j) ? "font-semibold text-sienna" : ""}`}>
                      {val}
                    </td>
                  ))}
                </>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------------- tableau (linalg / inverse / rank shared view) ---------------- */

function TableauGrid({ state }: { state: MatrixState }) {
  const t = state.tableau!;
  return (
    <div className="rounded border border-rule bg-white p-3" data-testid="tableau">
      {t.opText && (
        <div className="mb-2 inline-block rounded bg-gold/15 px-2 py-1 font-mono text-xs font-medium text-ink">{t.opText}</div>
      )}
      <GridTable
        grid={t.left}
        colLabels={t.colLabels}
        rightGrid={t.right}
        rightLabel={t.rightLabel}
        highlightRow={t.highlight.pivotRow}
        highlightCol={t.highlight.pivotCol}
        changedRows={t.highlight.changedRows}
        zeroedCells={t.highlight.zeroedCells}
      />
    </div>
  );
}

function PivotSummary({ state }: { state: MatrixState }) {
  const p = state.pivots!;
  return (
    <div className="flex flex-wrap gap-4 rounded border border-rule bg-ledger/40 px-3 py-2 text-xs text-graphite">
      <span>
        rank = <span className="font-mono font-semibold text-ink">{p.rank}</span>
      </span>
      <span>
        nullity = <span className="font-mono font-semibold text-ink">{p.nullity}</span>
      </span>
      <span>
        pivot columns = <span className="font-mono text-ink">{p.pivotCols.map((c) => c + 1).join(", ") || "—"}</span>
      </span>
      <span>
        free columns = <span className="font-mono text-ink">{p.freeCols.map((c) => c + 1).join(", ") || "—"}</span>
      </span>
    </div>
  );
}

/* ---------------- Ax = b solution ---------------- */

function SolutionPanel({ state }: { state: MatrixState }) {
  const s = state.solution!;
  if (s.kind === "none") {
    return (
      <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
        No solution — the system is inconsistent: <span className="font-mono">{s.contradiction}</span>.
      </div>
    );
  }
  if (s.kind === "unique") {
    return (
      <div className="rounded border border-forest/40 bg-forest/10 px-3 py-2 text-sm text-forestDark">
        <div className="font-medium">Unique solution</div>
        <div className="mt-1 font-mono text-ink">{s.colLabels.map((l, i) => `${l} = ${s.x![i]}`).join(",  ")}</div>
      </div>
    );
  }
  return (
    <div className="rounded border border-gold/40 bg-gold/10 px-3 py-2 text-sm text-ink">
      <div className="font-medium text-graphite">Infinitely many solutions</div>
      <div className="mt-1 space-y-0.5 font-mono">
        {s.parametric!.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- determinant / cofactor tree ---------------- */

function DeterminantPanel({ state }: { state: MatrixState }) {
  const d = state.determinant!;
  return (
    <div className="space-y-3 rounded border border-rule bg-white p-3">
      <CofactorTree node={d.root} focusTerm={d.focusTerm} depth={0} />
      {d.value !== null && (
        <div className={`rounded px-3 py-2 text-sm font-medium ${d.invertible === false ? "bg-sienna/10 text-sienna" : "bg-forest/10 text-forestDark"}`}>
          det(A) = <span className="font-mono">{d.value}</span>
          {d.invertible !== null && <span className="ml-2 text-xs font-normal">{d.invertible ? "— invertible" : "— singular"}</span>}
        </div>
      )}
    </div>
  );
}

function CofactorTree({ node, focusTerm, depth }: { node: CofactorNode; focusTerm: number | null; depth: number }) {
  return (
    <div className={depth > 0 ? "ml-4 border-l-2 border-rule pl-3" : ""}>
      <GridTable grid={node.matrix} />
      <p className="mt-1 font-mono text-xs text-graphite">{node.formula}</p>
      {node.terms.length > 0 && (
        <div className="mt-2 space-y-2">
          {node.terms.map((term, i) => (
            <div key={i} className={`rounded p-1 ${i === focusTerm ? "bg-forest/10" : ""}`}>
              <div className="text-xs font-medium text-graphite">
                Term {i + 1}: a₁,{term.col + 1} = {term.entry}, cofactor C{term.col + 1} = {term.sign}
                {term.minor.value} → contributes <span className="font-mono text-ink">{term.contribution}</span>
              </div>
              <CofactorTree node={term.minor} focusTerm={null} depth={depth + 1} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- inverse ---------------- */

function InversePanel({ state }: { state: MatrixState }) {
  const inv = state.inverse!;
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <div className="rounded border border-rule bg-white p-3">
        <div className="mb-1 text-xs font-medium text-graphite">A</div>
        <GridTable grid={inv.original} />
      </div>
      <div className="rounded border border-rule bg-white p-3">
        <div className="mb-1 text-xs font-medium text-graphite">A⁻¹</div>
        {inv.inverse ? <GridTable grid={inv.inverse} /> : <div className="text-sm text-sienna">No inverse exists (A is singular).</div>}
      </div>
      {inv.product && (
        <div className="rounded border border-rule bg-white p-3 md:col-span-2">
          <div className="mb-1 text-xs font-medium text-graphite">A · A⁻¹ {inv.verified ? "= I (verified)" : "≠ I"}</div>
          <GridTable grid={inv.product} />
        </div>
      )}
    </div>
  );
}

/* ---------------- rank / nullspace ---------------- */

function NullspacePanel({ state }: { state: MatrixState }) {
  const ns = state.nullspace!;
  if (ns.freeCols.length === 0) {
    return <div className="rounded border border-forest/40 bg-forest/10 px-3 py-2 text-sm text-forestDark">Nullspace = {"{0}"} (no free variables).</div>;
  }
  return (
    <div className="rounded border border-gold/40 bg-gold/10 px-3 py-2 text-sm text-ink">
      <div className="font-medium text-graphite">
        Nullspace basis ({ns.basis.length} vector{ns.basis.length === 1 ? "" : "s"})
      </div>
      <div className="mt-1 flex flex-wrap gap-3 font-mono">
        {ns.basis.map((v, k) => (
          <span key={k}>
            v{k + 1} = ({v.join(", ")})
          </span>
        ))}
      </div>
      <div className="mt-2 space-y-0.5 font-mono">
        {ns.parametric.map((line, i) => (
          <div key={i}>{line}</div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- eigenvalues / eigenvectors ---------------- */

function EigenPanel({ state }: { state: MatrixState }) {
  const e = state.eigen!;
  return (
    <div className="space-y-3">
      {e.polynomial && <div className="rounded border border-rule bg-white px-3 py-2 font-mono text-sm text-ink">det(A − λI) = {e.polynomial.text} = 0</div>}
      {e.rootMethod.length > 0 && (
        <div className="rounded border border-rule bg-ledger/40 px-3 py-2 text-xs text-graphite">
          {e.rootMethod.map((m, i) => (
            <p key={i}>{m}</p>
          ))}
        </div>
      )}
      {e.eigenvalues.length > 0 && (
        <div className="overflow-x-auto">
          <table className="ledger-table font-mono text-sm">
            <thead>
              <tr>
                <th>λ</th>
                <th>algebraic mult.</th>
                <th>exact?</th>
                <th>geometric mult.</th>
                <th>eigenvector basis</th>
              </tr>
            </thead>
            <tbody>
              {e.eigenvalues.map((ev, i) => {
                const vec = e.eigenvectors.find((x) => x.eigenvalueIndex === i);
                const focused = e.focus === i;
                return (
                  <tr key={i} className={focused ? "bg-forest/10" : ""}>
                    <td className="text-center font-semibold text-ink">{ev.text}</td>
                    <td className="text-center">{ev.multiplicity}</td>
                    <td className="text-center">{ev.exact ? "yes" : "no (decimal)"}</td>
                    <td className="text-center">{vec?.geometricMultiplicity ?? "—"}</td>
                    <td className="text-left">{vec && vec.basis.length > 0 ? vec.basis.map((v, k) => <div key={k}>v = ({v.join(", ")})</div>) : vec ? "not computed exactly" : "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      {e.shifted && (
        <div className="rounded border border-rule bg-white p-3">
          <div className="mb-1 text-xs font-medium text-graphite">A − λI (λ = {e.eigenvalues[e.focus ?? 0]?.text})</div>
          <GridTable grid={e.shifted} />
        </div>
      )}
    </div>
  );
}
