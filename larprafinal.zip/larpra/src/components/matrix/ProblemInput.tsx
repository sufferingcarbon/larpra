import { MatrixInput, MatrixOperation, MATRIX_OPERATIONS } from "../../types/matrix";
import { MAX_DIM } from "../../algorithms/matrix/common";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  problem: MatrixInput;
  onChange: (problem: MatrixInput) => void;
  errors: string[];
}

const OP_LABEL: Record<MatrixOperation, string> = {
  gaussian: "Solve Ax = b (Gaussian elimination)",
  determinant: "Determinant",
  inverse: "Inverse",
  rank: "Rank & nullspace",
  eigen: "Eigenvalues & eigenvectors",
};

/** Editable coefficient matrix (with an optional right-hand-side column for Ax = b), an operation picker, and add/remove row/column controls. */
export function ProblemInput({ problem, onChange, errors }: Props) {
  const m = problem.matrix.length;
  const n = problem.matrix[0]?.length ?? 0;
  const needsRhs = problem.operation === "gaussian";
  const needsSquare = problem.operation === "determinant" || problem.operation === "inverse" || problem.operation === "eigen";

  const setOperation = (operation: MatrixOperation) => {
    let matrix = problem.matrix;
    let rhs = problem.rhs;
    if ((operation === "determinant" || operation === "inverse" || operation === "eigen") && m !== n) {
      // switching to a square-only operation on a non-square matrix: pad/trim to square so the editor stays usable
      const size = Math.max(m, n);
      matrix = Array.from({ length: size }, (_, i) => Array.from({ length: size }, (_, j) => problem.matrix[i]?.[j] ?? (i === j ? 1 : 0)));
    }
    if (operation === "gaussian" && !rhs) rhs = matrix.map(() => 0);
    onChange({ ...problem, operation, matrix, rhs: operation === "gaussian" ? rhs : undefined });
  };

  const addRow = () => {
    const matrix = [...problem.matrix, Array.from({ length: n }, () => 0)];
    onChange({ ...problem, matrix, rhs: needsRhs ? [...(problem.rhs ?? []), 0] : problem.rhs });
  };
  const removeRow = (i: number) => {
    const matrix = problem.matrix.filter((_, k) => k !== i);
    onChange({ ...problem, matrix, rhs: needsRhs ? problem.rhs?.filter((_, k) => k !== i) : problem.rhs });
  };
  const addCol = () => {
    const matrix = problem.matrix.map((row) => [...row, 0]);
    onChange({ ...problem, matrix });
  };
  const removeCol = (j: number) => {
    const matrix = problem.matrix.map((row) => row.filter((_, k) => k !== j));
    onChange({ ...problem, matrix });
  };
  const setCell = (i: number, j: number, value: number) => {
    const matrix = problem.matrix.map((row, ri) => (ri === i ? row.map((c, ci) => (ci === j ? value : c)) : row));
    onChange({ ...problem, matrix });
  };
  const setRhs = (i: number, value: number) => {
    const rhs = (problem.rhs ?? problem.matrix.map(() => 0)).map((x, k) => (k === i ? value : x));
    onChange({ ...problem, rhs });
  };

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <label className="block text-sm text-graphite print:hidden">
        Operation:{" "}
        <select
          className="focus-ring rounded border border-rule px-2 py-1"
          value={problem.operation}
          onChange={(e) => setOperation(e.target.value as MatrixOperation)}
        >
          {MATRIX_OPERATIONS.map((op) => (
            <option key={op} value={op}>
              {OP_LABEL[op]}
            </option>
          ))}
        </select>
      </label>

      <div className="flex flex-wrap items-center gap-4 text-xs text-graphite">
        <span>
          Size: <span className="font-mono font-semibold text-ink">{m} × {n}</span>
          {needsSquare && m !== n && <span className="ml-1 text-sienna">(must be square for this operation)</span>}
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="ledger-table">
          <thead>
            <tr>
              <th></th>
              {Array.from({ length: n }, (_, j) => (
                <th key={j}>
                  <div className="flex items-center justify-center gap-1">
                    <span className="font-sans">x{j + 1}</span>
                    {n > 1 && (
                      <button className="focus-ring text-graphite hover:text-sienna" onClick={() => removeCol(j)} aria-label={`Remove column ${j + 1}`}>
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </th>
              ))}
              {needsRhs && <th className="font-sans">b</th>}
            </tr>
          </thead>
          <tbody>
            {problem.matrix.map((row, i) => (
              <tr key={i}>
                <th className="text-left">
                  <div className="flex items-center gap-1">
                    <span className="font-sans">R{i + 1}</span>
                    {m > 1 && (
                      <button className="focus-ring text-graphite hover:text-sienna" onClick={() => removeRow(i)} aria-label={`Remove row ${i + 1}`}>
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </th>
                {row.map((val, j) => (
                  <td key={j}>
                    <input
                      type="number"
                      step="any"
                      aria-label={`Entry at row ${i + 1}, column ${j + 1}`}
                      className="focus-ring w-16 rounded border border-rule px-1 py-1 text-right"
                      value={val}
                      onChange={(e) => setCell(i, j, Number(e.target.value))}
                    />
                  </td>
                ))}
                {needsRhs && (
                  <td>
                    <input
                      type="number"
                      step="any"
                      aria-label={`Right-hand side for row ${i + 1}`}
                      className="focus-ring w-16 rounded border border-rule bg-ledger/40 px-1 py-1 text-right"
                      value={problem.rhs?.[i] ?? 0}
                      onChange={(e) => setRhs(i, Number(e.target.value))}
                    />
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-3">
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline disabled:opacity-40" onClick={addRow} disabled={m >= MAX_DIM}>
          <Plus size={14} /> Add row
        </button>
        <button
          className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline disabled:opacity-40"
          onClick={addCol}
          disabled={n >= MAX_DIM || needsSquare}
        >
          <Plus size={14} /> Add column
        </button>
      </div>
      <p className="text-xs text-graphite">At most {MAX_DIM} × {MAX_DIM}. Entries may be negative or decimal; the solver treats them exactly (as fractions).</p>
    </div>
  );
}
