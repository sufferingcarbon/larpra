import { AssignmentProblemInput } from "../../types/assignment";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  problem: AssignmentProblemInput;
  onChange: (problem: AssignmentProblemInput) => void;
  errors: string[];
}

export function ProblemInput({ problem, onChange, errors }: Props) {
  const addWorker = () => {
    const idx = problem.workerNames.length + 1;
    onChange({
      ...problem,
      workerNames: [...problem.workerNames, `W${idx}`],
      costs: [...problem.costs, problem.taskNames.map(() => 0)],
    });
  };

  const removeWorker = (i: number) => {
    onChange({
      ...problem,
      workerNames: problem.workerNames.filter((_, idx) => idx !== i),
      costs: problem.costs.filter((_, idx) => idx !== i),
    });
  };

  const addTask = () => {
    const idx = problem.taskNames.length + 1;
    onChange({
      ...problem,
      taskNames: [...problem.taskNames, `T${idx}`],
      costs: problem.costs.map((row) => [...row, 0]),
    });
  };

  const removeTask = (j: number) => {
    onChange({
      ...problem,
      taskNames: problem.taskNames.filter((_, idx) => idx !== j),
      costs: problem.costs.map((row) => row.filter((_, idx) => idx !== j)),
    });
  };

  const updateWorkerName = (i: number, name: string) => {
    onChange({ ...problem, workerNames: problem.workerNames.map((n, idx) => (idx === i ? name : n)) });
  };
  const updateTaskName = (j: number, name: string) => {
    onChange({ ...problem, taskNames: problem.taskNames.map((n, idx) => (idx === j ? name : n)) });
  };
  const updateCost = (i: number, j: number, value: number) => {
    onChange({
      ...problem,
      costs: problem.costs.map((row, ri) => (ri === i ? row.map((c, ci) => (ci === j ? value : c)) : row)),
    });
  };

  const m = problem.workerNames.length;
  const n = problem.taskNames.length;

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex items-center gap-4 text-xs text-graphite">
        <span>
          Workers: <span className="font-mono font-semibold text-ink">{m}</span>
        </span>
        <span>
          Tasks: <span className="font-mono font-semibold text-ink">{n}</span>
        </span>
        {m !== n && (
          <span className="rounded-full bg-gold/15 px-2 py-0.5 font-medium text-gold">
            Unequal — a dummy {m > n ? "task" : "worker"} will be added automatically
          </span>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th></th>
              {problem.taskNames.map((name, j) => (
                <th key={j}>
                  <div className="flex items-center justify-center gap-1">
                    <input
                      className="focus-ring w-16 rounded border border-rule bg-white px-1 py-0.5 text-center font-sans"
                      value={name}
                      onChange={(e) => updateTaskName(j, e.target.value)}
                    />
                    {problem.taskNames.length > 1 && (
                      <button
                        className="focus-ring text-graphite hover:text-sienna"
                        onClick={() => removeTask(j)}
                        aria-label="Remove task"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {problem.workerNames.map((workerName, i) => (
              <tr key={i}>
                <th className="text-left">
                  <div className="flex items-center gap-1">
                    <input
                      className="focus-ring w-16 rounded border border-rule bg-white px-1 py-0.5 font-sans"
                      value={workerName}
                      onChange={(e) => updateWorkerName(i, e.target.value)}
                    />
                    {problem.workerNames.length > 1 && (
                      <button
                        className="focus-ring text-graphite hover:text-sienna"
                        onClick={() => removeWorker(i)}
                        aria-label="Remove worker"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </th>
                {problem.taskNames.map((_, j) => (
                  <td key={j}>
                    <input
                      type="number"
                      className="focus-ring w-14 rounded border border-rule px-1 py-1 text-right"
                      value={problem.costs[i]?.[j] ?? 0}
                      onChange={(e) => updateCost(i, j, Number(e.target.value))}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex gap-3">
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addWorker}>
          <Plus size={14} /> Add worker
        </button>
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addTask}>
          <Plus size={14} /> Add task
        </button>
      </div>
    </div>
  );
}
