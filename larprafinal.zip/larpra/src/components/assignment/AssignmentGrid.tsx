import { AssignmentTableauState } from "../../types/assignment";

function cellKey(i: number, j: number) {
  return `${i}-${j}`;
}

export function AssignmentGrid({ state }: { state: AssignmentTableauState }) {
  const {
    workerNames,
    taskNames,
    costs,
    rowReductions,
    colReductions,
    coveredRows,
    coveredCols,
    matching,
    currentRow,
    visitedCols,
    augmentingPath,
    uncoveredMin,
  } = state;

  const pathByCell = new Map<string, number>();
  augmentingPath?.forEach((cell, idx) => pathByCell.set(cellKey(cell.row, cell.col), idx));

  const matchedCell = new Map<number, number>(); // row -> col
  matching.forEach((j, i) => {
    if (j !== null) matchedCell.set(i, j);
  });

  const phaseLabel = state.phase === "balance" ? "Square check" : state.phase === "reduction" ? "Reduction" : "Matching";

  return (
    <div className="overflow-x-auto">
      <div className="mb-2 flex flex-wrap items-center gap-3 text-xs">
        <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">{phaseLabel}</span>
        <span className="font-mono text-graphite">Cost so far: {state.currentCost}</span>
        {state.lineCount !== null && (
          <span className="font-mono text-graphite">
            Lines: {state.lineCount} / {workerNames.length}
          </span>
        )}
        {state.isOptimal && (
          <span className="rounded-full bg-forest/15 px-2.5 py-1 font-medium text-forestDark">Optimal</span>
        )}
        {uncoveredMin !== null && (
          <span className="rounded-full bg-gold/20 px-2.5 py-1 font-medium text-gold">min uncovered = {uncoveredMin}</span>
        )}
      </div>

      <table className="ledger-table min-w-full">
        <thead>
          <tr>
            <th className="text-left">Worker \ Task</th>
            {taskNames.map((name, j) => (
              <th key={name} className={coveredCols?.[j] ? "bg-graphite/20 text-graphite/50 line-through" : ""}>
                {name}
                {colReductions && colReductions[j] !== null && (
                  <div className="text-[10px] font-normal text-gold">−{colReductions[j]}</div>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {workerNames.map((workerName, i) => (
            <tr key={workerName}>
              <th className={`text-left font-sans font-medium ${coveredRows?.[i] ? "bg-graphite/20 text-graphite/50 line-through" : ""}`}>
                {workerName}
                {rowReductions && rowReductions[i] !== null && (
                  <span className="ml-1 text-[10px] font-normal text-gold">−{rowReductions[i]}</span>
                )}
              </th>
              {taskNames.map((taskName, j) => {
                const key = cellKey(i, j);
                const pathIdx = pathByCell.get(key);
                const isMatched = matchedCell.get(i) === j;
                const isCurrentRow = currentRow === i;
                const isVisitedCol = visitedCols?.[j] ?? false;
                const isZero = costs[i][j] === "0";

                const rowCov = coveredRows?.[i] ?? false;
                const colCov = coveredCols?.[j] ?? false;
                const showsCovering = coveredRows !== null;

                let tone = "";
                if (pathIdx !== undefined) tone = "bg-forest/25";
                else if (isMatched) tone = "bg-forest/10";
                else if (showsCovering && rowCov && colCov) tone = "bg-sienna/10";
                else if (showsCovering && !rowCov && !colCov) tone = "bg-ledger/40";
                else if (isCurrentRow && isVisitedCol) tone = "bg-gold/15";
                else if (isCurrentRow) tone = "bg-gold/5";

                return (
                  <td key={taskName} className={`relative ${tone}`}>
                    <div className="flex flex-col items-center leading-tight">
                      <span className={`text-sm ${isZero ? "font-semibold text-ink" : "text-graphite/70"}`}>
                        {costs[i][j]}
                      </span>
                      {isMatched && <span className="text-[10px] font-medium text-forestDark">assigned</span>}
                      {pathIdx !== undefined && (
                        <span className="absolute left-1 top-1 text-[10px] font-bold text-forestDark">{pathIdx + 1}</span>
                      )}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>

      {state.dummyNote && (
        <p className="mt-2 text-xs text-graphite">
          <span className="font-medium text-forestDark">Dummy added:</span> {state.dummyNote}
        </p>
      )}
      {augmentingPath && augmentingPath.length > 0 && (
        <p className="mt-2 text-xs text-graphite">
          Augmenting path: {augmentingPath.map((c) => `(${workerNames[c.row]}, ${taskNames[c.col]})`).join(" → ")}
        </p>
      )}
    </div>
  );
}
