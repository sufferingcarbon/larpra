import { CPMTableauState } from "../../types/cpm";

const W = 640;
const LABEL_W = 84;
const RIGHT = 60;
const TOP = 28;
const ROW = 28;
const BAR_H = 14;

const COLORS = {
  critical: "#B5482A",
  normal: "#4B5257",
  float: "#B08A2E",
  ink: "#161B22",
  rule: "#D8D4C6",
  graphite: "#4B5257",
};

/** The smallest 1, 2, 5 × 10ⁿ tick spacing that keeps the axis to about ten gridlines or fewer. */
export function niceStep(max: number): number {
  const rough = Math.max(max, 1e-9) / 10;
  const pow = Math.pow(10, Math.floor(Math.log10(rough)));
  const f = rough / pow;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * pow;
}

const num = (s: string | null): number | null => (s === null ? null : Number(s));

interface Props {
  state: CPMTableauState;
  /** Fixed time-axis maximum so the chart doesn't rescale from step to step. */
  timeMax?: number;
}

/**
 * Gantt view of the schedule so far. Bars appear as the forward pass computes them (ES→EF); once the
 * backward pass has run, a hatched band shows each activity's float (EF→LF); after the slack step the
 * critical activities turn red. A discovered critical path is emphasised and everything else dimmed.
 */
export function CPMGantt({ state, timeMax }: Props) {
  const byName = new Map(state.activities.map((a) => [a.name, a]));
  const order = state.topologicalOrder ?? state.activities.map((a) => a.name);

  const seen: number[] = [num(state.projectDuration) ?? 0];
  state.activities.forEach((a) => [a.ef, a.lf].forEach((v) => v !== null && seen.push(Number(v))));
  const max = Math.max(timeMax ?? 0, ...seen, 1);

  const plotW = W - LABEL_W - RIGHT;
  const x = (t: number) => LABEL_W + (t / max) * plotW;
  const H = TOP + order.length * ROW + 10;

  const step = niceStep(max);
  const ticks: number[] = [];
  for (let t = 0; t <= max + step * 1e-6; t += step) ticks.push(Number(t.toFixed(6)));

  const onPath = state.currentPath ? new Set(state.currentPath) : null;
  const D = num(state.projectDuration);

  return (
    <div className="rounded border border-rule bg-white p-3">
      {/* On a narrow screen the chart keeps a readable size and scrolls sideways instead of shrinking its text. */}
      <div className="overflow-x-auto">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full min-w-[540px]" role="img" aria-label="Gantt chart of the activity schedule">
        <defs>
          <pattern id="cpm-float-hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="6" stroke={COLORS.float} strokeWidth="2" opacity="0.55" />
          </pattern>
        </defs>

        {ticks.map((t) => (
          <g key={t}>
            <line x1={x(t)} y1={TOP - 6} x2={x(t)} y2={H - 8} stroke={COLORS.rule} strokeWidth="1" />
            <text x={x(t)} y={TOP - 12} textAnchor="middle" fontSize="10" fill={COLORS.graphite} fontFamily="IBM Plex Mono, monospace">
              {t}
            </text>
          </g>
        ))}

        {D !== null && (
          <line x1={x(D)} y1={TOP - 6} x2={x(D)} y2={H - 8} stroke={COLORS.critical} strokeWidth="1.5" strokeDasharray="4 3" />
        )}

        {order.map((name, i) => {
          const row = byName.get(name)!;
          const es = num(row.es), ef = num(row.ef), lf = num(row.lf);
          const cy = TOP + i * ROW + ROW / 2;
          const isCurrent = state.currentActivity === name;
          const dim = onPath !== null && !onPath.has(name);
          const highlighted = onPath !== null && onPath.has(name);
          const fill = row.isCritical === true ? COLORS.critical : COLORS.normal;
          const slackNum = num(row.slack);
          return (
            <g key={name} opacity={dim ? 0.3 : 1}>
              {isCurrent && <rect x={0} y={cy - ROW / 2 + 1} width={W} height={ROW - 2} fill={COLORS.float} opacity="0.13" />}
              <text
                x={LABEL_W - 8}
                y={cy + 4}
                textAnchor="end"
                fontSize="11"
                fontFamily="IBM Plex Mono, monospace"
                fill={row.isCritical === true ? COLORS.critical : COLORS.ink}
                fontWeight={row.isCritical === true || isCurrent ? 600 : 400}
              >
                {name.length > 10 ? name.slice(0, 9) + "…" : name}
              </text>
              {ef !== null && lf !== null && lf - ef > 1e-9 && (
                <rect x={x(ef)} y={cy - BAR_H / 2 + 2} width={Math.max(x(lf) - x(ef), 1)} height={BAR_H - 4} fill="url(#cpm-float-hatch)" stroke={COLORS.float} strokeWidth="0.75" strokeDasharray="2 2" />
              )}
              {es !== null && ef !== null && (
                <rect
                  x={x(es)}
                  y={cy - BAR_H / 2}
                  width={Math.max(x(ef) - x(es), 3)}
                  height={BAR_H}
                  rx="2"
                  fill={fill}
                  stroke={isCurrent ? COLORS.float : highlighted ? COLORS.ink : "none"}
                  strokeWidth={isCurrent || highlighted ? 2 : 0}
                >
                  <title>{`${name}: ${row.es} → ${row.ef}${row.slack !== null ? `, slack ${row.slack}` : ""}`}</title>
                </rect>
              )}
              {slackNum !== null && slackNum > 1e-9 && ef !== null && lf !== null && (
                <text x={x(lf) + 4} y={cy + 4} fontSize="10" fontFamily="IBM Plex Mono, monospace" fill={COLORS.float}>
                  slack {row.slack}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-graphite">
        <span className="flex items-center gap-1.5"><span className="inline-block h-2.5 w-4 rounded-sm" style={{ background: COLORS.normal }} /> activity (ES → EF)</span>
        <span className="flex items-center gap-1.5"><span className="inline-block h-2.5 w-4 rounded-sm" style={{ background: COLORS.critical }} /> critical (zero slack)</span>
        <span className="flex items-center gap-1.5"><span className="inline-block h-2.5 w-4 border border-dashed" style={{ borderColor: COLORS.float, background: "repeating-linear-gradient(45deg, #B08A2E88 0 2px, transparent 2px 5px)" }} /> float (EF → LF)</span>
        <span className="flex items-center gap-1.5"><span className="inline-block h-3 border-l-2 border-dashed" style={{ borderColor: COLORS.critical }} /> project end</span>
      </div>
    </div>
  );
}
