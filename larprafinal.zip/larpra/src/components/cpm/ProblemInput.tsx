import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { CPMActivityInput, CPMMode, CPMProblemInput } from "../../types/cpm";
import { expectedDuration, fmt, pertVariance } from "../../algorithms/cpm/common";
import { addActivity, parsePredecessors, removeActivity, renameActivity } from "../../algorithms/cpm/edit";

interface Props {
  problem: CPMProblemInput;
  mode: CPMMode;
  onChange: (problem: CPMProblemInput) => void;
  errors: string[];
}

const SEP = "\u0000";
/**
 * Comma-separated predecessor names. Keeps the raw text locally so typing "A, " isn't
 * immediately rewritten to "A", and re-syncs only when the list changes from outside
 * (loading an example, or renaming an activity elsewhere in the table).
 */
function PredecessorInput({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const [raw, setRaw] = useState(value.join(", "));
  const key = value.join(SEP);
  useEffect(() => {
    if (parsePredecessors(raw).join(SEP) !== key) setRaw(value.join(", "));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return (
    <input
      className="focus-ring w-32 rounded border border-rule px-1.5 py-1 font-mono text-sm"
      value={raw}
      placeholder="none"
      aria-label="Predecessors (comma-separated)"
      onChange={(e) => {
        setRaw(e.target.value);
        onChange(parsePredecessors(e.target.value));
      }}
    />
  );
}

const numValue = (x: number | undefined) => (typeof x === "number" && Number.isFinite(x) ? x : "");
const parseNum = (s: string): number | undefined => (s === "" ? undefined : Number(s));

export function ProblemInput({ problem, mode, onChange, errors }: Props) {
  const acts = problem.activities;

  const update = (i: number, patch: Partial<CPMActivityInput>) =>
    onChange({ activities: acts.map((a, idx) => (idx === i ? { ...a, ...patch } : a)) });

  const rename = (i: number, name: string) => onChange(renameActivity(problem, i, name));
  const remove = (i: number) => onChange(removeActivity(problem, i));
  const add = () => onChange(addActivity(problem, mode));

  return (
    <div className="space-y-3">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th className="!text-left">Activity</th>
              {mode === "cpm" ? (
                <th>Duration</th>
              ) : (
                <>
                  <th title="Optimistic (best case)">a</th>
                  <th title="Most likely">m</th>
                  <th title="Pessimistic (worst case)">b</th>
                  <th title="Expected duration (a + 4m + b) / 6">te</th>
                  <th title="Variance ((b − a) / 6)²">Var</th>
                </>
              )}
              <th className="!text-left">Predecessors</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {acts.map((a, i) => {
              const o = a.optimistic, m = a.mostLikely, p = a.pessimistic;
              const ready = [o, m, p].every((x) => typeof x === "number" && Number.isFinite(x));
              return (
                <tr key={i}>
                  <td className="!text-left">
                    <input
                      className="focus-ring w-24 rounded border border-rule px-1.5 py-1 font-mono text-sm"
                      value={a.name}
                      aria-label="Activity name"
                      onChange={(e) => rename(i, e.target.value)}
                    />
                  </td>
                  {mode === "cpm" ? (
                    <td>
                      <input
                        type="number"
                        min={0}
                        step="any"
                        className="focus-ring w-20 rounded border border-rule px-1.5 py-1 text-right"
                        value={numValue(a.duration)}
                        aria-label={`Duration of ${a.name}`}
                        onChange={(e) => update(i, { duration: parseNum(e.target.value) })}
                      />
                    </td>
                  ) : (
                    <>
                      {(["optimistic", "mostLikely", "pessimistic"] as const).map((k) => (
                        <td key={k}>
                          <input
                            type="number"
                            min={0}
                            step="any"
                            className="focus-ring w-16 rounded border border-rule px-1.5 py-1 text-right"
                            value={numValue(a[k])}
                            aria-label={`${k} estimate of ${a.name}`}
                            onChange={(e) => update(i, { [k]: parseNum(e.target.value) })}
                          />
                        </td>
                      ))}
                      <td className="text-graphite">{ready ? fmt(expectedDuration(o!, m!, p!)) : "—"}</td>
                      <td className="text-graphite">{ready ? fmt(pertVariance(o!, p!)) : "—"}</td>
                    </>
                  )}
                  <td className="!text-left">
                    <PredecessorInput value={a.predecessors} onChange={(v) => update(i, { predecessors: v })} />
                  </td>
                  <td>
                    <button
                      className="focus-ring text-graphite hover:text-sienna"
                      onClick={() => remove(i)}
                      aria-label={`Remove activity ${a.name}`}
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={add}>
        <Plus size={14} /> Add activity
      </button>
      <p className="text-xs text-graphite/70">
        Predecessors are the activities that must finish before this one can start — names separated by commas, or blank if it
        can start immediately. Durations may be decimals; a duration of 0 makes a milestone.
      </p>
    </div>
  );
}
