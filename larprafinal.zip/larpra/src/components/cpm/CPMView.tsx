import { CPMTableauState } from "../../types/cpm";
import { CPMGantt } from "./CPMGantt";

const PHASE_LABEL: Record<CPMTableauState["phase"], string> = {
  setup: "Setup",
  forward: "Forward pass",
  backward: "Backward pass",
  slack: "Slack",
  "critical-path": "Critical path",
};

const Cell = ({ value, fresh }: { value: string | null; fresh?: boolean }) => (
  <td className={fresh ? "bg-gold/20 font-semibold text-ink" : ""}>
    {value === null ? <span className="text-graphite/30">·</span> : value}
  </td>
);

export function CPMView({ state, timeMax }: { state: CPMTableauState; timeMax?: number }) {
  const cur = state.currentActivity;
  const pathSet = new Set(state.currentPath ?? []);

  // Which activities the current pass has already handled — drives the order chips.
  const done = (name: string): boolean => {
    const row = state.activities.find((a) => a.name === name)!;
    if (state.phase === "setup") return false;
    if (state.phase === "forward") return row.es !== null;
    if (state.phase === "backward") return row.ls !== null;
    return true;
  };

  const freshEsEf = state.phase === "forward";
  const freshLsLf = state.phase === "backward";
  const freshSlack = state.phase === "slack";

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="rounded-full bg-ink px-2.5 py-1 font-medium text-paper">{PHASE_LABEL[state.phase]}</span>
        {state.projectDuration !== null && (
          <span className="rounded-full bg-forest/10 px-2.5 py-1 font-medium text-forestDark">Project duration: {state.projectDuration}</span>
        )}
        {state.projectVariance !== null && (
          <span className="rounded-full bg-gold/15 px-2.5 py-1 font-medium text-ink">
            Variance: {state.projectVariance} · σ = {state.projectStdDev}
          </span>
        )}
      </div>

      {state.topologicalOrder && (
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-graphite">{state.phase === "backward" ? "Order (worked in reverse):" : "Order:"}</span>
          {(state.phase === "backward" ? [...state.topologicalOrder].reverse() : state.topologicalOrder).map((n, i) => (
            <span
              key={n}
              className={`rounded border px-1.5 py-0.5 font-mono ${
                n === cur
                  ? "border-gold bg-gold/25 font-semibold text-ink"
                  : done(n)
                  ? "border-forest/40 bg-forest/10 text-forestDark"
                  : "border-rule bg-white text-graphite"
              }`}
            >
              {i > 0 && <span className="mr-1 text-graphite/40">›</span>}
              {n}
            </span>
          ))}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th className="!text-left">Activity</th>
              {state.isPert && <th title="Optimistic / most likely / pessimistic">a / m / b</th>}
              <th>{state.isPert ? "te" : "Duration"}</th>
              {state.isPert && <th>Var</th>}
              <th className="!text-left">Predecessors</th>
              <th>ES</th>
              <th>EF</th>
              <th>LS</th>
              <th>LF</th>
              <th>Slack</th>
              <th>Critical</th>
            </tr>
          </thead>
          <tbody>
            {state.activities.map((a) => {
              const isCur = a.name === cur;
              const onPath = pathSet.has(a.name);
              return (
                <tr key={a.name} className={isCur ? "bg-gold/10" : onPath ? "bg-sienna/10" : ""}>
                  <th className={`!text-left font-mono ${a.isCritical ? "text-sienna" : ""}`}>{a.name}</th>
                  {state.isPert && a.estimates && (
                    <td className="text-graphite">
                      {a.estimates.optimistic} / {a.estimates.mostLikely} / {a.estimates.pessimistic}
                    </td>
                  )}
                  <td>{a.duration}</td>
                  {state.isPert && <td className="text-graphite">{a.variance}</td>}
                  <td className="!text-left font-mono text-graphite">{a.predecessors.length ? a.predecessors.join(", ") : "—"}</td>
                  <Cell value={a.es} fresh={isCur && freshEsEf} />
                  <Cell value={a.ef} fresh={isCur && freshEsEf} />
                  <Cell value={a.ls} fresh={isCur && freshLsLf} />
                  <Cell value={a.lf} fresh={isCur && freshLsLf} />
                  <Cell value={a.slack} fresh={freshSlack} />
                  <td className={freshSlack ? "bg-gold/20" : ""}>
                    {a.isCritical === null ? (
                      <span className="text-graphite/30">·</span>
                    ) : a.isCritical ? (
                      <span className="font-semibold text-sienna">critical</span>
                    ) : (
                      <span className="text-graphite/50">—</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <CPMGantt state={state} timeMax={timeMax} />

      {state.criticalPaths && state.criticalPaths.length > 0 && (
        <div className="space-y-1.5">
          <h4 className="text-xs font-semibold uppercase tracking-wide text-graphite">
            Critical path{state.criticalPaths.length === 1 ? "" : "s"} found so far
          </h4>
          <ul className="space-y-1">
            {state.criticalPaths.map((p, i) => {
              const isNew = state.currentPath !== null && p.join(">") === state.currentPath.join(">");
              return (
                <li
                  key={i}
                  className={`rounded border px-2.5 py-1 font-mono text-xs ${
                    isNew ? "border-sienna bg-sienna/10 font-semibold text-sienna" : "border-rule bg-white text-ink"
                  }`}
                >
                  {p.join(" → ")}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
