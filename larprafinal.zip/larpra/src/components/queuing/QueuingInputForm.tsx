import { MM1Input, MMcInput, QueuingModelType } from "../../types/queuing";

interface Props {
  model: QueuingModelType;
  onModelChange: (m: QueuingModelType) => void;
  mm1: MM1Input;
  onMM1Change: (p: MM1Input) => void;
  mmc: MMcInput;
  onMMcChange: (p: MMcInput) => void;
  errors: string[];
}

function Field({ label, value, onChange, step = "any", min }: { label: string; value: number; onChange: (v: number) => void; step?: string; min?: number }) {
  return (
    <label className="flex flex-col gap-1 text-xs text-graphite">
      {label}
      <input
        type="number"
        step={step}
        min={min}
        className="focus-ring w-full rounded border border-rule px-2 py-1.5 text-right font-mono text-sm text-ink"
        value={Number.isFinite(value) ? value : ""}
        onChange={(e) => onChange(e.target.value === "" ? NaN : Number(e.target.value))}
      />
    </label>
  );
}

export function QueuingInputForm({ model, onModelChange, mm1, onMM1Change, mmc, onMMcChange, errors }: Props) {
  return (
    <div className="space-y-4">
      <div className="inline-flex rounded border border-rule bg-ledger/40 p-0.5 text-sm">
        <button
          className={`rounded px-3 py-1.5 transition-colors ${model === "mm1" ? "bg-forest text-white" : "text-graphite hover:text-ink"}`}
          onClick={() => onModelChange("mm1")}
        >
          M/M/1 — single server
        </button>
        <button
          className={`rounded px-3 py-1.5 transition-colors ${model === "mmc" ? "bg-forest text-white" : "text-graphite hover:text-ink"}`}
          onClick={() => onModelChange("mmc")}
        >
          M/M/c — multiple servers
        </button>
      </div>

      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      {model === "mm1" ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Field label="Arrival rate λ" value={mm1.lambda} onChange={(v) => onMM1Change({ ...mm1, lambda: v })} min={0} />
          <Field label="Service rate μ" value={mm1.mu} onChange={(v) => onMM1Change({ ...mm1, mu: v })} min={0} />
          <Field label="Distribution cutoff (n)" value={mm1.maxN} onChange={(v) => onMM1Change({ ...mm1, maxN: v })} step="1" min={1} />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Field label="Arrival rate λ" value={mmc.lambda} onChange={(v) => onMMcChange({ ...mmc, lambda: v })} min={0} />
          <Field label="Service rate μ (per server)" value={mmc.mu} onChange={(v) => onMMcChange({ ...mmc, mu: v })} min={0} />
          <Field label="Servers c" value={mmc.servers} onChange={(v) => onMMcChange({ ...mmc, servers: v })} step="1" min={1} />
          <Field label="Distribution cutoff (n)" value={mmc.maxN} onChange={(v) => onMMcChange({ ...mmc, maxN: v })} step="1" min={1} />
        </div>
      )}
      <p className="text-xs text-graphite">
        λ and μ share any consistent unit of time (e.g. both per hour). The distribution cutoff only controls how many
        states of the steady-state table and chart are shown — it doesn't change any of the summary metrics.
      </p>
    </div>
  );
}
