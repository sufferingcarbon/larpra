import { QueuingDistributionRow } from "../../types/queuing";
import { CdfPoint } from "../../algorithms/queuing/waitTimeCurve";
import { parseDisplayNumber } from "./parseDisplay";

/* ---------------------------- Utilization gauge --------------------------- */

export function UtilizationGauge({ rho }: { rho: string }) {
  const val = parseDisplayNumber(rho);
  const pct = Math.max(0, Math.min(100, val * 100));
  const color = val >= 0.9 ? "#B5482A" : val >= 0.7 ? "#B08A2E" : "#2F6B4F";
  return (
    <div>
      <div className="flex items-baseline justify-between text-xs text-graphite">
        <span>Server utilization ρ</span>
        <span className="font-mono text-sm font-semibold text-ink">{rho}</span>
      </div>
      <div className="mt-1.5 h-3 w-full overflow-hidden rounded-full border border-rule bg-ledger">
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

/* --------------------------- Pn distribution chart -------------------------- */

const CHART_W = 640;
const CHART_H = 220;
const PAD_L = 36;
const PAD_B = 24;
const PAD_T = 10;
const PAD_R = 10;

export function DistributionChart({ rows }: { rows: QueuingDistributionRow[] }) {
  const values = rows.map((r) => parseDisplayNumber(r.pn));
  const cumValues = rows.map((r) => parseDisplayNumber(r.cumulative));
  const maxVal = Math.max(...values, 0.0001);
  const plotW = CHART_W - PAD_L - PAD_R;
  const plotH = CHART_H - PAD_T - PAD_B;
  const n = rows.length;
  const barW = plotW / n;

  const xFor = (i: number) => PAD_L + i * barW + barW / 2;
  const yForPmf = (v: number) => PAD_T + plotH * (1 - v / maxVal);
  const yForCdf = (v: number) => PAD_T + plotH * (1 - v);

  const cdfPath = cumValues.map((v, i) => `${i === 0 ? "M" : "L"} ${xFor(i)} ${yForCdf(v)}`).join(" ");

  // Show at most ~15 x-axis labels so it stays legible for large maxN.
  const labelStride = Math.max(1, Math.ceil(n / 15));

  return (
    <div>
      <svg viewBox={`0 0 ${CHART_W} ${CHART_H}`} className="w-full" role="img" aria-label="Steady-state distribution of the number of customers in the system">
        {/* y-axis gridlines for the PMF (left axis) */}
        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <line key={f} x1={PAD_L} x2={CHART_W - PAD_R} y1={PAD_T + plotH * (1 - f)} y2={PAD_T + plotH * (1 - f)} stroke="#D8D4C6" strokeWidth={1} />
        ))}
        {/* PMF bars */}
        {values.map((v, i) => (
          <rect
            key={i}
            x={PAD_L + i * barW + barW * 0.15}
            y={yForPmf(v)}
            width={barW * 0.7}
            height={Math.max(0, PAD_T + plotH - yForPmf(v))}
            fill="#2F6B4F"
            opacity={0.85}
          />
        ))}
        {/* Cumulative (CDF) line, right-axis scale 0..1 */}
        <path d={cdfPath} fill="none" stroke="#B08A2E" strokeWidth={2} />
        {cumValues.map((v, i) => (
          <circle key={i} cx={xFor(i)} cy={yForCdf(v)} r={2} fill="#B08A2E" />
        ))}
        {/* x-axis labels */}
        {rows.map((r, i) =>
          i % labelStride === 0 ? (
            <text key={i} x={xFor(i)} y={CHART_H - 6} textAnchor="middle" fontSize={9} fill="#4B5257">
              {r.n}
            </text>
          ) : null
        )}
        {/* left axis label */}
        <text x={4} y={PAD_T + 8} fontSize={9} fill="#4B5257">
          Pn
        </text>
        <text x={CHART_W - PAD_R - 18} y={PAD_T + 8} fontSize={9} fill="#B08A2E">
          CDF
        </text>
      </svg>
      <div className="mt-1 flex items-center gap-4 text-[11px] text-graphite">
        <span className="flex items-center gap-1">
          <span className="inline-block h-2 w-3 rounded-sm bg-forest" /> P(N = n)
        </span>
        <span className="flex items-center gap-1">
          <span className="inline-block h-0.5 w-3 bg-gold" /> P(N ≤ n), cumulative
        </span>
        <span>n = number of customers in the system</span>
      </div>
    </div>
  );
}

/* ---------------------------- Wait-time CDF chart --------------------------- */

export function WaitTimeCdfChart({
  curves,
  timeUnitLabel = "time",
}: {
  curves: { label: string; color: string; points: CdfPoint[] }[];
  timeUnitLabel?: string;
}) {
  if (curves.length === 0 || curves[0].points.length === 0) return null;
  const tMax = Math.max(...curves.flatMap((c) => c.points.map((p) => p.t)));
  const plotW = CHART_W - PAD_L - PAD_R;
  const plotH = CHART_H - PAD_T - PAD_B;
  const xFor = (t: number) => PAD_L + (tMax > 0 ? (t / tMax) * plotW : 0);
  const yFor = (v: number) => PAD_T + plotH * (1 - v);

  return (
    <div>
      <svg viewBox={`0 0 ${CHART_W} ${CHART_H}`} className="w-full" role="img" aria-label="Cumulative distribution of waiting time">
        {[0, 0.25, 0.5, 0.75, 1].map((f) => (
          <line key={f} x1={PAD_L} x2={CHART_W - PAD_R} y1={yFor(f)} y2={yFor(f)} stroke="#D8D4C6" strokeWidth={1} />
        ))}
        {curves.map((c) => (
          <path
            key={c.label}
            d={c.points.map((p, i) => `${i === 0 ? "M" : "L"} ${xFor(p.t)} ${yFor(p.value)}`).join(" ")}
            fill="none"
            stroke={c.color}
            strokeWidth={2}
          />
        ))}
        <text x={4} y={PAD_T + 8} fontSize={9} fill="#4B5257">
          P(≤ t)
        </text>
        <text x={PAD_L} y={CHART_H - 4} fontSize={9} fill="#4B5257">
          0
        </text>
        <text x={CHART_W - PAD_R} y={CHART_H - 4} textAnchor="end" fontSize={9} fill="#4B5257">
          {tMax.toFixed(2)} {timeUnitLabel}
        </text>
      </svg>
      <div className="mt-1 flex flex-wrap items-center gap-4 text-[11px] text-graphite">
        {curves.map((c) => (
          <span key={c.label} className="flex items-center gap-1">
            <span className="inline-block h-0.5 w-3" style={{ background: c.color }} /> {c.label}
          </span>
        ))}
      </div>
    </div>
  );
}
