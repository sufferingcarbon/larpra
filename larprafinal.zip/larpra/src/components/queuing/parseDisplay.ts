/**
 * The solver reports every metric as an exact display string ("5/6" or "0.8333" or "1").
 * Charts need plain numbers to compute pixel positions — this is purely a rendering
 * convenience and never feeds back into any computed metric.
 */
export function parseDisplayNumber(s: string | null | undefined): number {
  if (!s) return NaN;
  if (s.includes("/")) {
    const [n, d] = s.split("/").map(Number);
    return n / d;
  }
  return Number(s);
}
