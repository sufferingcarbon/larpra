import { QueuingMetricsPartial, QueuingState } from "../../types/queuing";
import { UtilizationGauge, DistributionChart, WaitTimeCdfChart } from "./QueuingCharts";
import { parseDisplayNumber } from "./parseDisplay";
import { mm1WaitCurves, mmcQueueWaitCurve } from "../../algorithms/queuing/waitTimeCurve";

const METRIC_LABELS: Record<keyof QueuingMetricsPartial, string> = {
  offeredLoad: "Offered load a = λ/μ",
  rho: "Utilization ρ",
  p0: "P0 — system empty",
  probWait: "Erlang C — P(customer waits)",
  erlangB: "Erlang B — P(blocked, loss system)",
  Lq: "Lq — expected # waiting",
  L: "L — expected # in system",
  Wq: "Wq — expected wait time",
  W: "W — expected time in system",
};

const METRIC_ORDER: (keyof QueuingMetricsPartial)[] = ["offeredLoad", "rho", "p0", "probWait", "Lq", "L", "Wq", "W", "erlangB"];

export function QueuingView({ state }: { state: QueuingState }) {
  const m = state.metrics;
  const visibleMetrics = METRIC_ORDER.filter((k) => m[k] !== null);
  const lambda = parseDisplayNumber(state.lambda);
  const mu = parseDisplayNumber(state.mu);

  const waitCurves = (() => {
    if (m.Wq === null) return null;
    if (state.model === "mm1") {
      const { system, queue } = mm1WaitCurves(lambda, mu);
      return [
        { label: "P(time in system ≤ t)", color: "#2F6B4F", points: system },
        { label: "P(time in queue ≤ t)", color: "#B08A2E", points: queue },
      ];
    }
    if (state.model === "mmc" && state.servers && m.probWait !== null) {
      const queue = mmcQueueWaitCurve(lambda, mu, state.servers, parseDisplayNumber(m.probWait));
      return [{ label: "P(time in queue ≤ t)", color: "#B08A2E", points: queue }];
    }
    return null;
  })();

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-graphite">
        <span>
          λ = <span className="font-mono text-ink">{state.lambda}</span>
        </span>
        <span>
          μ = <span className="font-mono text-ink">{state.mu}</span>
        </span>
        {state.servers !== null && (
          <span>
            servers c = <span className="font-mono text-ink">{state.servers}</span>
          </span>
        )}
      </div>

      {m.rho !== null && <UtilizationGauge rho={m.rho} />}

      {visibleMetrics.length > 0 && (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {visibleMetrics.map((k) => (
            <div
              key={k}
              className={`rounded border px-3 py-2 transition-colors ${
                state.justComputed === k ? "border-forest bg-forest/10" : "border-rule bg-ledger/40"
              }`}
            >
              <div className="text-[11px] leading-tight text-graphite">{METRIC_LABELS[k]}</div>
              <div className="font-mono text-base font-semibold text-ink">{m[k]}</div>
            </div>
          ))}
        </div>
      )}

      {state.distribution && (
        <div>
          <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-graphite">Steady-state distribution</h4>
          <DistributionChart rows={state.distribution} />
        </div>
      )}

      {waitCurves && (
        <div>
          <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-graphite">Waiting-time distribution</h4>
          <WaitTimeCdfChart curves={waitCurves} />
        </div>
      )}
    </div>
  );
}
