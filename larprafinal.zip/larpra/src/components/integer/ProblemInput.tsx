import { ConstraintRelation } from "../../types/lp";
import { IPProblem, VarType, VAR_TYPES } from "../../types/integer";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  problem: IPProblem;
  onChange: (problem: IPProblem) => void;
  errors: string[];
}

const relations: ConstraintRelation[] = ["<=", ">=", "="];
const typeLabels: Record<VarType, string> = { integer: "int", binary: "0/1", continuous: "cont." };

export function IPProblemInput({ problem, onChange, errors }: Props) {
  const types = (i: number): VarType => problem.varTypes?.[i] ?? "integer";

  const setVarCount = (n: number) => {
    n = Math.max(1, Math.min(8, n));
    const variables = Array.from({ length: n }, (_, i) => problem.variables[i] ?? `x${i + 1}`);
    const objective = Array.from({ length: n }, (_, i) => problem.objective[i] ?? 0);
    const varTypes = Array.from({ length: n }, (_, i) => types(i));
    const constraints = problem.constraints.map((c) => ({ ...c, coeffs: Array.from({ length: n }, (_, i) => c.coeffs[i] ?? 0) }));
    onChange({ ...problem, variables, objective, varTypes, constraints });
  };

  const updateObjective = (i: number, value: number) => {
    const objective = problem.objective.slice();
    objective[i] = value;
    onChange({ ...problem, objective });
  };

  const updateType = (i: number, t: VarType) => {
    const varTypes = problem.variables.map((_, j) => types(j));
    varTypes[i] = t;
    onChange({ ...problem, varTypes });
  };

  const updateConstraintCoeff = (rowIdx: number, colIdx: number, value: number) => {
    const constraints = problem.constraints.map((c, i) => (i === rowIdx ? { ...c, coeffs: c.coeffs.map((v, j) => (j === colIdx ? value : v)) } : c));
    onChange({ ...problem, constraints });
  };

  const updateConstraintField = <K extends "relation" | "rhs">(rowIdx: number, field: K, value: K extends "relation" ? ConstraintRelation : number) => {
    const constraints = problem.constraints.map((c, i) => (i === rowIdx ? { ...c, [field]: value } : c));
    onChange({ ...problem, constraints });
  };

  const addConstraint = () => onChange({ ...problem, constraints: [...problem.constraints, { coeffs: problem.variables.map(() => 0), relation: "<=" as ConstraintRelation, rhs: 0 }] });
  const removeConstraint = (i: number) => onChange({ ...problem, constraints: problem.constraints.filter((_, idx) => idx !== i) });

  return (
    <div className="space-y-5">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-4">
        <label className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Sense</span>
          <select className="focus-ring rounded border border-rule bg-white px-2 py-1" value={problem.sense} onChange={(e) => onChange({ ...problem, sense: e.target.value as "max" | "min" })}>
            <option value="max">Maximize</option>
            <option value="min">Minimize</option>
          </select>
        </label>
        <label className="flex items-center gap-2 text-sm">
          <span className="text-graphite">Variables</span>
          <select className="focus-ring rounded border border-rule bg-white px-2 py-1" value={problem.variables.length} onChange={(e) => setVarCount(Number(e.target.value))}>
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div>
        <p className="mb-1.5 text-xs font-medium uppercase tracking-wide text-graphite">Variable types</p>
        <div className="flex flex-wrap gap-3">
          {problem.variables.map((v, i) => (
            <label key={i} className="flex items-center gap-1.5 text-sm">
              <span className="font-mono">{v}</span>
              <select className="focus-ring rounded border border-rule bg-white px-1.5 py-1 text-xs" value={types(i)} onChange={(e) => updateType(i, e.target.value as VarType)}>
                {VAR_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {typeLabels[t]}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </div>
        <p className="mt-1 text-xs text-graphite/70">
          "int" is a non-negative whole number, "0/1" is an int capped at 1 (no separate x ≤ 1 constraint needed), "cont." is never branched on.
        </p>
      </div>

      <div>
        <p className="mb-1.5 text-xs font-medium uppercase tracking-wide text-graphite">Objective function Z</p>
        <div className="flex flex-wrap items-center gap-2 font-mono text-sm">
          {problem.objective.map((c, i) => (
            <span key={i} className="flex items-center gap-1">
              {i > 0 && <span>+</span>}
              <input type="number" className="focus-ring w-16 rounded border border-rule px-2 py-1 text-right" value={c} onChange={(e) => updateObjective(i, Number(e.target.value))} />
              <span>{problem.variables[i]}</span>
            </span>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between">
          <p className="text-xs font-medium uppercase tracking-wide text-graphite">Constraints</p>
          <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addConstraint}>
            <Plus size={14} /> Add constraint
          </button>
        </div>
        <div className="space-y-2">
          {problem.constraints.map((c, rowIdx) => (
            <div key={rowIdx} className="flex flex-wrap items-center gap-2 font-mono text-sm">
              {c.coeffs.map((coeff, colIdx) => (
                <span key={colIdx} className="flex items-center gap-1">
                  {colIdx > 0 && <span>+</span>}
                  <input type="number" className="focus-ring w-14 rounded border border-rule px-1.5 py-1 text-right" value={coeff} onChange={(e) => updateConstraintCoeff(rowIdx, colIdx, Number(e.target.value))} />
                  <span>{problem.variables[colIdx]}</span>
                </span>
              ))}
              <select className="focus-ring rounded border border-rule px-1.5 py-1" value={c.relation} onChange={(e) => updateConstraintField(rowIdx, "relation", e.target.value as ConstraintRelation)}>
                {relations.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
              <input type="number" className="focus-ring w-16 rounded border border-rule px-1.5 py-1 text-right" value={c.rhs} onChange={(e) => updateConstraintField(rowIdx, "rhs", Number(e.target.value))} />
              <button className="focus-ring ml-1 text-graphite hover:text-sienna" onClick={() => removeConstraint(rowIdx)} aria-label="Remove constraint">
                <Trash2 size={15} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
