import { useMemo, useState } from "react";
import { BnBNode, IPProblem } from "../../types/integer";
import { boundsText, nodeProblem } from "../../algorithms/integer/common";
import { solveSimplex } from "../../algorithms/lp/simplex";
import { SimplexView } from "../lp/SimplexView";
import { StepControls } from "../StepControls";
import { X } from "lucide-react";

/**
 * A closer look at one subproblem: its bounds relative to the root, the LP relaxation's outcome, and —
 * on request — the actual two-phase simplex solve for that subproblem's LP, replayed tableau by tableau
 * with the same step controls the LP module uses. This is what makes "every node is a real LP" checkable
 * by hand rather than asserted.
 */
export function NodeDetail({ problem, node, onClose }: { problem: IPProblem; node: BnBNode; onClose: () => void }) {
  const [showLP, setShowLP] = useState(false);
  const [lpStep, setLpStep] = useState(0);

  const lp = useMemo(() => (showLP ? solveSimplex(nodeProblem(problem, node)) : null), [showLP, problem, node]);
  const bounds = boundsText(problem, node.lb, node.ub);

  return (
    <div className="rounded border border-rule bg-white">
      <div className="flex items-center justify-between border-b border-rule px-4 py-2.5">
        <h4 className="font-display text-sm font-semibold">
          P{node.id}
          {node.branch && <span className="ml-2 font-mono text-xs font-normal text-graphite">({node.branch.variable} {node.branch.direction} {node.branch.bound})</span>}
        </h4>
        <button className="focus-ring text-graphite hover:text-sienna" onClick={onClose} aria-label="Close">
          <X size={16} />
        </button>
      </div>
      <div className="space-y-2 p-4 text-sm">
        <Row label="Purpose" value={node.purpose === "feasibility" ? "Feasibility check (objective replaced by 0)" : "Optimize"} />
        <Row label="Bounds beyond the root" value={bounds || "(none — this is the root)"} />
        <Row label="Parent's bound inherited" value={node.parentBound ?? "(none — root has no parent)"} />
        <Row label="LP status" value={node.lpStatus ?? "not solved (pruned without solving)"} />
        {node.lpValue !== null && <Row label="LP objective" value={node.lpValue} mono />}
        {node.lpSolution && <Row label="LP solution" value={problem.variables.map((v, i) => `${v} = ${node.lpSolution![i]}`).join(", ")} mono />}
        {node.branchVariable && <Row label="Branched on" value={node.branchVariable} />}

        {node.lpStatus === "optimal" || node.lpStatus === "infeasible" || node.lpStatus === "unbounded" ? (
          <div className="pt-2">
            <button className="focus-ring rounded border border-rule px-3 py-1.5 text-xs font-medium text-forestDark hover:border-forest" onClick={() => setShowLP((s) => !s)}>
              {showLP ? "Hide" : "Show"} full simplex solve for this subproblem
            </button>
          </div>
        ) : (
          <p className="pt-1 text-xs text-graphite/70">This node was pruned without solving its LP (its parent's bound already ruled it out).</p>
        )}
      </div>

      {showLP && lp && (
        <div className="border-t border-rule">
          <div className="p-4">
            <div className="mb-2 text-xs text-graphite">
              {lp.status === "optimal" || lp.status === "alternate_optima" ? `Z = ${lp.optimalValue}` : lp.status}
            </div>
            {lp.steps[lpStep] && <SimplexView state={lp.steps[lpStep].state} />}
          </div>
          <StepControls index={lpStep} total={lp.steps.length} onChange={setLpStep} onShowFullSolution={() => setLpStep(lp.steps.length - 1)} onReset={() => setLpStep(0)} />
        </div>
      )}
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex flex-wrap gap-2">
      <span className="w-44 shrink-0 text-xs uppercase tracking-wide text-graphite">{label}</span>
      <span className={mono ? "font-mono text-xs" : "text-xs"}>{value}</span>
    </div>
  );
}
