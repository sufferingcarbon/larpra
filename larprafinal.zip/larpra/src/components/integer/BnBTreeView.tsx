import { useMemo, useState } from "react";
import { BnBNode, IPProblem } from "../../types/integer";
import { boundsText } from "../../algorithms/integer/common";

const STATUS_STYLE: Record<string, { fill: string; stroke: string; text: string; label: string }> = {
  open: { fill: "#fff", stroke: "#c9c4b8", text: "#6b675f", label: "open" },
  branched: { fill: "#eef2ee", stroke: "#4c6b52", text: "#33472f", label: "branched" },
  integer: { fill: "#e4f0e6", stroke: "#2f5233", text: "#1f3a22", label: "integer" },
  infeasible: { fill: "#fbe9e4", stroke: "#a1442b", text: "#7a331f", label: "infeasible" },
  "pruned-bound": { fill: "#f6f4ee", stroke: "#8a8577", text: "#5c584d", label: "pruned (bound)" },
  "pruned-inherited": { fill: "#f6f4ee", stroke: "#8a8577", text: "#5c584d", label: "pruned" },
  unbounded: { fill: "#fdf3d9", stroke: "#a8791a", text: "#6b4e12", label: "unbounded" },
};

interface DrawNode {
  node: BnBNode;
  displayStatus: string;
  x: number;
  y: number;
}

const BOX_W = 108;
const BOX_H = 44;
const X_GAP = 16;
const Y_GAP = 54;

/**
 * Renders the Branch & Bound tree as it stands after `stepIndex` steps: a node appears once its
 * `createdAtStep` has passed, and shows its final status only once `resolvedAtStep` has passed too —
 * so scrubbing through steps regrows the tree exactly as the search built it.
 */
export function BnBTreeView({
  problem,
  tree,
  stepIndex,
  onOpenNode,
}: {
  problem: IPProblem;
  tree: BnBNode[];
  stepIndex: number;
  onOpenNode: (id: number) => void;
}) {
  const [hovered, setHovered] = useState<number | null>(null);
  const visibleIds = useMemo(() => tree.filter((n) => n.createdAtStep <= stepIndex).map((n) => n.id), [tree, stepIndex]);
  const visible = new Set(visibleIds);

  const layout = useMemo(() => {
    // Post-order x-positions (leaves packed left-to-right; a parent centers over its visible children).
    const positions = new Map<number, DrawNode>();
    let cursor = 0;
    const place = (id: number, depth: number) => {
      const node = tree[id];
      const kids = node.children.filter((c) => visible.has(c));
      if (kids.length === 0) {
        positions.set(id, { node, displayStatus: "", x: cursor, y: depth });
        cursor += 1;
      } else {
        kids.forEach((c) => place(c, depth + 1));
        const xs = kids.map((c) => positions.get(c)!.x);
        const x = (Math.min(...xs) + Math.max(...xs)) / 2;
        positions.set(id, { node, displayStatus: "", x, y: depth });
      }
    };
    if (visible.has(0)) place(0, 0);
    positions.forEach((d) => {
      d.displayStatus = d.node.resolvedAtStep !== null && d.node.resolvedAtStep <= stepIndex ? d.node.status : "open";
    });
    return positions;
  }, [tree, stepIndex]);

  if (layout.size === 0) return null;
  const maxX = Math.max(...[...layout.values()].map((d) => d.x));
  const maxY = Math.max(...[...layout.values()].map((d) => d.y));
  const width = (maxX + 1) * (BOX_W + X_GAP);
  const height = (maxY + 1) * (BOX_H + Y_GAP) + 10;

  return (
    <div className="overflow-x-auto rounded border border-rule bg-white p-3">
      <svg width={Math.max(width, 260)} height={height} className="block">
        {/* edges */}
        {[...layout.values()].map(({ node }) => {
          const parent = node.parentId !== null ? layout.get(node.parentId) : undefined;
          const me = layout.get(node.id)!;
          if (!parent) return null;
          const x1 = parent.x * (BOX_W + X_GAP) + BOX_W / 2 + 6;
          const y1 = parent.y * (BOX_H + Y_GAP) + BOX_H + 6;
          const x2 = me.x * (BOX_W + X_GAP) + BOX_W / 2 + 6;
          const y2 = me.y * (BOX_H + Y_GAP) + 6;
          const midY = (y1 + y2) / 2;
          return (
            <g key={`e${node.id}`}>
              <path d={`M ${x1} ${y1} C ${x1} ${midY}, ${x2} ${midY}, ${x2} ${y2}`} fill="none" stroke="#c9c4b8" strokeWidth={1.5} />
              {node.branch && (
                <text x={(x1 + x2) / 2 + (x2 >= x1 ? 6 : -6)} y={midY} fontSize={10} fill="#6b675f" textAnchor={x2 >= x1 ? "start" : "end"}>
                  {node.branch.variable} {node.branch.direction} {node.branch.bound}
                </text>
              )}
            </g>
          );
        })}
        {/* nodes */}
        {[...layout.values()].map(({ node, displayStatus, x, y }) => {
          const style = STATUS_STYLE[displayStatus] ?? STATUS_STYLE.open;
          const px = x * (BOX_W + X_GAP) + 6;
          const py = y * (BOX_H + Y_GAP) + 6;
          const isHover = hovered === node.id;
          return (
            <g key={node.id} transform={`translate(${px},${py})`} className="cursor-pointer" onClick={() => onOpenNode(node.id)} onMouseEnter={() => setHovered(node.id)} onMouseLeave={() => setHovered(null)}>
              <rect width={BOX_W} height={BOX_H} rx={5} fill={style.fill} stroke={style.stroke} strokeWidth={isHover ? 2.5 : 1.25} />
              <text x={BOX_W / 2} y={16} fontSize={11} fontWeight={600} textAnchor="middle" fill={style.text}>
                P{node.id}
              </text>
              <text x={BOX_W / 2} y={30} fontSize={9.5} textAnchor="middle" fill={style.text}>
                {node.lpValue !== null ? `Z=${round(node.lpValue)}` : style.label}
              </text>
              <text x={BOX_W / 2} y={41} fontSize={8} textAnchor="middle" fill={style.text} opacity={0.75}>
                {style.label}
              </text>
            </g>
          );
        })}
      </svg>
      <p className="mt-2 text-xs text-graphite/70">Click a subproblem to see its LP relaxation and bounds{visible.has(0) ? "" : "."}</p>
      <TreeLegend />
      {hovered !== null && (
        <p className="mt-1 font-mono text-xs text-graphite">{boundsText(problem, tree[hovered].lb, tree[hovered].ub) || "(root — original constraints)"}</p>
      )}
    </div>
  );
}

function round(exactStr: string): string {
  if (!exactStr.includes("/")) return exactStr;
  const [n, d] = exactStr.split("/").map(Number);
  return (n / d).toFixed(2);
}

function TreeLegend() {
  const order = ["integer", "branched", "pruned-bound", "infeasible", "unbounded", "open"];
  return (
    <div className="mt-2 flex flex-wrap gap-2 text-[10px]">
      {order.map((k) => {
        const s = STATUS_STYLE[k];
        return (
          <span key={k} className="flex items-center gap-1 rounded-full px-2 py-0.5" style={{ backgroundColor: s.fill, color: s.text, border: `1px solid ${s.stroke}` }}>
            {s.label}
          </span>
        );
      })}
    </div>
  );
}
