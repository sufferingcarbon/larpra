import { ChevronLeft, ChevronRight, Play, Pause, SkipForward, RotateCcw } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface StepControlsProps {
  index: number;
  total: number;
  onChange: (index: number) => void;
  onShowFullSolution: () => void;
  onReset: () => void;
}

export function StepControls({ index, total, onChange, onShowFullSolution, onReset }: StepControlsProps) {
  const [playing, setPlaying] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (playing) {
      timer.current = setInterval(() => {
        onChange(Math.min(index + 1, total - 1));
      }, 1100);
    }
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, index, total]);

  useEffect(() => {
    if (index >= total - 1 && playing) setPlaying(false);
  }, [index, total, playing]);

  return (
    <div className="flex flex-wrap items-center gap-2 border-t border-rule bg-ledger/60 px-4 py-3 print:hidden">
      <button
        className="focus-ring flex items-center gap-1 rounded border border-rule bg-white px-3 py-1.5 text-sm text-ink hover:border-forest disabled:opacity-40"
        onClick={() => onChange(Math.max(0, index - 1))}
        disabled={index === 0}
      >
        <ChevronLeft size={16} /> Previous
      </button>
      <button
        className="focus-ring flex items-center gap-1 rounded border border-rule bg-white px-3 py-1.5 text-sm text-ink hover:border-forest disabled:opacity-40"
        onClick={() => onChange(Math.min(total - 1, index + 1))}
        disabled={index >= total - 1}
      >
        Next <ChevronRight size={16} />
      </button>
      <button
        className="focus-ring flex items-center gap-1 rounded border border-rule bg-white px-3 py-1.5 text-sm text-ink hover:border-forest disabled:opacity-40"
        onClick={() => setPlaying((p) => !p)}
        disabled={index >= total - 1}
      >
        {playing ? <Pause size={16} /> : <Play size={16} />} {playing ? "Pause" : "Auto Play"}
      </button>
      <button
        className="focus-ring flex items-center gap-1 rounded border border-forest bg-forest px-3 py-1.5 text-sm text-white hover:bg-forestDark"
        onClick={onShowFullSolution}
      >
        <SkipForward size={16} /> Show Full Solution
      </button>
      <button
        className="focus-ring ml-auto flex items-center gap-1 rounded border border-rule bg-white px-3 py-1.5 text-sm text-graphite hover:border-sienna hover:text-sienna"
        onClick={() => {
          setPlaying(false);
          onReset();
        }}
      >
        <RotateCcw size={16} /> Reset
      </button>
      <span className="w-full text-xs text-graphite sm:w-auto sm:ml-2">
        Step {index + 1} of {total}
      </span>
    </div>
  );
}
