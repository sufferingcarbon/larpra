import {
  SquareFunction,
  Truck,
  Users,
  Boxes,
  Network,
  Route,
  GanttChartSquare,
  Clock,
  Swords,
  Grid3x3,
  BookOpen,
  Menu,
  X,
  LucideIcon,
} from "lucide-react";
import { useState } from "react";

export type ModuleId =
  | "dashboard"
  | "lp"
  | "transportation"
  | "assignment"
  | "integer"
  | "network"
  | "tsp"
  | "cpm"
  | "queuing"
  | "game"
  | "matrix"
  | "help";

interface ModuleDef {
  id: ModuleId;
  label: string;
  icon: LucideIcon;
  ready: boolean;
}

export const modules: ModuleDef[] = [
  { id: "lp", label: "Linear Programming", icon: SquareFunction, ready: true },
  { id: "transportation", label: "Transportation Problem", icon: Truck, ready: true },
  { id: "assignment", label: "Assignment Problem", icon: Users, ready: true },
  { id: "network", label: "Network & Routing", icon: Network, ready: true },
  { id: "tsp", label: "Traveling Salesman", icon: Route, ready: true },
  { id: "cpm", label: "CPM / PERT", icon: GanttChartSquare, ready: true },
  { id: "integer", label: "Integer Programming", icon: Boxes, ready: true },
  { id: "queuing", label: "Queuing Models", icon: Clock, ready: true },
  { id: "game", label: "Game Theory", icon: Swords, ready: true },
  { id: "matrix", label: "Matrix / Linear Equations", icon: Grid3x3, ready: true },
  { id: "help", label: "Algorithm Reference", icon: BookOpen, ready: true },
];

interface SidebarProps {
  active: ModuleId;
  onSelect: (id: ModuleId) => void;
}

export function Sidebar({ active, onSelect }: SidebarProps) {
  const [open, setOpen] = useState(false);

  const content = (
    <nav className="flex h-full flex-col bg-ink text-paper">
      <button
        className="focus-ring flex items-center gap-2 px-5 py-5 text-left"
        onClick={() => {
          onSelect("dashboard");
          setOpen(false);
        }}
      >
        <span className="font-display text-lg font-semibold tracking-tight">larpra</span>
      </button>
      <p className="px-5 pb-4 text-xs leading-relaxed text-paper/50">
        An Operations Research lab, worked out in the open — every tableau, every iteration.
      </p>
      <ul className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-4">
        {modules.map((m) => {
          const Icon = m.icon;
          const isActive = active === m.id;
          return (
            <li key={m.id}>
              <button
                className={`focus-ring flex w-full items-center gap-3 rounded px-3 py-2 text-left text-sm transition-colors ${
                  isActive ? "bg-forest text-white" : "text-paper/80 hover:bg-white/10"
                }`}
                onClick={() => {
                  onSelect(m.id);
                  setOpen(false);
                }}
              >
                <Icon size={16} />
                <span className="flex-1">{m.label}</span>
                {!m.ready && (
                  <span className="rounded-full bg-white/10 px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-paper/50">
                    soon
                  </span>
                )}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );

  return (
    <>
      <div className="hidden w-64 shrink-0 md:block print:hidden">{content}</div>
      <div className="flex items-center justify-between border-b border-rule bg-ink px-4 py-3 md:hidden print:hidden">
        <span className="font-display text-lg font-semibold text-paper">larpra</span>
        <button className="focus-ring text-paper" onClick={() => setOpen(true)} aria-label="Open menu">
          <Menu size={22} />
        </button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 shadow-xl">
            <div className="flex justify-end px-3 pt-3">
              <button className="focus-ring text-paper" onClick={() => setOpen(false)} aria-label="Close menu">
                <X size={20} />
              </button>
            </div>
            {content}
          </div>
        </div>
      )}
    </>
  );
}
