import { modules, ModuleId } from "./Sidebar";
import { ArrowRight } from "lucide-react";

export function Dashboard({ onSelect }: { onSelect: (id: ModuleId) => void }) {
  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="font-display text-3xl font-semibold text-ink">larpra</h1>
      <p className="mt-2 max-w-xl text-graphite">
        A from-scratch Operations Research lab for the browser: pick a module, enter a problem, and
        step through the actual algorithm — the same engine that solves the problem also drives
        every "Next Step" click, so the two never disagree.
      </p>
      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        {modules.map((m) => {
          const Icon = m.icon;
          return (
            <button
              key={m.id}
              onClick={() => onSelect(m.id)}
              className={`focus-ring group flex items-center justify-between rounded border px-4 py-3 text-left transition-colors ${
                m.ready
                  ? "border-rule bg-white hover:border-forest"
                  : "border-rule/60 bg-white/40 text-graphite/70"
              }`}
            >
              <span className="flex items-center gap-3">
                <Icon size={18} />
                <span className="text-sm font-medium">{m.label}</span>
              </span>
              {m.ready ? (
                <ArrowRight size={16} className="text-graphite transition-transform group-hover:translate-x-0.5" />
              ) : (
                <span className="text-[10px] uppercase tracking-wide text-graphite/60">soon</span>
              )}
            </button>
          );
        })}
      </div>
      <p className="mt-8 text-xs text-graphite/70">
        Linear Programming (graphical + two-phase simplex), Transportation (NW Corner/Least
        Cost/VAM + MODI), Assignment (Hungarian algorithm), Network & Routing (Dijkstra, Kruskal/
        Prim, Edmonds-Karp), Traveling Salesman (Nearest Neighbor + exact Branch and Bound),
        CPM / PERT (forward and backward passes, slack, every critical path, PERT variance),
        Integer Programming (exact Branch &amp; Bound, reusing the same simplex engine for every
        subproblem), Queuing Models (M/M/1 and M/M/c, exact Erlang-C/B formulas), Game
        Theory (best responses, dominance, zero-sum LPs, exact support-enumeration Nash
        equilibria), and Matrix / Linear Equations (Gaussian elimination, cofactor-expansion
        determinants, Gauss-Jordan inverses, rank/nullspace, and eigenvalues/eigenvectors, all in
        exact fractions) are implemented and tested.
      </p>
    </div>
  );
}
