import { SimplexTableauState } from "../../algorithms/lp/simplex";

export function SimplexView({ state }: { state: SimplexTableauState }) {
  const { columns, basisVars, rows, rhs, cj, zj, cjMinusZj, ratios, enteringCol, leavingRow } = state;

  return (
    <div className="overflow-x-auto">
      <div className="mb-2 flex flex-wrap items-center gap-3 text-xs">
        <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">
          Phase {state.phase}
        </span>
        <span className="font-mono text-graphite">Z = {state.objectiveValue}</span>
        {state.isOptimal && (
          <span className="rounded-full bg-forest/15 px-2.5 py-1 font-medium text-forestDark">Optimal</span>
        )}
        {state.tie && (
          <span className="rounded-full bg-gold/20 px-2.5 py-1 font-medium text-gold">Tied ratio (degenerate)</span>
        )}
      </div>
      <table className="ledger-table min-w-full">
        <thead>
          <tr>
            <th className="text-left">Basis</th>
            {columns.map((c, j) => (
              <th key={c} className={j === enteringCol ? "bg-forest/20" : ""}>
                {c}
              </th>
            ))}
            <th>RHS</th>
            {ratios.length > 0 && <th>Ratio</th>}
          </tr>
        </thead>
        <tbody>
          <tr className="bg-ledger/40">
            <th className="text-left font-sans font-medium text-graphite">Cj</th>
            {cj.map((v, j) => (
              <td key={j} className={j === enteringCol ? "bg-forest/10 font-semibold" : ""}>
                {v}
              </td>
            ))}
            <td />
            {ratios.length > 0 && <td />}
          </tr>
          {rows.map((row, i) => (
            <tr key={i} className={i === leavingRow ? "bg-sienna/10" : ""}>
              <th className="text-left font-sans font-medium">
                {basisVars[i]}
                {i === leavingRow && <span className="ml-1 text-[10px] text-sienna">leaves</span>}
              </th>
              {row.map((v, j) => (
                <td
                  key={j}
                  className={
                    i === leavingRow && j === enteringCol
                      ? "bg-sienna/30 font-semibold"
                      : j === enteringCol
                      ? "bg-forest/10"
                      : ""
                  }
                >
                  {v}
                </td>
              ))}
              <td className="font-semibold">{rhs[i]}</td>
              {ratios.length > 0 && <td>{ratios[i] ?? "—"}</td>}
            </tr>
          ))}
          <tr className="bg-ledger">
            <th className="text-left font-sans font-medium text-graphite">Zj</th>
            {zj.map((v, j) => (
              <td key={j}>{v}</td>
            ))}
            <td />
            {ratios.length > 0 && <td />}
          </tr>
          <tr className="bg-ledger">
            <th className="text-left font-sans font-medium text-graphite">Cj − Zj</th>
            {cjMinusZj.map((v, j) => (
              <td key={j} className={j === enteringCol ? "bg-forest/20 font-semibold" : ""}>
                {v}
              </td>
            ))}
            <td />
            {ratios.length > 0 && <td />}
          </tr>
        </tbody>
      </table>
      {state.enteringVar && (
        <p className="mt-2 text-xs text-graphite">
          Entering variable: <span className="font-mono font-semibold text-forestDark">{state.enteringVar}</span>
          {state.leavingVar && (
            <>
              {" "}
              · Leaving variable: <span className="font-mono font-semibold text-sienna">{state.leavingVar}</span>
            </>
          )}
          {state.pivotElement && (
            <>
              {" "}
              · Pivot element: <span className="font-mono font-semibold">{state.pivotElement}</span>
            </>
          )}
        </p>
      )}
    </div>
  );
}
