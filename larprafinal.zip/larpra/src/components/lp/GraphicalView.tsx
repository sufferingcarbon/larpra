import { useState } from "react";
import { GraphicalState } from "../../algorithms/lp/graphical";

const W = 520;
const H = 420;
const PAD = 40;

type Pt = { x: number; y: number };

function clipSegment(a: number, b: number, c: number, maxX: number, maxY: number) {
  // Line: a*x + b*y = c. Find where it crosses the plot rectangle [0,maxX] x [0,maxY].
  const candidates: Pt[] = [];
  if (Math.abs(b) > 1e-9) {
    candidates.push({ x: 0, y: (c - a * 0) / b });
    candidates.push({ x: maxX, y: (c - a * maxX) / b });
  }
  if (Math.abs(a) > 1e-9) {
    candidates.push({ x: (c - b * 0) / a, y: 0 });
    candidates.push({ x: (c - b * maxY) / a, y: maxY });
  }
  const inBounds = candidates.filter(
    (p) => p.x >= -1e-6 && p.x <= maxX + 1e-6 && p.y >= -1e-6 && p.y <= maxY + 1e-6
  );
  if (inBounds.length < 2) return null;
  // Pick the two candidates furthest apart to avoid degenerate zero-length picks at shared corners.
  let best: [Pt, Pt] | null = null;
  let bestDist = -1;
  for (let i = 0; i < inBounds.length; i++) {
    for (let j = i + 1; j < inBounds.length; j++) {
      const d = Math.hypot(inBounds[i].x - inBounds[j].x, inBounds[i].y - inBounds[j].y);
      if (d > bestDist) {
        bestDist = d;
        best = [inBounds[i], inBounds[j]];
      }
    }
  }
  return best;
}

export function GraphicalView({
  state,
  varNames,
}: {
  state: GraphicalState;
  varNames: [string, string];
}) {
  const [active, setActive] = useState<number | null>(null);
  const { maxX, maxY } = state.bounds;

  const sx = (x: number) => PAD + (x / maxX) * (W - 2 * PAD);
  const sy = (y: number) => H - PAD - (y / maxY) * (H - 2 * PAD);

  const polygonPoints = state.vertices.map((v) => `${sx(v.x)},${sy(v.y)}`).join(" ");

  return (
    <div className="rounded border border-rule bg-white p-3">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full bg-grid bg-[length:24px_24px]">
        {/* axes */}
        <line x1={PAD} y1={H - PAD} x2={W - PAD} y2={H - PAD} stroke="#4B5257" strokeWidth={1.5} />
        <line x1={PAD} y1={PAD} x2={PAD} y2={H - PAD} stroke="#4B5257" strokeWidth={1.5} />
        <text x={W - PAD} y={H - PAD + 18} fontSize={11} textAnchor="end" fill="#4B5257" fontFamily="IBM Plex Mono">
          {varNames[0]}
        </text>
        <text x={PAD - 8} y={PAD - 6} fontSize={11} textAnchor="start" fill="#4B5257" fontFamily="IBM Plex Mono">
          {varNames[1]}
        </text>

        {/* feasible region */}
        {state.vertices.length >= 3 && (
          <polygon points={polygonPoints} fill="#2F6B4F" fillOpacity={0.16} stroke="#2F6B4F" strokeWidth={1.5} />
        )}

        {/* constraint lines */}
        {state.lines.map((line, i) => {
          const seg = clipSegment(line.a, line.b, line.c, maxX, maxY);
          if (!seg) return null;
          const isAxis = line.label.includes("= 0");
          return (
            <line
              key={i}
              x1={sx(seg[0].x)}
              y1={sy(seg[0].y)}
              x2={sx(seg[1].x)}
              y2={sy(seg[1].y)}
              stroke={isAxis ? "#D8D4C6" : "#B08A2E"}
              strokeWidth={isAxis ? 1 : 1.5}
              strokeDasharray={isAxis ? "3 3" : undefined}
            />
          );
        })}

        {/* corner points */}
        {state.vertices.map((v, i) => {
          const isOptimal = state.optimalIndex === i;
          return (
            <g key={i} onClick={() => setActive(i)} className="cursor-pointer">
              <circle
                cx={sx(v.x)}
                cy={sy(v.y)}
                r={isOptimal ? 6 : 4.5}
                fill={isOptimal ? "#B5482A" : "#161B22"}
                stroke="white"
                strokeWidth={1.5}
              />
              {(active === i || isOptimal) && (
                <text
                  x={sx(v.x) + 8}
                  y={sy(v.y) - 8}
                  fontSize={11}
                  fontFamily="IBM Plex Mono"
                  fill="#161B22"
                >
                  ({v.x}, {v.y}){isOptimal ? ` Z=${v.objective}` : ""}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      <p className="mt-2 text-xs text-graphite">
        Tap a corner point to see its coordinates. The highlighted point is the optimal vertex once
        it has been identified.
      </p>
    </div>
  );
}
