import { MaxFlowState } from "../../types/network";
import { GraphViz, GraphVizEdge, GraphVizNode } from "./GraphViz";

export function MaxFlowView({ state, source, sink }: { state: MaxFlowState; source: string; sink: string }) {
  const nodeSet = new Set<string>();
  state.edges.forEach((e) => {
    nodeSet.add(e.from);
    nodeSet.add(e.to);
  });

  const pathEdgeKeys = new Set<string>();
  if (state.augmentingPath) {
    for (let i = 0; i < state.augmentingPath.length - 1; i++) {
      pathEdgeKeys.add(`${state.augmentingPath[i]}|${state.augmentingPath[i + 1]}`);
    }
  }

  const nodes: GraphVizNode[] = Array.from(nodeSet).map((id) => {
    let tone: GraphVizNode["tone"] = "default";
    if (id === source) tone = "source";
    else if (id === sink) tone = "sink";
    else if (state.augmentingPath?.includes(id)) tone = "current";
    return { id, tone };
  });

  const edges: GraphVizEdge[] = state.edges.map((e) => {
    const onPath = pathEdgeKeys.has(`${e.from}|${e.to}`);
    const saturated = e.residual === "0";
    return {
      from: e.from,
      to: e.to,
      label: `${e.flow}/${e.capacity}`,
      tone: onPath ? "path" : saturated ? "rejected" : Number(e.flow) > 0 ? "accepted" : "default",
    };
  });

  return (
    <div className="space-y-3">
      <GraphViz nodes={nodes} edges={edges} directed />
      <div className="mb-1 flex flex-wrap items-center gap-3 text-xs">
        <span className="font-mono text-graphite">Total flow: {state.totalFlow}</span>
        {state.bottleneck !== null && (
          <span className="rounded-full bg-gold/20 px-2.5 py-1 font-medium text-gold">bottleneck = {state.bottleneck}</span>
        )}
      </div>
      {state.augmentingPath && (
        <p className="text-xs text-graphite">
          Augmenting path: <span className="font-mono">{state.augmentingPath.join(" → ")}</span>
        </p>
      )}
      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th className="text-left">Edge</th>
              <th>Capacity</th>
              <th>Flow</th>
              <th>Residual</th>
            </tr>
          </thead>
          <tbody>
            {state.edges.map((e, i) => {
              const onPath = pathEdgeKeys.has(`${e.from}|${e.to}`);
              return (
                <tr key={i} className={onPath ? "bg-sienna/10" : ""}>
                  <th className="text-left font-sans font-normal text-graphite">
                    {e.from}→{e.to}
                  </th>
                  <td className="text-center font-mono">{e.capacity}</td>
                  <td className="text-center font-mono">{e.flow}</td>
                  <td className="text-center font-mono">{e.residual}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
