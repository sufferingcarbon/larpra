import { GraphInput } from "../../types/network";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  graph: GraphInput;
  onChange: (graph: GraphInput) => void;
  errors: string[];
  /** Hide the directed/undirected toggle when the algorithm forces one or the other. */
  lockDirected?: boolean;
}

export function GraphEditor({ graph, onChange, errors, lockDirected }: Props) {
  const addNode = () => {
    let idx = graph.nodes.length + 1;
    let name = `N${idx}`;
    while (graph.nodes.includes(name)) {
      idx += 1;
      name = `N${idx}`;
    }
    onChange({ ...graph, nodes: [...graph.nodes, name] });
  };

  const renameNode = (i: number, name: string) => {
    const oldName = graph.nodes[i];
    const nodes = graph.nodes.map((n, idx) => (idx === i ? name : n));
    const edges = graph.edges.map((e) => ({
      ...e,
      from: e.from === oldName ? name : e.from,
      to: e.to === oldName ? name : e.to,
    }));
    onChange({ ...graph, nodes, edges });
  };

  const removeNode = (i: number) => {
    const name = graph.nodes[i];
    onChange({
      ...graph,
      nodes: graph.nodes.filter((_, idx) => idx !== i),
      edges: graph.edges.filter((e) => e.from !== name && e.to !== name),
    });
  };

  const addEdge = () => {
    if (graph.nodes.length < 1) return;
    onChange({
      ...graph,
      edges: [...graph.edges, { from: graph.nodes[0], to: graph.nodes[Math.min(1, graph.nodes.length - 1)], weight: 1 }],
    });
  };

  const updateEdge = (i: number, patch: Partial<{ from: string; to: string; weight: number }>) => {
    onChange({ ...graph, edges: graph.edges.map((e, idx) => (idx === i ? { ...e, ...patch } : e)) });
  };

  const removeEdge = (i: number) => {
    onChange({ ...graph, edges: graph.edges.filter((_, idx) => idx !== i) });
  };

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      {!lockDirected && (
        <label className="flex items-center gap-2 text-sm text-graphite">
          <input
            type="checkbox"
            checked={graph.directed}
            onChange={(e) => onChange({ ...graph, directed: e.target.checked })}
          />
          Directed graph
        </label>
      )}

      <div>
        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-graphite">Nodes</h4>
        <div className="flex flex-wrap gap-2">
          {graph.nodes.map((n, i) => (
            <div key={i} className="flex items-center gap-1 rounded border border-rule bg-white px-1.5 py-1">
              <input
                className="focus-ring w-14 rounded border-0 bg-transparent px-1 text-center font-mono text-sm"
                value={n}
                onChange={(e) => renameNode(i, e.target.value)}
              />
              <button className="focus-ring text-graphite hover:text-sienna" onClick={() => removeNode(i)} aria-label="Remove node">
                <Trash2 size={12} />
              </button>
            </div>
          ))}
          <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addNode}>
            <Plus size={14} /> Add node
          </button>
        </div>
      </div>

      <div>
        <h4 className="mb-1 text-xs font-semibold uppercase tracking-wide text-graphite">Edges</h4>
        <div className="overflow-x-auto">
          <table className="ledger-table min-w-full">
            <thead>
              <tr>
                <th>From</th>
                <th>To</th>
                <th>Weight</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {graph.edges.map((e, i) => (
                <tr key={i}>
                  <td>
                    <select
                      className="focus-ring rounded border border-rule px-1 py-0.5 font-mono"
                      value={e.from}
                      onChange={(ev) => updateEdge(i, { from: ev.target.value })}
                    >
                      {graph.nodes.map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <select
                      className="focus-ring rounded border border-rule px-1 py-0.5 font-mono"
                      value={e.to}
                      onChange={(ev) => updateEdge(i, { to: ev.target.value })}
                    >
                      {graph.nodes.map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <input
                      type="number"
                      className="focus-ring w-16 rounded border border-rule px-1 py-1 text-right"
                      value={e.weight}
                      onChange={(ev) => updateEdge(i, { weight: Number(ev.target.value) })}
                    />
                  </td>
                  <td>
                    <button
                      className="focus-ring text-graphite hover:text-sienna"
                      onClick={() => removeEdge(i)}
                      aria-label="Remove edge"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <button className="focus-ring mt-2 flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addEdge}>
          <Plus size={14} /> Add edge
        </button>
      </div>
    </div>
  );
}
