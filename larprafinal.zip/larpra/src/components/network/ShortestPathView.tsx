import { GraphInput, ShortestPathState } from "../../types/network";
import { GraphViz, GraphVizEdge, GraphVizNode } from "./GraphViz";

export function ShortestPathView({ graph, state, source }: { graph: GraphInput; state: ShortestPathState; source: string }) {
  const nodes: GraphVizNode[] = graph.nodes.map((id) => {
    const row = state.nodes.find((r) => r.node === id);
    let tone: GraphVizNode["tone"] = "default";
    if (id === source) tone = "source";
    if (state.currentNode === id) tone = "current";
    else if (row?.visited) tone = "visited";
    return { id, tone };
  });

  const edges: GraphVizEdge[] = graph.edges.map((e) => {
    const isConsidered = state.edgeConsidered?.from === e.from && state.edgeConsidered?.to === e.to;
    return {
      from: e.from,
      to: e.to,
      label: String(e.weight),
      tone: isConsidered ? (state.improved ? "accepted" : "considering") : "default",
    };
  });

  return (
    <div className="space-y-3">
      <GraphViz nodes={nodes} edges={edges} directed={graph.directed} />
      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th className="text-left">Node</th>
              <th>Distance</th>
              <th>Predecessor</th>
              <th>Visited</th>
            </tr>
          </thead>
          <tbody>
            {state.nodes.map((row) => (
              <tr key={row.node} className={state.currentNode === row.node ? "bg-gold/10" : ""}>
                <th className="text-left font-sans font-medium">{row.node}</th>
                <td className="text-center font-mono">{row.distance ?? "∞"}</td>
                <td className="text-center font-mono">{row.predecessor ?? "—"}</td>
                <td className="text-center">{row.visited ? "✓" : ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
