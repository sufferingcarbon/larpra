import { useMemo } from "react";

export type NodeTone = "default" | "source" | "sink" | "current" | "visited" | "tree";
export type EdgeTone = "default" | "accepted" | "tree" | "rejected" | "considering" | "path";

export interface GraphVizNode {
  id: string;
  tone?: NodeTone;
}

export interface GraphVizEdge {
  from: string;
  to: string;
  label?: string;
  tone?: EdgeTone;
}

const W = 480;
const H = 340;
const R = 125;
const CX = W / 2;
const CY = H / 2 + 4;

const NODE_COLORS: Record<NodeTone, string> = {
  default: "#161B22",
  source: "#2F6B4F",
  sink: "#B5482A",
  current: "#B08A2E",
  visited: "#2F6B4F",
  tree: "#2F6B4F",
};

const EDGE_COLORS: Record<EdgeTone, string> = {
  default: "#D8D4C6",
  accepted: "#2F6B4F",
  tree: "#2F6B4F",
  rejected: "#B5482A",
  considering: "#B08A2E",
  path: "#B5482A",
};

/** Simple deterministic circular layout — no pan/zoom, but stable and legible for the textbook-sized graphs this lab targets. */
export function GraphViz({ nodes, edges, directed }: { nodes: GraphVizNode[]; edges: GraphVizEdge[]; directed: boolean }) {
  const positions = useMemo(() => {
    const map = new Map<string, { x: number; y: number }>();
    const n = Math.max(nodes.length, 1);
    nodes.forEach((node, i) => {
      const angle = (2 * Math.PI * i) / n - Math.PI / 2;
      map.set(node.id, { x: CX + R * Math.cos(angle), y: CY + R * Math.sin(angle) });
    });
    return map;
  }, [nodes]);

  return (
    <div className="rounded border border-rule bg-white p-3">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full">
        <defs>
          <marker id="network-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 0 L 10 5 L 0 10 z" fill="#4B5257" />
          </marker>
        </defs>
        {edges.map((e, i) => {
          const a = positions.get(e.from);
          const b = positions.get(e.to);
          if (!a || !b) return null;
          const tone = e.tone ?? "default";
          const color = EDGE_COLORS[tone];
          const dx = b.x - a.x;
          const dy = b.y - a.y;
          const len = Math.hypot(dx, dy) || 1;
          const shrink = 17;
          const x2 = b.x - (dx / len) * shrink;
          const y2 = b.y - (dy / len) * shrink;
          const mx = (a.x + x2) / 2;
          const my = (a.y + y2) / 2;
          return (
            <g key={`${e.from}-${e.to}-${i}`}>
              <line
                x1={a.x}
                y1={a.y}
                x2={x2}
                y2={y2}
                stroke={color}
                strokeWidth={tone !== "default" ? 2.75 : 1.5}
                markerEnd={directed ? "url(#network-arrow)" : undefined}
              />
              {e.label && (
                <text x={mx} y={my - 4} fontSize={10} textAnchor="middle" fontFamily="IBM Plex Mono" fill="#4B5257">
                  {e.label}
                </text>
              )}
            </g>
          );
        })}
        {nodes.map((node) => {
          const p = positions.get(node.id);
          if (!p) return null;
          const color = NODE_COLORS[node.tone ?? "default"];
          return (
            <g key={node.id}>
              <circle cx={p.x} cy={p.y} r={15} fill={color} stroke="white" strokeWidth={2} />
              <text x={p.x} y={p.y + 4} fontSize={11} textAnchor="middle" fontFamily="IBM Plex Mono" fill="white">
                {node.id}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
