import { MSTState } from "../../types/network";
import { GraphViz, GraphVizEdge, GraphVizNode } from "./GraphViz";

export function MSTView({ state }: { state: MSTState }) {
  const nodeSet = new Set<string>();
  state.edges.forEach((e) => {
    nodeSet.add(e.from);
    nodeSet.add(e.to);
  });

  const nodes: GraphVizNode[] = Array.from(nodeSet).map((id) => ({
    id,
    tone: state.treeNodes.includes(id) ? "tree" : "default",
  }));

  const edges: GraphVizEdge[] = state.edges.map((e) => {
    const isCurrent = state.currentEdge?.from === e.from && state.currentEdge?.to === e.to;
    let tone: GraphVizEdge["tone"] = "default";
    if (e.status === "accepted") tone = "tree";
    else if (e.status === "rejected-cycle") tone = isCurrent ? "rejected" : "default";
    if (isCurrent && e.status !== "accepted") tone = "considering";
    return { from: e.from, to: e.to, label: e.weight, tone };
  });

  return (
    <div className="space-y-3">
      <GraphViz nodes={nodes} edges={edges} directed={false} />
      <div className="mb-1 flex flex-wrap items-center gap-3 text-xs">
        <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite">
          {state.method === "kruskal" ? "Kruskal's algorithm" : "Prim's algorithm"}
        </span>
        <span className="font-mono text-graphite">Total weight so far: {state.totalWeight}</span>
        <span className="font-mono text-graphite">Tree nodes: {state.treeNodes.length}</span>
      </div>
      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th className="text-left">Edge</th>
              <th>Weight</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {state.edges.map((e, i) => {
              const isCurrent = state.currentEdge?.from === e.from && state.currentEdge?.to === e.to;
              return (
                <tr key={i} className={isCurrent ? "bg-gold/10" : ""}>
                  <th className="text-left font-sans font-normal text-graphite">
                    {e.from}–{e.to}
                  </th>
                  <td className="text-center font-mono">{e.weight}</td>
                  <td className="text-center">
                    {e.status === "accepted" && <span className="font-medium text-forestDark">accepted</span>}
                    {e.status === "rejected-cycle" && <span className="font-medium text-sienna">rejected (cycle)</span>}
                    {e.status === "unconsidered" && <span className="text-graphite/50">—</span>}
                    {e.status === "candidate" && <span className="font-medium text-gold">candidate</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
