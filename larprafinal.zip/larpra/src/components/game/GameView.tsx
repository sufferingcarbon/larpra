import { Equilibrium, GameState, SupportAttempt, SupportOutcome } from "../../types/game";
import { LPProblem } from "../../types/lp";
import { PayoffTable } from "./PayoffTable";
import { SimplexView } from "../lp/SimplexView";
import { solveSimplex } from "../../algorithms/lp/simplex";

export const OUTCOME_LABEL: Record<SupportOutcome, string> = {
  equilibrium: "Equilibrium",
  "no-solution-q": "No solution for q",
  "non-unique-q": "q not unique",
  "nonpositive-q": "q not positive",
  "no-solution-p": "No solution for p",
  "non-unique-p": "p not unique",
  "nonpositive-p": "p not positive",
  "row-deviation": "Row deviates",
  "col-deviation": "Column deviates",
};

const OUTCOME_ORDER: SupportOutcome[] = [
  "equilibrium",
  "no-solution-q",
  "non-unique-q",
  "nonpositive-q",
  "no-solution-p",
  "non-unique-p",
  "nonpositive-p",
  "row-deviation",
  "col-deviation",
];

const set = (names: string[], idx: number[]) => `{${idx.map((i) => names[i]).join(", ")}}`;

/** `expanded` opens the simplex replays (used for the full-solution / print view). */
export function GameView({ state, expanded = false }: { state: GameState; expanded?: boolean }) {
  const showEq = state.equilibria.length > 0 && (state.phase === "pure" || state.phase === "supports" || state.phase === "summary" || state.stepKind === "zero-sum-solution");
  return (
    <div className="space-y-4" data-testid="game-view">
      <PayoffTable state={state} />
      {state.dominance && <DominancePanel state={state} />}
      {state.zeroSumInfo && <ZeroSumPanel state={state} expanded={expanded} />}
      {state.degeneracy && <DegeneracyPanel state={state} />}
      {state.supports && <SupportsPanel state={state} />}
      {showEq && <EquilibriaList equilibria={state.equilibria} state={state} />}
    </div>
  );
}

/* ---------------- dominance ---------------- */

function DominancePanel({ state }: { state: GameState }) {
  const d = state.dominance!;
  const { rowNames, colNames } = state;
  if (d.round === null) {
    return (
      <div className="rounded border border-rule bg-ledger/40 px-3 py-2 text-sm text-graphite">
        <div>
          Player 1: {d.dominantRow ? <b className="text-ink">{rowNames[d.dominantRow.index]}</b> : "no dominant strategy"}
          {d.dominantRow && ` (${d.dominantRow.kind === "strict" ? "strictly" : "weakly"} dominant)`}
        </div>
        <div>
          Player 2: {d.dominantCol ? <b className="text-ink">{colNames[d.dominantCol.index]}</b> : "no dominant strategy"}
          {d.dominantCol && ` (${d.dominantCol.kind === "strict" ? "strictly" : "weakly"} dominant)`}
        </div>
      </div>
    );
  }
  return (
    <div className="rounded border border-rule bg-ledger/40 px-3 py-2 text-sm text-graphite">
      <div className="mb-1 text-xs font-medium uppercase tracking-wide">Round {d.round} — removed simultaneously</div>
      <ul className="list-inside list-disc space-y-0.5">
        {d.eliminations.map((e, i) => {
          const names = e.player === 1 ? rowNames : colNames;
          return (
            <li key={i}>
              Player {e.player}: <b className="text-sienna">{names[e.index]}</b> is strictly dominated by <b className="text-forestDark">{names[e.by]}</b>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/* ---------------- zero-sum ---------------- */

export function formatLP(lp: LPProblem): string[] {
  const term = (c: number, v: string, first: boolean) => {
    const abs = Math.abs(c);
    const body = `${abs === 1 ? "" : abs}${v}`;
    return first ? (c < 0 ? `−${body}` : body) : `${c < 0 ? "−" : "+"} ${body}`;
  };
  const expr = (coeffs: number[]) => {
    const parts: string[] = [];
    coeffs.forEach((c, i) => {
      if (c !== 0) parts.push(term(c, lp.variables[i], parts.length === 0));
    });
    return parts.length ? parts.join(" ") : "0";
  };
  const rel = (r: string) => (r === ">=" ? "≥" : r === "<=" ? "≤" : "=");
  return [
    `${lp.sense === "max" ? "maximize" : "minimize"}  ${expr(lp.objective)}`,
    ...lp.constraints.map((c) => `${expr(c.coeffs)} ${rel(c.relation)} ${c.rhs}${c.label ? `    (${c.label})` : ""}`),
    `${lp.variables.join(", ")} ≥ 0`,
  ];
}

function LPBlock({ title, lp }: { title: string; lp: LPProblem }) {
  return (
    <div className="rounded border border-rule bg-white">
      <div className="border-b border-rule bg-ledger px-3 py-1 text-xs font-medium text-graphite">{title}</div>
      <pre className="overflow-x-auto px-3 py-2 font-mono text-xs leading-relaxed text-ink">{formatLP(lp).join("\n")}</pre>
    </div>
  );
}

/** The LP solved by the app's own exact simplex engine — the same one the Linear Programming module uses — shown tableau by tableau. */
function SimplexReplay({ lp, expanded }: { lp: LPProblem; expanded: boolean }) {
  const result = solveSimplex(lp);
  return (
    <details open={expanded} className="rounded border border-rule bg-white">
      <summary className="cursor-pointer px-3 py-1.5 text-xs font-medium text-graphite hover:text-forestDark">Simplex tableaux ({result.steps.length} steps)</summary>
      <div className="space-y-4 px-3 pb-3 pt-1">
        {result.steps.map((st, i) => (
          <div key={i}>
            <div className="mb-1 text-xs font-medium text-ink">
              {i + 1}. {st.title}
            </div>
            <SimplexView state={st.state} />
          </div>
        ))}
      </div>
    </details>
  );
}

function ZeroSumPanel({ state, expanded }: { state: GameState; expanded: boolean }) {
  const z = state.zeroSumInfo!;
  const { rowNames, colNames } = state;
  const isSecurity = state.stepKind === "security";
  return (
    <div className="space-y-3">
      {isSecurity && (
        <div className="grid gap-3 sm:grid-cols-2">
          <table className="ledger-table w-full">
            <thead>
              <tr>
                <th className="text-left">Player 1 row</th>
                <th>Worst case (row minimum)</th>
              </tr>
            </thead>
            <tbody>
              {rowNames.map((r, i) => (
                <tr key={i} className={z.maximinRows.includes(i) ? "bg-forest/15" : ""}>
                  <th className="text-left">{r}</th>
                  <td>{z.rowMins[i]}</td>
                </tr>
              ))}
              <tr>
                <th className="text-left">Maximin</th>
                <td className="font-semibold">{z.maximin}</td>
              </tr>
            </tbody>
          </table>
          <table className="ledger-table w-full">
            <thead>
              <tr>
                <th className="text-left">Player 2 column</th>
                <th>Player 1's best (column maximum)</th>
              </tr>
            </thead>
            <tbody>
              {colNames.map((c, j) => (
                <tr key={j} className={z.minimaxCols.includes(j) ? "bg-sienna/10" : ""}>
                  <th className="text-left">{c}</th>
                  <td>{z.colMaxs[j]}</td>
                </tr>
              ))}
              <tr>
                <th className="text-left">Minimax</th>
                <td className="font-semibold">{z.minimax}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
      {(state.stepKind === "lp-row" || state.stepKind === "lp-col" || state.stepKind === "zero-sum-solution") && z.rowLP && (
        <LPBlock title={`Player 1's LP${z.shift && z.shift !== "0" ? ` (payoffs shifted by +${z.shift})` : ""}`} lp={z.rowLP} />
      )}
      {state.stepKind === "lp-row" && z.rowLP && <SimplexReplay lp={z.rowLP} expanded={expanded} />}
      {(state.stepKind === "lp-col" || state.stepKind === "zero-sum-solution") && z.colLP && <LPBlock title="Player 2's LP (the dual)" lp={z.colLP} />}
      {state.stepKind === "lp-col" && z.colLP && <SimplexReplay lp={z.colLP} expanded={expanded} />}
      {state.stepKind === "zero-sum-solution" && z.p && z.q && (
        <div className="rounded border border-forest/40 bg-forest/10 px-3 py-2 text-sm text-forestDark">
          <div>
            Value of the game: <b className="font-mono">{z.value}</b> · Σy = Σz = <span className="font-mono">{z.rowLPObjective}</span>
          </div>
          <div className="font-mono text-xs">
            p = ({z.p.join(", ")}) · q = ({z.q.join(", ")})
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- degeneracy ---------------- */

function DegeneracyPanel({ state }: { state: GameState }) {
  const d = state.degeneracy!;
  return (
    <div className={`rounded border px-3 py-2 text-sm ${d.degenerate ? "border-gold/50 bg-gold/10 text-gold" : "border-rule bg-ledger/40 text-graphite"}`}>
      {d.degenerate ? (
        <>
          <b>Degenerate game.</b> {d.witness}
        </>
      ) : (
        <>
          <b className="text-ink">Nondegenerate game</b> — no strategy has more best responses than its support size, so the number of equilibria is odd and equal-size support enumeration finds all of them.
        </>
      )}
    </div>
  );
}

/* ---------------- support enumeration ---------------- */

function AttemptRow({ a, state }: { a: SupportAttempt; state: GameState }) {
  const ok = a.outcome === "equilibrium";
  return (
    <li className={`rounded border px-2 py-1.5 text-xs ${ok ? "border-forest/50 bg-forest/10" : "border-rule bg-white"}`} data-outcome={a.outcome}>
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono">
          {set(state.rowNames, a.rows)} × {set(state.colNames, a.cols)}
        </span>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${ok ? "bg-forest/20 text-forestDark" : "bg-ledger text-graphite"}`}>{OUTCOME_LABEL[a.outcome]}</span>
      </div>
      <div className="mt-0.5 text-graphite">{a.detail}</div>
      {a.equations.length > 0 && (
        <details className="mt-1">
          <summary className="cursor-pointer text-graphite/80 hover:text-forestDark">Indifference equations</summary>
          <pre className="mt-1 overflow-x-auto font-mono text-[11px] leading-relaxed">{a.equations.join("\n")}</pre>
        </details>
      )}
    </li>
  );
}

function SupportsPanel({ state }: { state: GameState }) {
  const s = state.supports!;
  const tally = OUTCOME_ORDER.filter((o) => (s.tally[o] ?? 0) > 0);
  return (
    <div className="space-y-2">
      <div className="text-sm text-graphite">
        {s.size === null ? (
          <>
            <b className="font-mono text-ink">{s.pairsTotal}</b> support pairs in total (equal-size subsets of rows and columns).
          </>
        ) : (
          <>
            Size <b className="font-mono text-ink">{s.size}</b>: <b className="font-mono text-ink">{s.pairsThisSize}</b> pair{s.pairsThisSize === 1 ? "" : "s"} tried.
          </>
        )}
      </div>
      {tally.length > 0 && (
        <div className="flex flex-wrap gap-1.5 text-[11px]">
          {tally.map((o) => (
            <span key={o} className={`rounded-full px-2 py-0.5 ${o === "equilibrium" ? "bg-forest/20 text-forestDark" : "bg-ledger text-graphite"}`}>
              {OUTCOME_LABEL[o]}: {s.tally[o]}
            </span>
          ))}
        </div>
      )}
      {s.attempts.length > 0 && (
        <ul className="max-h-96 space-y-1 overflow-y-auto print:max-h-none print:overflow-visible" aria-label="Support pairs tried">
          {s.attempts.map((a, i) => (
            <AttemptRow key={i} a={a} state={state} />
          ))}
        </ul>
      )}
    </div>
  );
}

/* ---------------- equilibria ---------------- */

function Bars({ names, exact, num }: { names: string[]; exact: string[]; num: number[] }) {
  return (
    <div className="space-y-0.5">
      {names.map((name, i) => (
        <div key={i} className="flex items-center gap-2 text-xs">
          <span className="w-16 shrink-0 truncate text-graphite" title={name}>
            {name}
          </span>
          <div className="h-2.5 flex-1 rounded-sm bg-ledger">
            <div className="h-full rounded-sm bg-forest" style={{ width: `${Math.max(0, Math.min(1, num[i])) * 100}%` }} />
          </div>
          <span className="w-14 shrink-0 text-right font-mono">{exact[i]}</span>
        </div>
      ))}
    </div>
  );
}

export function EquilibriaList({ equilibria, state }: { equilibria: Equilibrium[]; state: GameState }) {
  return (
    <div className="space-y-2">
      <div className="text-sm font-medium text-ink">
        Nash equilibri{equilibria.length === 1 ? "um" : "a"} found so far: {equilibria.length}
      </div>
      {equilibria.map((e, k) => (
        <div key={k} className="rounded border border-rule bg-white p-3" data-testid="equilibrium">
          <div className="mb-2 flex flex-wrap items-center gap-2 text-xs">
            <span className="rounded-full bg-forest/15 px-2 py-0.5 font-medium text-forestDark">{e.kind === "pure" ? "Pure" : "Mixed"}</span>
            <span className="font-mono text-graphite">
              payoffs: Player 1 = {e.payoffA}, Player 2 = {e.payoffB}
            </span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-graphite">Player 1 plays</div>
              <Bars names={state.rowNames} exact={e.p} num={e.pNum} />
            </div>
            <div>
              <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-graphite">Player 2 plays</div>
              <Bars names={state.colNames} exact={e.q} num={e.qNum} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
