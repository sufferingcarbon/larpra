import { GameInput } from "../../types/game";
import { MAX_STRATEGIES } from "../../algorithms/game/common";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  problem: GameInput;
  onChange: (problem: GameInput) => void;
  errors: string[];
}

const neg = (x: number) => 0 - x; // avoids −0

/**
 * Two payoff tables side by side (Player 1's and Player 2's). In zero-sum mode Player 2's table is not editable: it is
 * always the negative of Player 1's, and updates as Player 1's is edited.
 */
export function GameInputForm({ problem, onChange, errors }: Props) {
  const m = problem.rowNames.length;
  const n = problem.colNames.length;
  const zs = problem.zeroSum;

  const addRow = () =>
    onChange({
      ...problem,
      rowNames: [...problem.rowNames, `R${m + 1}`],
      payoffA: [...problem.payoffA, problem.colNames.map(() => 0)],
      payoffB: [...problem.payoffB, problem.colNames.map(() => 0)],
    });
  const removeRow = (i: number) =>
    onChange({
      ...problem,
      rowNames: problem.rowNames.filter((_, k) => k !== i),
      payoffA: problem.payoffA.filter((_, k) => k !== i),
      payoffB: problem.payoffB.filter((_, k) => k !== i),
    });
  const addCol = () =>
    onChange({
      ...problem,
      colNames: [...problem.colNames, `C${n + 1}`],
      payoffA: problem.payoffA.map((r) => [...r, 0]),
      payoffB: problem.payoffB.map((r) => [...r, 0]),
    });
  const removeCol = (j: number) =>
    onChange({
      ...problem,
      colNames: problem.colNames.filter((_, k) => k !== j),
      payoffA: problem.payoffA.map((r) => r.filter((_, k) => k !== j)),
      payoffB: problem.payoffB.map((r) => r.filter((_, k) => k !== j)),
    });
  const renameRow = (i: number, name: string) => onChange({ ...problem, rowNames: problem.rowNames.map((x, k) => (k === i ? name : x)) });
  const renameCol = (j: number, name: string) => onChange({ ...problem, colNames: problem.colNames.map((x, k) => (k === j ? name : x)) });

  const setCell = (which: "A" | "B", i: number, j: number, value: number) => {
    const upd = (M: number[][]) => M.map((row, ri) => (ri === i ? row.map((c, ci) => (ci === j ? value : c)) : row));
    if (which === "A") {
      onChange({ ...problem, payoffA: upd(problem.payoffA), payoffB: zs ? problem.payoffB.map((row, ri) => (ri === i ? row.map((c, ci) => (ci === j ? neg(value) : c)) : row)) : problem.payoffB });
    } else {
      onChange({ ...problem, payoffB: upd(problem.payoffB) });
    }
  };

  const setZeroSum = (on: boolean) =>
    onChange({ ...problem, zeroSum: on, payoffB: on ? problem.payoffA.map((r) => r.map(neg)) : problem.payoffB });

  const table = (which: "A" | "B") => {
    const M = which === "A" ? problem.payoffA : problem.payoffB;
    const readOnly = which === "B" && zs;
    return (
      <div className="overflow-x-auto">
        <div className="mb-1 text-xs font-medium text-graphite">
          {which === "A" ? "Player 1 (row player) payoffs" : zs ? "Player 2 (column player) payoffs — always the negative of Player 1's" : "Player 2 (column player) payoffs"}
        </div>
        <table className="ledger-table">
          <thead>
            <tr>
              <th></th>
              {problem.colNames.map((name, j) => (
                <th key={j}>
                  {which === "A" ? (
                    <div className="flex items-center justify-center gap-1">
                      <input
                        aria-label={`Column ${j + 1} name`}
                        className="focus-ring w-16 rounded border border-rule bg-white px-1 py-0.5 text-center font-sans"
                        value={name}
                        onChange={(e) => renameCol(j, e.target.value)}
                      />
                      {n > 1 && (
                        <button className="focus-ring text-graphite hover:text-sienna" onClick={() => removeCol(j)} aria-label="Remove column strategy">
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                  ) : (
                    <span className="font-sans">{name}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {problem.rowNames.map((rowName, i) => (
              <tr key={i}>
                <th className="text-left">
                  {which === "A" ? (
                    <div className="flex items-center gap-1">
                      <input
                        aria-label={`Row ${i + 1} name`}
                        className="focus-ring w-16 rounded border border-rule bg-white px-1 py-0.5 font-sans"
                        value={rowName}
                        onChange={(e) => renameRow(i, e.target.value)}
                      />
                      {m > 1 && (
                        <button className="focus-ring text-graphite hover:text-sienna" onClick={() => removeRow(i)} aria-label="Remove row strategy">
                          <Trash2 size={12} />
                        </button>
                      )}
                    </div>
                  ) : (
                    <span className="font-sans">{rowName}</span>
                  )}
                </th>
                {problem.colNames.map((_, j) => (
                  <td key={j}>
                    <input
                      type="number"
                      step="any"
                      aria-label={`${which === "A" ? "Player 1" : "Player 2"} payoff at ${rowName}, ${problem.colNames[j]}`}
                      className={`focus-ring w-16 rounded border border-rule px-1 py-1 text-right ${readOnly ? "bg-ledger/60 text-graphite" : ""}`}
                      value={M[i]?.[j] ?? 0}
                      readOnly={readOnly}
                      onChange={(e) => setCell(which, i, j, Number(e.target.value))}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-4 text-xs text-graphite">
        <span>
          Player 1 strategies: <span className="font-mono font-semibold text-ink">{m}</span>
        </span>
        <span>
          Player 2 strategies: <span className="font-mono font-semibold text-ink">{n}</span>
        </span>
        <label className="flex items-center gap-1.5 text-sm">
          <input type="checkbox" className="focus-ring" checked={zs} onChange={(e) => setZeroSum(e.target.checked)} />
          Zero-sum game (Player 2's payoff = −Player 1's)
        </label>
      </div>

      <div className={`grid gap-4 ${zs ? "" : "lg:grid-cols-2"}`}>
        {table("A")}
        {!zs && table("B")}
      </div>

      <div className="flex gap-3">
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline disabled:opacity-40" onClick={addRow} disabled={m >= MAX_STRATEGIES}>
          <Plus size={14} /> Add Player 1 strategy (row)
        </button>
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline disabled:opacity-40" onClick={addCol} disabled={n >= MAX_STRATEGIES}>
          <Plus size={14} /> Add Player 2 strategy (column)
        </button>
      </div>
      <p className="text-xs text-graphite">At most {MAX_STRATEGIES} strategies per player. Payoffs may be negative or decimal; the solver treats them exactly.</p>
    </div>
  );
}
