import { GameState } from "../../types/game";

/**
 * The bimatrix. Each cell shows "Player 1's payoff, Player 2's payoff". A payoff is underlined when its owner's
 * strategy is a best response in that cell (Player 1 compares down a column, Player 2 across a row); a cell where both
 * are underlined is a pure equilibrium and is shaded. Strategies removed by dominance are struck through and their
 * cells greyed, and the ones being removed in the current round are outlined.
 */
export function PayoffTable({ state }: { state: GameState }) {
  const { rowNames, colNames, a, b, rowBR, colBR, highlightCells, eliminatedRows, eliminatedCols, dominance, zeroSum } = state;
  const isHot = (i: number, j: number) => highlightCells.some(([x, y]) => x === i && y === j);
  const goingRows = new Set((dominance?.eliminations ?? []).filter((e) => e.player === 1).map((e) => e.index));
  const goingCols = new Set((dominance?.eliminations ?? []).filter((e) => e.player === 2).map((e) => e.index));
  const dominatorRows = new Set((dominance?.eliminations ?? []).filter((e) => e.player === 1).map((e) => e.by));
  const dominatorCols = new Set((dominance?.eliminations ?? []).filter((e) => e.player === 2).map((e) => e.by));

  const headCls = (gone: boolean, leaving: boolean, dominator: boolean) =>
    [
      gone ? "bg-graphite/20 text-graphite/50 line-through" : "",
      leaving ? "outline outline-2 -outline-offset-2 outline-sienna" : "",
      dominator ? "outline outline-2 -outline-offset-2 outline-forest" : "",
    ].join(" ");

  return (
    <div className="overflow-x-auto" data-testid="payoff-table">
      <table className="ledger-table min-w-full">
        <thead>
          <tr>
            <th className="text-left">
              {zeroSum ? "Player 1 payoff" : "Player 1, Player 2"}
              <div className="text-[10px] font-normal">rows ↓ · columns →</div>
            </th>
            {colNames.map((c, j) => (
              <th key={j} className={headCls(eliminatedCols.includes(j), goingCols.has(j), dominatorCols.has(j))}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rowNames.map((r, i) => (
            <tr key={i}>
              <th className={`text-left font-sans font-medium ${headCls(eliminatedRows.includes(i), goingRows.has(i), dominatorRows.has(i))}`}>{r}</th>
              {colNames.map((_, j) => {
                const gone = eliminatedRows.includes(i) || eliminatedCols.includes(j);
                const hot = isHot(i, j);
                const rBR = rowBR?.[i]?.[j] ?? false;
                const cBR = colBR?.[i]?.[j] ?? false;
                return (
                  <td
                    key={j}
                    data-cell={`${i}-${j}`}
                    className={`text-center ${gone ? "bg-graphite/10 text-graphite/40" : hot ? "bg-forest/15" : ""}`}
                  >
                    <span className={rBR ? "border-b-2 border-forest font-semibold text-forestDark" : ""} title={rBR ? `${r} is Player 1's best response to ${colNames[j]}` : undefined}>
                      {a[i][j]}
                    </span>
                    {!zeroSum && (
                      <>
                        <span className="text-graphite/60">{" , "}</span>
                        <span className={cBR ? "border-b-2 border-sienna font-semibold text-sienna" : ""} title={cBR ? `${colNames[j]} is Player 2's best response to ${r}` : undefined}>
                          {b[i][j]}
                        </span>
                      </>
                    )}
                    {zeroSum && cBR && <span className="ml-1 text-[10px] text-sienna" title={`${colNames[j]} is Player 2's best response to ${r}`}>●</span>}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {(rowBR || colBR) && (
        <p className="mt-1 text-[11px] text-graphite">
          {zeroSum ? (
            <>
              <span className="border-b-2 border-forest font-semibold text-forestDark">green underline</span> = Player 1's best response to that column;{" "}
              <span className="text-sienna">●</span> = Player 2's best response (smallest payoff to Player 1) to that row.
            </>
          ) : (
            <>
              <span className="border-b-2 border-forest font-semibold text-forestDark">green underline</span> = Player 1 is best-responding (compared down the column);{" "}
              <span className="border-b-2 border-sienna font-semibold text-sienna">red underline</span> = Player 2 is best-responding (compared across the row). Shaded cell = both.
            </>
          )}
        </p>
      )}
    </div>
  );
}
