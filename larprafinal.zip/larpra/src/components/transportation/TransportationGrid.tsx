import { TransportationTableauState } from "../../types/transportation";

function cellKey(i: number, j: number) {
  return `${i}-${j}`;
}

export function TransportationGrid({ state }: { state: TransportationTableauState }) {
  const {
    sourceNames,
    destNames,
    costs,
    allocations,
    isBasic,
    isEpsilon,
    remainingSupply,
    remainingDemand,
    originalSupply,
    originalDemand,
    crossedRows,
    crossedCols,
    selectedCell,
    rowPenalties,
    colPenalties,
    highlightPenaltyRow,
    highlightPenaltyCol,
    u,
    v,
    opportunityCosts,
    enteringCell,
    leavingCell,
    loopPath,
  } = state;

  const loopByCell = new Map<string, "+" | "-">();
  loopPath?.forEach((step) => loopByCell.set(cellKey(step.row, step.col), step.sign));

  const m = sourceNames.length;
  const n = destNames.length;

  return (
    <div className="overflow-x-auto">
      <div className="mb-2 flex flex-wrap items-center gap-3 text-xs">
        <span className="rounded-full bg-ledger px-2.5 py-1 font-medium text-graphite capitalize">
          {state.phase === "modi" ? "MODI" : state.phase === "balance" ? "Balance check" : "Construction"}
        </span>
        <span className="font-mono text-graphite">Cost so far: {state.currentCost}</span>
        <span className="font-mono text-graphite">
          Basic cells: {state.basicCellCount} / {state.requiredBasicCells}
        </span>
        {state.isOptimal && (
          <span className="rounded-full bg-forest/15 px-2.5 py-1 font-medium text-forestDark">Optimal</span>
        )}
        {state.theta && (
          <span className="rounded-full bg-gold/20 px-2.5 py-1 font-medium text-gold">θ = {state.theta}</span>
        )}
      </div>

      <table className="ledger-table min-w-full">
        <thead>
          <tr>
            <th className="text-left">{v ? "vⱼ →" : ""}</th>
            {v && destNames.map((_, j) => <th key={`v-${j}`}>{v[j] ?? "—"}</th>)}
            {v && <th />}
          </tr>
          <tr>
            <th className="text-left">{u ? "uᵢ ↓" : "Source \\ Dest"}</th>
            {destNames.map((name, j) => (
              <th
                key={name}
                className={crossedCols[j] ? "bg-graphite/20 text-graphite/50 line-through" : ""}
              >
                {name}
              </th>
            ))}
            <th>Supply</th>
          </tr>
        </thead>
        <tbody>
          {sourceNames.map((srcName, i) => (
            <tr key={srcName}>
              <th
                className={`text-left font-sans font-medium ${
                  crossedRows[i] ? "bg-graphite/20 text-graphite/50 line-through" : ""
                }`}
              >
                {u ? `${srcName} (u=${u[i] ?? "—"})` : srcName}
              </th>
              {destNames.map((destName, j) => {
                const key = cellKey(i, j);
                const alloc = allocations[i][j];
                const sign = loopByCell.get(key);
                const isSelected = selectedCell && selectedCell.row === i && selectedCell.col === j;
                const isEntering = enteringCell && enteringCell.row === i && enteringCell.col === j;
                const isLeaving = leavingCell && leavingCell.row === i && leavingCell.col === j;
                const isPenaltyHighlighted =
                  (highlightPenaltyRow === i && highlightPenaltyCol === null) ||
                  (highlightPenaltyCol === j && highlightPenaltyRow === null);
                const opp = opportunityCosts?.[i]?.[j] ?? null;

                let tone = "";
                if (isLeaving) tone = "bg-sienna/25";
                else if (isEntering) tone = "bg-forest/25";
                else if (sign === "+") tone = "bg-forest/10";
                else if (sign === "-") tone = "bg-sienna/10";
                else if (isSelected) tone = "bg-gold/20";
                else if (isPenaltyHighlighted) tone = "bg-gold/10";
                else if (isBasic[i][j]) tone = "bg-ledger/40";

                return (
                  <td key={destName} className={`relative ${tone}`}>
                    <div className="flex flex-col items-end leading-tight">
                      <span className="text-[10px] text-graphite/70">{costs[i][j]}</span>
                      <span className={`text-sm ${isBasic[i][j] ? "font-semibold text-ink" : "text-graphite/40"}`}>
                        {alloc !== null ? alloc : "·"}
                        {isEpsilon[i][j] && <span className="ml-0.5 text-[10px] text-gold">ε</span>}
                      </span>
                      {opp !== null && !isBasic[i][j] && (
                        <span className={`text-[10px] ${opp.startsWith("-") ? "text-sienna" : "text-graphite/50"}`}>
                          Δ={opp}
                        </span>
                      )}
                      {sign && (
                        <span
                          className={`absolute left-1 top-1 text-xs font-bold ${
                            sign === "+" ? "text-forestDark" : "text-sienna"
                          }`}
                        >
                          {sign}
                        </span>
                      )}
                    </div>
                  </td>
                );
              })}
              <td className="font-semibold">
                {remainingSupply[i]}
                {originalSupply && originalSupply[i] !== remainingSupply[i] && (
                  <span className="ml-1 text-[10px] text-graphite/50">/ {originalSupply[i]}</span>
                )}
              </td>
            </tr>
          ))}
          <tr className="bg-ledger/40">
            <th className="text-left font-sans font-medium text-graphite">Demand</th>
            {destNames.map((name, j) => (
              <td key={name} className="font-semibold">
                {remainingDemand[j]}
                {originalDemand && originalDemand[j] !== remainingDemand[j] && (
                  <span className="ml-1 text-[10px] text-graphite/50">/ {originalDemand[j]}</span>
                )}
              </td>
            ))}
            <td />
          </tr>
          {rowPenalties && (
            <tr className="bg-gold/5">
              <th className="text-left font-sans font-medium text-graphite" colSpan={n + 2}>
                Row penalties: {sourceNames.map((s, i) => `${s}=${rowPenalties[i] ?? "—"}`).join("  ·  ")}
              </th>
            </tr>
          )}
          {colPenalties && (
            <tr className="bg-gold/5">
              <th className="text-left font-sans font-medium text-graphite" colSpan={n + 2}>
                Column penalties: {destNames.map((d, j) => `${d}=${colPenalties[j] ?? "—"}`).join("  ·  ")}
              </th>
            </tr>
          )}
        </tbody>
      </table>

      {state.dummyNote && (
        <p className="mt-2 text-xs text-graphite">
          <span className="font-medium text-forestDark">Dummy added:</span> {state.dummyNote}
        </p>
      )}
      {state.degenerateNote && (
        <p className="mt-2 text-xs text-graphite">
          <span className="font-medium text-gold">Degeneracy:</span> {state.degenerateNote}
        </p>
      )}
      {loopPath && (
        <p className="mt-2 text-xs text-graphite">
          Loop: {loopPath.map((c) => `(${sourceNames[c.row]}, ${destNames[c.col]})${c.sign}`).join(" → ")}
        </p>
      )}
    </div>
  );
}
