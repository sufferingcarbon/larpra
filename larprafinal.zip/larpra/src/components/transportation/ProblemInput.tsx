import { TransportationProblemInput } from "../../types/transportation";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  problem: TransportationProblemInput;
  onChange: (problem: TransportationProblemInput) => void;
  errors: string[];
}

export function ProblemInput({ problem, onChange, errors }: Props) {
  const addSource = () => {
    const idx = problem.sourceNames.length + 1;
    onChange({
      ...problem,
      sourceNames: [...problem.sourceNames, `S${idx}`],
      supply: [...problem.supply, 0],
      costs: [...problem.costs, problem.destNames.map(() => 0)],
    });
  };

  const removeSource = (i: number) => {
    onChange({
      ...problem,
      sourceNames: problem.sourceNames.filter((_, idx) => idx !== i),
      supply: problem.supply.filter((_, idx) => idx !== i),
      costs: problem.costs.filter((_, idx) => idx !== i),
    });
  };

  const addDest = () => {
    const idx = problem.destNames.length + 1;
    onChange({
      ...problem,
      destNames: [...problem.destNames, `D${idx}`],
      demand: [...problem.demand, 0],
      costs: problem.costs.map((row) => [...row, 0]),
    });
  };

  const removeDest = (j: number) => {
    onChange({
      ...problem,
      destNames: problem.destNames.filter((_, idx) => idx !== j),
      demand: problem.demand.filter((_, idx) => idx !== j),
      costs: problem.costs.map((row) => row.filter((_, idx) => idx !== j)),
    });
  };

  const updateSourceName = (i: number, name: string) => {
    onChange({ ...problem, sourceNames: problem.sourceNames.map((n, idx) => (idx === i ? name : n)) });
  };
  const updateDestName = (j: number, name: string) => {
    onChange({ ...problem, destNames: problem.destNames.map((n, idx) => (idx === j ? name : n)) });
  };
  const updateSupply = (i: number, value: number) => {
    onChange({ ...problem, supply: problem.supply.map((s, idx) => (idx === i ? value : s)) });
  };
  const updateDemand = (j: number, value: number) => {
    onChange({ ...problem, demand: problem.demand.map((d, idx) => (idx === j ? value : d)) });
  };
  const updateCost = (i: number, j: number, value: number) => {
    onChange({
      ...problem,
      costs: problem.costs.map((row, ri) => (ri === i ? row.map((c, ci) => (ci === j ? value : c)) : row)),
    });
  };

  const totalSupply = problem.supply.reduce((a, b) => a + (Number.isFinite(b) ? b : 0), 0);
  const totalDemand = problem.demand.reduce((a, b) => a + (Number.isFinite(b) ? b : 0), 0);

  return (
    <div className="space-y-4">
      {errors.length > 0 && (
        <div className="rounded border border-sienna/40 bg-sienna/10 px-3 py-2 text-sm text-sienna">
          <ul className="list-inside list-disc space-y-0.5">
            {errors.map((e, i) => (
              <li key={i}>{e}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="flex items-center gap-4 text-xs text-graphite">
        <span>
          Total supply: <span className="font-mono font-semibold text-ink">{totalSupply}</span>
        </span>
        <span>
          Total demand: <span className="font-mono font-semibold text-ink">{totalDemand}</span>
        </span>
        {totalSupply !== totalDemand && (
          <span className="rounded-full bg-gold/15 px-2 py-0.5 font-medium text-gold">
            Unbalanced — a dummy {totalSupply > totalDemand ? "destination" : "source"} will be added automatically
          </span>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="ledger-table min-w-full">
          <thead>
            <tr>
              <th></th>
              {problem.destNames.map((name, j) => (
                <th key={j}>
                  <div className="flex items-center justify-center gap-1">
                    <input
                      className="focus-ring w-16 rounded border border-rule bg-white px-1 py-0.5 text-center font-sans"
                      value={name}
                      onChange={(e) => updateDestName(j, e.target.value)}
                    />
                    {problem.destNames.length > 1 && (
                      <button
                        className="focus-ring text-graphite hover:text-sienna"
                        onClick={() => removeDest(j)}
                        aria-label="Remove destination"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </th>
              ))}
              <th>Supply</th>
            </tr>
          </thead>
          <tbody>
            {problem.sourceNames.map((srcName, i) => (
              <tr key={i}>
                <th className="text-left">
                  <div className="flex items-center gap-1">
                    <input
                      className="focus-ring w-16 rounded border border-rule bg-white px-1 py-0.5 font-sans"
                      value={srcName}
                      onChange={(e) => updateSourceName(i, e.target.value)}
                    />
                    {problem.sourceNames.length > 1 && (
                      <button
                        className="focus-ring text-graphite hover:text-sienna"
                        onClick={() => removeSource(i)}
                        aria-label="Remove source"
                      >
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </th>
                {problem.destNames.map((_, j) => (
                  <td key={j}>
                    <input
                      type="number"
                      className="focus-ring w-14 rounded border border-rule px-1 py-1 text-right"
                      value={problem.costs[i]?.[j] ?? 0}
                      onChange={(e) => updateCost(i, j, Number(e.target.value))}
                    />
                  </td>
                ))}
                <td>
                  <input
                    type="number"
                    className="focus-ring w-16 rounded border border-rule px-1 py-1 text-right"
                    value={problem.supply[i] ?? 0}
                    onChange={(e) => updateSupply(i, Number(e.target.value))}
                  />
                </td>
              </tr>
            ))}
            <tr className="bg-ledger/40">
              <th className="text-left font-sans font-medium text-graphite">Demand</th>
              {problem.destNames.map((_, j) => (
                <td key={j}>
                  <input
                    type="number"
                    className="focus-ring w-14 rounded border border-rule px-1 py-1 text-right"
                    value={problem.demand[j] ?? 0}
                    onChange={(e) => updateDemand(j, Number(e.target.value))}
                  />
                </td>
              ))}
              <td />
            </tr>
          </tbody>
        </table>
      </div>

      <div className="flex gap-3">
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addSource}>
          <Plus size={14} /> Add source
        </button>
        <button className="focus-ring flex items-center gap-1 text-xs font-medium text-forest hover:underline" onClick={addDest}>
          <Plus size={14} /> Add destination
        </button>
      </div>
    </div>
  );
}
