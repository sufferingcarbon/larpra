# larpra

A modern, from-scratch Operations Research lab for the browser — a spiritual (not code or
branding) replacement for TORA-style university OR labs. Every algorithm is reimplemented from
first principles; nothing here is copied from TORA.

**Milestone 1** (Linear Programming: graphical method + two-phase simplex), **Milestone 2**
(Transportation: NW Corner/Least Cost/VAM + MODI), **Assignment** (Hungarian algorithm),
**Network & Routing** (Dijkstra shortest path, Kruskal/Prim minimum spanning tree, Edmonds-Karp
maximum flow), **Traveling Salesman** (Nearest Neighbor heuristic + exact Branch and Bound),
**CPM / PERT** (forward and backward passes, slack, every critical path, PERT expected durations
and project variance), **Integer Programming** (exact Branch and Bound reusing the simplex
engine), **Queuing Models** (M/M/1 and M/M/c, exact Erlang-C/B formulas), **Game Theory**
(two-player normal-form games: best responses, pure equilibria, iterated dominance, zero-sum
minimax LPs, and every mixed Nash equilibrium by exact support enumeration), and **Matrix / Linear
Equations** (Gaussian elimination and back-substitution, cofactor-expansion determinants,
Gauss-Jordan inverses, rank and nullspace, and eigenvalues/eigenvectors for small matrices, all in
exact fractions) are implemented and tested. All ten dashboard modules are complete as of
Milestone 10.

## Running it

```bash
npm install
npm run dev       # starts Vite on http://localhost:5173
```

```bash
npm run build      # type-checks (tsc -b) and produces a static build in dist/
npm run preview    # serve that build locally
```

## Running the tests

```bash
npm test           # runs the vitest suite once
npm run test:watch # watch mode
```

3,117 tests in 48 files currently cover all ten engines and the save/load layer (the per-module
counts below are from when each milestone landed; Matrix / Linear Equations is described last):

- **Linear Programming** (11 tests): an all-≤ maximization, a ≥ two-phase minimization, an
  equality-constraint (Phase I) problem, infeasibility detection, unboundedness detection,
  alternate optima detection, and input-validation errors — for both the simplex engine and the
  graphical engine, using known corner-point values worked out by hand.
- **Transportation** (32 tests, cross-validated against `scipy.optimize.linprog`): NW Corner,
  Least Cost and VAM all reaching the same optimum via MODI on balanced, unbalanced (dummy row/
  column), and degenerate (ε-basic-cell) problems, plus rendering smoke tests.
- **Assignment** (20 tests, cross-validated against `scipy.optimize.linear_sum_assignment`): a
  hand-verified 4×4, a 5×5, an unbalanced 4×5 case needing several covering/adjustment rounds,
  tie-breaking (alternate optima), exact non-integer costs, and input validation — plus page and
  grid rendering smoke tests for every built-in example.
- **Network & Routing** (26 tests, cross-validated against `networkx`): Dijkstra on a 6-node
  directed graph (including an unreachable-node case and a rejected negative-edge case), Kruskal
  and Prim both reaching networkx's minimum spanning tree weight on two graphs (one engineered to
  force a genuine cycle rejection), and Edmonds-Karp reaching networkx's max-flow value on two
  networks (verified via flow conservation and a min-cut identification whose capacity matches the
  flow) — plus 16 page/view rendering smoke tests across every step of every example.
- **Traveling Salesman** (33 tests, cross-validated against brute-force enumeration of all
  possible tours): exact Branch and Bound reaching the true optimum on a Euclidean 5-city case, a
  6-city symmetric case, and a 5-city asymmetric case, with checks that the search frontier is
  fully exhausted (proving optimality) and that pruning actually occurs; Nearest Neighbor verified
  to always return a valid tour whose cost is never below the true optimum, plus edge cases
  (missing edges, custom start city, tie-breaking determinism) — plus 10 page/view rendering smoke
  tests.
- **CPM / PERT** (104 tests, cross-validated against `networkx` + exact fractions + a `scipy`
  linear program): every ES/EF/LS/LF/slack value, critical path and PERT variance of the six
  built-in examples, plus 150 random DAGs (activities deliberately listed out of topological
  order; 22 of them with tied critical paths) — all compared to an independent implementation that
  finds critical paths by enumerating every source→sink path and checks the project duration with
  an LP. Also: step-by-step emission (nothing appears before it is computed), cycle/reference/
  estimate validation, zero-slack activities joined by a *non-tight* hand-off, floating-point ties,
  the 100-path listing cap, mode switching, and rendering smoke tests for every step of every
  example. The ground truth is regenerated with `python3 tools/cpm_ground_truth.py`
  (needs `networkx` and `scipy`).
- **Game Theory** (1,090 tests, cross-validated against an independent oracle): 94 algorithm tests
  (exact linear algebra incl. a Hilbert-matrix solve; best responses with ties; strict/weak
  dominance and iterated elimination order; the degeneracy test; support enumeration pair
  bookkeeping and rejection reasons; zero-sum security levels, LP construction, strong duality on
  120 random games and the minimax theorem on 100; input validation; invariance under affine
  payoff transforms, transposition and strategy reordering; Wilson's odd-count theorem on 200 random
  nondegenerate games; a 6×6 game inside the time budget), **963 ground-truth checks** over 206
  games (the 11 built-in examples plus seeded random games in six families — small, mid-size,
  large, tie-heavy, zero-sum and symmetric): pure equilibria against brute force, the degeneracy
  verdict against a different (LP-based) definition-level test, the *complete* equilibrium list of
  every nondegenerate game against nashpy's vertex enumeration cross-checked with a separate exact
  Python enumeration, and zero-sum values against `scipy.optimize.linprog` — and 33 page/view
  rendering tests over every step of every example. The oracle deliberately does **not** trust
  nashpy's own `support_enumeration()`, which silently misses equilibria on some nondegenerate
  games (16 of the 98 nondegenerate games in the fixture). Regenerate the fixture with
  `python3 tools/game_ground_truth.py` (needs `numpy`, `scipy` and `nashpy`).
- **Matrix / Linear Equations** (459 tests, cross-validated against an independent oracle): row
  operations, forward/backward elimination phases and RREF properties; Gaussian elimination
  reaching a unique solution, a proven inconsistency, or a free-variable parametrization on 2×2 and
  3×3 systems, with exact re-substitution checks (`Ax = b`) and permutation invariance; determinants
  via the 2×2/3×3 closed forms and the general cofactor expansion, checked against
  `det(AB) = det(A)det(B)`, `det(A⁻¹) = 1/det(A)`, and a battery of pseudo-random matrices; matrix
  inversion via Gauss-Jordan on `[A | I]` verified by an exact `A · A⁻¹ = I` check, plus correct
  rejection of singular matrices; rank and nullspace via RREF, checked against the rank–nullity
  theorem and `A·v = 0` for every basis vector on a battery of matrices; and eigenvalues/eigenvectors
  via an exact Faddeev–LeVerrier characteristic polynomial, rational-root-theorem deflation, the
  exact quadratic formula, and a numeric (Durand-Kerner) fallback for irrational/complex cubic and
  quartic roots — including a defective (non-diagonalizable) matrix, a rotation matrix with purely
  imaginary eigenvalues, and symmetric matrices whose eigenvectors from distinct eigenvalues are
  checked for exact orthogonality. **332 ground-truth checks** cross-validate against an independent
  from-scratch Python exact-`Fraction` Gauss-Jordan/cofactor implementation (not reusing any
  TypeScript code), itself cross-checked against `numpy.linalg.det`/`eigvals`, over 90 cases (the 20
  built-in examples plus 70 seeded random matrices in three families) — plus 43 page/view rendering
  tests over every step of every example. Regenerate the fixture with
  `python3 tools/matrix_ground_truth.py` (needs `numpy`).

## Saving, sharing and printing

Every module page has a **Save & share** card under the Solve/Reset bar:

| Button | What it does |
| --- | --- |
| **Problem (.json)** | Downloads the inputs (and how to solve them: method / mode / start city) as a `larpra` file. |
| **Solution (.json)** | Downloads the same inputs plus the module's *whole result* — every step with its explanation, operation and "why". It is always the problem that was actually solved, even if you edited the form afterwards. |
| **Save as PDF** | Expands the page to the full step-by-step solution and opens the browser's print dialog — choose "Save as PDF". The sidebar, controls and buttons are hidden, inputs print as plain text, tableau highlighting and Gantt/graph colours are kept, and the file name defaults to `larpra-<module>-solution`. The page returns to its previous view afterwards. |
| **Import…** | Loads a problem *or* solution file back into the form (a solution file loads as a problem — press Solve to see the steps again). Files for another module are refused with the module to open. |

**File format (`schemaVersion` 1).** One JSON envelope for all ten modules:

```json
{
  "app": "larpra",
  "schemaVersion": 1,
  "module": "cpm",
  "kind": "problem",
  "exportedAt": "2026-09-20T14:05:09.000Z",
  "options": { "mode": "cpm" },
  "problem": { "activities": [ { "name": "A", "duration": 2, "predecessors": [] } ] },
  "solution": { "…": "only when kind is \"solution\"" }
}
```

`module` is one of `lp`, `transportation`, `assignment`, `network`, `tsp`, `cpm`, `integer`, `queuing`, `game`, `matrix`. `problem` mirrors each module's input form (`network` adds a `type`: `shortest-path`, `mst` or `max-flow`; `queuing` adds a `model`: `mm1` or `mmc`; `matrix` adds an `operation`: `gaussian`, `determinant`, `inverse`, `rank` or `eigen`, and `rhs` only when solving `Ax = b`). `null` means ∞ / "no edge" (only TSP distance cells may be null); a blank CPM cell is simply absent. Exact fractions in a solution are written as strings (`"3/2"`). A file with a *newer* `schemaVersion` is refused with a request to update; older versions will be migrated when the format changes.

**What import checks.** Structure only — the right fields, types, dimensions, allowed values, finite numbers within ±1e12, list/text length limits, and a 5 MB file cap — with messages that name the field (`problem.objective must have 2 values (has 1)`). Unknown keys are dropped, never copied into the app. Whether the problem is *solvable* (balanced, acyclic, non-negative, stable …) is left to each module's own validator, so imported and typed problems get identical messages. Export runs the same check on the finished file, so a half-filled form is refused with the reason instead of producing a file that can't be loaded.

**Tests.** 133 tests cover: every built-in example of every module surviving export → import unchanged (all ten modules, both TSP methods, both LP methods, all three network problems, both queuing models, all five matrix operations); one solution file per module re-solving to a byte-identical result after import; ∞ and blank-cell handling; exact-fraction/bigint serialisation; rejection tests (bad JSON, wrong app, future version, wrong module, malformed fields, out-of-range numbers, a ragged matrix row, a wrong-length right-hand side, an unrecognized matrix operation, a `__proto__` pollution attempt …); and rendering checks for the Save & share card on every page. The print stylesheet is not something vitest can see, so it was verified by driving the built app in headless Chromium (as of Milestone 6): for all eleven module/method combinations then available it downloaded both JSON files, printed a real PDF and confirmed by text extraction that every step title is present and no controls or navigation are, re-imported files in both directions, and checked the rejection messages. Integer Programming, Queuing Models, Game Theory and Matrix / Linear Equations were added afterwards and covered by the same vitest export/import suite, but not re-run through that Playwright pass.

## Project structure

```
src/
  algorithms/
    lp/               standardize.ts, simplex.ts, graphical.ts, examples.ts, __tests__/
    transportation/   standardize.ts, tableau.ts, common.ts, northwestCorner.ts, leastCost.ts,
                       vogel.ts, modi.ts, solve.ts, examples.ts, __tests__/
    assignment/       standardize.ts, tableau.ts, common.ts, hungarian.ts, solve.ts, examples.ts,
                       __tests__/
    network/          graph.ts, dijkstra.ts, mst.ts, maxflow.ts, solve.ts, examples.ts, __tests__/
    tsp/              standardize.ts, nearestNeighbor.ts, branchAndBound.ts, solve.ts, examples.ts,
                       __tests__/
    cpm/              common.ts, standardize.ts, cpm.ts, edit.ts, solve.ts, examples.ts,
                       __tests__/ (incl. fixtures/groundTruth.ts, generated)
    integer/          common.ts, standardize.ts, branchAndBound.ts, solve.ts, examples.ts,
                       examples.data.json, __tests__/
    queuing/          common.ts, erlang.ts, mm1.ts, mmc.ts, waitTimeCurve.ts, solve.ts,
                       examples.ts, __tests__/
    game/             common.ts, linalg.ts, bestResponse.ts, dominance.ts, degeneracy.ts,
                       supportEnumeration.ts, zeroSum.ts, verify.ts, solve.ts, examples.ts,
                       __tests__/ (incl. fixtures/groundTruth.ts, generated)
    matrix/           common.ts, gaussianElimination.ts, linearSystem.ts, determinant.ts,
                       inverse.ts, rank.ts, eigenvalues.ts, solve.ts, examples.ts,
                       __tests__/ (incl. fixtures/groundTruth.ts, generated)
  components/
    Sidebar.tsx, Dashboard.tsx, StepControls.tsx, ExportBar.tsx
    lp/ProblemInput.tsx, lp/GraphicalView.tsx, lp/SimplexView.tsx
    transportation/ProblemInput.tsx, transportation/TransportationGrid.tsx
    assignment/ProblemInput.tsx, assignment/AssignmentGrid.tsx
    network/GraphEditor.tsx, network/GraphViz.tsx, network/ShortestPathView.tsx,
      network/MSTView.tsx, network/MaxFlowView.tsx
    tsp/ProblemInput.tsx, tsp/TSPMap.tsx, tsp/NNView.tsx, tsp/BnBView.tsx
    cpm/ProblemInput.tsx, cpm/CPMView.tsx, cpm/CPMGantt.tsx
    integer/ProblemInput.tsx, integer/BnBTreeView.tsx, integer/NodeDetail.tsx
    queuing/QueuingInputForm.tsx, queuing/QueuingView.tsx, queuing/QueuingCharts.tsx,
      queuing/parseDisplay.ts
    game/GameInputForm.tsx, game/PayoffTable.tsx, game/GameView.tsx
    matrix/ProblemInput.tsx, matrix/MatrixView.tsx
  pages/
    LinearProgramming.tsx, Transportation.tsx, Assignment.tsx, Network.tsx, TSP.tsx, CPM.tsx,
    IntegerProgramming.tsx, Queuing.tsx, Game.tsx, Matrix.tsx, Help.tsx, ComingSoon.tsx, __tests__/
  types/lp.ts, types/transportation.ts, types/assignment.ts, types/network.ts, types/tsp.ts,
    types/cpm.ts, types/integer.ts, types/queuing.ts, types/game.ts, types/matrix.ts
  utils/fraction.ts   exact BigInt-based rational arithmetic shared by every engine
  export/             larpra file format: schema.ts, serialize.ts, validate.ts, file.ts, download.ts, __tests__/
  App.tsx, main.tsx, index.css
tools/
  cpm_ground_truth.py   independent networkx/Fraction/LP ground truth for the CPM tests
  ip_ground_truth.py    independent PuLP/scipy ground truth for the Integer Programming tests
  game_ground_truth.py  independent nashpy/scipy/exact-Fraction ground truth for the Game Theory tests
  matrix_ground_truth.py independent from-scratch exact-Fraction/numpy ground truth for the Matrix tests
```

## How each engine works (short version)

**Linear Programming.** `standardize.ts` turns a raw `LPProblem` (any mix of ≤ / ≥ / =
constraints, max or min) into a standard-form tableau. `simplex.ts` runs the classic **two-phase
method** rather than Big-M, so no symbolic "M" ever has to be represented — Phase I minimizes the
sum of the artificial columns, and Phase II only runs if that minimum is exactly zero. Every pivot
is pushed onto the same `AlgorithmStep[]` array that both "Solve" and "Next Step" read from.

**Transportation.** `standardize.ts` balances supply and demand with a zero-cost dummy row/column
if needed. NW Corner, Least Cost and VAM (`northwestCorner.ts`, `leastCost.ts`, `vogel.ts`) each
build an initial basic feasible solution their own way, topped up with ε-basic cells
(`fixDegeneracy` in `tableau.ts`) if degenerate. `modi.ts` then runs the u–v method to optimality:
compute dual values, find the most-negative opportunity cost, trace the unique closed loop via a
spanning-tree BFS, and pivot by θ, one step per phase.

**Assignment (Hungarian algorithm).** `standardize.ts` pads a rectangular cost matrix to square
with zero-cost dummy workers/tasks. `hungarian.ts` then: (1) subtracts each row's minimum, (2)
subtracts each column's minimum, and (3) repeatedly attempts an augmenting path (Kuhn's algorithm)
for every currently-unmatched worker through zero-cost cells — one step per attempt, success or
failure. Whenever a full pass leaves the matching short of a perfect assignment, it covers every
zero with the minimum number of lines via **König's theorem** (an alternating reachability search
from the free rows, over the existing matching), finds the smallest uncovered value, and adjusts
the matrix (subtract from uncovered cells, add back where two lines cross) before trying to augment
again. The existing partial matching is proven to survive every adjustment unchanged (matched
cells are always covered by exactly one line, never zero or two), so the algorithm never has to
restart the search from scratch.

**Network & Routing.** `graph.ts` builds an adjacency list and checks connectivity/validity shared
by all three algorithms. `dijkstra.ts` finalizes the closest unvisited node each iteration and
relaxes its outgoing edges one at a time (rejecting negative weights outright, since Dijkstra's
proof of correctness depends on them). `mst.ts` implements both **Kruskal** (sort every edge,
accept unless a union-find check shows it would close a cycle) and **Prim** (grow one tree,
always adding the cheapest edge crossing the current cut) — both reach the same minimum weight.
`maxflow.ts` runs **Edmonds-Karp**: repeatedly BFS for the shortest augmenting path in the
residual graph, push flow equal to the bottleneck, and stop when none remains, at which point it
also identifies the min cut (nodes still reachable from the source) to confirm optimality via the
max-flow/min-cut theorem.

**Traveling Salesman.** `nearestNeighbor.ts` is a straightforward greedy heuristic — always hop to
the closest unvisited city — explicitly flagged in its own output as not guaranteed optimal.
`branchAndBound.ts` is an exact **best-first Branch and Bound** search: each node's lower bound is
the cost so far plus, for every city not yet exited, that city's cheapest still-available
outgoing edge (an admissible bound, since no real tour can beat every city getting its single
cheapest option simultaneously). Nodes are popped best-bound-first from a priority frontier;
whenever a node's bound is no better than the best complete tour found so far, it's pruned without
being expanded. The tour returned once the frontier is exhausted is provably optimal, not just the
best one tried.

**CPM / PERT.** `standardize.ts` validates the activity list (names, predecessor references,
durations or a ≤ m ≤ b estimates) and topologically orders it with Kahn's algorithm, breaking ties
by the order the user listed activities so the same input always yields the same steps; if a cycle
blocks the order it names the loop (`A → B → C → A`). `cpm.ts` then emits one step per action: (in
PERT mode) the conversion of each estimate to an expected duration `(a + 4m + b) / 6` and a
variance `((b − a) / 6)²`; the network set-up; **one forward-pass step per activity**
(`ES = max EF of predecessors`, `EF = ES + d`, naming which predecessor sets the pace or that
several tie); the project duration; **one backward-pass step per activity** (`LF = min LS of
successors`, `LS = LF − d`); a slack step (`slack = LS − ES`, critical when ≤ tolerance); and one
step for each **critical path**. A critical path is a source→sink chain of zero-slack activities
in which every hand-off is *tight* (one activity's EF equals the next one's ES) — merely being
zero-slack isn't enough, because a critical activity can wait on a different predecessor than the
critical one before it. Every such path's durations add up to exactly the project duration (a
tested invariant). In PERT mode the project variance is the sum of activity variances along the
critical path; when several critical paths tie, the largest path variance is used (the cautious
choice) and this is called out in the explanation and the notes. The CPM engine uses plain
numbers, not `Fraction`: durations are integers or short decimals, and a tolerance of 1e-9 absorbs
float noise (so `0.1 + 0.2` ties with `0.3`).

**Integer Programming.** `standardize.ts` extends the LP problem with a `varTypes` array
(`integer`, `binary`, or `continuous` per variable). `branchAndBound.ts` reuses the exact
`Fraction`-based two-phase simplex engine unchanged to solve every relaxation, so an LP subproblem
and a top-level LP get identical treatment. It supports **depth-first** or **best-bound** node
selection and branches on the **lowest-index** or **most-fractional** fractional variable
(configurable); a node is pruned the moment its own LP bound can no longer beat the current
incumbent, and pruning is inherited down a branch without even solving the child's LP when the
parent's bound already can't win. Binary variables get an implicit `x ≤ 1` bound; an unbounded root
relaxation triggers a separate feasibility-only search (objective replaced by zero) so the app can
still report a witness point instead of just "unbounded". Every node — its bounds, branch, LP
result, and whether it was solved, pruned, or skipped — is a step, so the branch-and-bound tree in
the UI is the literal search, not a redrawn summary of it.

**Game Theory.** A game is two payoff matrices A (row player) and B (column player); zero-sum is
the case B = −A. `bestResponse.ts` marks every maximizer (ties included) down each column of A and
across each row of B; a cell marked by both is a pure equilibrium. `dominance.ts` removes
*strictly* dominated strategies in simultaneous rounds (never weakly dominated ones, which can lose
equilibria and make the result order-dependent). For mixed equilibria, `supportEnumeration.ts`
tries every pair of equal-size supports (I, J): the *indifference equations* — every supported row
earns the same payoff u against q, every supported column the same v against p, probabilities
summing to 1 — are solved as exact linear systems by `linalg.ts` (Gauss-Jordan over `Fraction`),
and a pair is an equilibrium only if the solution is strictly positive and no strategy outside the
support pays more. Equal sizes suffice for nondegenerate games, and `degeneracy.ts` checks that
premise exactly (shift payoffs positive, then look for a vertex of the best-response polytope with
more tight constraints than its dimension); a degenerate game gets a named witness and a caveat
that the list may not be complete. For zero-sum games `zeroSum.ts` reports maximin/minimax, then
builds Player 1's LP (minimize Σy subject to A′ᵀy ≥ 1 after shifting all payoffs positive) and its
dual for Player 2 as ordinary `LPProblem`s, solved by the same exact simplex engine as the Linear
Programming module; the two optima must match (LP duality), giving the value and both optimal
mixes. `verify.ts` independently re-checks every reported equilibrium against the Nash conditions
before it is shown.

**Matrix / Linear Equations.** Every algorithm shares one `Tableau` class (`common.ts`) whose three
mutators — `swapRows`, `scaleRow`, `eliminate` — are the only way any matrix entry ever changes, and
each one returns the `RowOp` it performed, so a step can't silently omit an operation.
`gaussianElimination.ts` splits reduction into a `forwardPhase` (leftmost-column, topmost-non-zero
pivoting, eliminating everything below each pivot) and a `backwardPhase` (scaling each pivot to 1
and clearing above it, i.e. Gauss-Jordan) that every other file composes: `linearSystem.ts` runs
both phases on `[A | b]` and classifies the result as a unique solution, a proven inconsistency (a
row reading `0 = c`), or infinitely many solutions (one particular solution plus a nullspace basis,
one vector per free variable); `inverse.ts` runs the same two phases on `[A | I]`, reporting A as
singular the moment forward elimination can't find n pivots, and otherwise verifying the result by
computing `A · A⁻¹` exactly; `rank.ts` runs them on A alone and reads the pivot/free columns
straight off the reduced form. `determinant.ts` expands along row 1 (`det(A) = Σⱼ a₁ⱼ·Cⱼ`),
building a renderable tree with closed forms for 1×1/2×2/3×3 at the top level and skipping zero
entries in sparser rows. `eigenvalues.ts` computes the exact characteristic polynomial via the
**Faddeev–LeVerrier recursion** (repeated multiplication by A and taking traces — far cheaper than
symbolically expanding `det(A − λI)`, and every coefficient stays an exact `Fraction`), then finds
its roots via the rational root theorem with deflation, the quadratic formula (exact whenever the
discriminant is a perfect square), and a numeric Durand-Kerner fallback for cubics/quartics with no
further rational roots; for each exact real eigenvalue it solves `(A − λI)v = 0` by the same
row-reduction machinery to get an exact eigenvector basis, honestly reporting when an eigenvalue is
irrational or complex (in which case no exact eigenvector is computed) and when an eigenspace's
geometric multiplicity falls short of the eigenvalue's algebraic multiplicity (a defective matrix).

**Queuing Models.** `mm1.ts` and `mmc.ts` solve M/M/1 and M/M/c respectively — Poisson arrivals,
exponential service, FCFS, unlimited queue capacity — entirely with `Fraction` arithmetic, since
every quantity (ρ, P0, Erlang C, Lq, L, Wq, W, the steady-state Pn) is a rational function of the
rational inputs λ, μ and the integer server count c. `erlang.ts` holds the shared building block,
the offered-load terms aⁿ/n!, used for P0, Erlang C (the standard M/M/c wait-probability formula)
and Erlang B (the blocking probability of the companion no-waiting-room loss system, reported
alongside Erlang C as a cross-check: B ≤ C always). Each step is one formula actually evaluated, in
derivation order, so the running metrics panel fills in exactly the way the underlying math was
worked out — an unstable system (ρ ≥ 1) stops right after the stability check, since no
steady-state distribution exists to compute. `waitTimeCurve.ts` separately derives the two models'
closed-form waiting-time CDFs (plain floating point, since it only drives an SVG curve, not a
reported metric) for the wait-time distribution chart.

All of the arithmetic inside every LP/Transportation/Assignment tableau uses `Fraction` (`utils/fraction.ts`), a small BigInt
numerator/denominator type, instead of native floating point — so optimality tests ("is this ≤
0?", "is this exactly zero?") are exact comparisons rather than `< 1e-9` fudges.

## Known limitations

- Matrix / Linear Equations caps matrices at 6×6 (cofactor expansion is factorial in the worst
  case, and every row operation is printed as a step) and eigenvalues at 4×4 (the characteristic
  polynomial's roots have no general closed form beyond degree 4). Complex or irrational eigenvalues
  are reported as decimal approximations rather than exact values, and no exact eigenvector is
  computed for them — only for eigenvalues that come out exactly rational. A repeated eigenvalue's
  eigenvectors are a valid basis of the eigenspace but are not run through Gram-Schmidt, so two
  basis vectors from the *same* eigenspace are not guaranteed orthogonal even for a symmetric
  matrix (vectors from *different* eigenvalues are). The Matrix page has been checked by `tsc`,
  `vitest` and `vite build` only — not yet driven in a browser.
- Game Theory handles two players with at most 6 strategies each (support enumeration is
  exponential: Σ C(m,k)·C(n,k) pairs). It covers normal-form games only — no extensive-form or
  repeated games, no correlated or trembling-hand equilibria, and dominance by *mixed* strategies is
  not considered (only pure dominators). In a degenerate game the equilibria can form a continuum;
  the app lists the isolated equal-support ones it finds and says the list may be incomplete. The
  Game Theory page has been checked by `tsc`, `vitest` and `vite build` only — not yet driven in a
  browser.
- Queuing Models covers only M/M/1 and M/M/c with infinite queue capacity and an infinite calling
  population — no finite-capacity (M/M/c/K), finite-population, or non-Markovian (M/G/1, general
  service-time) variants yet. The wait-time CDF chart uses the closed-form M/M/c *queue*-wait
  distribution; the exact system-time (W) CDF for c > 1 involves a further sum over server states
  and isn't charted.
- CPM / PERT models only finish-to-start precedence (no lags, leads, resource limits or calendar
  dates), and PERT's project variance assumes independent activities and looks only at the critical
  path — it can understate uncertainty when several paths are nearly as long. If a network has more
  than 100 critical paths (e.g. many equal parallel branches in series) only the first 100 are
  listed, and the app says so. There is no "probability of finishing by day X" calculator yet.
- The graphical LP method is 2-variable only, and its unbounded-direction test is a directional
  heuristic — correct for the textbook cases exercised in the test suite, not a formally exhaustive
  recession-cone search.
- LP sensitivity analysis reports shadow prices for ≤ constraints only and raw Cj − Zj reduced
  costs; it does not compute allowable coefficient/RHS ranges yet.
- Network & Routing and TSP visualizations use a simple deterministic layout (circular, or the
  example's given coordinates for TSP) rather than a force-directed graph library — no pan/zoom
  yet.
- Exact TSP Branch and Bound is a genuine exponential-worst-case search; it's fine for the small
  textbook instances built in, but the UI does not yet warn or offer cancellation for large
  instances a user might type in by hand.
- Save/load and printing are done (see "Saving, sharing and printing"), but there is still no "My Problems" library in local storage, no PWA/offline install, and no drag-and-drop import (use the Import… button). "Save as PDF" uses the browser's print dialog rather than generating a PDF file itself, so the layout is the browser's; on iOS Safari use Share → Print → pinch to save as PDF.
- UI has been verified via `tsc -b`, `vitest` (including `react-dom/server` smoke tests for every
  built-in example of every module), and a successful `vite build`. The CPM / PERT page was also
  driven end to end in headless Chromium (Playwright) at desktop and 390 px widths — solving,
  stepping, editing/renaming/cycle errors, CPM↔PERT switching, mobile layout. The earlier modules
  have not been re-clicked through in a browser in this environment — please sanity-check them
  after `npm run dev`.
